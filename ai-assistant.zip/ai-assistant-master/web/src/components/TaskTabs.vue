<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import Icon from './Icon.vue'
import {
  closeTab,
  closeTabsAll,
  closeTabsLeft,
  closeTabsOthers,
  closeTabsRight,
  openInTab,
  openNewTaskDialog,
  store,
} from '../stores/app'

const openSessions = computed(() =>
  store.openTabs
    .map((id) => store.sessions.find((s) => s.session_id === id))
    .filter(Boolean),
)

// ---- 右键菜单 ----
const menu = ref({ open: false, sessionId: '', x: 0, y: 0 })
const menuRef = ref(null)

function onContextMenu(e, sessionId) {
  e.preventDefault()
  const idx = store.openTabs.indexOf(sessionId)
  // 菜单靠右显示时向左偏移，避免超出视口
  const menuW = 170
  const menuH = 190
  const x = Math.min(e.clientX, window.innerWidth - menuW - 8)
  const y = Math.min(e.clientY, window.innerHeight - menuH - 8)
  menu.value = { open: true, sessionId, x: Math.max(8, x), y: Math.max(8, y), idx }
}

function closeMenu() {
  menu.value.open = false
}

function run(action) {
  const id = menu.value.sessionId
  closeMenu()
  if (action === 'current') closeTab(id)
  else if (action === 'left') closeTabsLeft(id)
  else if (action === 'right') closeTabsRight(id)
  else if (action === 'others') closeTabsOthers(id)
  else if (action === 'all') closeTabsAll()
}

function onDocPointerDown(e) {
  if (!menu.value.open) return
  if (menuRef.value && menuRef.value.contains(e.target)) return
  closeMenu()
}
function onKeydown(e) {
  if (e.key === 'Escape') closeMenu()
}

onMounted(() => {
  document.addEventListener('pointerdown', onDocPointerDown, true)
  document.addEventListener('keydown', onKeydown)
})
onUnmounted(() => {
  document.removeEventListener('pointerdown', onDocPointerDown, true)
  document.removeEventListener('keydown', onKeydown)
})

const menuIdx = computed(() => store.openTabs.indexOf(menu.value.sessionId))
const hasLeft = computed(() => menuIdx.value > 0)
const hasRight = computed(() => menuIdx.value >= 0 && menuIdx.value < store.openTabs.length - 1)
const hasOthers = computed(() => store.openTabs.length > 1)
const hasAny = computed(() => store.openTabs.length > 0)

function onWheel(e) {
  const el = e.currentTarget
  if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) el.scrollLeft += e.deltaY
}
</script>

<template>
  <div class="tabs" @wheel.passive="onWheel">
    <button
      v-for="s in openSessions"
      :key="s.session_id"
      class="tab"
      :class="{ active: s.session_id === store.activeId }"
      :title="s.title || '新任务'"
      @click="openInTab(s.session_id)"
      @click.middle="closeTab(s.session_id)"
      @contextmenu="onContextMenu($event, s.session_id)"
    >
      <span class="dot" :class="s.status || 'idle'"></span>
      <span class="tab-title ellipsis">{{ s.title || '新任务' }}</span>
      <span class="tab-close" title="关闭标签页" @click.stop="closeTab(s.session_id)">
        <Icon name="x" :size="12" />
      </span>
    </button>
    <button class="tab-new" title="新建任务 (Ctrl+T)" @click="openNewTaskDialog()">
      <Icon name="plus" :size="15" />
    </button>

    <!-- 右键菜单 -->
    <Teleport to="body">
      <Transition name="menu-pop">
        <div
          v-if="menu.open"
          ref="menuRef"
          class="ctx-menu"
          :style="{ left: menu.x + 'px', top: menu.y + 'px' }"
        >
          <button class="ctx-item" :disabled="!hasAny" @click="run('current')">
            <Icon name="x" :size="13" /> 关闭当前
          </button>
          <button class="ctx-item" :disabled="!hasLeft" @click="run('left')">
            <Icon name="chevron-left" :size="13" /> 关闭左边
          </button>
          <button class="ctx-item" :disabled="!hasRight" @click="run('right')">
            <Icon name="chevron-right" :size="13" /> 关闭右边
          </button>
          <button class="ctx-item" :disabled="!hasOthers" @click="run('others')">
            <Icon name="panel" :size="13" /> 关闭其他
          </button>
          <div class="ctx-sep"></div>
          <button class="ctx-item danger" :disabled="!hasAny" @click="run('all')">
            <Icon name="trash" :size="13" /> 关闭全部
          </button>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<style scoped>
.tabs {
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 4px;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
  padding: 8px 4px;
}
.tabs::-webkit-scrollbar { display: none; }

.tab {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 9px 0 11px;
  border-radius: var(--r-s);
  font-size: 12.5px;
  color: var(--text-2);
  white-space: nowrap;
  max-width: 190px;
  border: 1px solid transparent;
  transition: all 0.15s var(--ease);
  flex-shrink: 0;
}
.tab:hover { background: var(--surface-2); color: var(--text); }
.tab.active {
  background: var(--surface);
  border-color: var(--border);
  color: var(--text);
  font-weight: 600;
  box-shadow: var(--sh-xs);
}
.tab-title { max-width: 132px; }
.tab-close {
  width: 18px;
  height: 18px;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-3);
  opacity: 0;
  transition: all 0.12s var(--ease);
  flex-shrink: 0;
}
.tab:hover .tab-close, .tab.active .tab-close { opacity: 1; }
.tab-close:hover { background: var(--err-soft); color: var(--err); }

.tab-new {
  width: 30px;
  height: 30px;
  border-radius: var(--r-s);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-3);
  flex-shrink: 0;
  transition: all 0.14s var(--ease);
}
.tab-new:hover { background: var(--brand-soft); color: var(--brand); }
</style>

<!-- 右键菜单样式（Teleport 到 body，需非 scoped 或 :global） -->
<style>
.ctx-menu {
  position: fixed;
  z-index: 300;
  min-width: 160px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-m);
  box-shadow: var(--sh-l);
  padding: 5px;
  display: flex;
  flex-direction: column;
  gap: 1px;
}
.ctx-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  text-align: left;
  padding: 7px 10px;
  border-radius: var(--r-s);
  font-size: 12.5px;
  color: var(--text-2);
  transition: background 0.12s var(--ease), color 0.12s var(--ease);
}
.ctx-item:hover:not(:disabled) { background: var(--surface-2); color: var(--text); }
.ctx-item:disabled { opacity: 0.4; cursor: not-allowed; }
.ctx-item.danger { color: var(--err); }
.ctx-item.danger:hover:not(:disabled) { background: var(--err-soft); color: var(--err); }
.ctx-sep { height: 1px; background: var(--border); margin: 4px 6px; }

.menu-pop-enter-active { transition: all 0.14s var(--ease-out); }
.menu-pop-enter-from { opacity: 0; transform: scale(0.96) translateY(-2px); }
</style>
