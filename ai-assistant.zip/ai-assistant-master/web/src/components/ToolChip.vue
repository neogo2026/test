<script setup>
import { computed, ref } from 'vue'
import Icon from './Icon.vue'
import { toolIcon } from '../utils/format'

const props = defineProps({
  tool: { type: Object, required: true },
})

const open = ref(false)

const statusMap = {
  running: { label: '执行中', cls: 'run' },
  waiting: { label: '待审批', cls: 'warn' },
  done: { label: '完成', cls: 'ok' },
  failed: { label: '失败', cls: 'err' },
  denied: { label: '已拒绝', cls: 'err' },
}
const status = computed(() => statusMap[props.tool.status] || { label: props.tool.status, cls: '' })
const icon = computed(() => toolIcon(props.tool.name))
const argsText = computed(() => {
  try { return JSON.stringify(props.tool.arguments ?? {}, null, 2) } catch { return String(props.tool.arguments ?? '') }
})
</script>

<template>
  <div class="chip" :class="status.cls">
    <button class="chip-head" @click="open = !open">
      <span class="chip-icon"><Icon :name="icon" :size="13" /></span>
      <span class="chip-name mono">{{ tool.name }}</span>
      <span class="chip-status" :class="status.cls">
        <span v-if="tool.status === 'running'" class="mini-spin"></span>
        {{ status.label }}
      </span>
      <Icon name="chevron-down" :size="13" class="chevron" :class="{ open }" />
    </button>
    <div v-if="open" class="chip-body">
      <div class="mini-label">参数</div>
      <pre class="code-block">{{ argsText }}</pre>
      <template v-if="tool.summary">
        <div class="mini-label">结果</div>
        <pre class="code-block">{{ tool.summary }}</pre>
      </template>
      <div v-if="tool.error" class="chip-error">
        <Icon name="alert" :size="13" /> {{ tool.error }}
      </div>
    </div>
  </div>
</template>

<style scoped>
.chip {
  border: 1px solid var(--border);
  border-radius: var(--r-s);
  background: var(--surface);
  overflow: hidden;
  max-width: 620px;
  transition: border-color 0.15s var(--ease), box-shadow 0.15s var(--ease);
}
.chip:hover { box-shadow: var(--sh-xs); }
.chip.warn { border-color: color-mix(in srgb, var(--warn) 45%, transparent); }
.chip.err { border-color: color-mix(in srgb, var(--err) 40%, transparent); }
.chip.ok { border-color: var(--border); }

.chip-head {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  transition: background 0.12s var(--ease);
}
.chip-head:hover { background: var(--surface-2); }
.chip-icon {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: var(--surface-3);
  color: var(--text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.chip-name { font-size: 11.8px; font-weight: 600; color: var(--text); }
.chip-status {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10.5px;
  font-weight: 600;
  padding: 1.5px 8px;
  border-radius: var(--r-full);
  background: var(--surface-3);
  color: var(--text-3);
}
.chip-status.run { background: var(--run-soft); color: var(--run); }
.chip-status.warn { background: var(--warn-soft); color: var(--warn); }
.chip-status.ok { background: var(--ok-soft); color: var(--ok); }
.chip-status.err { background: var(--err-soft); color: var(--err); }
.mini-spin {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  border: 1.5px solid currentColor;
  border-top-color: transparent;
  animation: spin 0.8s linear infinite;
}
.chevron { color: var(--text-3); transition: transform 0.16s var(--ease); margin-left: 2px; }
.chevron.open { transform: rotate(180deg); }

.chip-body { padding: 4px 10px 10px; border-top: 1px solid var(--border); }
.mini-label {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.05em;
  color: var(--text-3);
  text-transform: uppercase;
  margin: 8px 0 4px;
}
.chip-body .code-block { max-height: 240px; margin: 0; }
.chip-error {
  display: flex;
  align-items: center;
  gap: 5px;
  color: var(--err);
  font-size: 12px;
  margin-top: 8px;
}
</style>
