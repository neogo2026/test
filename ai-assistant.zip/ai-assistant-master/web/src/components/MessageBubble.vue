<script setup>
import { computed } from 'vue'
import { renderMarkdown } from '../utils/markdown'
import Icon from './Icon.vue'
import ToolChip from './ToolChip.vue'

const props = defineProps({
  message: { type: Object, default: null },
  draft: { type: Object, default: null },
  tools: { type: Object, required: true },
  streaming: { type: Boolean, default: false },
})

const html = computed(() => renderMarkdown(props.message ? props.message.content : (props.draft?.text || '')))

const chips = computed(() => {
  if (!props.message?.tool_calls) return []
  return props.message.tool_calls.map((c) => ({
    call_id: c.call_id,
    ...(props.tools[c.call_id] || { name: c.name, arguments: c.arguments, status: 'done' }),
  }))
})

const isUser = computed(() => props.message?.role === 'user')
</script>

<template>
  <!-- 用户消息 -->
  <div v-if="isUser" class="msg user">
    <div class="bubble">{{ message.content }}</div>
  </div>

  <!-- 助手消息 -->
  <div v-else-if="message && message.role === 'assistant'" class="msg assistant">
    <div class="avatar"><Icon name="zap" :size="13" /></div>
    <div class="body">
      <div v-if="message.content" class="md" v-html="html"></div>
      <div v-if="chips.length" class="tools">
        <ToolChip v-for="chip in chips" :key="chip.call_id" :tool="chip" />
      </div>
    </div>
  </div>

  <!-- 流式草稿 -->
  <div v-else-if="draft" class="msg assistant">
    <div class="avatar"><Icon name="zap" :size="13" /></div>
    <div class="body">
      <div v-if="draft.text" class="md" v-html="html"></div>
      <span v-if="draft.text" class="cursor"></span>
      <div v-else-if="streaming" class="thinking">
        <span class="think-dot"></span><span class="think-dot"></span><span class="think-dot"></span>
        <span class="think-label">思考中</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.msg { display: flex; margin: 16px 0; animation: msg-in 0.26s var(--ease-out); }
@keyframes msg-in {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: none; }
}

/* 用户 */
.msg.user { justify-content: flex-end; padding-left: 48px; }
.bubble {
  max-width: 100%;
  background: var(--brand-soft);
  border: 1px solid var(--brand-soft-2);
  color: var(--text);
  padding: 10px 15px;
  border-radius: 16px 16px 5px 16px;
  font-size: 13.8px;
  line-height: 1.65;
  white-space: pre-wrap;
  word-break: break-word;
}

/* 助手 */
.msg.assistant { align-items: flex-start; gap: 12px; padding-right: 16px; }
.avatar {
  width: 28px;
  height: 28px;
  border-radius: 9px;
  background: var(--brand-grad);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--sh-brand);
  flex-shrink: 0;
  margin-top: 1px;
}
.body { flex: 1; min-width: 0; }

.md { font-size: 13.9px; line-height: 1.75; word-break: break-word; }
.md :deep(p) { margin: 0.45em 0; }
.md :deep(h1), .md :deep(h2), .md :deep(h3), .md :deep(h4) {
  margin: 1em 0 0.45em;
  font-weight: 700;
  letter-spacing: -0.01em;
  line-height: 1.45;
}
.md :deep(h1) { font-size: 1.32em; }
.md :deep(h2) { font-size: 1.18em; }
.md :deep(h3) { font-size: 1.07em; }
.md :deep(ul), .md :deep(ol) { padding-left: 1.5em; margin: 0.45em 0; }
.md :deep(li) { margin: 0.25em 0; }
.md :deep(li::marker) { color: var(--text-3); }
.md :deep(code) {
  font-family: var(--mono);
  font-size: 0.87em;
  background: var(--bg-sub);
  border: 1px solid var(--border);
  padding: 1.5px 5px;
  border-radius: 5px;
}
.md :deep(pre) {
  background: var(--bg-sub);
  border: 1px solid var(--border);
  border-radius: var(--r-s);
  padding: 12px 14px;
  overflow-x: auto;
  margin: 0.7em 0;
}
.md :deep(pre code) { background: none; border: none; padding: 0; font-size: 12.3px; line-height: 1.65; }
.md :deep(table) { border-collapse: collapse; margin: 0.7em 0; font-size: 12.8px; }
.md :deep(th), .md :deep(td) { border: 1px solid var(--border); padding: 6px 12px; text-align: left; }
.md :deep(th) { background: var(--surface-2); font-weight: 600; }
.md :deep(blockquote) {
  margin: 0.7em 0;
  padding: 6px 14px;
  border-left: 3px solid var(--brand);
  background: var(--surface-2);
  border-radius: 0 var(--r-s) var(--r-s) 0;
  color: var(--text-2);
}
.md :deep(hr) { border: none; border-top: 1px solid var(--border); margin: 1em 0; }
.md :deep(a) { font-weight: 500; }

.cursor {
  display: inline-block;
  width: 7px;
  height: 15px;
  background: var(--brand);
  border-radius: 2px;
  margin-left: 2px;
  vertical-align: text-bottom;
  animation: blink 1s steps(2) infinite;
}
@keyframes blink { 50% { opacity: 0; } }

.tools { display: flex; flex-direction: column; gap: 7px; margin-top: 8px; }

.thinking { display: flex; align-items: center; gap: 5px; padding: 6px 0; }
.think-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--brand);
  opacity: 0.5;
  animation: bounce 1.15s var(--ease) infinite;
}
.think-dot:nth-child(2) { animation-delay: 0.14s; }
.think-dot:nth-child(3) { animation-delay: 0.28s; }
@keyframes bounce {
  0%, 100% { transform: translateY(0); opacity: 0.4; }
  45% { transform: translateY(-4px); opacity: 1; }
}
.think-label { font-size: 12px; color: var(--text-3); margin-left: 4px; }
</style>
