<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import api from '../api/client'
import Icon from './Icon.vue'
import { loadSessions, store, toast } from '../stores/app'

const props = defineProps({
  sessionId: { type: String, required: true },
})
const emit = defineEmits(['send'])

const text = ref('')
const textarea = ref(null)
const modelOpen = ref(false)
const gateOpen = ref(false)
const focused = ref(false)

const session = computed(() => store.sessions.find((s) => s.session_id === props.sessionId))
const profiles = computed(() => store.models.profiles || [])
const currentModel = computed(() => {
  const name = session.value?.model_profile
  return profiles.value.find((p) => p.name === name)?.name || name || store.models.default || ''
})
const effectiveModel = computed(() => session.value?.model_profile || store.models.default)

function autoGrow() {
  const el = textarea.value
  if (!el) return
  el.style.height = 'auto'
  el.style.height = Math.min(el.scrollHeight, 200) + 'px'
}

function send() {
  const value = text.value.trim()
  if (!value) return
  text.value = ''
  autoGrow()
  emit('send', value)
}

function onKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault()
    send()
  }
}

function focusComposer() {
  textarea.value?.focus()
}
onMounted(() => window.addEventListener('forge-focus-composer', focusComposer))
onUnmounted(() => window.removeEventListener('forge-focus-composer', focusComposer))

async function setModel(name) {
  await api.patch(`/api/sessions/${props.sessionId}`, { model_profile: name })
  await loadSessions()
  modelOpen.value = false
  toast(`模型已切换：${name}`, 'ok')
}

async function setGate(mode) {
  await api.patch(`/api/sessions/${props.sessionId}`, { gate_mode: mode })
  await loadSessions()
  gateOpen.value = false
  toast(`门禁已切换：${mode === 'allow_all' ? '自动批准' : '审批确认'}`, 'ok')
}
</script>

<template>
  <div class="dock">
    <div class="composer" :class="{ focused }">
      <textarea
        ref="textarea"
        v-model="text"
        class="input"
        rows="1"
        placeholder="描述你的任务，AI 工程师将开始工作…"
        @keydown="onKeydown"
        @input="autoGrow"
        @focus="focused = true"
        @blur="focused = false"
      ></textarea>

      <div class="bar">
        <div class="left">
          <!-- 模型 -->
          <div class="picker">
            <button class="pill" :class="{ on: modelOpen }" @click="modelOpen = !modelOpen; gateOpen = false">
              <Icon name="sparkles" :size="13" />
              <span class="pill-text">{{ currentModel }}</span>
              <Icon name="chevron-down" :size="11" />
            </button>
            <Transition name="menu">
              <div v-if="modelOpen" class="menu" @mouseleave="modelOpen = false">
                <div class="menu-label">选择模型</div>
                <button
                  v-for="p in profiles"
                  :key="p.name"
                  class="menu-item"
                  :class="{ on: effectiveModel === p.name }"
                  @click="setModel(p.name)"
                >
                  <div class="mi-row">
                    <span class="mi-name mono">{{ p.name }}</span>
                    <span v-if="p.provider === 'local'" class="badge local">本地</span>
                    <span v-if="p.name === store.models.default" class="badge brand">默认</span>
                    <Icon v-if="effectiveModel === p.name" name="check" :size="13" class="mi-check" />
                  </div>
                  <div class="mi-sub">
                    {{ p.model }} · {{ Math.round(p.context_window / 1000) }}K 上下文
                    <span v-if="p.provider === 'local' && !p.rsi_model_loaded"> · 模型未加载，首次推理自动加载</span>
                  </div>
                </button>
              </div>
            </Transition>
          </div>

          <!-- 门禁 -->
          <div class="picker">
            <button class="pill" :class="{ on: gateOpen }" @click="gateOpen = !gateOpen; modelOpen = false">
              <Icon name="shield" :size="13" />
              <span class="pill-text">{{ session?.gate_mode === 'allow_all' ? '自动批准' : '审批确认' }}</span>
              <Icon name="chevron-down" :size="11" />
            </button>
            <Transition name="menu">
              <div v-if="gateOpen" class="menu" @mouseleave="gateOpen = false">
                <div class="menu-label">操作门禁</div>
                <button class="menu-item" :class="{ on: session?.gate_mode !== 'allow_all' }" @click="setGate('ask')">
                  <div class="mi-row">
                    <span class="mi-name">审批确认</span>
                    <Icon v-if="session?.gate_mode !== 'allow_all'" name="check" :size="13" class="mi-check" />
                  </div>
                  <div class="mi-sub">高风险写操作与命令逐条人工批准（推荐）</div>
                </button>
                <button class="menu-item" :class="{ on: session?.gate_mode === 'allow_all' }" @click="setGate('allow_all')">
                  <div class="mi-row">
                    <span class="mi-name">自动批准</span>
                    <Icon v-if="session?.gate_mode === 'allow_all'" name="check" :size="13" class="mi-check" />
                  </div>
                  <div class="mi-sub">信任任务全自动执行，不打断</div>
                </button>
              </div>
            </Transition>
          </div>
        </div>

        <div class="right">
          <span class="hint">Enter 发送 · Shift+Enter 换行</span>
          <button class="send" :disabled="!text.trim()" title="发送" @click="send">
            <Icon name="arrow-up" :size="17" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dock {
  padding: 8px 20px 16px;
  flex-shrink: 0;
  background: linear-gradient(to top, var(--bg) 55%, transparent);
}
.composer {
  max-width: 860px;
  margin: 0 auto;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-l);
  box-shadow: var(--sh-m);
  padding: 12px 14px 10px;
  transition: border-color 0.16s var(--ease), box-shadow 0.16s var(--ease);
}
.composer.focused {
  border-color: color-mix(in srgb, var(--brand) 55%, transparent);
  box-shadow: 0 0 0 3.5px var(--brand-soft), var(--sh-m);
}
.input {
  width: 100%;
  border: none;
  background: none;
  box-shadow: none !important;
  resize: none;
  font-size: 14px;
  line-height: 1.65;
  max-height: 200px;
  padding: 2px 2px 6px;
}
.input:focus { border: none; }

.bar { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.left { display: flex; gap: 6px; position: relative; }
.picker { position: relative; }
.pill {
  display: flex;
  align-items: center;
  gap: 5px;
  height: 27px;
  padding: 0 9px;
  border-radius: var(--r-full);
  border: 1px solid var(--border);
  background: var(--surface-2);
  color: var(--text-2);
  font-size: 11.5px;
  font-weight: 500;
  transition: all 0.14s var(--ease);
}
.pill:hover { border-color: var(--border-2); color: var(--text); }
.pill.on { border-color: var(--brand); color: var(--brand); background: var(--brand-soft); }
.pill-text { max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.menu {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 0;
  min-width: 248px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-m);
  box-shadow: var(--sh-l);
  padding: 6px;
  z-index: 30;
}
.menu-label {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--text-3);
  padding: 5px 9px 3px;
}
.menu-item {
  display: block;
  width: 100%;
  text-align: left;
  padding: 8px 9px;
  border-radius: var(--r-s);
  transition: background 0.12s var(--ease);
}
.menu-item:hover { background: var(--surface-2); }
.menu-item.on { background: var(--brand-soft); }
.mi-row { display: flex; align-items: center; gap: 7px; }
.mi-name { font-size: 12.5px; font-weight: 600; color: var(--text); }
.mi-check { margin-left: auto; color: var(--brand); }
.mi-sub { font-size: 11px; color: var(--text-3); margin-top: 2px; line-height: 1.5; }
.badge.local {
  font-size: 9.5px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: var(--r-full);
  background: var(--ok-soft, #ecfdf5);
  color: var(--ok, #047857);
  line-height: 1.4;
}

.right { display: flex; align-items: center; gap: 10px; }
.hint { font-size: 10.5px; color: var(--text-3); }
.send {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: var(--brand-grad);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--sh-brand);
  transition: all 0.16s var(--ease);
  flex-shrink: 0;
}
.send:hover:not(:disabled) { transform: translateY(-1px) scale(1.03); box-shadow: 0 6px 20px rgba(91, 91, 214, 0.45); }
.send:active:not(:disabled) { transform: scale(0.96); }
.send:disabled { background: var(--surface-3); color: var(--text-3); box-shadow: none; }

.menu-enter-active { transition: all 0.16s var(--ease-out); }
.menu-enter-from { opacity: 0; transform: translateY(5px) scale(0.98); }

@media (max-width: 640px) { .hint { display: none; } }
</style>
