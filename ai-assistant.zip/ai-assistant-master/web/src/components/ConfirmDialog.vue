<script setup>
import Icon from './Icon.vue'

defineProps({
  open: { type: Boolean, default: false },
  title: { type: String, default: '确认操作' },
  message: { type: String, default: '' },
  confirmText: { type: String, default: '确定' },
  danger: { type: Boolean, default: false },
})
const emit = defineEmits(['confirm', 'cancel'])
</script>

<template>
  <Teleport to="body">
    <Transition name="fade">
      <div v-if="open" class="overlay" @click.self="emit('cancel')">
        <Transition name="pop" appear>
          <div class="dialog">
            <div class="dlg-icon" :class="{ danger }">
              <Icon :name="danger ? 'alert' : 'info'" :size="22" />
            </div>
            <div class="dlg-title">{{ title }}</div>
            <div class="dlg-msg">{{ message }}</div>
            <div class="dlg-actions">
              <button class="btn btn-ghost" @click="emit('cancel')">取消</button>
              <button class="btn" :class="danger ? 'btn-danger' : 'btn-primary'" @click="emit('confirm')">
                {{ confirmText }}
              </button>
            </div>
          </div>
        </Transition>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(10, 12, 18, 0.42);
  backdrop-filter: blur(3px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
}
.dialog {
  width: 360px;
  max-width: calc(100vw - 40px);
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-l);
  box-shadow: var(--sh-l);
  padding: 24px 24px 20px;
  text-align: center;
}
.dlg-icon {
  width: 44px;
  height: 44px;
  margin: 0 auto 12px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--brand-soft);
  color: var(--brand);
}
.dlg-icon.danger { background: var(--err-soft); color: var(--err); }
.dlg-title { font-size: 15.5px; font-weight: 700; letter-spacing: -0.01em; }
.dlg-msg { font-size: 13px; color: var(--text-2); line-height: 1.7; margin-top: 7px; word-break: break-word; }
.dlg-actions { display: flex; gap: 10px; justify-content: center; margin-top: 20px; }
.dlg-actions .btn { min-width: 92px; }

.pop-enter-active { transition: all 0.2s var(--ease-out); }
.pop-enter-from { opacity: 0; transform: scale(0.94) translateY(10px); }
</style>
