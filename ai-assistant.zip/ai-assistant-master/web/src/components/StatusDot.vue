<script setup>
defineProps({
  status: { type: String, default: 'idle' },
})
</script>

<template>
  <span class="dot" :class="status"></span>
</template>
