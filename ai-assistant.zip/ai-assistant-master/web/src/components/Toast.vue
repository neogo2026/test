<script setup>
import { store } from '../stores/app'
import Icon from './Icon.vue'

const iconOf = { ok: 'check', warn: 'alert', err: 'alert', info: 'info' }
</script>

<template>
  <Teleport to="body">
    <div class="toasts">
      <TransitionGroup name="toast">
        <div v-for="t in store.toasts" :key="t.id" class="toast" :class="t.type">
          <span class="t-icon"><Icon :name="iconOf[t.type] || 'info'" :size="14" /></span>
          <span class="t-msg">{{ t.message }}</span>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<style scoped>
.toasts {
  position: fixed;
  bottom: 26px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  z-index: 300;
  pointer-events: none;
}
.toast {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 36px;
  padding: 0 16px;
  border-radius: var(--r-full);
  background: var(--text);
  color: var(--bg);
  font-size: 12.5px;
  font-weight: 500;
  box-shadow: var(--sh-l);
  border: 1px solid transparent;
}
.toast.ok .t-icon { color: var(--ok); }
.toast.warn .t-icon { color: var(--warn); }
.toast.err .t-icon { color: var(--err); }
.toast.info .t-icon { color: var(--brand-2); }
.t-icon { display: flex; }
.t-msg { max-width: 60vw; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.toast-enter-active, .toast-leave-active { transition: all 0.22s var(--ease-out); }
.toast-enter-from { opacity: 0; transform: translateY(10px) scale(0.96); }
.toast-leave-to { opacity: 0; transform: translateY(6px) scale(0.97); }
</style>
