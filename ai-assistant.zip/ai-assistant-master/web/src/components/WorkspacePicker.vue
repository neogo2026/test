<script setup>
import { computed, ref, watch } from 'vue'
import api from '../api/client'
import Icon from './Icon.vue'
import { setWorkspace, store, toast } from '../stores/app'

const props = defineProps({
  open: { type: Boolean, default: false },
  required: { type: Boolean, default: false },
})
const emit = defineEmits(['close'])

const loading = ref(false)
const error = ref('')
const path = ref('')
const parent = ref(null)
const entries = ref([])
const roots = ref([])
const manual = ref('')
const mkdirName = ref('')
const showMkdir = ref(false)
const picked = ref('')

const title = computed(() => (props.required ? '选择工作空间' : '切换工作空间'))
const subtitle = computed(() =>
  props.required
    ? '首次使用需先选择工作空间 —— AI 将在该目录内读写文件、执行命令。'
    : '切换后，后续对话将在新目录中执行；选择会被记住。',
)

async function load(target) {
  loading.value = true
  error.value = ''
  try {
    const data = await api.get(`/api/fs/list?path=${encodeURIComponent(target || '')}`)
    path.value = data.path || ''
    parent.value = data.parent
    entries.value = data.entries || []
    roots.value = data.roots || []
    manual.value = data.path || ''
    picked.value = data.path || ''
  } catch (e) {
    error.value = e.message || '读取失败'
  } finally {
    loading.value = false
  }
}

function enter(dir) {
  load(dir.path)
}

function goUp() {
  if (parent.value) load(parent.value)
}

function goManual() {
  const target = manual.value.trim()
  if (target) load(target)
}

async function createDir() {
  const name = mkdirName.value.trim()
  if (!name || !path.value) return
  try {
    const data = await api.post('/api/fs/mkdir', { path: path.value, name })
    mkdirName.value = ''
    showMkdir.value = false
    await load(data.path)
    toast('文件夹已创建', 'ok')
  } catch (e) {
    error.value = e.message
  }
}

async function confirm() {
  if (!picked.value) {
    error.value = '请进入一个目录后再确认'
    return
  }
  try {
    await setWorkspace(picked.value)
    emit('close')
  } catch (e) {
    error.value = e.message
  }
}

watch(
  () => props.open,
  (open) => {
    if (open) {
      showMkdir.value = false
      mkdirName.value = ''
      load(store.workspaceSaved ? store.workspace : '')
    }
  },
  { immediate: true },
)
</script>

<template>
  <Teleport to="body">
    <Transition name="fade">
      <div v-if="open" class="overlay" @click.self="required ? null : emit('close')">
        <div class="dialog">
          <div class="head">
            <div class="icon"><Icon name="folder" :size="18" /></div>
            <div class="head-text">
              <div class="title">{{ title }}</div>
              <div class="sub">{{ subtitle }}</div>
            </div>
            <button v-if="!required" class="close" title="关闭" @click="emit('close')">
              <Icon name="x" :size="16" />
            </button>
          </div>

          <div class="toolbar">
            <button class="btn btn-ghost sm" :disabled="!parent" @click="goUp">
              <Icon name="chevron-left" :size="14" /> 上级
            </button>
            <input
              v-model="manual"
              class="path-input mono"
              placeholder="输入绝对路径，如 D:\projects\demo"
              @keydown.enter="goManual"
            />
            <button class="btn btn-ghost sm" @click="goManual">前往</button>
            <button class="btn btn-ghost sm" :disabled="!path" @click="showMkdir = !showMkdir">
              <Icon name="plus" :size="14" /> 新建
            </button>
          </div>

          <div v-if="showMkdir" class="mkdir">
            <input v-model="mkdirName" placeholder="新文件夹名称" @keydown.enter="createDir" />
            <button class="btn btn-soft sm" @click="createDir">创建</button>
          </div>

          <div class="list">
            <div v-if="loading" class="hint">读取中…</div>
            <template v-else>
              <div v-if="!path" class="roots">
                <button v-for="r in roots" :key="r.path" class="root" @click="enter(r)">
                  <Icon name="folder" :size="16" />
                  <span class="ellipsis">{{ r.name }}</span>
                </button>
              </div>
              <template v-else>
                <button v-for="e in entries" :key="e.path" class="entry" @click="enter(e)">
                  <Icon name="folder" :size="15" />
                  <span class="ellipsis">{{ e.name }}</span>
                  <Icon name="chevron-right" :size="14" class="chev" />
                </button>
                <div v-if="!entries.length" class="hint">此目录下没有子文件夹</div>
              </template>
            </template>
          </div>

          <div v-if="error" class="error">{{ error }}</div>

          <div class="foot">
            <div class="picked">
              <span class="picked-label">将使用：</span>
              <span class="picked-path mono ellipsis" :title="picked">{{ picked || '（未选择）' }}</span>
            </div>
            <div class="actions">
              <button v-if="!required" class="btn btn-ghost" @click="emit('close')">取消</button>
              <button class="btn btn-primary" :disabled="!picked" @click="confirm">
                <Icon name="check" :size="15" /> 使用此工作空间
              </button>
            </div>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(10, 12, 18, 0.45);
  backdrop-filter: blur(3px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 250;
  padding: 20px;
}
.dialog {
  width: 760px;
  max-width: 94vw;
  height: 600px;
  max-height: 90vh;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-l);
  box-shadow: var(--sh-l);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.head { display: flex; align-items: flex-start; gap: 12px; padding: 18px 20px 12px; }
.icon {
  width: 36px; height: 36px; border-radius: 11px;
  background: var(--brand-soft); color: var(--brand);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.head-text { flex: 1; min-width: 0; }
.title { font-size: 15px; font-weight: 700; }
.sub { font-size: 12px; color: var(--text-3); margin-top: 3px; line-height: 1.6; }
.close { color: var(--text-3); width: 28px; height: 28px; border-radius: 7px; display: flex; align-items: center; justify-content: center; }
.close:hover { background: var(--surface-3); color: var(--text); }

.toolbar { display: flex; gap: 8px; padding: 0 20px 10px; align-items: center; }
.toolbar .btn.sm { height: 30px; padding: 0 10px; font-size: 12px; }
.path-input { flex: 1; height: 32px; padding: 0 10px; font-size: 12px; }
.mkdir { display: flex; gap: 8px; padding: 0 20px 10px; }
.mkdir input { flex: 1; height: 32px; padding: 0 10px; font-size: 12.5px; }

.list {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  margin: 0 20px;
  border: 1px solid var(--border);
  border-radius: var(--r-m);
  padding: 6px;
  background: var(--surface-2);
}
.hint { padding: 30px; text-align: center; color: var(--text-3); font-size: 12.5px; }
.roots { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; padding: 4px; }
.root {
  display: flex; align-items: center; gap: 8px;
  padding: 12px; border-radius: var(--r-s);
  background: var(--surface); border: 1px solid var(--border);
  font-size: 12.5px; color: var(--text); text-align: left;
  transition: all 0.14s var(--ease);
}
.root:hover { border-color: var(--brand); background: var(--brand-soft); }
.entry {
  width: 100%; display: flex; align-items: center; gap: 9px;
  padding: 8px 10px; border-radius: var(--r-s);
  font-size: 12.8px; color: var(--text); text-align: left;
  transition: background 0.12s var(--ease);
}
.entry:hover { background: var(--surface); box-shadow: var(--sh-xs); }
.entry .chev { margin-left: auto; color: var(--text-3); }

.error { margin: 8px 20px 0; font-size: 12px; color: var(--err); }

.foot {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 20px; border-top: 1px solid var(--border); margin-top: 12px;
}
.picked { flex: 1; min-width: 0; display: flex; align-items: baseline; gap: 6px; }
.picked-label { font-size: 11.5px; color: var(--text-3); flex-shrink: 0; }
.picked-path { font-size: 12px; color: var(--text-2); }
.actions { display: flex; gap: 8px; flex-shrink: 0; }

.fade-enter-active, .fade-leave-active { transition: opacity 0.18s var(--ease); }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
