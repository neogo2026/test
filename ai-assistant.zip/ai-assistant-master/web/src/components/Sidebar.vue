<script setup>
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Icon from './Icon.vue'
import ConfirmDialog from './ConfirmDialog.vue'
import {
  deleteAllSessions,
  deleteSession,
  openInTab,
  openNewTaskDialog,
  setTheme,
  store,
  toggleSidebar,
} from '../stores/app'
import { timeAgo } from '../utils/format'
import { openWorkspacePicker } from '../stores/app'

const route = useRoute()
const router = useRouter()
const query = ref('')
const confirm = ref({ open: false, title: '', message: '', confirmText: '删除', action: null })

const collapsed = computed(() => store.sidebarCollapsed)
const workspaceName = computed(() => {
  if (!store.workspaceSaved) return '选择工作空间'
  const p = store.workspace || ''
  const parts = p.split(/[\\/]/).filter(Boolean)
  return parts[parts.length - 1] || p
})

const navItems = [
  { path: '/', label: '工作台', icon: 'panel' },
  { path: '/skills', label: '技能', icon: 'sparkles' },
  { path: '/usage', label: '用量', icon: 'chart' },
  { path: '/settings', label: '设置', icon: 'sliders' },
]

const filtered = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!q) return store.sessions
  return store.sessions.filter((s) => (s.title || '新任务').toLowerCase().includes(q))
})

function goNew() {
  if (route.path !== '/') router.push('/')
  openNewTaskDialog()
}

function onOpen(sessionId) {
  if (route.path !== '/') router.push('/')
  openInTab(sessionId)
}

function toggleTheme() {
  setTheme(store.theme === 'light' ? 'dark' : 'light')
}

function askDelete(s) {
  confirm.value = {
    open: true,
    title: '删除对话',
    message: `确定删除「${s.title || '新任务'}」吗？删除后不可恢复。`,
    confirmText: '删除',
    action: () => deleteSession(s.session_id),
  }
}

function askDeleteAll() {
  const n = store.sessions.length
  if (!n) return
  confirm.value = {
    open: true,
    title: '全部删除',
    message: `确定删除全部 ${n} 个历史对话吗？删除后不可恢复。`,
    confirmText: '全部删除',
    action: () => deleteAllSessions(),
  }
}

async function onConfirm() {
  const action = confirm.value.action
  confirm.value.open = false
  if (action) await action()
}
</script>

<template>
  <aside class="sidebar" :class="{ collapsed }">
    <!-- 品牌 -->
    <div class="brand">
      <div class="brand-mark"><Icon name="zap" :size="18" /></div>
      <div v-if="!collapsed" class="brand-text">
        <span class="brand-name">AI助理</span>
        <span class="brand-sub">AI 编程工作台</span>
      </div>
      <button
        v-if="!collapsed"
        class="icon-btn collapse-btn"
        title="收起侧栏 (Ctrl+B)"
        @click="toggleSidebar()"
      >
        <Icon name="chevron-left" :size="16" />
      </button>
    </div>

    <!-- 折叠态：展开按钮 -->
    <button
      v-if="collapsed"
      class="rail-expand"
      title="展开侧栏 (Ctrl+B)"
      @click="toggleSidebar()"
    >
      <Icon name="chevron-right" :size="16" />
      <span v-if="store.sessions.length" class="rail-badge">{{ store.sessions.length }}</span>
    </button>

    <!-- 新建任务 -->
    <button class="new-task" :class="{ mini: collapsed }" :title="collapsed ? '新建任务 (Ctrl+T)' : ''" @click="goNew">
      <Icon name="plus" :size="16" />
      <span v-if="!collapsed">新建任务</span>
      <kbd v-if="!collapsed">Ctrl T</kbd>
    </button>

    <!-- 导航 -->
    <nav class="nav">
      <router-link
        v-for="item in navItems"
        :key="item.path"
        :to="item.path"
        class="nav-item"
        :class="{ active: route.path === item.path }"
        :title="collapsed ? item.label : ''"
      >
        <Icon :name="item.icon" :size="17" />
        <span v-if="!collapsed" class="nav-label">{{ item.label }}</span>
      </router-link>
    </nav>

    <!-- 工作空间 -->
    <button v-if="!collapsed" class="ws-chip" :class="{ unset: !store.workspaceSaved }" :title="store.workspace || '选择工作空间'" @click="openWorkspacePicker()">
      <Icon name="folder" :size="14" />
      <span class="ws-name ellipsis">{{ workspaceName }}</span>
      <Icon name="chevron-down" :size="12" class="ws-chev" />
    </button>
    <button v-else class="icon-btn ws-rail" :title="store.workspace || '选择工作空间'" @click="openWorkspacePicker()">
      <Icon name="folder" :size="17" />
    </button>

    <!-- 历史对话 -->
    <template v-if="!collapsed">
      <div class="hist-head">
        <span class="hist-title">历史对话</span>
        <span class="hist-count">{{ store.sessions.length }}</span>
      </div>
      <div class="hist-search">
        <Icon name="search" :size="14" />
        <input v-model="query" placeholder="搜索对话…" />
        <button v-if="query" class="clear" @click="query = ''"><Icon name="x" :size="12" /></button>
      </div>
      <div class="hist-list">
        <button
          v-for="s in filtered"
          :key="s.session_id"
          class="hist-item"
          :class="{ on: s.session_id === store.activeId }"
          @click="onOpen(s.session_id)"
        >
          <span class="dot" :class="s.status || 'idle'"></span>
          <span class="hist-main">
            <span class="hist-name ellipsis">{{ s.title || '新任务' }}</span>
            <span class="hist-time">{{ timeAgo(s.updated_at) }}</span>
          </span>
          <span class="hist-del" title="删除" @click.stop="askDelete(s)">
            <Icon name="trash" :size="13" />
          </span>
        </button>
        <div v-if="!filtered.length" class="hist-empty">
          {{ query ? '没有匹配的对话' : '暂无历史对话' }}
        </div>
      </div>
      <div class="hist-foot">
        <button class="del-all" :disabled="!store.sessions.length" @click="askDeleteAll">
          <Icon name="trash" :size="13" />
          <span>全部删除</span>
          <span v-if="store.sessions.length" class="del-count">{{ store.sessions.length }}</span>
        </button>
      </div>
    </template>

    <!-- 折叠态：底部状态 -->
    <template v-if="collapsed">
      <div class="spacer"></div>
    </template>

    <!-- 底部状态 -->
    <div class="sb-footer" :class="{ mini: collapsed }">
      <button class="icon-btn" :title="store.theme === 'light' ? '切换深色' : '切换浅色'" @click="toggleTheme">
        <Icon :name="store.theme === 'light' ? 'moon' : 'sun'" :size="16" />
      </button>
      <div class="conn" :class="store.wsOk ? 'on' : 'off'" :title="store.wsOk ? '服务已连接' : '连接中…'">
        <span class="conn-dot"></span>
        <span v-if="!collapsed" class="conn-text">{{ store.wsOk ? '已连接' : '连接中' }}</span>
      </div>
    </div>

    <ConfirmDialog
      :open="confirm.open"
      :title="confirm.title"
      :message="confirm.message"
      :confirm-text="confirm.confirmText"
      :danger="true"
      @confirm="onConfirm"
      @cancel="confirm.open = false"
    />
  </aside>
</template>

<style scoped>
.sidebar {
  width: var(--sidebar-w);
  flex-shrink: 0;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  min-height: 0;
  transition: width 0.24s var(--ease-out);
  overflow: hidden;
}
.sidebar.collapsed { width: var(--rail-w); }

/* 品牌 */
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 14px 10px;
  flex-shrink: 0;
}
.brand-mark {
  width: 32px;
  height: 32px;
  border-radius: 10px;
  background: var(--brand-grad);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--sh-brand);
  flex-shrink: 0;
}
.brand-text { display: flex; flex-direction: column; line-height: 1.2; min-width: 0; flex: 1; }
.brand-name { font-size: 14.5px; font-weight: 700; letter-spacing: -0.02em; }
.brand-sub { font-size: 10.5px; color: var(--text-3); margin-top: 1px; }
.collapse-btn { margin-left: auto; }
.sidebar.collapsed .brand {
  flex-direction: column;
  padding: 12px 0 4px;
  gap: 4px;
}

/* 新建任务 */
.new-task {
  margin: 4px 12px 8px;
  height: 38px;
  border-radius: var(--r-m);
  background: var(--brand-grad);
  color: var(--text-on-brand);
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  font-size: 13px;
  font-weight: 600;
  box-shadow: var(--sh-brand);
  transition: all 0.16s var(--ease);
  flex-shrink: 0;
}
.new-task:hover { filter: brightness(1.06); transform: translateY(-1px); }
.new-task:active { transform: scale(0.985); }
.new-task kbd {
  margin-left: auto;
  font-family: var(--font);
  font-size: 10px;
  font-weight: 500;
  padding: 2px 5px;
  border-radius: 5px;
  background: rgba(255, 255, 255, 0.2);
  color: rgba(255, 255, 255, 0.9);
}
.new-task.mini {
  margin: 4px auto 8px;
  width: 38px;
  height: 38px;
  padding: 0;
  justify-content: center;
}

/* 导航 */
.nav {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 2px 10px 8px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 34px;
  padding: 0 10px;
  border-radius: var(--r-s);
  color: var(--text-2);
  font-size: 13px;
  font-weight: 500;
  transition: all 0.14s var(--ease);
}
.nav-item:hover { background: var(--surface-2); color: var(--text); text-decoration: none; }
.nav-item.active { background: var(--brand-soft); color: var(--brand); font-weight: 600; }
.sidebar.collapsed .nav { align-items: center; padding: 2px 0 8px; border-bottom: none; }
.sidebar.collapsed .nav-item { width: 38px; height: 38px; padding: 0; justify-content: center; }

/* 工作空间 */
.ws-chip {
  margin: 0 12px 6px;
  height: 32px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 10px;
  border-radius: var(--r-s);
  border: 1px solid var(--border);
  background: var(--surface-2);
  color: var(--text-2);
  font-size: 12px;
  transition: all 0.14s var(--ease);
  flex-shrink: 0;
}
.ws-chip:hover { border-color: color-mix(in srgb, var(--brand) 45%, transparent); background: var(--brand-soft); color: var(--brand); }
.ws-chip.unset { border-style: dashed; border-color: var(--warn); color: var(--warn); background: var(--warn-soft); }
.ws-name { flex: 1; min-width: 0; font-weight: 600; }
.ws-chev { opacity: 0.7; }
.ws-rail { margin: 0 auto 8px; }

/* 历史 */
.hist-head {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 12px 16px 6px;
  flex-shrink: 0;
}
.hist-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.06em;
  color: var(--text-3);
  text-transform: uppercase;
}
.hist-count {
  font-size: 10.5px;
  color: var(--text-3);
  background: var(--surface-3);
  padding: 0 6px;
  border-radius: var(--r-full);
  line-height: 16px;
}
.hist-search {
  margin: 0 12px 6px;
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 0 9px;
  height: 30px;
  border-radius: var(--r-s);
  background: var(--surface-2);
  border: 1px solid transparent;
  color: var(--text-3);
  transition: all 0.15s var(--ease);
  flex-shrink: 0;
}
.hist-search:focus-within { background: var(--surface); border-color: var(--brand); box-shadow: 0 0 0 3px var(--brand-soft); }
.hist-search input {
  flex: 1;
  min-width: 0;
  border: none;
  background: none;
  box-shadow: none;
  font-size: 12.5px;
  padding: 0;
  height: 100%;
}
.hist-search input:focus { border: none; box-shadow: none; }
.hist-search .clear { display: flex; color: var(--text-3); }
.hist-search .clear:hover { color: var(--text); }

.hist-list {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 2px 8px;
}
.hist-item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 8px 7px 10px;
  border-radius: var(--r-s);
  text-align: left;
  transition: background 0.12s var(--ease);
  position: relative;
}
.hist-item:hover { background: var(--surface-2); }
.hist-item.on { background: var(--brand-soft); }
.hist-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.hist-name { font-size: 12.5px; color: var(--text); }
.hist-item.on .hist-name { color: var(--brand); font-weight: 600; }
.hist-time { font-size: 10.5px; color: var(--text-3); margin-top: 1px; }
.hist-del {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-3);
  opacity: 0;
  transition: all 0.13s var(--ease);
  flex-shrink: 0;
}
.hist-item:hover .hist-del { opacity: 1; }
.hist-del:hover { background: var(--err-soft); color: var(--err); }
.hist-empty { text-align: center; color: var(--text-3); font-size: 12px; padding: 26px 0; }

.hist-foot { padding: 8px 12px; border-top: 1px solid var(--border); flex-shrink: 0; }
.del-all {
  width: 100%;
  height: 30px;
  border-radius: var(--r-s);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-3);
  border: 1px dashed var(--border-2);
  transition: all 0.14s var(--ease);
}
.del-all:hover:not(:disabled) { color: var(--err); border-color: var(--err); border-style: solid; background: var(--err-soft); }
.del-count { font-size: 10.5px; opacity: 0.8; }

/* 折叠态 */
.spacer { flex: 1; }
.rail-expand {
  position: relative;
  margin: 2px auto 8px;
  width: 36px;
  height: 28px;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--surface-2);
  color: var(--text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s var(--ease);
  flex-shrink: 0;
}
.rail-expand:hover {
  color: var(--brand);
  border-color: color-mix(in srgb, var(--brand) 50%, transparent);
  background: var(--brand-soft);
}
.rail-badge {
  position: absolute;
  top: -5px;
  right: -6px;
  min-width: 15px;
  height: 15px;
  padding: 0 3px;
  border-radius: var(--r-full);
  background: var(--brand);
  color: #fff;
  font-size: 9.5px;
  font-weight: 700;
  line-height: 15px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

/* 底部 */
.sb-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 10px 14px;
  border-top: 1px solid var(--border);
  flex-shrink: 0;
}
.sb-footer.mini { flex-direction: column; padding: 10px 0; gap: 6px; }
.conn {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  color: var(--text-3);
}
.conn-dot { width: 6px; height: 6px; border-radius: 50%; }
.conn.on .conn-dot { background: var(--ok); box-shadow: 0 0 5px var(--ok); }
.conn.off .conn-dot { background: var(--warn); animation: dot-pulse-warn 1.6s infinite; }
</style>
