<script setup>
import Icon from './Icon.vue'
import { resolveApproval } from '../stores/app'
import { toolIcon } from '../utils/format'

const props = defineProps({
  approval: { type: Object, required: true },
})
const emit = defineEmits(['resolved'])

async function act(approved) {
  await resolveApproval(props.approval.approval_id, approved)
  emit('resolved', props.approval.approval_id)
}

function argsText() {
  try { return JSON.stringify(props.approval.arguments ?? {}, null, 2) } catch { return String(props.approval.arguments ?? '') }
}
</script>

<template>
  <div class="approval">
    <div class="ap-head">
      <div class="ap-icon"><Icon name="shield" :size="16" /></div>
      <div class="ap-title">
        <span class="ap-strong">需要人工审批</span>
        <span class="ap-tool mono"><Icon :name="toolIcon(approval.tool)" :size="12" /> {{ approval.tool }}</span>
      </div>
      <span class="badge warn"><span class="dot waiting_approval"></span>等待中</span>
    </div>
    <p class="ap-reason">{{ approval.reason }}</p>
    <pre class="code-block ap-code">{{ argsText() }}</pre>
    <div class="ap-actions">
      <button class="btn btn-ok" @click="act(true)"><Icon name="check" :size="15" /> 批准执行</button>
      <button class="btn btn-ghost" @click="act(false)"><Icon name="x" :size="15" /> 拒绝</button>
    </div>
  </div>
</template>

<style scoped>
.approval {
  border: 1px solid color-mix(in srgb, var(--warn) 40%, transparent);
  background: linear-gradient(180deg, var(--warn-soft), transparent 70%);
  border-radius: var(--r-m);
  padding: 14px 16px;
  max-width: 620px;
}
.ap-head { display: flex; align-items: center; gap: 10px; }
.ap-icon {
  width: 30px;
  height: 30px;
  border-radius: 9px;
  background: var(--warn-soft);
  color: var(--warn);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.ap-title { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.ap-strong { font-size: 13px; font-weight: 700; }
.ap-tool {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11.5px;
  color: var(--text-2);
}
.ap-reason { font-size: 12.3px; color: var(--text-2); margin: 9px 0 10px; line-height: 1.6; }
.ap-code { max-height: 200px; background: var(--surface); }
.ap-actions { display: flex; gap: 9px; margin-top: 12px; }
.ap-actions .btn { height: 32px; }
</style>
