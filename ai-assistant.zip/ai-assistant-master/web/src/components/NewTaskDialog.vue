<script setup>
import { computed, ref, watch } from 'vue'
import Icon from './Icon.vue'
import { closeNewTaskDialog, newSession, openInTab, store } from '../stores/app'
import { timeAgo } from '../utils/format'

const creating = ref(false)
const selectedModel = ref('')
const selectedGate = ref('ask')
const selectedRsi = ref('observe')

const profiles = computed(() => store.models.profiles || [])
const recent = computed(() => store.sessions.slice(0, 8))

watch(
  () => store.newTaskDialog,
  (open) => {
    if (open) {
      selectedModel.value = store.models.default || ''
      selectedGate.value = 'ask'
      selectedRsi.value = 'observe'
    }
  },
  { immediate: true },
)

function openRecent(sessionId) {
  openInTab(sessionId)
  closeNewTaskDialog()
}

async function create() {
  if (creating.value) return
  creating.value = true
  try {
    await newSession({ model_profile: selectedModel.value, gate_mode: selectedGate.value, rsi_mode: selectedRsi.value })
    closeNewTaskDialog()
  } finally {
    creating.value = false
  }
}
</script>

<template>
  <Teleport to="body">
    <Transition name="fade">
      <div v-if="store.newTaskDialog" class="overlay" @click.self="closeNewTaskDialog()">
        <Transition name="pop" appear>
          <div class="dialog" @keydown.esc="closeNewTaskDialog()">
            <div class="head">
              <div class="icon"><Icon name="plus" :size="18" /></div>
              <div class="head-text">
                <div class="title">新建任务</div>
                <div class="sub">选择模型与操作门禁，或直接打开最近的对话继续。</div>
              </div>
              <button class="close" title="关闭" @click="closeNewTaskDialog()">
                <Icon name="x" :size="16" />
              </button>
            </div>

            <div class="body">
              <!-- 模型选择 -->
              <div class="section">
                <div class="section-label">
                  <Icon name="sparkles" :size="13" /> 模型
                </div>
                <div class="model-list">
                  <button
                    v-for="p in profiles"
                    :key="p.name"
                    class="model-item"
                    :class="{ on: selectedModel === p.name }"
                    @click="selectedModel = p.name"
                  >
                    <div class="mi-row">
                      <span class="mi-name mono">{{ p.name }}</span>
                      <span v-if="p.name === store.models.default" class="badge brand">默认</span>
                      <Icon v-if="selectedModel === p.name" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="mi-sub">{{ p.model }} · {{ Math.round(p.context_window / 1000) }}K 上下文</div>
                  </button>
                  <div v-if="!profiles.length" class="empty-hint">暂无可用模型</div>
                </div>
              </div>

              <!-- 权限（门禁）选择 -->
              <div class="section">
                <div class="section-label">
                  <Icon name="shield" :size="13" /> 权限
                </div>
                <div class="gate-list">
                  <button
                    class="gate-item"
                    :class="{ on: selectedGate === 'ask' }"
                    @click="selectedGate = 'ask'"
                  >
                    <div class="gi-row">
                      <span class="gi-name">审批确认</span>
                      <Icon v-if="selectedGate === 'ask'" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="gi-sub">高风险写操作与命令逐条人工批准（推荐）</div>
                  </button>
                  <button
                    class="gate-item"
                    :class="{ on: selectedGate === 'allow_all' }"
                    @click="selectedGate = 'allow_all'"
                  >
                    <div class="gi-row">
                      <span class="gi-name">自动批准</span>
                      <Icon v-if="selectedGate === 'allow_all'" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="gi-sub">信任任务全自动执行，不打断</div>
                  </button>
                </div>
              </div>

              <!-- 自进化 RSI -->
              <div class="section">
                <div class="section-label">
                  <Icon name="zap" :size="13" /> 自进化 RSI
                </div>
                <div class="gate-list">
                  <button
                    class="gate-item"
                    :class="{ on: selectedRsi === 'off' }"
                    @click="selectedRsi = 'off'"
                  >
                    <div class="gi-row">
                      <span class="gi-name">关闭</span>
                      <Icon v-if="selectedRsi === 'off'" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="gi-sub">不采集、不注入，保持 baseline</div>
                  </button>
                  <button
                    class="gate-item"
                    :class="{ on: selectedRsi === 'observe' }"
                    @click="selectedRsi = 'observe'"
                  >
                    <div class="gi-row">
                      <span class="gi-name">观察</span>
                      <Icon v-if="selectedRsi === 'observe'" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="gi-sub">采集轨迹、失败归因，不改行为（推荐）</div>
                  </button>
                  <button
                    class="gate-item"
                    :class="{ on: selectedRsi === 'active' }"
                    @click="selectedRsi = 'active'"
                  >
                    <div class="gi-row">
                      <span class="gi-name">主动进化</span>
                      <Icon v-if="selectedRsi === 'active'" name="check" :size="13" class="mi-check" />
                    </div>
                    <div class="gi-sub">注入已晋级记忆/技能，失败时运行时提示</div>
                  </button>
                </div>
              </div>

              <!-- 最近对话 -->
              <div class="section">
                <div class="section-label">
                  <Icon name="message" :size="13" /> 最近对话
                </div>
                <div class="recent-list">
                  <button
                    v-for="s in recent"
                    :key="s.session_id"
                    class="recent-item"
                    @click="openRecent(s.session_id)"
                  >
                    <span class="dot" :class="s.status || 'idle'"></span>
                    <span class="ri-name ellipsis">{{ s.title || '新任务' }}</span>
                    <span class="ri-time">{{ timeAgo(s.updated_at) }}</span>
                  </button>
                  <div v-if="!recent.length" class="empty-hint">暂无历史对话</div>
                </div>
              </div>
            </div>

            <div class="foot">
              <button class="btn btn-ghost" @click="closeNewTaskDialog()">取消</button>
              <button class="btn btn-primary" :disabled="creating" @click="create">
                <Icon name="plus" :size="15" /> {{ creating ? '创建中…' : '创建任务' }}
              </button>
            </div>
          </div>
        </Transition>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(10, 12, 18, 0.45);
  backdrop-filter: blur(3px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 250;
  padding: 20px;
}
.dialog {
  width: 520px;
  max-width: 94vw;
  max-height: 88vh;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-l);
  box-shadow: var(--sh-l);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.head { display: flex; align-items: flex-start; gap: 12px; padding: 18px 20px 12px; }
.icon {
  width: 36px; height: 36px; border-radius: 11px;
  background: var(--brand-soft); color: var(--brand);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.head-text { flex: 1; min-width: 0; }
.title { font-size: 15px; font-weight: 700; }
.sub { font-size: 12px; color: var(--text-3); margin-top: 3px; line-height: 1.6; }
.close {
  color: var(--text-3); width: 28px; height: 28px; border-radius: 7px;
  display: flex; align-items: center; justify-content: center;
}
.close:hover { background: var(--surface-3); color: var(--text); }

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 0 20px 4px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.section-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--text-3);
  margin-bottom: 7px;
}

/* 模型列表 */
.model-list {
  border: 1px solid var(--border);
  border-radius: var(--r-m);
  background: var(--surface-2);
  padding: 5px;
  max-height: 168px;
  overflow-y: auto;
}
.model-item {
  display: block;
  width: 100%;
  text-align: left;
  padding: 8px 10px;
  border-radius: var(--r-s);
  transition: background 0.12s var(--ease);
}
.model-item:hover { background: var(--surface); }
.model-item.on { background: var(--brand-soft); }
.mi-row { display: flex; align-items: center; gap: 7px; }
.mi-name { font-size: 12.5px; font-weight: 600; color: var(--text); }
.mi-check { margin-left: auto; color: var(--brand); }
.mi-sub { font-size: 11px; color: var(--text-3); margin-top: 2px; line-height: 1.5; }

.badge.brand {
  font-size: 9.5px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: var(--r-full);
  background: var(--brand-soft);
  color: var(--brand);
  line-height: 1.4;
}

/* 门禁 */
.gate-list { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.gate-item {
  text-align: left;
  padding: 10px 12px;
  border-radius: var(--r-m);
  border: 1px solid var(--border);
  background: var(--surface-2);
  transition: all 0.14s var(--ease);
}
.gate-item:hover { border-color: var(--border-2); }
.gate-item.on {
  border-color: var(--brand);
  background: var(--brand-soft);
}
.gi-row { display: flex; align-items: center; gap: 7px; }
.gi-name { font-size: 12.5px; font-weight: 600; color: var(--text); }
.gate-item.on .gi-name { color: var(--brand); }
.gi-sub { font-size: 11px; color: var(--text-3); margin-top: 3px; line-height: 1.5; }

/* 最近对话 */
.recent-list {
  border: 1px solid var(--border);
  border-radius: var(--r-m);
  background: var(--surface-2);
  padding: 5px;
  max-height: 176px;
  overflow-y: auto;
}
.recent-item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 10px;
  border-radius: var(--r-s);
  text-align: left;
  transition: background 0.12s var(--ease);
}
.recent-item:hover { background: var(--surface); }
.ri-name { flex: 1; min-width: 0; font-size: 12.5px; color: var(--text); }
.ri-time { font-size: 10.5px; color: var(--text-3); flex-shrink: 0; }

.empty-hint { padding: 18px; text-align: center; color: var(--text-3); font-size: 12px; }

.foot {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 14px 20px;
  border-top: 1px solid var(--border);
  margin-top: 8px;
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.18s var(--ease); }
.fade-enter-from, .fade-leave-to { opacity: 0; }
.pop-enter-active { transition: all 0.2s var(--ease-out); }
.pop-enter-from { opacity: 0; transform: scale(0.95) translateY(10px); }

@media (max-width: 560px) {
  .gate-list { grid-template-columns: 1fr; }
}
</style>
