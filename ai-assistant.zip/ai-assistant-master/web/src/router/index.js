import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  { path: '/', name: 'workbench', component: () => import('../views/Workbench.vue') },
  { path: '/skills', name: 'skills', component: () => import('../views/Skills.vue') },
  { path: '/usage', name: 'usage', component: () => import('../views/Usage.vue') },
  { path: '/settings', name: 'settings', component: () => import('../views/Settings.vue') },
]

export default createRouter({
  history: createWebHashHistory(),
  routes,
})
