// WebSocket：单连接多路复用 + 指数退避重连 + 心跳
let ws = null
let retry = 0
let timer = null
let handler = null
let onOpen = null
let onClose = null
let heartbeat = null

export function connectWS(handleEvent, open, close) {
  handler = handleEvent
  onOpen = open
  onClose = close
  openSocket()
}

function openSocket() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws'
  ws = new WebSocket(`${proto}://${location.host}/ws`)

  ws.onopen = () => {
    retry = 0
    onOpen && onOpen()
    heartbeat = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'ping' }))
      }
    }, 25000)
  }

  ws.onmessage = (e) => {
    try {
      const frame = JSON.parse(e.data)
      handler && handler(frame)
    } catch { /* 忽略坏帧 */ }
  }

  ws.onclose = () => {
    clearInterval(heartbeat)
    onClose && onClose()
    scheduleReconnect()
  }

  ws.onerror = () => {
    try { ws.close() } catch { /* noop */ }
  }
}

function scheduleReconnect() {
  clearTimeout(timer)
  retry = Math.min(retry + 1, 6)
  const delay = Math.min(1000 * 2 ** retry, 15000)
  timer = setTimeout(openSocket, delay)
}
