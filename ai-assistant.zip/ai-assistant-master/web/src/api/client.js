// REST 客户端：统一 {code, data} 解析
const BASE = ''

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  })
  if (!res.ok && res.status >= 500) {
    throw new Error(`服务异常 ${res.status}`)
  }
  const body = await res.json().catch(() => ({}))
  if (body.code && body.code !== 200) {
    throw new Error(body.message || `请求失败 ${body.code}`)
  }
  return body.data !== undefined ? body.data : body
}

export const api = {
  get: (path) => request(path),
  post: (path, data) => request(path, { method: 'POST', body: JSON.stringify(data ?? {}) }),
  put: (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data ?? {}) }),
  patch: (path, data) => request(path, { method: 'PATCH', body: JSON.stringify(data ?? {}) }),
  delete: (path) => request(path, { method: 'DELETE' }),
}

export default api
