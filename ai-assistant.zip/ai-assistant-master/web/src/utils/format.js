export function timeAgo(iso) {
  if (!iso) return ''
  const t = new Date(iso).getTime()
  if (Number.isNaN(t)) return ''
  const diff = Math.max(0, (Date.now() - t) / 1000)
  if (diff < 45) return '刚刚'
  if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} 天前`
  const d = new Date(iso)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())}`
}

export function fmtNum(n) {
  return Number(n || 0).toLocaleString('zh-CN')
}

export function shortNum(n) {
  const v = Number(n || 0)
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}k`
  return String(v)
}

export function greeting() {
  const h = new Date().getHours()
  if (h < 5) return '夜深了'
  if (h < 11) return '早上好'
  if (h < 14) return '中午好'
  if (h < 18) return '下午好'
  return '晚上好'
}

// 工具 → 图标映射
export function toolIcon(name = '') {
  if (['run_shell', 'run_python'].includes(name)) return 'terminal'
  if (['read_file', 'write_file', 'edit_file', 'multi_edit'].includes(name)) return 'file'
  if (['grep', 'glob'].includes(name)) return 'search'
  if (['list_dir'].includes(name)) return 'folder'
  if (['delete_path', 'move_path'].includes(name)) return 'folder'
  if (['calculator', 'now', 'echo'].includes(name)) return 'sparkles'
  return 'wrench'
}
