import { reactive } from 'vue'
import api from '../api/client'
import { connectWS } from '../api/ws'

// 零依赖响应式单例 store
export const store = reactive({
  ready: false,
  wsOk: false,
  theme: localStorage.getItem('forge-theme') || 'light',
  models: { default: '', profiles: [] },
  health: null,

  sessions: [],            // 全部会话（含历史）
  openTabs: [],            // 当前打开的任务 Tab（session_id 顺序）
  activeId: '',            // 当前激活任务
  openDirs: {},            // sessionId -> { messages, tools, draft, approvals, loaded }
  sidebarCollapsed: localStorage.getItem('forge-sb') === '1',
  workspace: '',
  workspaceSaved: false,
  workspacePicker: false,
  newTaskDialog: false,
  toasts: [],

  usageToday: { total_tokens: 0, calls: 0 },
})

let toastSeq = 0
export function toast(message, type = 'info') {
  const id = ++toastSeq
  store.toasts.push({ id, message, type })
  setTimeout(() => {
    store.toasts = store.toasts.filter((t) => t.id !== id)
  }, 2800)
}

export function setTheme(theme) {
  store.theme = theme
  localStorage.setItem('forge-theme', theme)
  document.documentElement.setAttribute('data-theme', theme)
}

function saveTabs() {
  localStorage.setItem('forge-tabs', JSON.stringify(store.openTabs))
}

export function toggleSidebar() {
  store.sidebarCollapsed = !store.sidebarCollapsed
  localStorage.setItem('forge-sb', store.sidebarCollapsed ? '1' : '0')
}

// ------------------------------------------------------------------
// 初始化
// ------------------------------------------------------------------
export async function initStore() {
  document.documentElement.setAttribute('data-theme', store.theme)
  connectWS(onEvent, () => { store.wsOk = true }, () => { store.wsOk = false })
  await Promise.all([loadSessions(), loadModels(), loadHealth(), loadUsageToday(), loadWorkspace()])
  try {
    const saved = JSON.parse(localStorage.getItem('forge-tabs') || '[]')
    const ids = new Set(store.sessions.map((s) => s.session_id))
    store.openTabs = saved.filter((id) => ids.has(id))
  } catch { store.openTabs = [] }
  if (store.openTabs.length) setActive(store.openTabs[0])
  store.ready = true
}

export async function loadSessions() {
  const list = await api.get('/api/sessions')
  const known = new Map(store.sessions.map((s) => [s.session_id, s]))
  for (const s of list) {
    if (known.has(s.session_id)) {
      Object.assign(known.get(s.session_id), s)
    } else {
      store.sessions.push(s)
    }
  }
  const ids = new Set(list.map((s) => s.session_id))
  store.sessions = store.sessions.filter((s) => ids.has(s.session_id))
  store.sessions.sort((a, b) => (a.updated_at < b.updated_at ? 1 : -1))
}

export async function loadModels() {
  store.models = await api.get('/api/models')
}

export async function loadHealth() {
  store.health = await api.get('/api/system/health')
}

export async function loadWorkspace() {
  try {
    const data = await api.get('/api/settings/workspace')
    store.workspace = data.path || ''
    store.workspaceSaved = !!data.saved
  } catch {
    store.workspace = ''
    store.workspaceSaved = false
  }
}

export async function setWorkspace(path) {
  const data = await api.put('/api/settings/workspace', { path })
  store.workspace = data.path
  store.workspaceSaved = true
  store.workspacePicker = false
  toast('工作空间已切换，后续对话将在该目录执行', 'ok')
  return data.path
}

export function openWorkspacePicker() {
  store.workspacePicker = true
}

export async function loadUsageToday() {
  try {
    store.usageToday = await api.get('/api/usage/today')
  } catch { store.usageToday = { total_tokens: 0, calls: 0 } }
}

// ------------------------------------------------------------------
// 任务（会话）与 Tab
// ------------------------------------------------------------------
export async function newSession(opts = {}) {
  const body = {}
  if (opts.model_profile) body.model_profile = opts.model_profile
  if (opts.gate_mode) body.gate_mode = opts.gate_mode
  if (opts.rsi_mode) body.capabilities = { rsi_mode: opts.rsi_mode }
  const s = await api.post('/api/sessions', body)
  store.sessions.unshift(s)
  if (!store.openTabs.includes(s.session_id)) store.openTabs.push(s.session_id)
  saveTabs()
  setActive(s.session_id)
  toast('已创建新任务', 'ok')
  return s
}

export function openNewTaskDialog() {
  store.newTaskDialog = true
}

export function closeNewTaskDialog() {
  store.newTaskDialog = false
}

export function openInTab(sessionId) {
  if (!store.openTabs.includes(sessionId)) {
    store.openTabs.push(sessionId)
    saveTabs()
  }
  setActive(sessionId)
}

export function closeTab(sessionId) {
  store.openTabs = store.openTabs.filter((id) => id !== sessionId)
  saveTabs()
  delete store.openDirs[sessionId]
  if (store.activeId === sessionId) {
    setActive(store.openTabs[store.openTabs.length - 1] || '')
  }
}

// 批量关闭 Tab（右键菜单）
export function closeTabsRight(sessionId) {
  const idx = store.openTabs.indexOf(sessionId)
  if (idx < 0) return
  const removed = store.openTabs.slice(idx + 1)
  removed.forEach((id) => delete store.openDirs[id])
  store.openTabs = store.openTabs.slice(0, idx + 1)
  saveTabs()
  if (removed.includes(store.activeId)) {
    setActive(store.openTabs[store.openTabs.length - 1] || '')
  }
}

export function closeTabsLeft(sessionId) {
  const idx = store.openTabs.indexOf(sessionId)
  if (idx < 0) return
  const removed = store.openTabs.slice(0, idx)
  removed.forEach((id) => delete store.openDirs[id])
  store.openTabs = store.openTabs.slice(idx)
  saveTabs()
  if (removed.includes(store.activeId)) {
    setActive(sessionId)
  }
}

export function closeTabsOthers(sessionId) {
  if (!store.openTabs.includes(sessionId)) return
  const removed = store.openTabs.filter((id) => id !== sessionId)
  removed.forEach((id) => delete store.openDirs[id])
  store.openTabs = [sessionId]
  saveTabs()
  if (removed.includes(store.activeId)) setActive(sessionId)
}

export function closeTabsAll() {
  store.openTabs = []
  saveTabs()
  store.openDirs = {}
  store.activeId = ''
}

export function setActive(sessionId) {
  store.activeId = sessionId || ''
  if (sessionId && !store.openDirs[sessionId]) {
    store.openDirs[sessionId] = { messages: [], tools: {}, draft: null, approvals: {}, loaded: false, streaming: false }
    loadMessages(sessionId)
  }
}

export async function loadMessages(sessionId) {
  const dir = store.openDirs[sessionId]
  if (!dir) return
  const messages = await api.get(`/api/sessions/${sessionId}/messages`)
  dir.messages = messages
  for (const m of messages) {
    if (m.role === 'tool' && m.tool_call_id) {
      let parsed = {}
      try { parsed = JSON.parse(m.content || '{}') } catch { /* ignore */ }
      const existing = dir.tools[m.tool_call_id]
      dir.tools[m.tool_call_id] = {
        name: m.name || existing?.name || 'tool',
        arguments: existing?.arguments || {},
        status: parsed.ok === false ? 'failed' : 'done',
        summary: typeof parsed.result === 'string'
          ? parsed.result.slice(0, 800)
          : JSON.stringify(parsed.result || '').slice(0, 800),
        error: parsed.error || '',
      }
    }
  }
  dir.loaded = true
}

export async function deleteSession(sessionId) {
  await api.delete(`/api/sessions/${sessionId}?purge=true`)
  removeSessionLocal(sessionId)
  toast('对话已删除', 'ok')
}

export async function deleteAllSessions() {
  const ids = store.sessions.map((s) => s.session_id)
  for (const id of ids) {
    try { await api.delete(`/api/sessions/${id}?purge=true`) } catch { /* 单个失败继续 */ }
  }
  store.openDirs = {}
  store.openTabs = []
  saveTabs()
  store.activeId = ''
  await loadSessions()
  toast(`已删除 ${ids.length} 个对话`, 'ok')
}

function removeSessionLocal(sessionId) {
  store.sessions = store.sessions.filter((s) => s.session_id !== sessionId)
  store.openTabs = store.openTabs.filter((id) => id !== sessionId)
  saveTabs()
  delete store.openDirs[sessionId]
  if (store.activeId === sessionId) {
    setActive(store.openTabs[store.openTabs.length - 1] || '')
  }
}

export async function sendMessage(sessionId, text) {
  const dir = store.openDirs[sessionId]
  if (!dir) return
  dir.messages.push({ role: 'user', content: text, created_at: new Date().toISOString() })
  dir.streaming = true
  dir.draft = { run_id: '', text: '' }
  try {
    const result = await api.post(`/api/sessions/${sessionId}/messages`, { text })
    if (dir.draft) dir.draft.run_id = result.run_id
  } catch (e) {
    dir.streaming = false
    dir.draft = null
    toast(`发送失败：${e.message}`, 'err')
    throw e
  }
}

export async function cancelSession(sessionId) {
  await api.post(`/api/sessions/${sessionId}/cancel`)
  toast('已请求停止', 'warn')
}

export async function resumeSession(sessionId) {
  await api.post(`/api/sessions/${sessionId}/resume`)
  toast('已恢复执行', 'ok')
}

export async function resolveApproval(approvalId, approved) {
  await api.post(`/api/approvals/${approvalId}/resolve`, { approved })
  toast(approved ? '已批准执行' : '已拒绝操作', approved ? 'ok' : 'warn')
}

export function updateSessionLocal(sessionId, fields) {
  const s = store.sessions.find((x) => x.session_id === sessionId)
  if (s) Object.assign(s, fields)
}

export function dirOf(sessionId) {
  return store.openDirs[sessionId]
}

// ------------------------------------------------------------------
// WS 事件分发
// ------------------------------------------------------------------
function onEvent(frame) {
  const { session_id: sid, event, payload } = frame
  if (event === 'pong' || event === 'hello') return

  if (event === 'session.status') {
    updateSessionLocal(payload.session_id || sid, { status: payload.status })
    if (payload.status === 'idle' || payload.status === 'error') {
      const dir = store.openDirs[payload.session_id]
      if (dir) dir.streaming = false
    }
    return
  }
  if (event === 'session.updated') {
    updateSessionLocal(sid, payload)
    return
  }
  if (event === 'session.deleted') {
    removeSessionLocal(sid)
    return
  }

  const dir = store.openDirs[sid]
  if (!dir) {
    if (event === 'run.completed' || event === 'run.failed') loadSessions()
    return
  }

  switch (event) {
    case 'run.started':
      dir.streaming = true
      if (dir.draft) dir.draft.run_id = payload.run_id || dir.draft.run_id
      updateSessionLocal(sid, { status: 'running' })
      break
    case 'model.delta': {
      if (!dir.draft) dir.draft = { run_id: payload.run_id, text: '' }
      if (!dir.draft.run_id) dir.draft.run_id = payload.run_id
      if (dir.draft.run_id === payload.run_id) dir.draft.text += payload.text || ''
      break
    }
    case 'model.completed': {
      const msg = {
        role: 'assistant',
        content: '',
        tool_calls: payload.tool_calls || [],
        created_at: new Date().toISOString(),
      }
      if (dir.draft && dir.draft.run_id === payload.run_id) {
        msg.content = dir.draft.text
        if (!payload.tool_calls?.length) dir.draft = null
        else dir.draft = { run_id: payload.run_id, text: '' }
      }
      dir.messages.push(msg)
      if (payload.usage?.total_tokens) loadUsageToday()
      break
    }
    case 'tool.requested': {
      dir.tools[payload.call_id] = {
        name: payload.name,
        arguments: payload.arguments,
        status: payload.denied ? 'denied' : payload.requires_approval ? 'waiting' : 'running',
        summary: '',
        error: payload.denied ? '策略拒绝' : '',
      }
      break
    }
    case 'tool.result': {
      const tool = dir.tools[payload.call_id] || { name: payload.name, arguments: {} }
      tool.status = payload.ok ? 'done' : 'failed'
      tool.summary = payload.summary || ''
      tool.error = payload.error || ''
      dir.tools[payload.call_id] = tool
      break
    }
    case 'approval.required': {
      dir.approvals[payload.approval_id] = {
        approval_id: payload.approval_id,
        tool: payload.tool,
        arguments: payload.arguments,
        reason: payload.reason,
      }
      const waiting = Object.values(dir.tools).find((t) => t.status === 'running' && t.name === payload.tool)
      if (waiting) waiting.status = 'waiting'
      break
    }
    case 'run.completed':
    case 'run.failed': {
      dir.streaming = false
      dir.draft = null
      dir.approvals = {}
      loadMessages(sid)
      loadSessions()
      if (event === 'run.failed') updateSessionLocal(sid, { status: 'error' })
      break
    }
    default:
      break
  }
}
