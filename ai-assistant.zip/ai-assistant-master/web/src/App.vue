<script setup>
import { computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import Sidebar from './components/Sidebar.vue'
import WorkspacePicker from './components/WorkspacePicker.vue'
import NewTaskDialog from './components/NewTaskDialog.vue'
import Toast from './components/Toast.vue'
import { initStore, openNewTaskDialog, store, toggleSidebar } from './stores/app'

const router = useRouter()
const pickerOpen = computed(() => store.ready && (!store.workspaceSaved || store.workspacePicker))

function onKey(e) {
  const meta = e.ctrlKey || e.metaKey
  if (!meta) return
  const key = e.key.toLowerCase()
  if (key === 't') {
    e.preventDefault()
    router.push('/')
    openNewTaskDialog()
  } else if (key === 'b') {
    e.preventDefault()
    toggleSidebar()
  } else if (key === 'k') {
    e.preventDefault()
    router.push('/')
    window.dispatchEvent(new CustomEvent('forge-focus-composer'))
  }
}

onMounted(() => {
  initStore()
  window.addEventListener('keydown', onKey)
})
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="app">
    <Sidebar />
    <main class="main">
      <router-view v-if="store.ready" v-slot="{ Component }">
        <Transition name="view" mode="out-in">
          <component :is="Component" />
        </Transition>
      </router-view>
      <div v-else class="boot">
        <div class="boot-logo">⚡</div>
        <div class="boot-bar"><span></span></div>
        <p class="boot-text">正在连接 AI助理…</p>
      </div>
    </main>
    <WorkspacePicker
      :open="pickerOpen"
      :required="!store.workspaceSaved"
      @close="store.workspacePicker = false"
    />
    <NewTaskDialog />
    <Toast />
  </div>
</template>

<style scoped>
.app { height: 100%; display: flex; overflow: hidden; }
.main { flex: 1; min-width: 0; display: flex; flex-direction: column; background: var(--bg); }

.boot {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 16px;
}
.boot-logo {
  width: 56px;
  height: 56px;
  border-radius: 16px;
  background: var(--brand-grad);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  box-shadow: var(--sh-brand);
  animation: boot-float 2.4s var(--ease) infinite;
}
@keyframes boot-float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-6px); }
}
.boot-bar {
  width: 120px;
  height: 3px;
  border-radius: 2px;
  background: var(--surface-3);
  overflow: hidden;
}
.boot-bar span {
  display: block;
  width: 40%;
  height: 100%;
  border-radius: 2px;
  background: var(--brand-grad);
  animation: boot-slide 1.1s var(--ease) infinite;
}
@keyframes boot-slide {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(350%); }
}
.boot-text { font-size: 12.5px; color: var(--text-3); }
</style>
