<script setup>
import { computed, onMounted, ref } from 'vue'
import api from '../api/client'
import Icon from '../components/Icon.vue'
import { fmtNum } from '../utils/format'

const daily = ref([])
const byModel = ref([])

onMounted(load)

async function load() {
  daily.value = (await api.get('/api/usage/daily?limit=14')).reverse()
  byModel.value = await api.get('/api/usage/by-model')
}

const maxTokens = computed(() => Math.max(1, ...daily.value.map((d) => d.total_tokens || 0)))
const totalTokens = computed(() => daily.value.reduce((sum, d) => sum + (d.total_tokens || 0), 0))
const totalCalls = computed(() => daily.value.reduce((sum, d) => sum + (d.calls || 0), 0))

function barH(v) {
  return `${Math.max(4, ((v || 0) / maxTokens.value) * 150)}px`
}
function shortDay(day) {
  return String(day || '').slice(5)
}
</script>

<template>
  <div class="page">
    <header class="page-head">
      <div>
        <h2 class="page-title">用量看板</h2>
        <p class="page-sub">按日 / 按模型的 token 消耗一览</p>
      </div>
      <a class="btn btn-ghost" href="/api/usage/export.csv" target="_blank">
        <Icon name="file" :size="14" /> 导出 CSV
      </a>
    </header>

    <div class="stats">
      <div class="stat card">
        <div class="stat-icon brand"><Icon name="chart" :size="17" /></div>
        <div>
          <div class="stat-label">近 14 天总消耗</div>
          <div class="stat-value">{{ fmtNum(totalTokens) }}<span class="unit">tokens</span></div>
        </div>
      </div>
      <div class="stat card">
        <div class="stat-icon ok"><Icon name="zap" :size="17" /></div>
        <div>
          <div class="stat-label">调用次数</div>
          <div class="stat-value">{{ fmtNum(totalCalls) }}<span class="unit">次</span></div>
        </div>
      </div>
      <div class="stat card">
        <div class="stat-icon warn"><Icon name="sparkles" :size="17" /></div>
        <div>
          <div class="stat-label">产生用量的模型</div>
          <div class="stat-value">{{ byModel.length }}<span class="unit">个</span></div>
        </div>
      </div>
    </div>

    <div class="card chart-card">
      <div class="card-head">
        <h3>每日用量</h3>
        <span class="card-sub">最近 {{ daily.length }} 天</span>
      </div>
      <div class="chart">
        <div
          v-for="d in daily"
          :key="d.day"
          class="bar-col"
          :title="`${d.day} · ${fmtNum(d.total_tokens)} tokens · ${d.calls} 次调用`"
        >
          <div class="bar-val">{{ d.total_tokens >= 1000 ? (d.total_tokens / 1000).toFixed(1) + 'k' : (d.total_tokens || '') }}</div>
          <div class="bar" :style="{ height: barH(d.total_tokens) }"></div>
          <div class="bar-label">{{ shortDay(d.day) }}</div>
        </div>
        <div v-if="!daily.length" class="chart-empty">暂无用量数据</div>
      </div>
    </div>

    <div class="card table-card">
      <div class="card-head"><h3>按模型汇总</h3></div>
      <table class="table">
        <thead>
          <tr><th>模型</th><th>输入</th><th>输出</th><th>合计</th><th>调用</th></tr>
        </thead>
        <tbody>
          <tr v-for="m in byModel" :key="m.model">
            <td><span class="model-tag mono">{{ m.model }}</span></td>
            <td class="num">{{ fmtNum(m.prompt_tokens) }}</td>
            <td class="num">{{ fmtNum(m.completion_tokens) }}</td>
            <td class="num strong">{{ fmtNum(m.total_tokens) }}</td>
            <td class="num">{{ fmtNum(m.calls) }}</td>
          </tr>
          <tr v-if="!byModel.length"><td colspan="5" class="empty">暂无数据</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.page { height: 100%; overflow-y: auto; padding: 24px 28px; max-width: 980px; margin: 0 auto; }
.page-head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 18px; }
.page-title { font-size: 20px; font-weight: 700; letter-spacing: -0.02em; }
.page-sub { font-size: 12.5px; color: var(--text-3); margin-top: 5px; }

.stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 14px; }
.stat { display: flex; align-items: center; gap: 12px; padding: 15px 16px; }
.stat-icon {
  width: 38px;
  height: 38px;
  border-radius: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.stat-icon.brand { background: var(--brand-soft); color: var(--brand); }
.stat-icon.ok { background: var(--ok-soft); color: var(--ok); }
.stat-icon.warn { background: var(--warn-soft); color: var(--warn); }
.stat-label { font-size: 11.5px; color: var(--text-3); }
.stat-value { font-size: 22px; font-weight: 700; letter-spacing: -0.02em; margin-top: 2px; font-variant-numeric: tabular-nums; }
.unit { font-size: 11px; font-weight: 500; color: var(--text-3); margin-left: 4px; }

.card-head { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }
.card-head h3 { font-size: 14px; font-weight: 700; }
.card-sub { font-size: 11px; color: var(--text-3); }

.chart-card { padding: 16px 20px 12px; margin-bottom: 14px; }
.chart { display: flex; align-items: flex-end; gap: 8px; min-height: 190px; padding-top: 8px; }
.bar-col { flex: 1; max-width: 52px; display: flex; flex-direction: column; align-items: center; gap: 5px; }
.bar {
  width: 100%;
  max-width: 34px;
  border-radius: 6px 6px 3px 3px;
  background: var(--brand-grad);
  opacity: 0.8;
  transition: all 0.3s var(--ease);
}
.bar-col:hover .bar { opacity: 1; transform: scaleY(1.02); }
.bar-val { font-size: 9.5px; color: var(--text-3); height: 13px; }
.bar-label { font-size: 10px; color: var(--text-3); }
.chart-empty { margin: auto; color: var(--text-3); font-size: 13px; }

.table-card { padding: 16px 20px; }
.table { width: 100%; border-collapse: collapse; font-size: 12.8px; }
.table th {
  text-align: left;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--text-3);
  padding: 0 10px 9px;
  border-bottom: 1px solid var(--border);
}
.table td { padding: 10px; border-bottom: 1px solid var(--border); }
.table tbody tr:last-child td { border-bottom: none; }
.table tbody tr { transition: background 0.12s var(--ease); }
.table tbody tr:hover { background: var(--surface-2); }
.model-tag {
  font-size: 11.5px;
  padding: 2px 8px;
  border-radius: var(--r-full);
  background: var(--surface-3);
  color: var(--text-2);
}
.num { font-variant-numeric: tabular-nums; color: var(--text-2); }
.strong { color: var(--text); font-weight: 700; }
.empty { text-align: center; color: var(--text-3); padding: 26px !important; }
@media (max-width: 720px) { .stats { grid-template-columns: 1fr; } }
</style>
