<script setup>
import { computed, onMounted, ref } from 'vue'
import api from '../api/client'
import Icon from '../components/Icon.vue'
import { toast } from '../stores/app'

const skills = ref([])
const selected = ref(null)
const draft = ref({ name: '', title: '', kinds: '', triggers: '', body: '' })
const saving = ref(false)
const query = ref('')

onMounted(load)

async function load() {
  skills.value = await api.get('/api/skills')
  if (!selected.value && skills.value.length) await pick(skills.value[0])
}

const filtered = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!q) return skills.value
  return skills.value.filter((s) => `${s.title} ${s.name} ${(s.triggers || []).join(' ')}`.toLowerCase().includes(q))
})

async function pick(s) {
  const detail = await api.get(`/api/skills/${s.name}`)
  selected.value = detail
  draft.value = {
    name: detail.name,
    title: detail.title,
    kinds: (detail.kinds || []).join(', '),
    triggers: (detail.triggers || []).join(', '),
    body: detail.body || '',
  }
}

function createNew() {
  selected.value = null
  draft.value = { name: '', title: '', kinds: '', triggers: '', body: '' }
}

async function save() {
  const name = draft.value.name.trim()
  if (!name) { toast('请填写技能名', 'warn'); return }
  saving.value = true
  try {
    await api.post('/api/skills', {
      name,
      title: draft.value.title.trim() || name,
      kinds: splitList(draft.value.kinds),
      triggers: splitList(draft.value.triggers),
      body: draft.value.body,
    })
    toast('技能已保存并生效', 'ok')
    await load()
    const found = skills.value.find((s) => s.name === name)
    if (found) await pick(found)
  } catch (e) {
    toast(e.message, 'err')
  } finally {
    saving.value = false
  }
}

async function remove(skill) {
  if (!confirm(`删除技能「${skill.title || skill.name}」？`)) return
  await api.delete(`/api/skills/${skill.name}`)
  selected.value = null
  draft.value = { name: '', title: '', kinds: '', triggers: '', body: '' }
  toast('技能已删除', 'ok')
  await load()
}

function splitList(text) {
  return text.split(/[,，]/).map((s) => s.trim()).filter(Boolean)
}
</script>

<template>
  <div class="page">
    <header class="page-head">
      <div>
        <h2 class="page-title">技能库</h2>
        <p class="page-sub">Markdown 方法论 —— 按触发词自动注入 Agent 上下文，保存即生效</p>
      </div>
      <button class="btn btn-primary" @click="createNew"><Icon name="plus" :size="15" /> 新建技能</button>
    </header>

    <div class="layout">
      <aside class="list card">
        <div class="search">
          <Icon name="search" :size="14" />
          <input v-model="query" placeholder="搜索技能…" />
        </div>
        <div class="items">
          <button
            v-for="s in filtered"
            :key="s.name"
            class="item"
            :class="{ on: selected?.name === s.name }"
            @click="pick(s)"
          >
            <span class="item-icon"><Icon name="sparkles" :size="14" /></span>
            <span class="item-main">
              <span class="item-title ellipsis">{{ s.title || s.name }}</span>
              <span class="item-sub ellipsis">{{ (s.triggers || []).slice(0, 3).join(' · ') || '无触发词' }}</span>
            </span>
          </button>
          <div v-if="!filtered.length" class="list-empty">{{ query ? '没有匹配的技能' : '暂无技能' }}</div>
        </div>
      </aside>

      <section class="editor card">
        <template v-if="draft.name || draft.body">
          <div class="grid2">
            <label class="field">
              <span>技能标识</span>
              <input v-model="draft.name" placeholder="my-skill" :disabled="!!selected" class="mono" />
            </label>
            <label class="field">
              <span>显示标题</span>
              <input v-model="draft.title" placeholder="技能显示名" />
            </label>
            <label class="field">
              <span>分类</span>
              <input v-model="draft.kinds" placeholder="dev, coding" />
            </label>
            <label class="field">
              <span>触发词（逗号分隔）</span>
              <input v-model="draft.triggers" placeholder="开发, 修bug, 重构" />
            </label>
          </div>
          <label class="field body">
            <span>方法论正文（Markdown）</span>
            <textarea v-model="draft.body" rows="16" placeholder="# 方法论正文…" class="mono"></textarea>
          </label>
          <div class="editor-bar">
            <button v-if="selected" class="btn btn-danger" @click="remove(selected)">
              <Icon name="trash" :size="14" /> 删除
            </button>
            <div class="spacer"></div>
            <button class="btn btn-primary" :disabled="saving" @click="save">
              <Icon name="check" :size="15" /> {{ saving ? '保存中…' : '保存并生效' }}
            </button>
          </div>
        </template>
        <div v-else class="editor-empty">
          <Icon name="sparkles" :size="30" />
          <p>选择左侧技能查看编辑，或新建一个技能</p>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.page { height: 100%; display: flex; flex-direction: column; padding: 24px 28px; min-height: 0; }
.page-head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 18px; flex-shrink: 0; }
.page-title { font-size: 20px; font-weight: 700; letter-spacing: -0.02em; }
.page-sub { font-size: 12.5px; color: var(--text-3); margin-top: 5px; }

.layout { flex: 1; min-height: 0; display: grid; grid-template-columns: 264px 1fr; gap: 14px; }

.list { display: flex; flex-direction: column; min-height: 0; overflow: hidden; }
.search {
  display: flex;
  align-items: center;
  gap: 7px;
  margin: 10px;
  padding: 0 10px;
  height: 32px;
  border-radius: var(--r-s);
  background: var(--surface-2);
  color: var(--text-3);
}
.search input { flex: 1; min-width: 0; border: none; background: none; box-shadow: none; font-size: 12.5px; height: 100%; padding: 0; }
.search:focus-within { box-shadow: 0 0 0 3px var(--brand-soft); background: var(--surface); }
.items { flex: 1; overflow-y: auto; padding: 0 8px 8px; }
.item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 9px;
  border-radius: var(--r-s);
  text-align: left;
  transition: background 0.12s var(--ease);
}
.item:hover { background: var(--surface-2); }
.item.on { background: var(--brand-soft); }
.item-icon {
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--surface-3);
  color: var(--text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.item.on .item-icon { background: var(--brand-soft-2); color: var(--brand); }
.item-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.item-title { font-size: 12.5px; font-weight: 600; color: var(--text); }
.item-sub { font-size: 10.5px; color: var(--text-3); margin-top: 1px; }
.list-empty { padding: 24px; text-align: center; color: var(--text-3); font-size: 12px; }

.editor { padding: 18px 20px; overflow-y: auto; min-height: 0; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 12px; }
.field > span { font-size: 11.5px; font-weight: 600; color: var(--text-2); }
.field input, .field textarea { padding: 8px 11px; font-size: 13px; }
.field.body textarea { font-size: 12.5px; line-height: 1.7; resize: vertical; }
.editor-bar { display: flex; align-items: center; gap: 9px; margin-top: 4px; }
.spacer { flex: 1; }
.editor-empty {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: var(--text-3);
  font-size: 13px;
}
@media (max-width: 860px) { .layout { grid-template-columns: 1fr; } .list { max-height: 200px; } }
</style>
