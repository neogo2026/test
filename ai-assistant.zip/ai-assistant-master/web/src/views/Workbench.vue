<script setup>
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import TaskTabs from '../components/TaskTabs.vue'
import MessageBubble from '../components/MessageBubble.vue'
import Composer from '../components/Composer.vue'
import ApprovalCard from '../components/ApprovalCard.vue'
import Icon from '../components/Icon.vue'
import api from '../api/client'
import {
  cancelSession,
  dirOf,
  openNewTaskDialog,
  resumeSession,
  sendMessage,
  store,
} from '../stores/app'
import { fmtNum, greeting, shortNum } from '../utils/format'

const streamEl = ref(null)

const activeSession = computed(() => store.sessions.find((s) => s.session_id === store.activeId))
const dir = computed(() => dirOf(store.activeId))
const busy = computed(() => !!activeSession.value && ['running', 'queued'].includes(activeSession.value.status))
const waitingHere = computed(() => activeSession.value?.status === 'waiting_approval')
const pausedRun = computed(() => activeSession.value?.status === 'error')
const visibleMessages = computed(() => (dir.value?.messages || []).filter((m) => m.role !== 'tool'))
const hasContent = computed(() => visibleMessages.value.length > 0 || !!dir.value?.draft)
const approvals = computed(() => Object.values(dir.value?.approvals || {}))
const rsiMode = computed(() => activeSession.value?.capabilities?.rsi_mode || 'observe')
const rsiLabel = computed(() => ({ off: 'RSI 关', observe: 'RSI 观察', active: 'RSI 主动' })[rsiMode.value] || 'RSI')

async function cycleRsi() {
  if (!store.activeId) return
  const order = ['off', 'observe', 'active']
  const next = order[(order.indexOf(rsiMode.value) + 1) % order.length]
  try {
    await api.post(`/api/rsi/sessions/${store.activeId}/mode`, { mode: next })
    const s = store.sessions.find((x) => x.session_id === store.activeId)
    if (s) {
      s.capabilities = { ...(s.capabilities || {}), rsi_mode: next }
    }
  } catch {
    /* RSI 插件未启用时保持安静 */
  }
}

const statusText = {
  idle: '空闲', queued: '排队中', running: '执行中',
  waiting_approval: '等待审批', error: '出错', done: '完成',
}

function scrollBottom(smooth = false) {
  nextTick(() => {
    const el = streamEl.value
    if (!el) return
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
  })
}

watch(
  () => [dir.value?.messages.length, dir.value?.draft?.text, activeSession.value?.status],
  () => scrollBottom(false),
)

async function onSend(text) {
  await sendMessage(store.activeId, text)
  scrollBottom(true)
}

// 新建/切换到空任务时，自动聚焦输入框 —— 打开即自由输入
watch(
  () => [store.activeId, hasContent.value],
  () => {
    if (store.activeId && !hasContent.value) {
      nextTick(() => window.dispatchEvent(new CustomEvent('forge-focus-composer')))
    }
  },
  { immediate: true },
)

function onResolved(approvalId) {
  const d = dirOf(store.activeId)
  if (d) delete d.approvals[approvalId]
}

onMounted(() => scrollBottom())
</script>

<template>
  <div class="wb">
    <!-- 顶栏 -->
    <header class="wb-head">
      <TaskTabs />
      <div class="head-right">
        <span v-if="busy || waitingHere" class="live">
          <span class="dot" :class="activeSession?.status"></span>
          {{ statusText[activeSession?.status] || '执行中' }}
        </span>
        <button v-if="busy || waitingHere" class="icon-btn" title="停止执行" @click="cancelSession(store.activeId)">
          <Icon name="stop" :size="15" />
        </button>
        <button v-if="pausedRun" class="icon-btn" title="断点续跑" @click="resumeSession(store.activeId)">
          <Icon name="refresh" :size="15" />
        </button>
        <button class="rsi-badge" :class="rsiMode" :title="'点击切换会话 RSI 模式'" @click="cycleRsi">
          <Icon name="zap" :size="12" /> {{ rsiLabel }}
        </button>
        <div class="usage" title="今日 token 用量">
          <Icon name="chart" :size="13" />
          <span>{{ shortNum(store.usageToday.total_tokens) }}</span>
        </div>
      </div>
    </header>

    <!-- 消息流 -->
    <div ref="streamEl" class="stream">
      <div class="stream-inner">
        <!-- 无打开任务 -->
        <div v-if="!store.activeId" class="hero">
          <div class="hero-orb"><Icon name="zap" :size="30" /></div>
          <h1 class="hero-title">开始锻造</h1>
          <p class="hero-sub">新建一个任务，或从左侧历史对话中选择继续。</p>
          <button class="btn btn-primary hero-btn" @click="openNewTaskDialog()">
            <Icon name="plus" :size="16" /> 新建任务
          </button>
        </div>

        <!-- 空任务欢迎 -->
        <div v-else-if="!hasContent && !busy" class="hero">
          <div class="hero-orb"><Icon name="zap" :size="30" /></div>
          <h1 class="hero-title">{{ greeting() }}，有什么要锻造的？</h1>
          <p class="hero-sub">描述任务，AI 工程师将在工作区内侦察、编码、验证 —— 全程可审批、可中断、可回溯。</p>
          <div class="shortcuts">
            <span><kbd>Enter</kbd> 发送</span>
            <span><kbd>Ctrl</kbd><kbd>K</kbd> 聚焦输入</span>
            <span><kbd>Ctrl</kbd><kbd>T</kbd> 新建任务</span>
            <span><kbd>Ctrl</kbd><kbd>B</kbd> 收起侧栏</span>
          </div>
        </div>

        <!-- 对话 -->
        <template v-else>
          <MessageBubble
            v-for="(m, i) in visibleMessages"
            :key="m.message_id || i"
            :message="m"
            :tools="dir?.tools || {}"
          />
          <MessageBubble
            v-if="dir?.draft"
            :draft="dir.draft"
            :tools="dir?.tools || {}"
            :streaming="busy"
          />
          <div v-for="a in approvals" :key="a.approval_id" class="approval-wrap">
            <div class="ap-avatar"><Icon name="shield" :size="13" /></div>
            <ApprovalCard :approval="a" @resolved="onResolved" />
          </div>
        </template>
      </div>
    </div>

    <!-- 输入区 -->
    <Composer v-if="store.activeId" :session-id="store.activeId" @send="onSend" />
    <div v-else class="no-tab">
      <button class="btn btn-primary" @click="openNewTaskDialog()"><Icon name="plus" :size="16" /> 新建任务开始</button>
    </div>
  </div>
</template>

<style scoped>
.wb { height: 100%; display: flex; flex-direction: column; min-height: 0; }

/* 顶栏 */
.wb-head {
  height: var(--head-h);
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 14px 0 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface-glass);
  backdrop-filter: blur(12px);
  z-index: 10;
}
.head-right { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
.live {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px;
  border-radius: var(--r-full);
  background: var(--surface-2);
  border: 1px solid var(--border);
  font-size: 11.5px;
  font-weight: 600;
  color: var(--text-2);
}
.usage {
  display: flex;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 10px;
  border-radius: var(--r-full);
  background: var(--surface-2);
  border: 1px solid var(--border);
  font-size: 11px;
  color: var(--text-3);
  font-variant-numeric: tabular-nums;
}
.rsi-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 26px;
  padding: 0 10px;
  border-radius: var(--r-full);
  border: 1px solid var(--border);
  background: var(--surface-2);
  color: var(--text-3);
  font-size: 11px;
  font-weight: 600;
}
.rsi-badge.observe { color: #b45309; border-color: #fde68a; background: #fffbeb; }
.rsi-badge.active { color: #047857; border-color: #a7f3d0; background: #ecfdf5; }
.rsi-badge.off { color: var(--text-3); }

/* 消息流 */
.stream { flex: 1; min-height: 0; overflow-y: auto; scroll-behavior: smooth; }
.stream-inner { max-width: 860px; margin: 0 auto; padding: 22px 24px 10px; }

/* 英雄区 */
.hero {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding-top: 6vh;
}
.hero-orb {
  width: 66px;
  height: 66px;
  border-radius: 20px;
  background: var(--brand-grad);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 10px 36px rgba(91, 91, 214, 0.4);
  margin-bottom: 22px;
  animation: orb-float 4s var(--ease) infinite;
  position: relative;
}
.hero-orb::after {
  content: '';
  position: absolute;
  inset: -12px;
  border-radius: 28px;
  background: var(--brand-grad);
  opacity: 0.14;
  filter: blur(18px);
  z-index: -1;
}
@keyframes orb-float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-7px); }
}
.hero-title { font-size: 25px; font-weight: 700; letter-spacing: -0.025em; }
.hero-sub { font-size: 13px; color: var(--text-3); max-width: 460px; line-height: 1.75; margin-top: 9px; }
.hero-btn { margin-top: 20px; height: 38px; padding: 0 20px; font-size: 13.5px; }

.shortcuts {
  display: flex;
  gap: 18px;
  margin-top: 34px;
  font-size: 11px;
  color: var(--text-3);
}
.shortcuts span { display: flex; align-items: center; gap: 4px; }
kbd {
  font-family: var(--font);
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 4px;
  background: var(--surface);
  border: 1px solid var(--border-2);
  color: var(--text-2);
  box-shadow: 0 1px 0 var(--border-2);
}

/* 审批 */
.approval-wrap { display: flex; align-items: flex-start; gap: 12px; margin: 16px 0; }
.ap-avatar {
  width: 28px;
  height: 28px;
  border-radius: 9px;
  background: var(--warn-soft);
  color: var(--warn);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 1px;
}

.no-tab { display: flex; justify-content: center; padding: 20px; }

@media (max-width: 720px) {
  .shortcuts { display: none; }
}
</style>
