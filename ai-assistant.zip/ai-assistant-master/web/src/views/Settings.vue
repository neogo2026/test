<script setup>
import { onMounted, ref } from 'vue'
import api from '../api/client'
import Icon from '../components/Icon.vue'
import { loadHealth, store, toast } from '../stores/app'

const plugins = ref([])
const busyPlugin = ref('')
const rsi = ref(null)
const rsiBusy = ref(false)

onMounted(async () => {
  await loadHealth()
  plugins.value = await api.get('/api/plugins')
  await loadRsi()
})

async function loadRsi() {
  try {
    rsi.value = await api.get('/api/rsi/status')
  } catch {
    rsi.value = null
  }
}

async function setRsiMode(mode) {
  if (rsiBusy.value) return
  rsiBusy.value = true
  try {
    rsi.value = await api.put('/api/rsi/settings', { mode })
    toast(`RSI 全局模式：${mode}`, 'ok')
  } catch (e) {
    toast(e.message, 'err')
  } finally {
    rsiBusy.value = false
  }
}

function keyInfo(name) {
  return store.health?.keys?.[name] || { configured: false, source: 'default', masked: '' }
}

async function togglePlugin(p) {
  busyPlugin.value = p.name
  try {
    await api.post(`/api/plugins/${p.name}/${p.enabled ? 'disable' : 'enable'}`)
    plugins.value = await api.get('/api/plugins')
    toast(`${p.title} 已${p.enabled ? '停用' : '启用'}`, 'ok')
  } catch (e) {
    toast(e.message, 'err')
  } finally {
    busyPlugin.value = ''
  }
}
</script>

<template>
  <div class="page">
    <header class="page-head">
      <div>
        <h2 class="page-title">设置</h2>
        <p class="page-sub">密钥 · 飞书连接 · 插件能力</p>
      </div>
    </header>

    <!-- 密钥 -->
    <section class="card section">
      <div class="section-head">
        <div class="section-icon brand"><Icon name="key" :size="16" /></div>
        <div>
          <h3>密钥配置</h3>
          <p>密钥仅保存在 <code>api/configs/secrets_local.py</code>（已 gitignore，绝不入库）</p>
        </div>
      </div>
      <div class="key-list">
        <div v-for="(info, name) in (store.health?.keys || {})" :key="name" class="key-row">
          <span class="key-name mono">{{ name }}</span>
          <span class="key-mask mono">{{ info.masked || '—' }}</span>
          <span class="key-src">{{ info.source }}</span>
          <span class="badge" :class="info.configured ? 'ok' : ''">{{ info.configured ? '已配置' : '未配置' }}</span>
        </div>
      </div>
      <p class="tip">
        <Icon name="info" :size="13" />
        参考模板：<code>api/configs/secrets_example.py</code>；也支持环境变量或复用上一代 AI助理 <code>tool/feishu.local.py</code>
      </p>
    </section>

    <!-- 飞书 -->
    <section class="card section">
      <div class="section-head">
        <div class="section-icon ok"><Icon name="message" :size="16" /></div>
        <div>
          <h3>飞书长程任务</h3>
          <p>配置 FEISHU_APP_ID / SECRET 后，可在手机 IM 里派活、审批、收结果</p>
        </div>
      </div>
      <div class="chips">
        <span class="badge" :class="store.health?.feishu?.configured ? 'ok' : ''">
          {{ store.health?.feishu?.configured ? '凭据已配置' : '未配置凭据' }}
        </span>
        <span class="badge" :class="store.health?.feishu?.sdk_installed ? 'ok' : ''">
          SDK {{ store.health?.feishu?.sdk_installed ? '已安装' : '未安装' }}
        </span>
        <span class="badge" :class="store.health?.feishu?.connected ? 'ok' : 'warn'">
          <span class="dot" :class="store.health?.feishu?.connected ? 'running' : 'idle'"></span>
          {{ store.health?.feishu?.connected ? '长连接运行中' : '未连接' }}
        </span>
      </div>
    </section>

    <!-- 自进化 RSI -->
    <section class="card section">
      <div class="section-head">
        <div class="section-icon brand"><Icon name="zap" :size="16" /></div>
        <div>
          <h3>自进化 RSI</h3>
          <p>轨迹采集 · 失败归因 · 候选评测 · 版本晋级/回滚；默认观察，主动模式由会话单独开启</p>
        </div>
      </div>
      <template v-if="rsi">
        <div class="rsi-kpis">
          <div class="rsi-kpi"><b>{{ rsi.stats.episodes }}</b><span>轨迹</span></div>
          <div class="rsi-kpi"><b>{{ rsi.stats.failures }}</b><span>失败</span></div>
          <div class="rsi-kpi"><b>{{ rsi.stats.candidates }}</b><span>候选</span></div>
          <div class="rsi-kpi"><b>{{ rsi.stats.active_memories }}</b><span>活跃资产</span></div>
        </div>
        <div class="rsi-row">
          <span class="rsi-label">全局模式</span>
          <div class="rsi-modes">
            <button
              v-for="mode in ['off', 'observe', 'active']"
              :key="mode"
              class="rsi-mode"
              :class="{ on: rsi.global_mode === mode }"
              :disabled="rsiBusy"
              @click="setRsiMode(mode)"
            >{{ mode }}</button>
          </div>
          <span class="rsi-version mono">active {{ rsi.active_version || '-' }}</span>
        </div>
        <p class="tip"><Icon name="info" :size="13" /> 关闭插件后工具与注入会立即摘除；会话级模式在新建任务时选择。</p>
      </template>
      <p v-else class="tip"><Icon name="alert" :size="13" /> RSI 插件未启用或未初始化。</p>
    </section>

    <!-- 插件 -->
    <section class="card section">
      <div class="section-head">
        <div class="section-icon warn"><Icon name="plug" :size="16" /></div>
        <div>
          <h3>插件管理</h3>
          <p>小内核 + 插件：一切能力皆插件，可随时启停（路由变更在重启后完全生效）</p>
        </div>
      </div>
      <div class="plugins">
        <div v-for="p in plugins" :key="p.name" class="plugin-row">
          <div class="plugin-main">
            <div class="plugin-title">
              {{ p.title }}
              <span v-if="p.version" class="plugin-ver mono">v{{ p.version }}</span>
            </div>
            <div class="plugin-desc">{{ p.description }}</div>
            <div v-if="p.error" class="plugin-err"><Icon name="alert" :size="12" /> {{ p.error }}</div>
          </div>
          <button
            class="switch"
            :class="{ on: p.enabled, busy: busyPlugin === p.name }"
            :title="p.enabled ? '点击停用' : '点击启用'"
            @click="togglePlugin(p)"
          >
            <span class="knob"></span>
          </button>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.page { height: 100%; overflow-y: auto; padding: 24px 28px; max-width: 880px; margin: 0 auto; }
.page-head { margin-bottom: 18px; }
.page-title { font-size: 20px; font-weight: 700; letter-spacing: -0.02em; }
.page-sub { font-size: 12.5px; color: var(--text-3); margin-top: 5px; }

.section { padding: 18px 20px; margin-bottom: 14px; }
.section-head { display: flex; gap: 12px; margin-bottom: 16px; }
.section-icon {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.section-icon.brand { background: var(--brand-soft); color: var(--brand); }
.section-icon.ok { background: var(--ok-soft); color: var(--ok); }
.section-icon.warn { background: var(--warn-soft); color: var(--warn); }
.section-head h3 { font-size: 14px; font-weight: 700; }
.section-head p { font-size: 12px; color: var(--text-3); margin-top: 3px; line-height: 1.6; }
code {
  font-family: var(--mono);
  font-size: 11px;
  background: var(--bg-sub);
  border: 1px solid var(--border);
  padding: 1px 5px;
  border-radius: 5px;
}

.key-list { border: 1px solid var(--border); border-radius: var(--r-s); overflow: hidden; }
.key-row {
  display: grid;
  grid-template-columns: 210px 1fr 150px 84px;
  align-items: center;
  gap: 10px;
  padding: 9px 13px;
  border-bottom: 1px solid var(--border);
  font-size: 12.3px;
}
.key-row:last-child { border-bottom: none; }
.key-row:nth-child(odd) { background: var(--surface-2); }
.key-name { font-size: 11.5px; font-weight: 600; color: var(--text); }
.key-mask { font-size: 11.5px; color: var(--text-3); }
.key-src { font-size: 11px; color: var(--text-3); overflow: hidden; text-overflow: ellipsis; }
.tip {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
  font-size: 11.5px;
  color: var(--text-3);
  line-height: 1.7;
}
.chips { display: flex; gap: 8px; flex-wrap: wrap; }

.rsi-kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
.rsi-kpi {
  border: 1px solid var(--border);
  border-radius: var(--r-s);
  background: var(--surface-2);
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.rsi-kpi b { font-size: 18px; color: var(--text); }
.rsi-kpi span { font-size: 11px; color: var(--text-3); }
.rsi-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.rsi-label { font-size: 12px; color: var(--text-3); }
.rsi-modes { display: flex; gap: 6px; }
.rsi-mode {
  font-size: 11.5px;
  padding: 5px 12px;
  border-radius: var(--r-full);
  border: 1px solid var(--border-2);
  background: var(--surface-2);
  color: var(--text-2);
  text-transform: lowercase;
}
.rsi-mode.on { background: var(--brand-grad); border-color: transparent; color: #fff; }
.rsi-mode:disabled { opacity: 0.6; }
.rsi-version { margin-left: auto; font-size: 11px; color: var(--text-3); }

.plugins { display: flex; flex-direction: column; }
.plugin-row {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 2px;
  border-bottom: 1px solid var(--border);
}
.plugin-row:last-child { border-bottom: none; }
.plugin-main { flex: 1; min-width: 0; }
.plugin-title { font-size: 13px; font-weight: 600; }
.plugin-ver { font-size: 10.5px; color: var(--text-3); margin-left: 6px; font-weight: 400; }
.plugin-desc { font-size: 11.5px; color: var(--text-3); margin-top: 2px; line-height: 1.6; }
.plugin-err { display: flex; align-items: center; gap: 4px; font-size: 11.5px; color: var(--err); margin-top: 4px; }

.switch {
  width: 40px;
  height: 23px;
  border-radius: var(--r-full);
  background: var(--surface-3);
  border: 1px solid var(--border-2);
  position: relative;
  transition: all 0.2s var(--ease);
  flex-shrink: 0;
}
.switch .knob {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 17px;
  height: 17px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
  transition: transform 0.2s var(--ease);
}
.switch.on { background: var(--brand-grad); border-color: transparent; }
.switch.on .knob { transform: translateX(17px); }
.switch.busy { opacity: 0.6; }
</style>
