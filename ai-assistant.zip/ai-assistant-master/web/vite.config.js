﻿import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

const API = process.env.FORGE_API || 'http://127.0.0.1:8036'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 8035,
    proxy: {
      '/api': { target: API, changeOrigin: true },
      '/ws': { target: API, ws: true },
    },
  },
})
