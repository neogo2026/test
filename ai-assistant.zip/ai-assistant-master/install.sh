#!/usr/bin/env bash
# ============================================================
# AI助理 Linux 一键安装
# ============================================================
set -e
cd "$(dirname "$0")"

echo "[1/3] 创建 Python 虚拟环境..."
python3 -m venv api/env1
api/env1/bin/pip install -q -r api/requirements.txt

echo "[2/3] 安装前端依赖并构建..."
cd web
npm install --no-fund --no-audit
npm run build
cd ..

if [ ! -f "api/configs/secrets_local.py" ]; then
    echo "[3/3] 首次运行：复制密钥模板 -> api/configs/secrets_local.py（请填入真实 Key）"
    cp api/configs/secrets_example.py api/configs/secrets_local.py
fi

echo "安装完成：bash start.sh 启动"
