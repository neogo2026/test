﻿# AI助理 · 下一代 AI 编程全能工作台

> 以 **agent-harness 框架**为后端底座重写，产品能力对齐 **上一代 AI助理**，架构全面升级。
> 「小内核 + 插件」· 顶部横向任务 Tab · 多任务异步并行 · 飞书长程任务 · Windows / Linux

---

## 界面速览

**① 主工作台** —— 顶部横向任务 Tab + 工具芯片 + Markdown 流式输出，AI 工程师边侦察、边改码、边验证：

![工作台](docs/screenshots/workbench-done.png)

**② 人工审批** —— 高危命令先「看清楚要执行什么」再批准，批准 / 拒绝内联卡一步到位：

![人工审批](docs/screenshots/workbench-approval.png)

**③ 空状态引导** —— 打开即用，一键新建任务：

![空状态](docs/screenshots/workbench-empty.png)

**④ 深色主题** —— 深浅双主题一键切换（左下角主题按钮）：

![深色主题](docs/screenshots/workbench-dark.png)

### 管理页面

| 技能库（Markdown 方法论，保存即生效） | 用量看板（按日 / 按模型，可导出 CSV） |
|---|---|
| ![技能库](docs/screenshots/skills.png) | ![用量看板](docs/screenshots/usage.png) |

**设置页** —— 密钥状态 · 飞书长连接 · 插件一键启停：

![设置](docs/screenshots/settings.png)

---

## 产品概览

| 维度 | 说明 |
|---|---|
| 定位 | 个人指挥 AI 员工并行干活的 AI 编程全能工具 |
| 后端 | `api/`：agent-harness 内核（契约+组合+事件溯源+审批恢复）+ 插件系统，FastAPI + SQLite，端口 8036 |
| 前端 | `web/`：Vue3 + Vite，**顶部横向任务 Tab**（多任务点选切换，非传统左侧栏） |
| 模型 | DeepSeek（deepseek-flash / deepseek-pro）· 智谱GLM Coding Plan（glm-5.3-flash / glm-5.3）· 任意 OpenAI 兼容渠道（零 Key 时仅内部使用 mock 自测，不在选择器展示）· **本地 Qwen3.5-2B-RSI**（:9065 服务运行时自动出现在模型选择器，带「本地」徽标） |
| 飞书 | WebSocket 长连接：IM 对话派活 / 审批 / 结果回传（复用 `tool/feishu.local.py`） |
| 部署 | Windows / Linux 统一 `deploy/`（start / stop / restart，支持 dev 模式）双平台 |

---

## 核心亮点

- **Run 即后台任务**：发消息立即返回，事件流经 WebSocket 实时推送，多任务异步并行，会话级 FIFO + 并发闸，慢客户端只丢自己的帧、绝不反压 Agent 循环。
- **门禁与审批**：`ask`（高风险写操作/命令逐条人工批准，默认）与 `allow_all`（信任任务全自动）双档位，随时即选即切；批准前先看「将执行什么」。
- **插件化内核**：工具、Agent、模型渠道、技能、飞书全是插件，内核零业务依赖，`设置 → 插件管理` 一键启停。
- **技能库**：Markdown 方法论按触发词自动注入上下文，界面里保存即生效。
- **用量记账**：按日 / 按模型 token 消耗看板 + CSV 导出。
- **自进化 RSI（双引擎）**：进化层插件（轨迹采集 → 失败归因 → 候选生成 → 评测 → 晋级/回滚）+ 本地 Qwen3.5-2B-RSI 私有模型（SFT / DPO / GRPO 训练链路）；默认 `observe` 只观察不改行为，可随时开关。
- **深浅双主题 · WS 断线自动重连 · Ctrl+T 新建任务 / Ctrl+K 聚焦输入 / Ctrl+B 收起侧栏**

---

## 自进化 RSI（双引擎）

> 目标：让 AI助理「越用越强，且变强可验证、可回滚」。方案与评测详见
> `test/disign/rsi-plugin-design.html` 与 `test/testing/index.html`。

**引擎 A · 进化层插件**（`api/plugins/extra/rsi`，默认 `observe`）：

- 六段闭环：**采集**（事件→episode）→ **归因**（失败打分 + 10 类根因）→ **候选**（技能/记忆/提示词补丁，默认 draft）→ **评测**（历史配对证据 / 沙箱）→ **门禁晋级** → **回滚**（版本指针，全审计）
- 开关：`FORGE_RSI_ENABLED` / `FORGE_RSI_MODE`（off / observe / active）；会话级模式在新建任务时选择或 `POST /api/rsi/sessions/{id}/mode`
- 模型工具：`rsi_recall / rsi_remember / rsi_reflect / rsi_propose / rsi_evaluate / rsi_promote / rsi_rollback …`
- 数据出口：`GET /api/rsi/export/{sft,dpo,eval}` → `api/data/rsi/exports/`（带 sha1 manifest）

**引擎 B · 本地模型工程**（`local-models/Qwen3.5-2B-RSI`）：

- OpenAI 兼容服务 `:9065`（基座 + 多 LoRA adapter、流式、tool_calls、版本/健康接口）
- 训练链路：`train prepare → sft → dpo → eval`（GRPO 实验性），adapter 带 manifest（模型/数据/模板 hash）
- `ModelSpec` 已预留 **Qwen3.5-9B / 35B-A3B**，迁移只换 spec，数据契约 / Recipe / 评测 / 接口不变
- 独立 `deploy/` 一键 start / stop / restart（Windows + Linux），默认懒加载（服务立即可访问）

**双引擎联动**：插件导出 JSONL → 模型工程 `train prepare/sft` → adapter 通过评测后放入
`adapters/qwen3.5-2b/rsi-v1/` → `:9065` 热加载 → AI助理 模型选择器灰度使用。

---

## 架构（相对上一代 AI助理 / agent-harness 的升级）

```
main.py（装配）
  ├── extensions/  内核 HTTP/WS 薄层
  ├── core/        内核：契约 · 存储 · 事件总线 · 策略 · 模型网关 · 运行时
  │      ├─ 后台异步 Run（asyncio.Task，不再阻塞请求）
  │      ├─ 会话级 FIFO + 跨会话并行 + 并发闸
  │      └─ 非阻塞 WS 广播（慢客户端只丢自己的帧，绝不反压 Agent 循环）
  ├── adapters/    Provider：mock + 通用 OpenAI 兼容（一适配器覆盖全渠道）
   ├── plugins/     ★ WordPress 式插件 + DeepSeek Harness「harness 即插件」
   │        ├─ core_tools   最小自测工具集（echo / now / calculator / run_python）
   │        ├─ dev_tools    编程主力（read/edit/multi_edit/grep/glob/shell…）+ coder Agent
   │        ├─ skills       Markdown 技能库（保存即生效）
   │        ├─ usage        token 用量记账
   │        ├─ feishu       飞书长程任务
   │        └─ rsi          ★ 自进化 RSI（采集/归因/候选/评测/晋级/记忆）
   └── V2 内核钩子：上下文 provider 链 · 模型前后中间件 · 工具前后中间件 ·
                    会话 capabilities · 事件退订与插件停用自动清理
```

**三项核心架构升级**（对齐并超越上一代 AI助理 的工程能力）：
1. **Run 即后台任务**：发消息立即返回，事件流实时推送（agent-harness 原为同步阻塞）；
2. **插件化内核**：主力能力（dev 工具/coder Agent）全部是插件装配，内核零业务依赖——为后续具身 harness 插件、SFT/RL 技能训练插件预留了插槽；
3. **事件总线三层设计**：WS 实时流（内存队列）+ 事实源落库（append-only）+ 旁路订阅者（飞书回传/用量记账）。

---

## 快速开始

### Windows

```bat
:: 仓库根目录下
deploy\start.bat          :: 生产模式：构建前端，单端口 http://127.0.0.1:8036
deploy\start.bat dev      :: 开发模式：API 8036 + 前端热更新 8035
deploy\stop.bat
deploy\restart.bat
```

或直接双击 **`desktop.exe`**（见文末「桌面启动器」）。

### Linux

```bash
bash install.sh                 # 可选：一键安装（venv + 前端构建 + 密钥模板）
deploy/start.sh                 # http://127.0.0.1:8036  （dev：deploy/start.sh dev）
deploy/stop.sh
deploy/restart.sh
```

### 密钥（重要）

LLM Key 等付费信息**只**存放于 `api/configs/secrets_local.py`（已被 .gitignore 忽略，绝不入库）：

```bash
cp api/configs/secrets_example.py api/configs/secrets_local.py   # 填入真实 Key
```

加载优先级：环境变量 > `secrets_local.py` > 上一代 AI助理 `tool/feishu.local.py`（飞书凭据自动复用）。
不配任何 Key 也能跑：自动进入 mock 模式，全链路可体验。接口文档见 `http://127.0.0.1:8036/docs`。

### 本地 RSI 模型（可选）

```bat
cd local-models\Qwen3.5-2B-RSI
deploy\start.bat        :: :9065，服务立即可访问；首次推理自动加载 2B 基座
```

服务运行时，AI助理 模型选择器自动出现 `qwen35-2b-rsi`（无需额外配置）；
Linux 用 `deploy/start.sh`。详见 `local-models/Qwen3.5-2B-RSI/README.md`。

---

## 前端交互设计

- **顶部横向任务 Tab**：新建任务在顶栏排开，状态灯（空闲/排队/执行中/待审批）一目了然，点选即切换；滚轮横滑、Ctrl+T 新建、中键关闭
- **工作台**：流式打字机输出 · 工具芯片（参数/结果展开）· 内联审批卡（批准前先看将执行什么）· 门禁档位与模型即选即切
- **空状态引导**：高频场景一键开始
- 深浅双主题 · WS 断线自动重连 · 技能/用量/设置管理页

---

## 插件开发（3 分钟上手）

在 `api/plugins/extra/` 下建一个目录，写 `plugin.py`：

```python
from plugins.base import Plugin, PluginContext, PluginMeta
from core.contracts import ToolSpec

class MyPlugin(Plugin):
    meta = PluginMeta(name="my", title="我的插件", version="0.1.0")

    def register(self, ctx: PluginContext):
        ctx.register_tool(
            ToolSpec(name="hello", description="打招呼"),
            lambda: {"msg": "hello"},
        )
        # 还可以：register_router / register_agent / register_provider
        #         register_screener / subscribe_events / set_skill_provider
        # V2 进化钩子：register_context_provider / register_model_middleware /
        #             register_tool_middleware（停用时自动清理，回到 baseline）

PLUGIN = MyPlugin()
```

重启后自动发现并在「设置 → 插件管理」出现开关。**具身 harness / 新模型渠道 / 行业工具集**都按此插槽接入。

---

## 自测

```bash
cd api
python script/selftest.py       # 全链路断言：健康/会话/工具/审批/黑名单/取消/技能/插件
python script/rsi_selftest.py   # RSI 进化闭环：采集→归因→候选→评测→晋级→回滚→导出→关闭
python script/ws_smoke.py       # WebSocket 实时流冒烟

cd ../local-models/Qwen3.5-2B-RSI
python scripts/selftest.py      # 模型工程自测（无权重，19 项）
```

---

## 目录

```
ai-assistant/
├── api/       后端（FastAPI + SQLite，端口 8036）
│     ├── core/        内核（契约 · 存储 · 事件总线 · 策略 · 模型网关 · 运行时 · 沙箱）
│     ├── plugins/     插件系统 + 内置插件（core_tools/dev_tools/skills/usage/feishu）
│     ├── adapters/    LLM Provider 适配（mock + 通用 OpenAI 兼容）
│     ├── extensions/  内核 HTTP/WS 层（system/sessions/ws/plugins）
│     ├── configs/     配置与密钥加载（secrets_local.py 已 gitignore）
│     ├── skills/      Markdown 技能包
│     └── script/      自测脚本
├── web/       前端（Vue3 + Vite，dev 8035 / 生产由 api 托管）
├── local-models/
│   └── Qwen3.5-2B-RSI/   本地自进化模型工程（:9065 推理 + SFT/DPO/GRPO 训练 + deploy）
├── launcher/  桌面启动器源码（launcher.py / launcher_core.py）
├── docs/      文档与截图（docs/screenshots/）
├── test/      评测与回归（testing/index.html RSI 三方评测、testing/local-model-concurrency.html 并发评测）
├── deploy/      启动 / 停止 / 重启脚本（Windows .bat + Linux .sh，详见 deploy/README.md）
├── install.sh   Linux 一键安装（venv + 前端构建 + 密钥模板）
└── .gitignore   # secrets_local.py / *.local.py / api/data/ / node_modules 等均忽略
```

---

## 路线图

1. **自进化 RSI · 已落地（V2 双引擎）**：进化层插件 + Qwen3.5-2B-RSI 私有化训练链路；后续：
   9B / 35B-A3B ModelSpec 迁移、vLLM multi-LoRA 真并发后端、GRPO 可验证奖励、行为循环治理（重复工具调用检测）
2. **具身 harness 插件**：安装小车 / 机械臂 / 人形机器人 harness，用 `register_agent + register_provider` 组合出具身大脑
3. 多 Agent 编排（DAG）、子代理隔离上下文、更智能的上下文压缩（摘要式）

---

## 桌面启动器（Windows EXE）

双击 **`desktop.exe`**（位于仓库根目录），即可用图形界面管理工具：

| 功能 | 说明 |
|---|---|
| ▶ 全部启动 | 启动后端 API（8036）；勾选“包含前端开发”则同时启动 Vite（8035） |
| ■ 全部关闭 | 停止全部服务并释放端口 |
| 单服务启停 | 后端 API / 前端开发服务各自独立的「启动 / 停止」按钮 |
| 🌐 打开网页 | 打开工作台；服务未运行时自动先拉起后端 |
| 📦 安装/更新依赖 | 创建 venv、pip 安装、npm install、前端构建（首次部署用） |
| 📂 打开目录 | 打开项目文件夹 |
| 状态灯 + 实时日志 | 运行状态每秒刷新，服务输出实时滚动 |

- 首次启动若缺少 `api/configs/secrets_local.py`，会自动从模板生成（请填入真实 Key）。
- 自检：`desktop.exe --selftest`（无界面，结果写入 `selftest_result.txt`）。
- 源码：`launcher/launcher.py`（界面）与 `launcher/launcher_core.py`（服务管理，可复用）。
