# AI助理 Windows stop helper
# Stops API (python main.py, port FORGE_PORT/8036) and optional Vite dev server (port 8035).
$ErrorActionPreference = "SilentlyContinue"

$Deploy = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Deploy
Set-Location $Root

$RunDir = Join-Path $Deploy "run"
$ApiPidFile = Join-Path $RunDir "api.pid"
$WebPidFile = Join-Path $RunDir "web.pid"
$ApiPort = if ($env:FORGE_PORT) { [int]$env:FORGE_PORT } else { 8036 }
$WebPort = if ($env:WEB_DEV_PORT) { [int]$env:WEB_DEV_PORT } else { 8035 }

function Get-Candidates([int]$Port, [string]$PidFile, [string]$Pattern) {
    $pids = @()
    if (Test-Path $PidFile) {
        $raw = Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($raw -match '^\d+$') { $pids += [int]$raw }
    }
    $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($conns) { $pids += ($conns | Select-Object -ExpandProperty OwningProcess) }
    return ($pids | Where-Object { $_ -and $_ -gt 0 } | Sort-Object -Unique), $Pattern
}

function Stop-Matching([int]$Port, [string]$PidFile, [string]$Pattern, [string]$Label) {
    $candidates = Get-Candidates $Port $PidFile $Pattern
    $stopped = @()
    $skipped = @()
    foreach ($procId in $candidates) {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction SilentlyContinue
        if (-not $proc) { continue }
        if ($proc.CommandLine -and $proc.CommandLine -match $Pattern) {
            taskkill /PID $procId /T /F 2>$null | Out-Null
            $stopped += $procId
        } else {
            $skipped += $procId
        }
    }
    if ($stopped.Count -gt 0) {
        Write-Host "[OK] Stopped $Label (PID: $($stopped -join ', '))"
    } elseif ($skipped.Count -gt 0) {
        Write-Host "[WARN] Port $Port used by non-matching process(es): $($skipped -join ', '); not killed."
    } else {
        Write-Host "[INFO] $Label is not running."
    }
}

Stop-Matching $ApiPort $ApiPidFile 'main\.py' "AI助理 API"
Stop-Matching $WebPort $WebPidFile 'vite|npm run dev|node' "AI助理 Web (dev)"

Remove-Item $ApiPidFile -ErrorAction SilentlyContinue
Remove-Item $WebPidFile -ErrorAction SilentlyContinue
exit 0
