@echo off
setlocal EnableExtensions
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0win_stop.ps1"
set "CODE=%ERRORLEVEL%"
if /i not "%1"=="/nopause" pause
endlocal & exit /b %CODE%
