# AI助理 部署脚本

统一在 `deploy/` 下管理 AI助理 的启动、停止、重启。服务后台运行，日志和 PID 在 `deploy/run/`。

## Windows

```bat
deploy\start.bat          :: 生产模式（构建前端 + 单端口 http://127.0.0.1:8036）
deploy\start.bat dev      :: 开发模式（API 8036 + Vite 热更新 8035）
deploy\stop.bat
deploy\restart.bat
deploy\restart.bat dev
```

脚本末尾会暂停显示结果；追加 `/nopause` 可跳过（脚本内部调用已自动跳过）。

## Linux / macOS

```bash
chmod +x deploy/*.sh
./deploy/start.sh          # 生产模式（dist 缺失或 FORCE_BUILD=1 时构建）
./deploy/start.sh dev      # 开发模式
./deploy/stop.sh
./deploy/restart.sh
./deploy/restart.sh dev
```

## 行为说明

- **Windows**：API / Vite 运行在**独立的最小化控制台窗口**（标题 `AI助理 API` / `AI助理 Web`），
  启动窗口可直接关闭；**关闭那个最小化窗口 = 停止对应服务**（也可用 `stop.bat`）
- **生产模式**：Windows 每次启动都 `npm run build`；Linux 默认复用 `web/dist`，设 `FORCE_BUILD=1` 强制重建
- 后台运行：日志与 PID 在 `deploy/run/`
  - `api.out.log` / `api.err.log` / `api.pid`
  - `web.out.log` / `web.err.log` / `web.pid`（仅 dev）
- `stop` 按 PID 文件 + 端口查找，只终止命令行匹配的进程（API 匹配 `main.py`，Web 匹配 `vite`），不会误杀占用端口的无关进程
- `restart` = 停止 → 等待 → 启动，参数原样透传（支持 `dev`）
- 首次运行自动：创建 `api/env1` 虚拟环境、安装后端依赖、生成 `api/configs/secrets_local.py` 模板

## 环境变量

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `FORGE_PORT` | `8036` | API 端口 |
| `FORGE_HOST` | `127.0.0.1` | API 监听地址 |
| `WEB_DEV_PORT` | `8035` | dev 模式 Vite 端口 |
| `FORCE_BUILD` | 空 | 设为 `1` 强制重建前端（Linux 生产模式默认复用 dist） |
| `PYTHON` | 自动 | Linux 指定系统 Python（仅创建 venv 时使用） |

## 就绪检查

```text
http://127.0.0.1:8036/api/ping
http://127.0.0.1:8036/
```

> Windows 脚本输出使用英文（避免 cmd 中文编码问题）；Linux 脚本输出中文。中文说明以本文件为准。
