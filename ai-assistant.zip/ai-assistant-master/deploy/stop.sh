#!/usr/bin/env bash
# AI助理 Linux/macOS 停止（API + 可选 Vite dev）
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DEPLOY/.." && pwd)"
cd "$ROOT"

RUN_DIR="$DEPLOY/run"
API_PID_FILE="$RUN_DIR/api.pid"
WEB_PID_FILE="$RUN_DIR/web.pid"
API_PORT="${FORGE_PORT:-8036}"
WEB_PORT="${WEB_DEV_PORT:-8035}"

stop_one() {
  local label="$1" port="$2" pidfile="$3" pattern="$4"
  local candidates=()
  if [ -f "$pidfile" ]; then
    local raw
    raw="$(head -n1 "$pidfile" 2>/dev/null || true)"
    [[ "$raw" =~ ^[0-9]+$ ]] && candidates+=("$raw")
  fi
  if command -v lsof >/dev/null 2>&1; then
    while IFS= read -r pid; do
      [ -n "$pid" ] && candidates+=("$pid")
    done < <(lsof -ti "tcp:$port" 2>/dev/null || true)
  fi

  local unique=()
  for pid in "${candidates[@]:-}"; do
    [ -z "$pid" ] && continue
    local dup=0
    for seen in "${unique[@]:-}"; do [ "$seen" = "$pid" ] && dup=1 && break; done
    [ "$dup" = 0 ] && unique+=("$pid")
  done

  local stopped=() skipped=()
  for pid in "${unique[@]:-}"; do
    [ -z "$pid" ] && continue
    kill -0 "$pid" 2>/dev/null || continue
    local cmd
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || ps -p "$pid" -o command= 2>/dev/null || true)"
    if [[ "$cmd" != *$pattern* ]]; then
      skipped+=("$pid")
      continue
    fi
    kill "$pid" 2>/dev/null || true
    for _ in $(seq 1 30); do
      kill -0 "$pid" 2>/dev/null || break
      sleep 0.5
    done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
    stopped+=("$pid")
  done

  if [ "${#stopped[@]}" -gt 0 ]; then
    echo "[OK] 已停止 $label（PID: ${stopped[*]}）"
  elif [ "${#skipped[@]}" -gt 0 ]; then
    echo "[WARN] 端口 $port 被非匹配进程占用（PID: ${skipped[*]}），未终止。"
  else
    echo "[INFO] $label 未在运行。"
  fi
}

stop_one "AI助理 API" "$API_PORT" "$API_PID_FILE" "main.py"
stop_one "AI助理 Web (dev)" "$WEB_PORT" "$WEB_PID_FILE" "vite"

rm -f "$API_PID_FILE" "$WEB_PID_FILE"
