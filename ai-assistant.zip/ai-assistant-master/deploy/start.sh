#!/usr/bin/env bash
# AI助理 Linux/macOS 启动（后台运行）
# 用法：deploy/start.sh [dev]   dev=API 8036 + Vite 热更新 8035
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DEPLOY/.." && pwd)"
cd "$ROOT"

MODE="${1:-}"
RUN_DIR="$DEPLOY/run"
mkdir -p "$RUN_DIR"
API_PID_FILE="$RUN_DIR/api.pid"
WEB_PID_FILE="$RUN_DIR/web.pid"
API_OUT_LOG="$RUN_DIR/api.out.log"
API_ERR_LOG="$RUN_DIR/api.err.log"
WEB_OUT_LOG="$RUN_DIR/web.out.log"
WEB_ERR_LOG="$RUN_DIR/web.err.log"

API_PORT="${FORGE_PORT:-8036}"
WEB_PORT="${WEB_DEV_PORT:-8035}"
API_URL="http://127.0.0.1:$API_PORT"
WEB_URL="http://localhost:$WEB_PORT"

export FORGE_HOST="${FORGE_HOST:-127.0.0.1}"
export FORGE_PORT="$API_PORT"
export PYTHONUTF8="${PYTHONUTF8:-1}"
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"

port_ours() {
  local port="$1" pattern="$2"
  local pids=""
  if command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -ti "tcp:$port" 2>/dev/null || true)"
  fi
  for pid in $pids; do
    local cmd
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || ps -p "$pid" -o command= 2>/dev/null || true)"
    if [[ "$cmd" == *$pattern* ]]; then
      echo "$pid"
      return 0
    fi
  done
  return 1
}

# ---- 已在运行？ ----
if old_pid="$(port_ours "$API_PORT" "main.py")"; then
  echo "[INFO] AI助理 API 已在运行（PID: $old_pid）：$API_URL"
  exit 0
fi
if command -v lsof >/dev/null 2>&1 && lsof -ti "tcp:$API_PORT" >/dev/null 2>&1; then
  echo "[ERROR] 端口 $API_PORT 已被其他进程占用，请先停止或设置 FORGE_PORT。"
  exit 1
fi

echo "============================================================"
echo " AI助理"
echo " Mode : $(if [ "$MODE" = "dev" ]; then echo 'dev (API + Vite 热更新)'; else echo 'production (单端口)'; fi)"
echo " API  : $API_URL"
if [ "$MODE" = "dev" ]; then echo " Web  : $WEB_URL (dev)"; fi
echo "============================================================"

# ---- Python venv ----
VENV_PY="$ROOT/api/env1/bin/python"
if [ ! -x "$VENV_PY" ]; then
  echo "[1/4] 创建 Python 虚拟环境（api/env1）..."
  if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] 未找到 python3，请安装 Python 3.10+。"
    exit 1
  fi
  python3 -m venv api/env1
else
  echo "[1/4] venv 已就绪（api/env1）"
fi

# ---- 后端依赖 + 密钥模板 ----
echo "[2/4] 检查后端依赖..."
"$VENV_PY" -m pip install -q -r "$ROOT/api/requirements.txt"
if [ ! -f "$ROOT/api/configs/secrets_local.py" ] && [ -f "$ROOT/api/configs/secrets_example.py" ]; then
  cp "$ROOT/api/configs/secrets_example.py" "$ROOT/api/configs/secrets_local.py"
  echo "       首次运行：已生成 api/configs/secrets_local.py（可填入真实 API Key）"
fi

# ---- 前端 ----
if [ "$MODE" = "dev" ]; then
  echo "[3/4] 开发模式：准备前端..."
  if [ ! -d "$ROOT/web/node_modules" ]; then
    (cd "$ROOT/web" && npm install --no-fund --no-audit)
  fi
else
  echo "[3/4] 构建前端..."
  if [ ! -f "$ROOT/web/dist/index.html" ] || [ -n "${FORCE_BUILD:-}" ]; then
    if [ ! -d "$ROOT/web/node_modules" ]; then
      (cd "$ROOT/web" && npm install --no-fund --no-audit)
    fi
    (cd "$ROOT/web" && npm run build)
  else
    echo "       复用现有 web/dist（设置 FORCE_BUILD=1 强制重建）"
  fi
fi

# ---- 启动 API（后台） ----
echo "[4/4] 后台启动 API..."
nohup "$VENV_PY" api/main.py >>"$API_OUT_LOG" 2>&1 &
API_PID=$!
echo "$API_PID" > "$API_PID_FILE"

API_READY=0
for _ in $(seq 1 60); do
  if ! kill -0 "$API_PID" 2>/dev/null; then break; fi
  if command -v curl >/dev/null 2>&1; then
    if curl -sf "$API_URL/api/ping" >/dev/null 2>&1; then API_READY=1; break; fi
  else
    if "$VENV_PY" -c "import sys,urllib.request; urllib.request.urlopen('http://127.0.0.1:'+sys.argv[1]+'/api/ping', timeout=1)" "$API_PORT" >/dev/null 2>&1; then
      API_READY=1; break
    fi
  fi
  sleep 0.5
done

if ! kill -0 "$API_PID" 2>/dev/null; then
  echo "[ERROR] API 启动失败，请查看日志："
  echo "        $API_OUT_LOG"
  echo "        $API_ERR_LOG"
  rm -f "$API_PID_FILE"
  exit 1
fi
if [ "$API_READY" != "1" ]; then
  echo "[WARN] API 已启动（PID: $API_PID），但健康检查尚未就绪。"
fi

# ---- dev 模式：启动 Vite ----
if [ "$MODE" = "dev" ]; then
  (cd "$ROOT/web" && nohup npm run dev >>"$WEB_OUT_LOG" 2>&1 & echo $! > "$WEB_PID_FILE")
  WEB_PID="$(cat "$WEB_PID_FILE" 2>/dev/null || true)"
  WEB_READY=0
  if [ -n "$WEB_PID" ]; then
    for _ in $(seq 1 60); do
      if ! kill -0 "$WEB_PID" 2>/dev/null; then break; fi
      if command -v curl >/dev/null 2>&1 && curl -sf "$WEB_URL" >/dev/null 2>&1; then WEB_READY=1; break; fi
      sleep 0.5
    done
  fi
  if [ "$WEB_READY" = "1" ]; then
    echo "[OK] Web 开发服务器已就绪（PID: $WEB_PID）"
  else
    echo "[WARN] Vite 尚未就绪，稍后手动打开 $WEB_URL；日志：$WEB_ERR_LOG"
  fi
fi

echo ""
echo "[OK] 已启动（API PID: $API_PID）"
echo "     URL  : $(if [ "$MODE" = "dev" ]; then echo "$WEB_URL"; else echo "$API_URL"; fi)"
echo "     日志 : $API_OUT_LOG"
echo "            $API_ERR_LOG"
echo "     停止 : deploy/stop.sh"
echo "     重启 : deploy/restart.sh"
