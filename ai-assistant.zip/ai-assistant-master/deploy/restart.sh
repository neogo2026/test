#!/usr/bin/env bash
# AI助理 Linux/macOS 重启
# 用法：deploy/restart.sh [dev]
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
"$DEPLOY/stop.sh"
sleep 1
exec "$DEPLOY/start.sh" "$@"
