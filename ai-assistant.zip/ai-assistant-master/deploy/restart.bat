@echo off
setlocal EnableExtensions
rem Usage: deploy\restart.bat [dev] [/nopause]
call "%~dp0stop.bat" /nopause
timeout /t 2 /nobreak >nul
call "%~dp0start.bat" %1 /nopause
set "CODE=%ERRORLEVEL%"
if /i not "%1"=="/nopause" pause
endlocal & exit /b %CODE%
