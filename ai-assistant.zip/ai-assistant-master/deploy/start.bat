@echo off
setlocal EnableExtensions
rem Usage: deploy\start.bat [dev] [/nopause]
set "MODE="
if /i "%1"=="dev" set "MODE=dev"
if /i "%2"=="dev" set "MODE=dev"
set "NOPAUSE="
if /i "%1"=="/nopause" set "NOPAUSE=1"
if /i "%2"=="/nopause" set "NOPAUSE=1"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0win_start.ps1" -Mode "%MODE%"
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" (
  pause
) else if not defined NOPAUSE (
  pause
)
endlocal & exit /b %CODE%
