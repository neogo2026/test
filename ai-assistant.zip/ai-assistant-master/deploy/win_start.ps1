# AI助理 Windows background launcher
# Usage: powershell -File win_start.ps1 [-Mode dev|""] ; env: FORGE_PORT, WEB_DEV_PORT, FORCE_BUILD
# API/Vite run in their own minimized consoles (start /min), detached from this window,
# logs are appended to deploy\run\*.log, PIDs are resolved from the listening ports.
param([string]$Mode = "")

$ErrorActionPreference = "Stop"

$Deploy = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Deploy
Set-Location $Root

$RunDir = Join-Path $Deploy "run"
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$ApiPidFile = Join-Path $RunDir "api.pid"
$WebPidFile = Join-Path $RunDir "web.pid"
$ApiOutLog = Join-Path $RunDir "api.out.log"
$ApiErrLog = Join-Path $RunDir "api.err.log"
$WebOutLog = Join-Path $RunDir "web.out.log"
$WebErrLog = Join-Path $RunDir "web.err.log"

function Set-DefaultEnv([string]$Name, [string]$Value) {
    if (-not [Environment]::GetEnvironmentVariable($Name)) {
        [Environment]::SetEnvironmentVariable($Name, $Value, "Process")
    }
}

Set-DefaultEnv "FORGE_HOST" "127.0.0.1"
Set-DefaultEnv "FORGE_PORT" "8036"
Set-DefaultEnv "WEB_DEV_PORT" "8035"
Set-DefaultEnv "PYTHONUTF8" "1"
Set-DefaultEnv "PYTHONIOENCODING" "utf-8"

$ApiPort = $env:FORGE_PORT
$WebPort = $env:WEB_DEV_PORT
$ApiUrl = "http://127.0.0.1:$ApiPort"
$WebUrl = "http://localhost:$WebPort"

function Test-PortState([int]$Port, [string]$Pattern) {
    $conn = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if (-not $conn) { return "free" }
    foreach ($owner in ($conn | Select-Object -ExpandProperty OwningProcess -Unique)) {
        $p = Get-CimInstance Win32_Process -Filter "ProcessId=$owner" -ErrorAction SilentlyContinue
        if ($p -and $p.CommandLine -match $Pattern) { return "ours" }
    }
    return "other"
}

function Get-ListenerPid([int]$Port) {
    $c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return [int]$c.OwningProcess }
    return $null
}

# ---- Already running? ----
$ApiState = Test-PortState ([int]$ApiPort) 'main\.py'
if ($ApiState -eq "ours") {
    $existingPid = Get-ListenerPid ([int]$ApiPort)
    if ($existingPid) { $existingPid | Set-Content -Encoding ASCII $ApiPidFile }
    Write-Host "[INFO] AI助理 API already listening on $ApiUrl (PID: $existingPid)"
    exit 0
}
if ($ApiState -eq "other") {
    Write-Host "[ERROR] Port $ApiPort is used by another process. Stop it or set FORGE_PORT."
    exit 1
}

Write-Host "============================================================"
Write-Host " AI助理"
Write-Host " Mode : $(if ($Mode -eq 'dev') { 'dev (API + Vite hot reload)' } else { 'production (single port)' })"
Write-Host " API  : $ApiUrl"
if ($Mode -eq "dev") { Write-Host " Web  : $WebUrl (dev)" }
Write-Host "============================================================"

# ---- Python venv ----
$VenvPython = Join-Path $Root "api\env1\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    Write-Host "[1/4] Creating Python venv (api\env1)..."
    $sysPy = Get-Command python -ErrorAction SilentlyContinue
    $sysArgs = @()
    if (-not $sysPy) {
        $sysPy = Get-Command py -ErrorAction SilentlyContinue
        $sysArgs = @("-3")
    }
    if (-not $sysPy) {
        Write-Host "[ERROR] Python not found. Install Python 3.10+ and add it to PATH."
        exit 1
    }
    $OldEap = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
    & $sysPy.Source @sysArgs -m venv (Join-Path $Root "api\env1") | Out-Null
    $ErrorActionPreference = $OldEap
    if (-not (Test-Path $VenvPython)) {
        Write-Host "[ERROR] Failed to create venv. See messages above."
        exit 1
    }
} else {
    Write-Host "[1/4] venv ready (api\env1)"
}

# ---- Backend deps + secrets bootstrap ----
Write-Host "[2/4] Checking backend dependencies..."
$OldEap = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
& $VenvPython -m pip install -q -r (Join-Path $Root "api\requirements.txt") *> $null
$DepCode = $LASTEXITCODE
$ErrorActionPreference = $OldEap
if ($DepCode -ne 0) {
    Write-Host "[ERROR] pip install failed (exit $DepCode). Check network or requirements.txt."
    exit 1
}
$SecretsLocal = Join-Path $Root "api\configs\secrets_local.py"
$SecretsExample = Join-Path $Root "api\configs\secrets_example.py"
if ((-not (Test-Path $SecretsLocal)) -and (Test-Path $SecretsExample)) {
    Copy-Item $SecretsExample $SecretsLocal
    Write-Host "       First run: created api\configs\secrets_local.py (fill your API keys)"
}

# ---- Frontend ----
$WebDir = Join-Path $Root "web"
$Npm = Get-Command npm -ErrorAction SilentlyContinue
$DistIndex = Join-Path $WebDir "dist\index.html"

if ($Mode -eq "dev") {
    Write-Host "[3/4] Dev mode: preparing frontend..."
    if (-not (Test-Path (Join-Path $WebDir "node_modules"))) {
        if (-not $Npm) { Write-Host "[ERROR] npm not found. Install Node.js."; exit 1 }
        $OldEap = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        & cmd.exe /c "npm install --no-fund --no-audit" 2>&1 | Out-Null
        $ErrorActionPreference = $OldEap
    }
} else {
    Write-Host "[3/4] Building frontend..."
    $NeedBuild = $true
    if ((-not $env:FORCE_BUILD) -and (Test-Path $DistIndex)) { $NeedBuild = $false }
    if ($NeedBuild) {
        if (-not $Npm) {
            if (Test-Path $DistIndex) {
                Write-Host "[WARN] npm not found; reuse existing web\dist"
                $NeedBuild = $false
            } else {
                Write-Host "[ERROR] npm not found and web\dist missing. Install Node.js."
                exit 1
            }
        }
    }
    if ($NeedBuild) {
        if (-not (Test-Path (Join-Path $WebDir "node_modules"))) {
            $OldEap = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
            & cmd.exe /c "cd /d `"$WebDir`" && npm install --no-fund --no-audit" 2>&1 | Out-Null
            $ErrorActionPreference = $OldEap
        }
        $OldEap = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        & cmd.exe /c "cd /d `"$WebDir`" && npm run build" 2>&1 | Out-Null
        $BuildCode = $LASTEXITCODE
        $ErrorActionPreference = $OldEap
        if ($BuildCode -ne 0) {
            Write-Host "[ERROR] npm run build failed (exit $BuildCode)."
            exit 1
        }
    } else {
        Write-Host "       Reusing existing web\dist (set FORCE_BUILD=1 to rebuild)"
    }
}

# ---- Start API in its own minimized console (detached) ----
Write-Host "[4/4] Starting API (own minimized console)..."
$apiCmd = 'start "AI助理 API" /min /D "' + $Root + '" cmd /c ""' + $VenvPython + '" api\main.py >> "' + $ApiOutLog + '" 2>> "' + $ApiErrLog + '""'
Start-Process -FilePath "$env:ComSpec" -ArgumentList "/c", $apiCmd -WindowStyle Hidden -WorkingDirectory $Root | Out-Null

$ApiReady = $false
for ($i = 0; $i -lt 90; $i++) {
    Start-Sleep -Milliseconds 500
    try {
        $resp = Invoke-RestMethod -Uri "$ApiUrl/api/ping" -TimeoutSec 1
        if ($resp.code -eq 200) { $ApiReady = $true; break }
    } catch { }
}

$ApiPid = Get-ListenerPid ([int]$ApiPort)
if (-not $ApiReady -or -not $ApiPid) {
    Write-Host "[ERROR] API not ready within 45s. Check: $ApiErrLog"
    exit 1
}
$ApiPid | Set-Content -Encoding ASCII $ApiPidFile

# ---- Dev mode: start Vite in its own minimized console ----
if ($Mode -eq "dev") {
    $webCmd = 'start "AI助理 Web" /min /D "' + $WebDir + '" cmd /c "npm run dev >> "' + $WebOutLog + '" 2>> "' + $WebErrLog + '""'
    Start-Process -FilePath "$env:ComSpec" -ArgumentList "/c", $webCmd -WindowStyle Hidden -WorkingDirectory $WebDir | Out-Null
    $WebReady = $false
    for ($i = 0; $i -lt 90; $i++) {
        Start-Sleep -Milliseconds 500
        try {
            $r = Invoke-WebRequest -Uri $WebUrl -UseBasicParsing -TimeoutSec 1
            if ($r.StatusCode -eq 200) { $WebReady = $true; break }
        } catch { }
    }
    $WebPid = Get-ListenerPid ([int]$WebPort)
    if ($WebReady -and $WebPid) {
        $WebPid | Set-Content -Encoding ASCII $WebPidFile
        Write-Host "[OK] Web dev server ready (PID: $WebPid)"
        Start-Process $WebUrl
    } else {
        Write-Host "[WARN] Vite dev server not ready yet; open $WebUrl manually later. Log: $WebErrLog"
    }
} else {
    Start-Process $ApiUrl
}

Write-Host ""
Write-Host "[OK] Started (API PID: $ApiPid)"
Write-Host "     URL    : $(if ($Mode -eq 'dev') { $WebUrl } else { $ApiUrl })"
Write-Host "     Logs   : $ApiOutLog"
Write-Host "              $ApiErrLog"
Write-Host "     Console: minimized windows 'AI助理 API" + $(if ($Mode -eq 'dev') { " / AI助理 Web" } else { "" }) + "'"
Write-Host "     Stop   : deploy\stop.bat"
Write-Host "     Restart: deploy\restart.bat"
exit 0
