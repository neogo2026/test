import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from launcher_core import ServiceManager, port_open  # noqa: E402

BASE = Path(r"D:\Env\git\ai-assistant\v1")
logs = []
mgr = ServiceManager(BASE, log=lambda tag, msg: logs.append(f"[{tag}] {msg}"))

print("1) 停止后端 …")
print("   ", mgr.stop_api(), "| port:", port_open(8036))

print("2) 启动后端 …")
ok, msg = mgr.start_api()
print("   ", ok, msg, "| port:", port_open(8036))

print("3) 再次停止后端 …")
print("   ", mgr.stop_api(), "| port:", port_open(8036))

print("4) 全部关闭 …")
print("   ", mgr.stop_all())
print("5) 状态:", mgr.status())
print("6) 网页地址:", mgr.web_url())
print("--- logs ---")
for line in logs[-12:]:
    print(line)
