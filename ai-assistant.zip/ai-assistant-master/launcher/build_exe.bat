@echo off
title Build AI Assistant Launcher EXE
setlocal

set "HERE=%~dp0"
set "ROOT=%HERE%.."
set "PY=%ROOT%\api\env1\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

echo [1/2] installing pyinstaller ...
"%PY%" -m pip install -q pyinstaller || goto :err

echo [2/2] building exe (may take 1-2 minutes) ...
"%PY%" -m PyInstaller --clean --noconfirm "AI-Assistant-Launcher.spec" || goto :err

copy /y "%HERE%dist\desktop.exe" "%ROOT%\desktop.exe" >nul
echo.
echo [DONE] %ROOT%\desktop.exe
pause
exit /b 0

:err
echo [ERROR] build failed, see messages above.
pause
exit /b 1
