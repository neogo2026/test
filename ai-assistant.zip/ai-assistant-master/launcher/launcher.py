# -*- coding: utf-8 -*-
"""AI助理 桌面启动器（Windows GUI）。

功能：全部启动 / 全部关闭 / 单服务启停 / 打开网页 / 安装依赖 / 实时日志 / 状态灯。
自检：`desktop.exe --selftest`（无界面，结果写入 selftest_result.txt）。
"""
from __future__ import annotations

import argparse
import os
import queue
import sys
import threading
import time
import traceback
from pathlib import Path

# ---------------- 路径 / 依赖 ----------------
APP_TITLE = "AI助理 控制台"
VERSION = "1.0.0"

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

sys.path.insert(0, str(APP_DIR))
from launcher_core import ServiceManager, find_base_dir, port_open  # noqa: E402

BASE = find_base_dir(APP_DIR)
if BASE is None:
    # 允许 exe 位于 v1/launcher/dist 或 v1 下
    for cand in [APP_DIR, *APP_DIR.parents]:
        if (cand / "api").exists() and (cand / "web").exists():
            BASE = cand
            break
if BASE is None:
    BASE = APP_DIR.parent if (APP_DIR.parent / "api").exists() else APP_DIR


# ---------------- 自检模式 ----------------
def run_selftest() -> int:
    out = []
    try:
        mgr = ServiceManager(BASE, log=lambda tag, msg: out.append(f"[{tag}] {msg}"))
        out.append(f"BASE={BASE}")
        ok, lines = mgr.selftest()
        out.extend(lines)
        result = "PASS" if ok else "FAIL"
    except Exception:  # noqa: BLE001
        out.append(traceback.format_exc())
        result = "FAIL"
    out.append(f"RESULT={result}")
    target = APP_DIR / "selftest_result.txt"
    try:
        target.write_text("\n".join(out), encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    try:
        print("\n".join(out))
    except Exception:  # noqa: BLE001
        pass
    return 0 if result == "PASS" else 1


# ---------------- GUI ----------------
def run_gui() -> int:
    import tkinter as tk
    from tkinter import font as tkfont
    from tkinter import messagebox, scrolledtext

    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:  # noqa: BLE001
            pass

    C = {
        "bg": "#f4f5f9",
        "card": "#ffffff",
        "border": "#e4e6ee",
        "text": "#16181f",
        "muted": "#8a90a2",
        "brand": "#5b5bd6",
        "brand2": "#8b5cf6",
        "ok": "#16a34a",
        "err": "#dc2626",
        "warn": "#d97706",
        "log_bg": "#0f172a",
        "log_fg": "#dbe2f0",
    }

    log_queue: queue.Queue = queue.Queue()

    def log_cb(tag: str, msg: str) -> None:
        log_queue.put((tag, msg))

    mgr = ServiceManager(BASE, log=log_cb)

    root = tk.Tk()
    root.title(f"{APP_TITLE} v{VERSION}")
    root.geometry("820x620")
    root.minsize(720, 560)
    root.configure(bg=C["bg"])

    base_font = tkfont.nametofont("TkDefaultFont")
    base_font.configure(family="Microsoft YaHei UI", size=9)
    tkfont.nametofont("TkTextFont").configure(family="Microsoft YaHei UI", size=9)

    busy = {"value": False}
    states = {"api": "stopped", "web": "stopped"}

    # ---------- 顶部 ----------
    head = tk.Frame(root, bg=C["bg"])
    head.pack(fill="x", padx=22, pady=(18, 8))
    tk.Label(head, text="⚡ AI助理", font=("Microsoft YaHei UI", 18, "bold"),
             bg=C["bg"], fg=C["text"]).pack(side="left")
    tk.Label(head, text="AI 编程全能工作台 · 启动控制台", font=("Microsoft YaHei UI", 10),
             bg=C["bg"], fg=C["muted"]).pack(side="left", padx=(10, 0), pady=(6, 0))
    overall = tk.Label(head, text="● 已停止", font=("Microsoft YaHei UI", 9, "bold"),
                       bg=C["bg"], fg=C["err"])
    overall.pack(side="right", pady=(6, 0))
    tk.Label(root, text=f"项目目录：{BASE}", font=("Microsoft YaHei UI", 8),
             bg=C["bg"], fg=C["muted"], anchor="w").pack(fill="x", padx=24)

    # ---------- 服务卡片 ----------
    cards = tk.Frame(root, bg=C["bg"])
    cards.pack(fill="x", padx=22, pady=12)

    def make_card(parent, key: str, title: str, meta: str):
        frame = tk.Frame(parent, bg=C["card"], highlightbackground=C["border"],
                         highlightthickness=1, bd=0)
        frame.pack(side="left", fill="both", expand=True, padx=(0, 12) if key == "api" else (0, 0))
        top = tk.Frame(frame, bg=C["card"])
        top.pack(fill="x", padx=16, pady=(14, 2))
        tk.Label(top, text=title, font=("Microsoft YaHei UI", 12, "bold"),
                 bg=C["card"], fg=C["text"]).pack(side="left")
        dot = tk.Label(top, text="● 已停止", font=("Microsoft YaHei UI", 9, "bold"),
                       bg=C["card"], fg=C["err"])
        dot.pack(side="right")
        tk.Label(frame, text=meta, font=("Microsoft YaHei UI", 8),
                 bg=C["card"], fg=C["muted"], anchor="w").pack(fill="x", padx=16)
        btns = tk.Frame(frame, bg=C["card"])
        btns.pack(fill="x", padx=14, pady=(10, 14))

        def mkbtn(text, bg, fg, cmd):
            b = tk.Button(btns, text=text, command=cmd, bg=bg, fg=fg, bd=0,
                          font=("Microsoft YaHei UI", 9, "bold"), padx=14, pady=5,
                          activebackground=bg, activeforeground=fg, cursor="hand2")
            b.pack(side="left", padx=(0, 8))
            return b

        return frame, dot, mkbtn

    api_frame, api_dot, api_mkbtn = make_card(
        cards, "api", "后端 API", "端口 8036 · 生产模式（托管前端页面）", )
    web_frame, web_dot, web_mkbtn = make_card(
        cards, "web", "前端开发服务", "端口 8035 · 热更新调试（可选）")

    def set_busy(value: bool) -> None:
        busy["value"] = value
        for b in [all_start_btn, all_stop_btn, api_start_btn, api_stop_btn,
                  web_start_btn, web_stop_btn, install_btn]:
            b.configure(state="disabled" if value else "normal")

    def run_async(fn, done=None):
        if busy["value"]:
            return
        set_busy(True)

        def worker():
            try:
                result = fn()
            except Exception:  # noqa: BLE001
                log_cb("ERROR", traceback.format_exc(limit=3))
                result = None
            root.after(0, lambda: (set_busy(False), done(result) if done else None))

        threading.Thread(target=worker, daemon=True).start()

    def notify(msg: str, kind: str = "info") -> None:
        log_cb("UI", msg)
        if kind == "error":
            messagebox.showerror(APP_TITLE, msg)

    def act_start_api():
        run_async(mgr.start_api, lambda r: notify(f"后端：{r[1]}", "error" if not r[0] else "info"))

    def act_stop_api():
        run_async(mgr.stop_api, lambda r: notify(f"后端：{r[1]}", "error" if not r[0] else "info"))

    def act_start_web():
        run_async(mgr.start_web, lambda r: notify(f"前端：{r[1]}", "error" if not r[0] else "info"))

    def act_stop_web():
        run_async(mgr.stop_web, lambda r: notify(f"前端：{r[1]}", "error" if not r[0] else "info"))

    def act_start_all():
        include_web = include_web_var.get()

        def job():
            ok, notes = mgr.start_all(include_web=include_web)
            return ok, "；".join(notes)

        run_async(job, lambda r: notify(f"全部启动：{r[1]}", "error" if not r[0] else "info"))

    def act_stop_all():
        run_async(mgr.stop_all, lambda r: notify("全部关闭：" + "；".join(r)))

    def act_open():
        def job():
            if not port_open(8036) and not port_open(8035):
                log_cb("OPEN", "服务未运行，先启动后端…")
                mgr.start_api()
            return mgr.open_web()

        run_async(job, lambda url: log_cb("OPEN", f"已打开 {url}"))

    def act_install():
        run_async(lambda: mgr.install(log=lambda m: log_cb("INSTALL", m)),
                  lambda r: notify(r[1], "error" if not r[0] else "info"))

    def act_open_dir():
        if os.name == "nt":
            os.startfile(str(BASE))  # noqa: S606

    api_start_btn = api_mkbtn("启动", C["brand"], "#ffffff", act_start_api)
    api_stop_btn = api_mkbtn("停止", "#eef0f6", C["text"], act_stop_api)
    web_start_btn = web_mkbtn("启动", C["brand"], "#ffffff", act_start_web)
    web_stop_btn = web_mkbtn("停止", "#eef0f6", C["text"], act_stop_web)

    # ---------- 操作栏 ----------
    bar = tk.Frame(root, bg=C["bg"])
    bar.pack(fill="x", padx=22, pady=(2, 8))

    def action_btn(text, bg, fg, cmd):
        b = tk.Button(bar, text=text, command=cmd, bg=bg, fg=fg, bd=0,
                      font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=7,
                      activebackground=bg, activeforeground=fg, cursor="hand2")
        b.pack(side="left", padx=(0, 10))
        return b

    all_start_btn = action_btn("▶ 全部启动", C["brand"], "#ffffff", act_start_all)
    all_stop_btn = action_btn("■ 全部关闭", "#e6e8f0", C["text"], act_stop_all)
    open_btn = action_btn("🌐 打开网页", "#e9f7ef", C["ok"], act_open)
    install_btn = action_btn("📦 安装/更新依赖", "#fff5e6", C["warn"], act_install)
    action_btn("📂 打开目录", "#eef0f6", C["text"], act_open_dir)

    include_web_var = tk.BooleanVar(value=False)
    tk.Checkbutton(bar, text="全部启动包含前端开发", variable=include_web_var,
                   bg=C["bg"], fg=C["muted"], activebackground=C["bg"],
                   font=("Microsoft YaHei UI", 8), cursor="hand2").pack(side="right", pady=6)

    # ---------- 日志 ----------
    log_wrap = tk.Frame(root, bg=C["log_bg"], highlightbackground="#1e293b", highlightthickness=1)
    log_wrap.pack(fill="both", expand=True, padx=22, pady=(6, 18))
    tk.Label(log_wrap, text="运行日志", bg=C["log_bg"], fg="#94a3b8",
             font=("Microsoft YaHei UI", 8, "bold"), anchor="w").pack(fill="x", padx=12, pady=(8, 0))
    log_text = scrolledtext.ScrolledText(
        log_wrap, bg=C["log_bg"], fg=C["log_fg"], insertbackground=C["log_fg"],
        bd=0, font=("Consolas", 9), wrap="word", height=10,
    )
    log_text.pack(fill="both", expand=True, padx=8, pady=(4, 8))
    log_text.configure(state="disabled")

    def append_log(tag: str, msg: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        log_text.configure(state="normal")
        log_text.insert("end", f"[{stamp}] [{tag}] {msg}\n")
        # 限制行数
        lines = int(log_text.index("end-1c").split(".")[0])
        if lines > 800:
            log_text.delete("1.0", f"{lines - 800}.0")
        log_text.see("end")
        log_text.configure(state="disabled")

    def pump_logs() -> None:
        try:
            while True:
                tag, msg = log_queue.get_nowait()
                append_log(tag, msg)
        except queue.Empty:
            pass
        root.after(120, pump_logs)

    # ---------- 状态刷新 ----------
    def refresh() -> None:
        st = mgr.status()
        running_count = 0
        for key, dot in (("api", api_dot), ("web", web_dot)):
            if key in ("api", "web") and busy.get(key):
                continue
            is_running = st[key]["running"]
            running_count += 1 if is_running else 0
            state = "running" if is_running else "stopped"
            if states[key] != state:
                states[key] = state
                if is_running:
                    dot.configure(text="● 运行中", fg=C["ok"])
                else:
                    dot.configure(text="● 已停止", fg=C["err"])
        if running_count == 2:
            overall.configure(text="● 全部运行中", fg=C["ok"])
        elif running_count == 1:
            overall.configure(text="● 部分运行", fg=C["warn"])
        else:
            overall.configure(text="● 已停止", fg=C["err"])
        root.after(1200, refresh)

    # ---------- 关闭 ----------
    def on_close() -> None:
        st = mgr.status()
        if st["api"]["running"] or st["web"]["running"]:
            if messagebox.askyesno(APP_TITLE, "服务仍在运行，是否一并关闭后退出？"):
                mgr.stop_all()
            else:
                root.destroy()
                return
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)

    log_cb("READY", f"启动器就绪 · 项目目录 {BASE}")
    if not mgr.has_venv():
        log_cb("SETUP", "未检测到 api/env1，请点击「安装/更新依赖」")
    if not mgr.has_node_modules():
        log_cb("SETUP", "未检测到 web/node_modules（前端开发服务不可用；生产模式不受影响）")
    append_log("READY", f"AI助理 控制台 v{VERSION} 已启动")
    pump_logs()
    refresh()
    root.mainloop()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument("--selftest", action="store_true", help="无界面自检")
    args, _ = parser.parse_known_args()
    if args.selftest:
        return run_selftest()
    try:
        return run_gui()
    except Exception:  # noqa: BLE001
        # GUI 无法启动时写错误文件，便于排查
        try:
            (APP_DIR / "launcher_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        raise


if __name__ == "__main__":
    sys.exit(main())
