# -*- coding: utf-8 -*-
"""AI助理 启动器核心（无 GUI，供 Tkinter 界面与自检复用）。"""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


def find_base_dir(start: Path) -> Path | None:
    for cand in [start, *start.parents]:
        if (cand / "api" / "main.py").exists():
            return cand
    return None


def port_open(port: int, host: str | None = None, timeout: float = 0.35) -> bool:
    hosts = [host] if host else ["127.0.0.1", "::1"]
    for h in hosts:
        try:
            with socket.create_connection((h, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False


def http_ok(port: int, path: str = "/api/ping", timeout: float = 1.5) -> bool:
    try:
        import urllib.request

        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:  # noqa: BLE001
        return False


def port_pids(port: int) -> list[int]:
    """用 netstat 找出监听指定端口的 PID（不依赖 psutil）。"""
    pids: list[int] = []
    try:
        out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True,
                             text=True, encoding="utf-8", errors="replace", timeout=10).stdout
    except Exception:  # noqa: BLE001
        return pids
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[3].upper() == "LISTENING":
            local = parts[1]
            if local.endswith(f":{port}"):
                try:
                    pids.append(int(parts[4]))
                except ValueError:
                    pass
    return sorted(set(pids))


def kill_pids(pids: list[int]) -> None:
    for pid in pids:
        if pid <= 0:
            continue
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=15)
        except Exception:  # noqa: BLE001
            pass


class Service:
    def __init__(self, key: str, title: str, port: int, cwd: Path, cmd: list[str], env: dict | None = None):
        self.key = key
        self.title = title
        self.port = port
        self.cwd = cwd
        self.cmd = cmd
        self.env = env or {}
        self.proc: subprocess.Popen | None = None
        self.started_at = 0.0

    @property
    def owned_running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    @property
    def running(self) -> bool:
        return port_open(self.port) or self.owned_running


class ServiceManager:
    def __init__(self, base_dir: Path, log=None):
        self.base = Path(base_dir)
        self.log = log or (lambda tag, msg: print(f"[{tag}] {msg}"))
        self._lock = threading.RLock()
        self.api_python = self._find_python()
        self.npm = shutil.which("npm.cmd") or shutil.which("npm") or "npm"
        self.api = Service(
            "api", "后端 API", 8036, self.base / "api",
            [self.api_python, "main.py"],
            env={"FORGE_PORT": "8036", "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"},
        )
        self.web = Service(
            "web", "前端开发", 8035, self.base / "web",
            [self.npm, "run", "dev"],
            env={"FORGE_API": "http://127.0.0.1:8036", "PYTHONIOENCODING": "utf-8"},
        )
        self._readers: list[threading.Thread] = []

    # ---------------- 环境 ----------------
    def _find_python(self) -> str:
        cand = self.base / "api" / "env1" / "Scripts" / "python.exe"
        if cand.exists():
            return str(cand)
        return shutil.which("python") or "python"

    def has_venv(self) -> bool:
        return (self.base / "api" / "env1" / "Scripts" / "python.exe").exists()

    def has_node_modules(self) -> bool:
        return (self.base / "web" / "node_modules").exists()

    def has_dist(self) -> bool:
        return (self.base / "web" / "dist" / "index.html").exists()

    def ensure_secrets(self) -> None:
        local = self.base / "api" / "configs" / "secrets_local.py"
        example = self.base / "api" / "configs" / "secrets_example.py"
        if not local.exists() and example.exists():
            shutil.copy2(example, local)
            self.log("SETUP", "已生成 api/configs/secrets_local.py 模板（请填写真实 Key）")

    # ---------------- 启动 / 停止 ----------------
    def status(self) -> dict:
        return {
            "api": {"running": self.api.running, "port": self.api.port, "pid": self.api.proc.pid if self.api.owned_running else None},
            "web": {"running": self.web.running, "port": self.web.port, "pid": self.web.proc.pid if self.web.owned_running else None},
        }

    def _spawn(self, svc: Service) -> tuple[bool, str]:
        with self._lock:
            if svc.running:
                return True, "已在运行"
            if not svc.cwd.exists():
                return False, f"目录不存在: {svc.cwd}"
            env = os.environ.copy()
            env.update(svc.env)
            try:
                svc.proc = subprocess.Popen(
                    svc.cmd, cwd=str(svc.cwd), env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace",
                    creationflags=CREATE_NO_WINDOW,
                )
            except Exception as exc:  # noqa: BLE001
                return False, f"启动失败: {exc}"
            svc.started_at = time.time()
            t = threading.Thread(target=self._reader, args=(svc, svc.proc), daemon=True)
            t.start()
            self._readers.append(t)
            self.log("START", f"{svc.title} 启动中（PID {svc.proc.pid}，端口 {svc.port}）")
            return True, "已启动"

    def _reader(self, svc: Service, proc: subprocess.Popen) -> None:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                msg = line.rstrip()
                if msg:
                    self.log(svc.key.upper(), msg)
        except Exception:  # noqa: BLE001
            pass

    def wait_ready(self, svc: Service, timeout: float = 40.0, ping: bool = True) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if svc.port and port_open(svc.port):
                if not ping or http_ok(svc.port):
                    return True
                if not svc.proc or svc.proc.poll() is not None:
                    return False
            if svc.proc is not None and svc.proc.poll() is not None:
                return False
            time.sleep(0.4)
        return False

    def _stop(self, svc: Service, label: str) -> tuple[bool, str]:
        with self._lock:
            if not svc.running:
                return True, "未运行"
            pid = svc.proc.pid if svc.owned_running else None
            if pid:
                kill_pids([pid])
            # 兜底：清理监听该端口的残留
            kill_pids(port_pids(svc.port))
            if svc.proc is not None:
                try:
                    svc.proc.wait(timeout=5)
                except Exception:  # noqa: BLE001
                    pass
                svc.proc = None
            deadline = time.time() + 8
            while time.time() < deadline and port_open(svc.port):
                time.sleep(0.25)
            ok = not port_open(svc.port)
            self.log("STOP", f"{svc.title} 已停止" if ok else f"{label} 停止后端口仍被占用")
            return ok, "已停止" if ok else "端口仍被占用"

    # ---------------- 对外 API ----------------
    def start_api(self) -> tuple[bool, str]:
        self.ensure_secrets()
        ok, msg = self._spawn(self.api)
        if not ok:
            return ok, msg
        if self.wait_ready(self.api, timeout=45) or port_open(self.api.port):
            self.log("READY", f"后端就绪：http://127.0.0.1:{self.api.port}")
            return True, "已就绪"
        return False, "后端启动超时（请查看日志）"

    def stop_api(self) -> tuple[bool, str]:
        return self._stop(self.api, "后端")

    def start_web(self) -> tuple[bool, str]:
        if not self.has_node_modules():
            return False, "缺少 web/node_modules（请先安装依赖）"
        ok, msg = self._spawn(self.web)
        if not ok:
            return ok, msg
        if self.wait_ready(self.web, timeout=60, ping=False):
            self.log("READY", f"前端开发服务就绪：http://localhost:{self.web.port}")
            return True, "已就绪"
        return False, "前端启动超时（请查看日志）"

    def stop_web(self) -> tuple[bool, str]:
        return self._stop(self.web, "前端")

    def start_all(self, include_web: bool = False) -> tuple[bool, list[str]]:
        notes = []
        ok, msg = self.start_api()
        notes.append(f"后端：{msg}")
        if include_web:
            ok2, msg2 = self.start_web()
            notes.append(f"前端：{msg2}")
            ok = ok and ok2
        return ok, notes

    def stop_all(self) -> list[str]:
        notes = []
        ok1, m1 = self.stop_api()
        ok2, m2 = self.stop_web()
        notes.append(f"后端：{m1}")
        notes.append(f"前端：{m2}")
        return notes

    def web_url(self) -> str:
        if port_open(self.api.port):
            return f"http://127.0.0.1:{self.api.port}"
        if port_open(self.web.port):
            return f"http://localhost:{self.web.port}"
        return f"http://127.0.0.1:{self.api.port}"

    def open_web(self) -> str:
        import webbrowser

        url = self.web_url()
        self.log("OPEN", f"打开网页 {url}")
        webbrowser.open(url)
        return url

    # ---------------- 安装依赖 ----------------
    def install(self, log=None) -> tuple[bool, str]:
        """初始化/更新依赖：venv + pip + npm install + npm run build。"""
        emit = log or (lambda m: self.log("INSTALL", m))
        api_dir = self.base / "api"
        web_dir = self.base / "web"
        try:
            if not self.has_venv():
                sys_py = shutil.which("python") or shutil.which("py")
                if not sys_py:
                    return False, "未找到 python，请先安装 Python 3.10+ 并加入 PATH"
                emit("创建虚拟环境 api/env1 …")
                r = subprocess.run([sys_py, "-m", "venv", str(api_dir / "env1")],
                                   capture_output=True, text=True, encoding="utf-8", errors="replace")
                if r.returncode != 0:
                    return False, f"创建虚拟环境失败：{(r.stderr or r.stdout)[-300:]}"
            emit("安装后端依赖（pip）…")
            r = subprocess.run([self.api_python, "-m", "pip", "install", "-q", "-r", "requirements.txt"],
                               cwd=str(api_dir), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=900)
            if r.returncode != 0:
                return False, f"pip 安装失败：{(r.stderr or r.stdout)[-400:]}"
            emit("安装前端依赖（npm install）…")
            r = subprocess.run([self.npm, "install", "--no-fund", "--no-audit"], cwd=str(web_dir),
                               capture_output=True, text=True, encoding="utf-8", errors="replace",
                               timeout=1800)
            if r.returncode != 0:
                return False, f"npm install 失败：{(r.stderr or r.stdout)[-400:]}"
            emit("构建前端（npm run build）…")
            r = subprocess.run([self.npm, "run", "build"], cwd=str(web_dir), capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=900)
            if r.returncode != 0:
                return False, f"npm run build 失败：{(r.stderr or r.stdout)[-400:]}"
            self.ensure_secrets()
            emit("依赖安装完成")
            return True, "安装完成"
        except subprocess.TimeoutExpired:
            return False, "安装超时（网络较慢？）"
        except Exception as exc:  # noqa: BLE001
            return False, f"安装异常：{exc}"

    # ---------------- 自检（供 exe 验证） ----------------
    def selftest(self) -> tuple[bool, list[str]]:
        lines = []
        was_running = port_open(self.api.port)
        lines.append(f"初始状态：后端端口 {self.api.port} {'已监听' if was_running else '未监听'}")
        if not was_running:
            ok, msg = self.start_api()
            lines.append(f"启动后端：{ok} / {msg}")
            if not ok:
                return False, lines
        else:
            ok = http_ok(self.api.port)
            lines.append(f"复用已运行后端：ping={'OK' if ok else 'FAIL'}")
            if not ok:
                return False, lines
        if not was_running:
            ok, msg = self.stop_api()
            lines.append(f"停止后端：{ok} / {msg}")
            if not ok:
                return False, lines
            lines.append(f"停止后端口：{'仍监听(异常)' if port_open(self.api.port) else '已释放'}")
            return (not port_open(self.api.port)), lines
        return True, lines
