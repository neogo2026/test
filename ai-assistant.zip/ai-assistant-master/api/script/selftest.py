# v1/api/script/selftest.py
"""
AI助理 全链路自测（无需 API Key，使用 mock 模型 + 临时数据库）。

覆盖：健康检查 / 会话 / mock 工具调用 / 流式事件 / 高风险审批 / 审批恢复 /
      飞书降级 / 插件管理 / 技能检索 / 黑名单 / 取消。

用法：cd v1/api && python script/selftest.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import time
from pathlib import Path

# 环境隔离：临时数据目录 + mock 模型（必须在导入 main 前生效）
_TMP = tempfile.mkdtemp(prefix="forge-selftest-")
os.environ["FORGE_DATA_DIR"] = _TMP
os.environ["FORGE_WORKSPACE_DIR"] = str(Path(_TMP) / "workspace")
os.environ["FORGE_DB_PATH"] = str(Path(_TMP) / "forge.db")
os.environ["MIMO_API_KEY"] = ""
os.environ["DEEPSEEK_API_KEY"] = ""
os.environ["ZHIPU_API_KEY"] = ""
os.environ["FEISHU_APP_ID"] = ""
os.environ["FEISHU_APP_SECRET"] = ""
os.environ["FORGE_FEISHU_ENABLED"] = "0"
# 强制 mock 链路：忽略本机真实密钥，自测零消费
os.environ["FORGE_SECRETS_OFF"] = "1"
os.environ["FORGE_MODEL_PROFILE"] = "mock"

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {detail}")


async def wait_run(cli, run_id: str, timeout_s: float = 20) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        run = (await cli.get(f"/api/runs/{run_id}")).json()["data"]
        if run and run["status"] in ("COMPLETED", "FAILED", "CANCELLED", "WAITING_APPROVAL"):
            return
        await asyncio.sleep(0.1)


async def wait_status(cli, run_id: str, status: str, timeout_s: float = 20) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        run = (await cli.get(f"/api/runs/{run_id}")).json()["data"]
        if run and run["status"] == status:
            return
        if run and run["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
            return
        await asyncio.sleep(0.1)


async def run_checks(cli) -> None:
    print("== 1. 系统探针与健康检查 ==")
    r = (await cli.get("/api/info")).json()
    check("服务信息", r.get("name") == "AI助理")
    home = await cli.get("/")
    check("首页为前端托管", "text/html" in home.headers.get("content-type", "") and b'id="app"' in home.content)
    r = (await cli.get("/api/ping")).json()
    check("ping", r["data"] == "pong")
    r = (await cli.get("/api/system/health")).json()["data"]
    check("健康检查-默认模型", r["default_model"] == "mock", f"got {r['default_model']}")
    check("健康检查-密钥脱敏", not r["keys"]["DEEPSEEK_API_KEY"]["configured"])
    check("健康检查-插件数>=5", len(r["plugins"]) >= 5, f"got {len(r['plugins'])}")

    print("== 2. 插件与工具注册 ==")
    r = (await cli.get("/api/tools")).json()["data"]
    names = {t["name"] for t in r}
    expected = {"read_file", "write_file", "edit_file", "grep", "glob", "run_shell", "calculator", "run_python"}
    check("dev 工具已注册", expected.issubset(names), f"missing {expected - names}")
    r = (await cli.get("/api/agents")).json()["data"]
    check("coder Agent 已注册", any(a["name"] == "coder" for a in r))

    print("== 3. 会话创建与配置 ==")
    r = (await cli.post("/api/sessions", json={"title": "自测任务", "gate_mode": "ask"})).json()["data"]
    sid = r["session_id"]
    check("会话创建", sid.startswith("s_"))
    r = (await cli.get(f"/api/sessions/{sid}")).json()["data"]
    check("会话默认 Agent", r["agent_name"] == "coder")

    print("== 4. mock 工具调用（只读，免批） ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "计算 3+4*2"})).json()["data"]
    run1 = r["run_id"]
    check("Run 立即返回", r["status"] in ("QUEUED", "RUNNING", "COMPLETED"))
    await wait_run(cli, run1)
    run = (await cli.get(f"/api/runs/{run1}")).json()["data"]
    check("Run 完成", run["status"] == "COMPLETED", f"got {run['status']}")
    events = (await cli.get(f"/api/sessions/{sid}/events")).json()["data"]
    types = [e["type"] for e in events]
    check("事件流含工具调用", "tool.requested" in types and "tool.result" in types)
    check("事件流含 model.completed", "model.completed" in types)
    messages = (await cli.get(f"/api/sessions/{sid}/messages")).json()["data"]
    check("消息持久化", any(m["role"] == "user" for m in messages) and any(m["role"] == "assistant" for m in messages))

    print("== 5. 高风险工具审批流（write_file → 批准 → 完成） ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "写文件 notes/hello.txt"})).json()["data"]
    run2 = r["run_id"]
    await wait_status(cli, run2, "WAITING_APPROVAL")
    run = (await cli.get(f"/api/runs/{run2}")).json()["data"]
    check("Run 挂起等待审批", run["status"] == "WAITING_APPROVAL", f"got {run['status']}")
    approvals = (await cli.get("/api/approvals?status=pending")).json()["data"]
    check("审批已创建", any(a["run_id"] == run2 for a in approvals))
    approval_id = next(a["approval_id"] for a in approvals if a["run_id"] == run2)
    r = (await cli.post(f"/api/approvals/{approval_id}/resolve", json={"approved": True})).json()
    check("审批通过", r["code"] == 200)
    await wait_run(cli, run2)
    run = (await cli.get(f"/api/runs/{run2}")).json()["data"]
    check("审批后 Run 完成", run["status"] == "COMPLETED", f"got {run['status']}")
    artifacts = (await cli.get(f"/api/runs/{run2}/artifacts")).json()["data"]
    check("产物登记", any("hello.txt" in a["name"] for a in artifacts))
    target = Path(os.environ["FORGE_WORKSPACE_DIR"]) / "notes" / "hello.txt"
    check("文件落盘工作区", target.exists())

    print("== 6. 审批拒绝流 ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "写文件 notes/no.txt"})).json()["data"]
    run3 = r["run_id"]
    await wait_status(cli, run3, "WAITING_APPROVAL")
    approvals = (await cli.get("/api/approvals?status=pending")).json()["data"]
    approval_id = next(a["approval_id"] for a in approvals if a["run_id"] == run3)
    await cli.post(f"/api/approvals/{approval_id}/resolve", json={"approved": False, "reason": "自测拒绝"})
    await wait_run(cli, run3)
    run = (await cli.get(f"/api/runs/{run3}")).json()["data"]
    check("拒绝后 Run 正常收尾", run["status"] == "COMPLETED", f"got {run['status']}")
    rejected = Path(os.environ["FORGE_WORKSPACE_DIR"]) / "notes" / "no.txt"
    check("被拒文件未落盘", not rejected.exists())

    print("== 7. 危险命令黑名单（screener） ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "shell shutdown /r /t 0"})).json()["data"]
    run4 = r["run_id"]
    await wait_run(cli, run4)
    events = (await cli.get(f"/api/runs/{run4}/events")).json()["data"]
    denied = any(e["type"] == "tool.requested" and e["payload"].get("denied") for e in events)
    check("黑名单命令被拒绝", denied)

    print("== 8. 会话取消 ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "写文件 notes/cancel.txt"})).json()["data"]
    run5 = r["run_id"]
    await wait_status(cli, run5, "WAITING_APPROVAL")
    r = (await cli.post(f"/api/sessions/{sid}/cancel")).json()["data"]
    check("取消接口", r.get("cancelled") is True)
    run = (await cli.get(f"/api/runs/{run5}")).json()["data"]
    check("Run 已取消", run["status"] == "CANCELLED", f"got {run['status']}")

    print("== 9. 技能系统 ==")
    r = (await cli.get("/api/skills")).json()["data"]
    check("内置技能加载", any(s["name"] == "dev-loop" for s in r))
    r = (await cli.post("/api/skills", json={
        "name": "test-skill", "title": "测试技能", "kinds": ["test"],
        "triggers": ["自测触发"], "body": "# 测试",
    })).json()["data"]
    check("技能创建", r["name"] == "test-skill")
    r = (await cli.get("/api/skills/search?q=自测触发")).json()["data"]
    check("技能检索命中", any(s["name"] == "test-skill" for s in r))
    r = (await cli.delete("/api/skills/test-skill")).json()["data"]
    check("技能删除", r["deleted"])

    print("== 10. 飞书降级（未配置凭据） ==")
    r = (await cli.get("/api/feishu/status")).json()["data"]
    check("飞书安全降级", r["configured"] is False and r["enabled"] is False)

    print("== 11. 插件管理 ==")
    r = (await cli.get("/api/plugins")).json()["data"]
    check("插件清单", len(r) >= 5)
    usage_plugin = next((p for p in r if p["name"] == "usage"), None)
    check("usage 插件启用", usage_plugin is not None and usage_plugin["enabled"])

    print("== 12. 会话隐藏与列表 ==")
    r = (await cli.get("/api/sessions")).json()["data"]
    check("会话列表", any(s["session_id"] == sid for s in r))
    r = (await cli.delete(f"/api/sessions/{sid}")).json()["data"]
    check("会话隐藏删除", r["deleted"] == sid)
    r = (await cli.get("/api/sessions")).json()["data"]
    check("隐藏后不在列表", not any(s["session_id"] == sid for s in r))


async def main() -> int:
    import httpx

    import main as forge_main

    async with forge_main.app.router.lifespan_context(forge_main.app):
        transport = httpx.ASGITransport(app=forge_main.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=30) as cli:
            await run_checks(cli)

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
