# -*- coding: utf-8 -*-
"""工作空间功能自检：浏览 / 设置 / 记忆 / 运行时生效。"""
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

TMP = tempfile.mkdtemp(prefix="forge-ws-")
os.environ["FORGE_DATA_DIR"] = TMP
os.environ["FORGE_DB_PATH"] = str(Path(TMP) / "f.db")
os.environ["FORGE_WORKSPACE_DIR"] = str(Path(TMP) / "default-ws")
os.environ["FORGE_FEISHU_ENABLED"] = "0"
os.environ["FORGE_SECRETS_OFF"] = "1"
os.environ["FORGE_MODEL_PROFILE"] = "mock"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PASS = 0
FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {detail}")


async def main() -> int:
    import httpx

    import main as forge

    ws = Path(TMP) / "my-project"
    (ws / "src").mkdir(parents=True)
    (ws / "src" / "marker-文件.txt").write_text("hello", encoding="utf-8")

    async with forge.app.router.lifespan_context(forge.app):
        transport = httpx.ASGITransport(app=forge.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://t", timeout=30) as cli:
            print("== 1. 目录浏览 ==")
            r = (await cli.get("/api/fs/list?path=")).json()
            check("根列表含磁盘/根目录", r["code"] == 200 and len(r["data"]["roots"]) >= 1,
                  str(r)[:200])
            r = (await cli.get(f"/api/fs/list?path={ws}")).json()
            check("列出子目录", r["code"] == 200 and any(e["name"] == "src" for e in r["data"]["entries"]),
                  str(r)[:200])
            check("返回上级路径", r["data"]["parent"] is not None)
            r = (await cli.get(f"/api/fs/list?path={ws / 'src'}")).json()
            check("文件不混入目录列表", all("marker" not in e["name"] for e in r["data"]["entries"]))
            check("路径不存在返回 404", (await cli.get(f"/api/fs/list?path={ws}/nope")).json()["code"] == 404)

            print("== 2. 新建文件夹 ==")
            r = (await cli.post("/api/fs/mkdir", json={"path": str(ws), "name": "newdir"})).json()
            check("创建成功", r["code"] == 200 and (ws / "newdir").is_dir(), str(r))
            r = (await cli.post("/api/fs/mkdir", json={"path": str(ws), "name": "newdir"})).json()
            check("重名拒绝", r["code"] == 400)

            print("== 3. 工作空间设置与记忆 ==")
            r = (await cli.get("/api/settings/workspace")).json()
            check("默认未保存", r["data"]["saved"] is False, str(r))
            r = (await cli.put("/api/settings/workspace", json={"path": str(ws)})).json()
            check("设置成功", r["code"] == 200 and Path(r["data"]["path"]) == ws.resolve(), str(r))
            r = (await cli.get("/api/settings/workspace")).json()
            check("已记住", r["data"]["saved"] is True and Path(r["data"]["path"]) == ws.resolve())
            r = (await cli.put("/api/settings/workspace", json={"path": str(ws / "nope")})).json()
            check("非法路径拒绝", r["code"] == 400)

            print("== 4. 任务在记住的工作空间执行 ==")
            s = (await cli.post("/api/sessions", json={"title": "ws-test"})).json()["data"]
            sid = s["session_id"]
            m = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "列出目录"})).json()["data"]
            run = {}
            for _ in range(60):
                await asyncio.sleep(0.2)
                run = (await cli.get(f"/api/runs/{m['run_id']}")).json()["data"]
                if run["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
                    break
            ev = (await cli.get(f"/api/sessions/{sid}/events")).json()["data"]
            tool_payload = next((e["payload"] for e in ev if e["type"] == "tool.result" and e["payload"].get("name") == "list_dir"), {})
            check("Run 完成", run["status"] == "COMPLETED", str(run)[:200])
            check("list_dir 执行于所选工作空间",
                  "my-project" in json.dumps(tool_payload, ensure_ascii=False) or "src" in json.dumps(tool_payload, ensure_ascii=False),
                  str(tool_payload)[:300])

            print("== 5. 切换工作空间后立即生效 ==")
            ws2 = Path(TMP) / "second-ws"
            (ws2 / "only-here").mkdir(parents=True)
            await cli.put("/api/settings/workspace", json={"path": str(ws2)})
            m = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "列出目录"})).json()["data"]
            for _ in range(60):
                await asyncio.sleep(0.2)
                run = (await cli.get(f"/api/runs/{m['run_id']}")).json()["data"]
                if run["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
                    break
            ev = (await cli.get(f"/api/sessions/{sid}/events")).json()["data"]
            tools = [e["payload"] for e in ev if e["type"] == "tool.result" and e["payload"].get("name") == "list_dir"]
            check("切换后作用于新目录", "only-here" in json.dumps(tools[-1:], ensure_ascii=False), str(tools[-1:])[:300])

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
