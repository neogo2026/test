# v1/api/script/rsi_selftest.py
"""RSI 进化层自测：采集 → 失败归因 → 候选 → 评测 → 晋级 → 回滚 → 导出 → 关闭。

无需 API Key（mock 模型 + 临时数据库）。用法：
    cd v1/api && python script/rsi_selftest.py
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import time
from pathlib import Path

_TMP = tempfile.mkdtemp(prefix="forge-rsi-selftest-")
os.environ["FORGE_DATA_DIR"] = _TMP
os.environ["FORGE_WORKSPACE_DIR"] = str(Path(_TMP) / "workspace")
os.environ["FORGE_DB_PATH"] = str(Path(_TMP) / "forge.db")
os.environ["FORGE_RSI_DIR"] = str(Path(_TMP) / "rsi")
os.environ["FORGE_RSI_ENABLED"] = "1"
os.environ["FORGE_RSI_MODE"] = "active"
os.environ["FORGE_RSI_MIN_SAMPLES"] = "1"
os.environ["FORGE_RSI_WORKER_INTERVAL_S"] = "3600"
os.environ["MIMO_API_KEY"] = ""
os.environ["DEEPSEEK_API_KEY"] = ""
os.environ["ZHIPU_API_KEY"] = ""
os.environ["FEISHU_APP_ID"] = ""
os.environ["FEISHU_APP_SECRET"] = ""
os.environ["FORGE_FEISHU_ENABLED"] = "0"
os.environ["FORGE_SECRETS_OFF"] = "1"
os.environ["FORGE_MODEL_PROFILE"] = "mock"

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {detail}")


async def wait_run(cli, run_id: str, timeout_s: float = 20) -> dict:
    deadline = time.time() + timeout_s
    run = {}
    while time.time() < deadline:
        run = (await cli.get(f"/api/runs/{run_id}")).json()["data"] or {}
        if run.get("status") in ("COMPLETED", "FAILED", "CANCELLED", "WAITING_APPROVAL"):
            return run
        await asyncio.sleep(0.1)
    return run


async def wait_episodes(cli, minimum: int, timeout_s: float = 20) -> list[dict]:
    deadline = time.time() + timeout_s
    items = []
    while time.time() < deadline:
        items = (await cli.get("/api/rsi/episodes")).json()["data"] or []
        if len(items) >= minimum:
            return items
        await asyncio.sleep(0.2)
    return items


async def run_checks(cli) -> None:
    print("== 1. RSI 状态与开关 ==")
    status = (await cli.get("/api/rsi/status")).json()["data"]
    check("RSI 已启用", status["enabled"] is True)
    check("全局模式 active", status["global_mode"] == "active", str(status.get("global_mode")))
    check("baseline 版本存在", status["active_version"] == "v0", str(status.get("active_version")))

    print("== 2. 会话级 RSI 模式 ==")
    r = (await cli.post("/api/sessions", json={"title": "rsi-active", "gate_mode": "allow_all",
                                               "capabilities": {"rsi_mode": "active"}})).json()["data"]
    sid = r["session_id"]
    check("会话能力回显", (r.get("capabilities") or {}).get("rsi_mode") == "active", json.dumps(r.get("capabilities")))

    print("== 3. 真实 Run → Episode 采集 ==")
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "计算 3+4*2"})).json()["data"]
    run = await wait_run(cli, r["run_id"])
    check("Run 完成", run.get("status") == "COMPLETED", str(run.get("status")))
    episodes = await wait_episodes(cli, 1)
    check("轨迹已采集", len(episodes) >= 1, f"got {len(episodes)}")
    ep = episodes[0]
    check("Episode 有关键字段", ep.get("run_id") and ep.get("outcome") == "success" and "signals" in ep)

    print("== 4. 失败样本（审批挂起后取消） ==")
    r = (await cli.post("/api/sessions", json={"title": "rsi-fail", "gate_mode": "ask",
                                               "capabilities": {"rsi_mode": "active"}})).json()["data"]
    sid_fail = r["session_id"]
    r = (await cli.post(f"/api/sessions/{sid_fail}/messages", json={"text": "写文件 notes/cancel.txt"})).json()["data"]
    run = await wait_run(cli, r["run_id"])
    check("失败样本进入审批挂起", run.get("status") == "WAITING_APPROVAL", str(run.get("status")))
    await cli.post(f"/api/sessions/{sid_fail}/cancel")
    await asyncio.sleep(0.5)
    episodes = await wait_episodes(cli, 2)
    check("第二段轨迹已采集", len(episodes) >= 2, f"got {len(episodes)}")

    print("== 5. 失败挖掘与候选生成 ==")
    mine = (await cli.post("/api/rsi/mine")).json()["data"]
    check("挖掘产生失败", len(mine.get("failures") or []) >= 1, json.dumps(mine.get("failures"))[:300])
    candidates = (await cli.get("/api/rsi/candidates")).json()["data"]
    check("生成候选", len(mine.get("candidates") or candidates) >= 1, json.dumps(mine.get("candidates"))[:300])
    check("候选可查询", len(candidates) >= 1)
    candidate_id = (mine.get("candidates") or candidates)[0]["candidate_id"]

    print("== 6. 评测 → 晋级 ==")
    exp = (await cli.post(f"/api/rsi/candidates/{candidate_id}/evaluate")).json()
    check("评测接口成功", exp.get("code") == 200, json.dumps(exp)[:300])
    verdict = (exp.get("data") or {}).get("verdict")
    check("评测有结论", verdict in {"pass", "insufficient", "reject"}, str(verdict))
    promoted = (await cli.post(f"/api/rsi/candidates/{candidate_id}/promote",
                               json={"force": True})).json()
    check("晋级成功", promoted.get("code") == 200, json.dumps(promoted)[:300])
    status = (await cli.get("/api/rsi/status")).json()["data"]
    check("active 版本更新", status["active_version"] not in ("", "v0"), str(status.get("active_version")))
    check("active 组件非空", bool((status.get("active_components") or {}).get("memories")))

    print("== 7. active 模式上下文注入（内部钩子） ==")
    import main as forge_main

    manager = forge_main.get_plugin_manager()
    plugin = manager.plugins.get("rsi") if manager else None
    service = plugin.service if plugin else None
    check("服务实例存在", service is not None)
    if service:
        class DummyAgent:
            name = "coder"
        snippet = await service.context_provider(DummyAgent(), sid, "测试 验证 修复", "mock")
        check("active 注入记忆", bool(snippet), "snippet empty")
        mode_off = await service.get_mode("*")
        check("全局模式解析", mode_off == "active", mode_off)

    print("== 8. 数据导出 ==")
    for fmt in ("sft", "dpo", "eval"):
        body = (await cli.get(f"/api/rsi/export/{fmt}")).json()
        check(f"导出 {fmt}", body.get("code") == 200, json.dumps(body)[:200])
        path = Path((body.get("data") or {}).get("file", ""))
        check(f"导出文件 {fmt}", path.exists() and path.stat().st_size >= 0, str(path))

    print("== 9. 回滚 ==")
    versions = (await cli.get("/api/rsi/versions")).json()["data"]
    active = versions.get("active")
    check("版本谱系可查询", bool(active), json.dumps(versions)[:200])
    rb = (await cli.post("/api/rsi/versions/v0/rollback")).json()
    check("回滚到 v0", rb.get("code") == 200, json.dumps(rb)[:200])
    status = (await cli.get("/api/rsi/status")).json()["data"]
    check("回滚后 active=v0", status["active_version"] == "v0", str(status.get("active_version")))

    print("== 10. 会话 off 后不采集 ==")
    await cli.post(f"/api/rsi/sessions/{sid}/mode", json={"mode": "off"})
    before = len((await cli.get("/api/rsi/episodes")).json()["data"] or [])
    r = (await cli.post(f"/api/sessions/{sid}/messages", json={"text": "计算 1+1"})).json()["data"]
    await wait_run(cli, r["run_id"])
    await asyncio.sleep(0.5)
    after = len((await cli.get("/api/rsi/episodes")).json()["data"] or [])
    check("off 模式不新增轨迹", after == before, f"{before}->{after}")

    print("== 11. 插件停用后完全回到 baseline ==")
    tools_before = {t["name"] for t in (await cli.get("/api/tools")).json()["data"]}
    check("RSI 工具已注册", "rsi_status" in tools_before)
    result = (await cli.post("/api/plugins/rsi/disable")).json()["data"]
    check("插件停用成功", bool(result))
    tools_after = {t["name"] for t in (await cli.get("/api/tools")).json()["data"]}
    check("RSI 工具已摘除", "rsi_status" not in tools_after, str(tools_after))
    agents = (await cli.get("/api/agents")).json()["data"]
    coder = next((a for a in agents if a["name"] == "coder"), {})
    check("Agent 工具列表恢复", "rsi_status" not in (coder.get("tools") or []))


async def main() -> int:
    import httpx

    import main as forge_main

    async with forge_main.app.router.lifespan_context(forge_main.app):
        transport = httpx.ASGITransport(app=forge_main.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=60) as cli:
            await run_checks(cli)

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
