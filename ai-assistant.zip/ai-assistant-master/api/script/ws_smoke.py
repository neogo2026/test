# v1/api/script/ws_smoke.py
"""WS 冒烟：连接 /ws → 发消息 → 断言收到 model.delta / tool.result 实时帧。"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from pathlib import Path

_TMP = tempfile.mkdtemp(prefix="forge-ws-")
os.environ["FORGE_DATA_DIR"] = _TMP
os.environ["FORGE_DB_PATH"] = str(Path(_TMP) / "forge.db")
os.environ["FORGE_WORKSPACE_DIR"] = str(Path(_TMP) / "ws")
os.environ["FORGE_FEISHU_ENABLED"] = "0"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


async def main() -> int:
    import json

    import httpx
    import websockets

    import main as forge_main

    async with forge_main.app.router.lifespan_context(forge_main.app):
        config = __import__("uvicorn").Config(forge_main.app, host="127.0.0.1", port=8031, lifespan="off")
        server = __import__("uvicorn").Server(config)
        server_task = asyncio.create_task(server.serve())
        await asyncio.sleep(1.5)

        async with httpx.AsyncClient(base_url="http://127.0.0.1:8031", timeout=15) as cli:
            sid = (await cli.post("/api/sessions", json={})).json()["data"]["session_id"]

        received: list[str] = []
        async with websockets.connect("ws://127.0.0.1:8031/ws") as ws:
            hello = json.loads(await ws.recv())
            assert hello["event"] == "hello", hello
            await ws.send(json.dumps({"type": "ping"}))
            async with httpx.AsyncClient(base_url="http://127.0.0.1:8031", timeout=15) as cli:
                await cli.post(f"/api/sessions/{sid}/messages", json={"text": "计算 12*12"})
            try:
                while True:
                    frame = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
                    received.append(frame["event"])
                    if frame["event"] in ("run.completed", "run.failed"):
                        break
            except asyncio.TimeoutError:
                pass

        server.should_exit = True
        await server_task

    need = {"model.delta", "model.completed", "tool.requested", "tool.result", "run.started", "run.completed"}
    got = set(received)
    missing = need - got
    print("收到事件:", sorted(got))
    if missing:
        print(f"[FAIL] 缺少事件: {missing}")
        return 1
    print("[PASS] WebSocket 实时流完整")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
