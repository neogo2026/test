# v1/api/plugins/builtin/feishu/ws_client.py
"""
飞书长连接客户端 · WebSocket 主动外连（无需公网 IP / 域名 / 内网穿透）。

纪律（承接上一代 AI助理 实战经验）：
- 未配置凭据时不启动，安全降级（状态 disabled）
- SDK 回调线程 → run_coroutine_threadsafe 投递回 FastAPI 主循环
- 回调绝不能抛异常，否则 SDK 可能中断连接
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import threading
import time
from typing import Any, Callable

_state: dict[str, Any] = {
    "enabled": False,
    "running": False,
    "connected": False,
    "error": "",
    "started_at": 0.0,
    "last_event_at": 0.0,
}

_thread: threading.Thread | None = None
_main_loop: asyncio.AbstractEventLoop | None = None
_lock = threading.Lock()

# 只探测不导入：lark_oapi 一旦在主线程导入，其 ws.client 会在模块顶层
# 捕获当前事件循环，导致线程内 client.start() 报 "This event loop is already running"。
# 真正的 import 必须发生在长连接线程内（见 _run）。
SDK_AVAILABLE = importlib.util.find_spec("lark_oapi") is not None


def status() -> dict:
    return dict(_state)


def sdk_available() -> bool:
    return SDK_AVAILABLE


def _app_creds() -> tuple[str, str]:
    from configs import secrets

    return secrets.FEISHU_APP_ID, secrets.FEISHU_APP_SECRET


def is_configured() -> bool:
    from configs.configs import FEISHU_ENABLED

    app_id, app_secret = _app_creds()
    return FEISHU_ENABLED and bool(app_id and app_secret)


def _strip_mention(text: str) -> str:
    import re

    return re.sub(r"<at[^>]*>.*?</at>", "", text or "").strip()


def _extract_text(event: Any) -> tuple[str, str]:
    """从 im.message.receive_v1 事件取 (chat_id, text)；非文本返回 ('', '')。"""
    msg = getattr(event, "event", None)
    message = getattr(msg, "message", None) if msg else None
    if not message:
        return "", ""
    chat_id = getattr(message, "chat_id", "") or ""
    if (getattr(message, "message_type", "") or "") != "text":
        return chat_id, ""
    try:
        content = json.loads(getattr(message, "content", "") or "{}")
    except (ValueError, TypeError):
        return chat_id, ""
    return chat_id, _strip_mention(content.get("text", ""))


def _on_message(data: Any) -> None:
    try:
        _state["last_event_at"] = time.time()
        from plugins.builtin.feishu.plugin import handle_feishu_message

        chat_id, text = _extract_text(data)
        if not chat_id or not text:
            return
        if _main_loop is None:
            return
        asyncio.run_coroutine_threadsafe(handle_feishu_message(chat_id, text), _main_loop)
    except Exception:  # 长连接回调绝不能抛异常
        _state["error"] = "消息处理异常"


def _run() -> None:
    try:
        import lark_oapi as lark
        from lark_oapi.ws.client import Client

        app_id, app_secret = _app_creds()
        handler = (
            lark.EventDispatcherHandler.builder("", "")
            .register_p2_im_message_receive_v1(_on_message)
            .build()
        )
        client = Client(app_id, app_secret, event_handler=handler)
        _state["running"] = True
        _state["connected"] = True
        _state["error"] = ""
        print("[OK] 飞书长连接已启动（WebSocket 主动外连）")
        client.start()  # 阻塞，SDK 内置自动重连
    except Exception as exc:  # noqa: BLE001
        _state["connected"] = False
        _state["error"] = str(exc)
        print(f"[警告] 飞书长连接启动失败：{exc}")


def start(loop: asyncio.AbstractEventLoop) -> bool:
    global _thread, _main_loop
    if not SDK_AVAILABLE:
        _state["enabled"] = False
        _state["error"] = "未安装 lark-oapi（pip install lark-oapi）"
        return False
    if not is_configured():
        _state["enabled"] = False
        return False
    _state["enabled"] = True
    with _lock:
        if _thread and _thread.is_alive():
            return True
        _main_loop = loop
        _state["started_at"] = time.time()
        _thread = threading.Thread(target=_run, name="feishu-ws", daemon=True)
        _thread.start()
    return True
