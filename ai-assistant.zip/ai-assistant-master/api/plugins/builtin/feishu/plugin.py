# v1/api/plugins/builtin/feishu/plugin.py
"""
飞书插件：用 IM 对话指挥本机长程任务。

入站：长连接 im.message.receive_v1 → chat_id 绑定本机会话 → start_run
出站：订阅事件总线 run.completed / run.failed / approval.required → 回传飞书

指令：/new 新建任务 · /status 进度 · /stop 停止 · /approve <id> · /reject <id>
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

import httpx
from fastapi import APIRouter

from configs.configs import API_PREFIX, FEISHU_ENABLED
from plugins.base import Plugin, PluginContext, PluginMeta

logger = logging.getLogger(__name__)
router = APIRouter(prefix=API_PREFIX)

FEISHU_BASE = "https://open.feishu.cn/open-apis"
_token_cache: dict[str, Any] = {"token": "", "exp": 0.0}


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


# ----------------------------------------------------------------------
# 飞书开放平台 API
# ----------------------------------------------------------------------
def _creds() -> tuple[str, str]:
    from configs import secrets

    return secrets.FEISHU_APP_ID, secrets.FEISHU_APP_SECRET


def configured() -> bool:
    app_id, app_secret = _creds()
    return FEISHU_ENABLED and bool(app_id and app_secret)


async def _tenant_token() -> str:
    now = time.time()
    if _token_cache["token"] and _token_cache["exp"] > now + 300:
        return _token_cache["token"]
    app_id, app_secret = _creds()
    async with httpx.AsyncClient(timeout=15) as cli:
        r = await cli.post(f"{FEISHU_BASE}/auth/v3/tenant_access_token/internal",
                           json={"app_id": app_id, "app_secret": app_secret})
        data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"飞书鉴权失败：{data.get('msg')}")
    _token_cache["token"] = data["tenant_access_token"]
    _token_cache["exp"] = now + int(data.get("expire", 7200))
    return _token_cache["token"]


async def send_text(chat_id: str, text: str) -> None:
    if not configured() or not chat_id:
        return
    try:
        token = await _tenant_token()
        async with httpx.AsyncClient(timeout=15) as cli:
            await cli.post(
                f"{FEISHU_BASE}/im/v1/messages?receive_id_type=chat_id",
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "receive_id": chat_id,
                    "msg_type": "text",
                    "content": json.dumps({"text": (text or "")[:4000]}, ensure_ascii=False),
                },
            )
    except Exception:  # noqa: BLE001 - 回传失败不影响主流程
        logger.exception("飞书消息回传失败")


# ----------------------------------------------------------------------
# 消息处理（ws_client 投递回主循环）
# ----------------------------------------------------------------------
async def handle_feishu_message(chat_id: str, text: str) -> None:
    from configs.configs import DEFAULT_GATE_MODE
    from core.harness import get_harness

    harness = await get_harness()
    runtime = harness.runtime
    text = (text or "").strip()
    if not text:
        return

    low = text.lower()

    # 指令路由
    if low in ("/new", "/新任务"):
        session = await runtime.create_session(
            title=f"飞书任务 {chat_id[-6:]}", gate_mode=DEFAULT_GATE_MODE, source="feishu"
        )
        await harness.storage.upsert_feishu_link(chat_id, session["session_id"], session["title"])
        await send_text(chat_id, f"已新建任务（{session['session_id'][:14]}…），直接发消息即可派活。")
        return

    if low in ("/status", "/状态"):
        link = await harness.storage.get_feishu_link(chat_id)
        if not link:
            await send_text(chat_id, "当前没有绑定任务，发送 /new 新建，或直接发消息自动创建。")
            return
        session = await harness.storage.get_session(link["session_id"])
        run = await harness.storage.last_run(link["session_id"])
        lines = [
            f"任务：{session.get('title') or session['session_id']}",
            f"会话状态：{session.get('status')}",
        ]
        if run:
            lines.append(f"最近 Run：{run['status']} · {run['step_count']} 步")
            if run.get("error"):
                lines.append(f"错误：{run['error'][:200]}")
        pending = await harness.storage.list_approvals(status="pending", session_id=link["session_id"])
        if pending:
            lines.append(f"待审批 {len(pending)} 项：/approve {pending[0]['approval_id']}")
        await send_text(chat_id, "\n".join(lines))
        return

    if low.startswith("/stop"):
        link = await harness.storage.get_feishu_link(chat_id)
        if link:
            run = await harness.storage.last_run(link["session_id"])
            if run and run["status"] not in ("COMPLETED", "FAILED", "CANCELLED"):
                await runtime.cancel_run(run["run_id"])
                await send_text(chat_id, "已停止当前任务。")
                return
        await send_text(chat_id, "没有正在运行的任务。")
        return

    if low.startswith("/approve") or low.startswith("/reject"):
        approved = low.startswith("/approve")
        parts = text.split()
        approval_id = parts[1] if len(parts) > 1 else ""
        if not approval_id:
            link = await harness.storage.get_feishu_link(chat_id)
            if link:
                pending = await harness.storage.list_approvals(status="pending", session_id=link["session_id"])
                if len(pending) == 1:
                    approval_id = pending[0]["approval_id"]
        if not approval_id:
            await send_text(chat_id, "用法：/approve <审批ID>（一次只批一项）")
            return
        result = await resolve_approval(approval_id, approved, resolver=f"feishu:{chat_id[-6:]}")
        await send_text(chat_id, result)
        return

    # 普通消息：绑定或新建会话，然后派活
    link = await harness.storage.get_feishu_link(chat_id)
    if link:
        session = await harness.storage.get_session(link["session_id"])
        if not session or session.get("hidden"):
            session = None
    else:
        session = None

    if session is None:
        session = await runtime.create_session(
            title=text[:18] or f"飞书任务 {chat_id[-6:]}", gate_mode=DEFAULT_GATE_MODE, source="feishu"
        )
        await harness.storage.upsert_feishu_link(chat_id, session["session_id"], session["title"])
        await send_text(chat_id, "已创建新任务并开始执行；/new 可强制再开一个。")
    else:
        await harness.storage.upsert_feishu_link(chat_id, session["session_id"], session.get("title") or "")

    await runtime.start_run(session["session_id"], text)


async def resolve_approval(approval_id: str, approved: bool, resolver: str = "feishu") -> str:
    from core.harness import get_harness

    harness = await get_harness()
    approval = await harness.approvals.get(approval_id)
    if not approval:
        return "审批不存在。"
    if approval["status"] != "pending":
        return f"该审批已处理（{approval['status']}）。"
    await harness.approvals.resolve(approval_id, approved, resolver=resolver)
    if approved:
        await harness.runtime.resume_run(approval["run_id"])
        return f"已批准 {approval['tool_name']}，任务继续执行。"
    return f"已拒绝 {approval['tool_name']}。"


# ----------------------------------------------------------------------
# 事件订阅：任务完成 / 失败 / 待审批 → 回传
# ----------------------------------------------------------------------
async def _on_event(session_id: str, event_type: str, payload: dict) -> None:
    from core.harness import get_harness

    if event_type not in ("run.completed", "run.failed", "approval.required"):
        return
    harness = await get_harness()
    link = await harness.storage.find_feishu_link_by_session(session_id)
    if not link:
        return
    chat_id = link["chat_id"]
    if event_type == "run.completed":
        output = str(payload.get("output") or "")
        await send_text(chat_id, f"✅ 任务完成\n\n{output[-1500:]}")
    elif event_type == "run.failed":
        await send_text(chat_id, f"❌ 任务失败：{str(payload.get('error'))[:500]}")
    elif event_type == "approval.required":
        await send_text(
            chat_id,
            f"⏳ 需要审批：{payload.get('tool')}\n参数：{json.dumps(payload.get('arguments') or {}, ensure_ascii=False)[:600]}\n"
            f"回复 /approve {payload.get('approval_id')} 批准，/reject 拒绝。",
        )


# ----------------------------------------------------------------------
# 路由
# ----------------------------------------------------------------------
@router.get("/feishu/status")
async def feishu_status():
    from plugins.builtin.feishu import ws_client

    return ok(
        {
            "configured": configured(),
            "sdk_installed": ws_client.sdk_available(),
            **ws_client.status(),
        }
    )


@router.post("/feishu/test")
async def feishu_test(chat_id: str = ""):
    if not configured():
        return {"code": 400, "message": "未配置飞书凭据"}
    if not chat_id:
        return {"code": 400, "message": "缺少 chat_id"}
    await send_text(chat_id, "AI助理 飞书连通测试 ✅")
    return ok({"sent": True})


# ----------------------------------------------------------------------
# 插件
# ----------------------------------------------------------------------
class FeishuPlugin(Plugin):
    meta = PluginMeta(
        name="feishu",
        title="飞书长程任务",
        version="1.0.0",
        description="飞书 WebSocket 长连接：IM 对话指挥本机 AI 长程任务，结果自动回传。",
        author="AI助理",
        priority=50,
        tags=["builtin", "connector", "feishu"],
    )

    def register(self, ctx: PluginContext) -> None:
        ctx.register_router(router)
        ctx.subscribe_events(_on_event)

    async def on_start(self, ctx: PluginContext) -> None:
        import asyncio

        from plugins.builtin.feishu import ws_client

        ws_client.start(asyncio.get_running_loop())


PLUGIN = FeishuPlugin()
