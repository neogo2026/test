# v1/api/plugins/builtin/skills/loader.py
"""
Markdown Skill 加载器（能力管理）。

Skill 是「怎么做」的方法论，不是可执行权限。
front-matter 元数据 + 触发词打分检索，只把命中摘要注入上下文。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Skill:
    name: str
    title: str
    kinds: list[str] = field(default_factory=list)
    triggers: list[str] = field(default_factory=list)
    version: str = "1.0.0"
    body: str = ""
    path: str = ""

    def summary(self, max_chars: int = 700) -> str:
        text = self.body.strip()
        if len(text) > max_chars:
            text = text[:max_chars] + "..."
        return f"### Skill: {self.title}\n触发词: {', '.join(self.triggers)}\n{text}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "title": self.title,
            "kinds": self.kinds,
            "triggers": self.triggers,
            "version": self.version,
            "chars": len(self.body),
            "path": self.path,
        }


def _parse_list(value: str) -> list[str]:
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    return [item.strip().strip("'\"") for item in value.split(",") if item.strip()]


def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    raw, body = parts[1], parts[2]
    meta: dict[str, Any] = {}
    for line in raw.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        meta[key] = _parse_list(value) if (value.startswith("[") and value.endswith("]")) else value
    return meta, body.lstrip("\n")


def render_skill(name: str, title: str, kinds: list[str], triggers: list[str], body: str) -> str:
    lines = [
        "---",
        f"name: {name}",
        f"title: {title}",
        f"kinds: [{', '.join(kinds)}]",
        f"triggers: [{', '.join(triggers)}]",
        "version: 1.0.0",
        "---",
        "",
        body.rstrip(),
        "",
    ]
    return "\n".join(lines)


class SkillLoader:
    def __init__(self, skills_dir: Path):
        self.skills_dir = Path(skills_dir)
        self._skills: dict[str, Skill] = {}

    def load_all(self) -> list[Skill]:
        self._skills.clear()
        if not self.skills_dir.exists():
            return []
        for path in sorted(self.skills_dir.glob("*.md")):
            text = path.read_text(encoding="utf-8", errors="replace")
            meta, body = _parse_frontmatter(text)
            name = str(meta.get("name") or path.stem)
            self._skills[name] = Skill(
                name=name,
                title=str(meta.get("title") or name),
                kinds=list(meta.get("kinds") or []),
                triggers=list(meta.get("triggers") or []),
                version=str(meta.get("version") or "1.0.0"),
                body=body,
                path=str(path),
            )
        return list(self._skills.values())

    def get(self, name: str) -> Skill | None:
        return self._skills.get(name)

    def list(self) -> list[dict[str, Any]]:
        return [skill.to_dict() for skill in self._skills.values()]

    def save(self, name: str, title: str, kinds: list[str], triggers: list[str], body: str) -> Skill:
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        path = self.skills_dir / f"{name}.md"
        path.write_text(render_skill(name, title, kinds, triggers, body), encoding="utf-8")
        skill = Skill(name=name, title=title, kinds=kinds, triggers=triggers, body=body, path=str(path))
        self._skills[name] = skill
        return skill

    def delete(self, name: str) -> bool:
        skill = self._skills.pop(name, None)
        if not skill:
            return False
        path = Path(skill.path)
        if path.exists():
            path.unlink()
        return True

    def search(self, query: str, limit: int = 3) -> list[Skill]:
        query = (query or "").strip()
        if not query:
            return []
        query_lower = query.lower()
        terms = set(re.findall(r"[a-zA-Z0-9_]+", query_lower))
        terms.update(ch for ch in query_lower if "\u4e00" <= ch <= "\u9fff")

        scored: list[tuple[float, Skill]] = []
        for skill in self._skills.values():
            score = 0.0
            for trigger in skill.triggers:
                if trigger and trigger.lower() in query_lower:
                    score += 6.0
            for kind in skill.kinds:
                if kind.lower() in query_lower:
                    score += 2.0
            haystack = f"{skill.title} {skill.name} {' '.join(skill.triggers)} {skill.body}".lower()
            for term in terms:
                if term and term in haystack:
                    score += 0.6
            if score > 0:
                scored.append((score, skill))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [skill for _, skill in scored[:limit]]
