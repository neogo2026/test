# v1/api/plugins/builtin/skills/routes.py
"""技能 CRUD 路由：保存即生效（热加载）。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from configs.configs import API_PREFIX

router = APIRouter(prefix=API_PREFIX)


class SkillSave(BaseModel):
    name: str
    title: str = ""
    kinds: list[str] = []
    triggers: list[str] = []
    body: str = ""


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


def _loader() -> Any:
    from plugins.builtin.skills.plugin import PLUGIN

    return PLUGIN.loader


@router.get("/skills")
async def list_skills():
    return ok(_loader().list())


@router.get("/skills/search")
async def search_skills(q: str = "", limit: int = 3):
    return ok([s.to_dict() for s in _loader().search(q, limit)])


@router.post("/skills")
async def save_skill(payload: SkillSave):
    name = payload.name.strip()
    if not name or not name.replace("-", "").replace("_", "").isalnum():
        return {"code": 400, "message": "技能名仅允许字母/数字/中划线/下划线"}
    skill = _loader().save(
        name, payload.title or name, payload.kinds, payload.triggers, payload.body
    )
    return ok(skill.to_dict())


@router.get("/skills/{name}")
async def get_skill(name: str):
    skill = _loader().get(name)
    if not skill:
        return {"code": 404, "message": f"技能不存在: {name}"}
    data = skill.to_dict()
    data["body"] = skill.body
    return ok(data)


@router.put("/skills/{name}")
async def update_skill(name: str, payload: SkillSave):
    if not _loader().get(name):
        return {"code": 404, "message": f"技能不存在: {name}"}
    skill = _loader().save(
        name, payload.title or name, payload.kinds, payload.triggers, payload.body
    )
    return ok(skill.to_dict())


@router.delete("/skills/{name}")
async def delete_skill(name: str):
    deleted = _loader().delete(name)
    return ok({"deleted": deleted})
