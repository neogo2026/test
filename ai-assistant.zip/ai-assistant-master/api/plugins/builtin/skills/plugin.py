# v1/api/plugins/builtin/skills/plugin.py
"""
技能插件：Markdown 方法论能力管理。

- 加载 skills/*.md（front-matter 元数据 + 正文）
- 注入内核上下文构建器（命中时只注入摘要，避免撑爆 token）
- 提供前端技能管理 CRUD 路由（保存即生效）
"""

from __future__ import annotations

from configs.configs import SKILLS_DIR
from plugins.base import Plugin, PluginContext, PluginMeta
from plugins.builtin.skills.loader import SkillLoader
from plugins.builtin.skills.routes import router as skills_router


class SkillsPlugin(Plugin):
    meta = PluginMeta(
        name="skills",
        title="技能库",
        version="1.0.0",
        description="Markdown 方法论技能：自动检索注入上下文 + 前端管理，保存即生效。",
        author="AI助理",
        priority=30,
        tags=["builtin", "skills"],
    )

    def __init__(self):
        self.loader = SkillLoader(SKILLS_DIR)

    def register(self, ctx: PluginContext) -> None:
        self.loader.load_all()
        ctx.set_skill_provider(self.loader.search)
        ctx.register_router(skills_router)

    async def on_start(self, ctx: PluginContext) -> None:
        # 技能目录可能被外部编辑，启动时再热加载一次
        self.loader.load_all()


PLUGIN = SkillsPlugin()
