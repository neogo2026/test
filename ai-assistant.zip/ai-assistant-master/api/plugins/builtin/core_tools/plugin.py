# v1/api/plugins/builtin/core_tools/plugin.py
"""
核心工具插件：echo / now / calculator / run_python。

这是最小内置工具集，保证零密钥环境下全链路（工具调用/审批/事件/恢复）可自测。
"""

from __future__ import annotations

import ast
import os
import sys
from datetime import datetime, timezone
from typing import Any

from core.contracts import ToolSpec
from plugins.base import Plugin, PluginContext, PluginMeta

_BIN_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a ** b,
}
_UNARY_OPS = {ast.UAdd: lambda a: a, ast.USub: lambda a: -a}


def _eval_ast(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _eval_ast(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
        left = _eval_ast(node.left)
        right = _eval_ast(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 10:
            raise ValueError("指数过大，已拒绝")
        return _BIN_OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_eval_ast(node.operand))
    raise ValueError("表达式只支持数字与 + - * / // % ** 运算")


def calculator(expression: str) -> dict[str, Any]:
    expression = (expression or "").strip()
    if len(expression) > 200:
        raise ValueError("表达式过长")
    tree = ast.parse(expression, mode="eval")
    return {"expression": expression, "result": _eval_ast(tree)}


def echo(text: str) -> dict[str, Any]:
    return {"text": text}


def now() -> dict[str, Any]:
    return {"now": datetime.now(timezone.utc).isoformat()}


async def run_python(code: str, timeout_s: float = 10) -> dict[str, Any]:
    import asyncio

    from core.exec_context import current_context

    if len(code) > 20_000:
        raise ValueError("代码过长")
    root = current_context().workspace_root()
    env = {
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        "PATH": os.environ.get("PATH", ""),
    }
    if sys.platform == "win32":
        env["SYSTEMROOT"] = os.environ.get("SYSTEMROOT", "")
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-I", "-c", code,
        cwd=str(root),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise RuntimeError(f"代码执行超时（>{timeout_s}s）")
    return {
        "exit_code": proc.returncode,
        "stdout": stdout.decode("utf-8", errors="replace")[-8000:],
        "stderr": stderr.decode("utf-8", errors="replace")[-8000:],
    }


class CoreToolsPlugin(Plugin):
    meta = PluginMeta(
        name="core_tools",
        title="核心工具",
        version="1.0.0",
        description="echo / now / calculator / run_python：零密钥环境的最小自测工具集。",
        author="AI助理",
        priority=10,
        tags=["builtin", "tools"],
    )

    def register(self, ctx: PluginContext) -> None:
        ctx.register_tool(
            ToolSpec(
                name="echo",
                description="回显文本，用于验证工具调用链路。",
                input_schema={"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
            ),
            echo,
        )
        ctx.register_tool(
            ToolSpec(
                name="now",
                description="返回当前 UTC 时间。",
                input_schema={"type": "object", "properties": {}},
            ),
            now,
        )
        ctx.register_tool(
            ToolSpec(
                name="calculator",
                description="安全计算数学表达式，支持数字与 + - * / // % **。",
                input_schema={
                    "type": "object",
                    "properties": {"expression": {"type": "string"}},
                    "required": ["expression"],
                },
            ),
            calculator,
        )
        ctx.register_tool(
            ToolSpec(
                name="run_python",
                description="在会话工作区内以隔离子进程执行 Python 代码；高风险，需人工批准。",
                input_schema={"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]},
                risk="high",
                side_effect="write",
                timeout_s=60,
            ),
            run_python,
        )


PLUGIN = CoreToolsPlugin()
