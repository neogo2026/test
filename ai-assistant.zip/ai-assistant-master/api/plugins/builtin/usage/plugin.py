# v1/api/plugins/builtin/usage/plugin.py
"""
用量插件：订阅 model.completed 事件 → 日/模型/会话 token 记账 + 报表路由。
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from configs.configs import API_PREFIX
from plugins.base import Plugin, PluginContext, PluginMeta

router = APIRouter(prefix=API_PREFIX)


class UsageSave(BaseModel):
    day: str
    model: str
    prompt: int = 0
    completion: int = 0
    total: int = 0


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


@router.get("/usage/daily")
async def usage_daily(limit: int = 30):
    from core.harness import get_harness

    harness = await get_harness()
    return ok(await harness.storage.usage_daily(limit))


@router.get("/usage/by-model")
async def usage_by_model(limit: int = 30):
    from core.harness import get_harness

    harness = await get_harness()
    return ok(await harness.storage.usage_by_model(limit))


@router.get("/usage/today")
async def usage_today():
    from core.harness import get_harness

    harness = await get_harness()
    return ok(await harness.storage.usage_today())


class UsagePlugin(Plugin):
    meta = PluginMeta(
        name="usage",
        title="用量记账",
        version="1.0.0",
        description="按 日/模型/会话 记录 token 用量，提供报表接口。",
        author="AI助理",
        priority=40,
        tags=["builtin", "observability"],
    )

    def __init__(self):
        self._ctx: PluginContext | None = None

    def register(self, ctx: PluginContext) -> None:
        self._ctx = ctx
        ctx.register_router(router)
        ctx.subscribe_events(self._on_event)

    async def _on_event(self, session_id: str, event_type: str, payload: dict) -> None:
        if event_type != "model.completed":
            return
        usage = payload.get("usage") or {}
        prompt = int(usage.get("prompt_tokens") or 0)
        completion = int(usage.get("completion_tokens") or 0)
        total = int(usage.get("total_tokens") or (prompt + completion))
        if total <= 0 or self._ctx is None:
            return
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        model = str(payload.get("model") or "unknown")
        await self._ctx.storage.add_usage(day, model, session_id, prompt, completion, total)


PLUGIN = UsagePlugin()
