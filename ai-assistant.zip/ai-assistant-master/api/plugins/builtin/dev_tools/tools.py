# v1/api/plugins/builtin/dev_tools/tools.py
"""
开发工具集实现。

文件操作全部经由 SafeWorkspace（路径越界防护）锚定在会话工作区内；
run_shell 使用子进程 + 超时 + 输出截断；
危险命令黑名单由 plugin.py 的 screener 统一预检。
"""

from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path
from typing import Any

from core.exec_context import current_context
from core.sandbox import SafeWorkspace


def _workspace() -> SafeWorkspace:
    ctx = current_context()
    return SafeWorkspace(ctx.workspace_root() if ctx.workspace_dir else Path("data/workspace"))


# ----------------------------------------------------------------------
# 只读工具
# ----------------------------------------------------------------------
def list_dir(path: str = ".") -> dict[str, Any]:
    return {"path": path or ".", "items": _workspace().list_dir(path)}


def read_file(path: str, offset: int = 1, limit: int = 400) -> dict[str, Any]:
    """按行读取文件（带行号），offset 从 1 开始。"""
    ws = _workspace()
    text = ws.read_text(path, max_chars=400_000)
    lines = text.splitlines()
    total = len(lines)
    start = max(1, offset)
    selected = lines[start - 1 : start - 1 + limit]
    numbered = "\n".join(f"{start + i}: {line}" for i, line in enumerate(selected))
    return {
        "path": path,
        "total_lines": total,
        "offset": start,
        "returned": len(selected),
        "content": numbered,
    }


def glob_files(pattern: str, path: str = ".") -> dict[str, Any]:
    ws = _workspace()
    base = ws.resolve(path)
    if not base.exists():
        raise FileNotFoundError(f"目录不存在: {path}")
    matches = sorted(p.relative_to(ws.root) for p in base.rglob(pattern) if ".git" not in p.parts)
    return {"pattern": pattern, "path": path, "matches": [str(m) for m in matches[:200]], "count": len(matches)}


def grep_search(pattern: str, path: str = ".", include: str = "*") -> dict[str, Any]:
    ws = _workspace()
    base = ws.resolve(path)
    regex = re.compile(pattern)
    results: list[dict[str, Any]] = []
    candidates = (
        [base]
        if base.is_file()
        else [p for p in base.rglob(include) if p.is_file() and ".git" not in p.parts]
    )
    for file_path in candidates[:500]:
        try:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for line_no, line in enumerate(text.splitlines(), 1):
            if regex.search(line):
                rel = file_path.relative_to(ws.root)
                results.append({"path": str(rel), "line": line_no, "text": line[:300]})
                if len(results) >= 200:
                    return {"pattern": pattern, "matches": results, "truncated": True}
    return {"pattern": pattern, "matches": results, "truncated": False}


# ----------------------------------------------------------------------
# 写操作工具（高风险，走审批）
# ----------------------------------------------------------------------
def write_file(path: str, content: str) -> dict[str, Any]:
    ws = _workspace()
    target = ws.write_text(path, content)
    return {"path": path, "absolute_path": str(target), "size": target.stat().st_size}


def edit_file(path: str, old_string: str, new_string: str, replace_all: bool = False) -> dict[str, Any]:
    ws = _workspace()
    text = ws.read_text(path, max_chars=2_000_000)
    count = text.count(old_string)
    if count == 0:
        raise ValueError(f"未找到待替换文本（请核对空白与缩进）")
    if count > 1 and not replace_all:
        raise ValueError(f"待替换文本出现 {count} 次；请提供更长的上下文或设置 replace_all")
    new_text = text.replace(old_string, new_string) if replace_all else text.replace(old_string, new_string, 1)
    target = ws.write_text(path, new_text)
    return {"path": path, "absolute_path": str(target), "replaced": count if replace_all else 1,
            "size": target.stat().st_size}


def multi_edit(path: str, edits: list[dict[str, Any]]) -> dict[str, Any]:
    ws = _workspace()
    text = ws.read_text(path, max_chars=2_000_000)
    applied = 0
    for edit in edits or []:
        old, new = str(edit.get("old") or ""), str(edit.get("new") or "")
        if old not in text:
            raise ValueError(f"未找到待替换文本: {old[:60]}...")
        text = text.replace(old, new, 1)
        applied += 1
    target = ws.write_text(path, text)
    return {"path": path, "absolute_path": str(target), "applied": applied, "size": target.stat().st_size}


def delete_path(path: str) -> dict[str, Any]:
    ws = _workspace()
    target = ws.resolve(path)
    if not target.exists():
        raise FileNotFoundError(f"路径不存在: {path}")
    if target == ws.root:
        raise ValueError("拒绝删除工作区根目录")
    import shutil

    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()
    return {"path": path, "deleted": True}


def move_path(src: str, dst: str) -> dict[str, Any]:
    ws = _workspace()
    source = ws.resolve(src)
    if not source.exists():
        raise FileNotFoundError(f"源路径不存在: {src}")
    target = ws.resolve(dst)
    target.parent.mkdir(parents=True, exist_ok=True)
    source.replace(target)
    return {"src": src, "dst": dst, "moved": True}


# ----------------------------------------------------------------------
# Shell（高风险，黑名单预检 + 审批）
# ----------------------------------------------------------------------
async def run_shell(command: str, timeout_s: float = 120) -> dict[str, Any]:
    ctx = current_context()
    cwd = ctx.workspace_root()
    shell = True
    proc = await asyncio.create_subprocess_shell(
        command,
        cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        shell=shell,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise RuntimeError(f"命令执行超时（>{timeout_s}s）")
    return {
        "command": command,
        "exit_code": proc.returncode,
        "stdout": stdout.decode("utf-8", errors="replace")[-8000:],
        "stderr": stderr.decode("utf-8", errors="replace")[-4000:],
    }


# ----------------------------------------------------------------------
# 危险命令预检（注册为 Policy Screener）
# ----------------------------------------------------------------------
SHELL_BLACKLIST = [
    "rm -rf /", "rm -rf ~", "rm -rf /*", "format ", "diskpart",
    "rd /s", "del /f /s /q", "remove-item -recurse -force",
    "shutdown", "reg delete", "bcdedit", "mkfs", "dd if=",
    ":(){ :|:& };:",
]


def danger_screener(tool_name: str, arguments: dict[str, Any]) -> str | None:
    """返回拒绝理由；None 表示放行。"""
    if tool_name == "run_shell":
        cmd = str(arguments.get("command") or "").lower()
        for frag in SHELL_BLACKLIST:
            if frag in cmd:
                return f"命令命中黑名单片段「{frag}」，已拒绝执行"
        if re.search(r"\bgit\b[^&|;]*\bpush\b", cmd):
            return "git push 默认禁用（防止误推远程），如需推送请手动执行"
    if tool_name == "run_python":
        code = str(arguments.get("code") or "").lower()
        for frag in ("shutil.rmtree('/')", "os.system('rm -rf"):
            if frag in code:
                return "代码命中黑名单片段，已拒绝执行"
    return None
