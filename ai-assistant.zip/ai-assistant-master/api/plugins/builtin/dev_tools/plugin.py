# v1/api/plugins/builtin/dev_tools/plugin.py
"""
开发工具插件：AI助理 的主力编程能力。

工具矩阵（对标上一代 AI助理 dev 工具集 / Claude Code）：
- 只读免批：list_dir / read_file / glob / grep
- 写操作需批：write_file / edit_file / multi_edit / delete_path / move_path
- 高危需批：run_shell（黑名单预检） / run_python（core_tools 提供）

同时注册主力 Agent「coder」——体现「harness 即插件」：
主力能力是插件装配出来的，不是内核硬编码。
"""

from __future__ import annotations

from configs.configs import (
    MAX_CONTEXT_TOKENS,
    MAX_STEPS,
    SHELL_TIMEOUT_S,
)
from configs.models import DEFAULT_MODEL_PROFILE
from core.contracts import AgentSpec, ToolSpec
from plugins.base import Plugin, PluginContext, PluginMeta
from plugins.builtin.dev_tools import tools as dev

DEV_TOOLS = [
    "list_dir", "read_file", "glob", "grep",
    "write_file", "edit_file", "multi_edit", "delete_path", "move_path",
    "run_shell",
    "run_python", "calculator", "now", "echo",
]


class DevToolsPlugin(Plugin):
    meta = PluginMeta(
        name="dev_tools",
        title="开发工具集",
        version="1.0.0",
        description="文件读写/编辑/搜索/Shell/Python 执行：AI 编程主力工具与 coder Agent。",
        author="AI助理",
        priority=20,
        tags=["builtin", "tools", "coding"],
    )

    def register(self, ctx: PluginContext) -> None:
        # ---- 只读 ----
        ctx.register_tool(
            ToolSpec(
                name="list_dir",
                description="列出会话工作区内目录内容。",
                input_schema={"type": "object", "properties": {"path": {"type": "string", "default": "."}}},
                timeout_s=15,
            ),
            dev.list_dir,
        )
        ctx.register_tool(
            ToolSpec(
                name="read_file",
                description="按行读取工作区内文本文件（带行号）。offset 从 1 开始，默认读 400 行。",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "offset": {"type": "integer", "default": 1},
                        "limit": {"type": "integer", "default": 400},
                    },
                    "required": ["path"],
                },
                timeout_s=20,
            ),
            dev.read_file,
        )
        ctx.register_tool(
            ToolSpec(
                name="glob",
                description="在工作区内按 glob 模式查找文件（如 **/*.py）。",
                input_schema={
                    "type": "object",
                    "properties": {"pattern": {"type": "string"}, "path": {"type": "string", "default": "."}},
                    "required": ["pattern"],
                },
                timeout_s=20,
            ),
            dev.glob_files,
        )
        ctx.register_tool(
            ToolSpec(
                name="grep",
                description="在工作区内按正则搜索文件内容，返回 文件:行号:文本。",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string", "default": "."},
                        "include": {"type": "string", "default": "*"},
                    },
                    "required": ["pattern"],
                },
                timeout_s=30,
            ),
            dev.grep_search,
        )

        # ---- 写操作（审批）----
        ctx.register_tool(
            ToolSpec(
                name="write_file",
                description="在工作区内写入/覆盖文本文件；需人工批准。",
                input_schema={
                    "type": "object",
                    "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
                    "required": ["path", "content"],
                },
                risk="high", side_effect="write", idempotency="key", timeout_s=20,
            ),
            dev.write_file,
        )
        ctx.register_tool(
            ToolSpec(
                name="edit_file",
                description="精确字符串替换编辑文件（opencode 风格）；需人工批准。",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "old_string": {"type": "string"},
                        "new_string": {"type": "string"},
                        "replace_all": {"type": "boolean", "default": False},
                    },
                    "required": ["path", "old_string", "new_string"],
                },
                risk="high", side_effect="write", idempotency="key", timeout_s=20,
            ),
            dev.edit_file,
        )
        ctx.register_tool(
            ToolSpec(
                name="multi_edit",
                description="对同一文件应用多处精确替换（edits 数组，每项含 old/new）；需人工批准。",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "edits": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {"old": {"type": "string"}, "new": {"type": "string"}},
                                "required": ["old", "new"],
                            },
                        },
                    },
                    "required": ["path", "edits"],
                },
                risk="high", side_effect="write", idempotency="key", timeout_s=30,
            ),
            dev.multi_edit,
        )
        ctx.register_tool(
            ToolSpec(
                name="delete_path",
                description="删除工作区内文件或目录；高风险需批准，不可恢复。",
                input_schema={"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]},
                risk="high", side_effect="irreversible", timeout_s=20,
            ),
            dev.delete_path,
        )
        ctx.register_tool(
            ToolSpec(
                name="move_path",
                description="移动/重命名工作区内文件或目录；需人工批准。",
                input_schema={
                    "type": "object",
                    "properties": {"src": {"type": "string"}, "dst": {"type": "string"}},
                    "required": ["src", "dst"],
                },
                risk="medium", side_effect="write", timeout_s=20,
            ),
            dev.move_path,
        )
        ctx.register_tool(
            ToolSpec(
                name="run_shell",
                description="在会话工作区执行 shell 命令（危险命令黑名单预检）；需人工批准。",
                input_schema={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "timeout_s": {"type": "number", "default": 120},
                    },
                    "required": ["command"],
                },
                risk="high", side_effect="write", timeout_s=SHELL_TIMEOUT_S + 10,
            ),
            dev.run_shell,
        )

        # ---- 安全预检 ----
        ctx.register_screener(dev.danger_screener)

        # ---- 主力 Agent：coder ----
        ctx.register_agent(
            AgentSpec(
                name="coder",
                title="AI 工程师",
                description="主力编程 Agent：读写代码、搜索、执行命令、自测闭环。",
                instructions=(
                    "你是一名严谨高效的 AI 工程师，在用户的工作区内完成编程任务。\n"
                    "工作方法：\n"
                    "1. 先侦察：list_dir / glob / grep / read_file 理解项目结构与相关代码；\n"
                    "2. 再动手：write_file / edit_file 做最小必要修改，不顺手重构无关代码；\n"
                    "3. 必验证：用 run_shell（或 run_python）运行测试/编译/脚本，确认改动有效；\n"
                    "4. 有闭环：失败时读错误、修问题、再验证；连续两次相同失败必须换思路；\n"
                    "5. 规格类任务（无现成测试）必须先写自检脚本（如 tests_selfcheck.py），覆盖正常路径与边界"
                    "（非法输入、空数据、边界值、异常分支），实现后运行自检，全部通过再收尾；\n"
                    "6. 写文件与执行命令会触发人工审批，属正常流程，不要假设已执行。\n"
                    "回答用中文，简洁说明：改了什么、验证结果、遗留风险。"
                ),
                model_profile=DEFAULT_MODEL_PROFILE,
                tools=DEV_TOOLS,
                max_steps=MAX_STEPS,
                max_context_tokens=MAX_CONTEXT_TOKENS,
                auto_skills=True,
            )
        )


PLUGIN = DevToolsPlugin()
