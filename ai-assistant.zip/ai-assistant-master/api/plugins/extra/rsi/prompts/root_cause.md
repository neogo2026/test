# Root Cause Taxonomy

| category | 典型表现 | 优先修复 |
| --- | --- | --- |
| understanding | 目标理解错、约束漏看 | 需求澄清、验收清单 |
| planning | 步骤顺序错、只输出计划、过早结束 | Planner 模板、强制动手 |
| tool | 该用 read_file 却用 shell、重复失败 | 工具选择纪律 |
| parameters | 路径越界、命令拼错、JSON 非法 | schema 校验、参数模板 |
| observation | 忽略 stderr、误读测试输出 | 错误优先阅读规则 |
| memory | 重复踩坑、忘记项目约定 | 分层记忆、经验回放 |
| verification | 未运行测试、未复现就宣告完成 | Verifier、完成前检查表 |
| environment | 依赖缺失、权限不足 | 环境诊断、前置检查 |
| model_boundary | 长输出截断、上下文不足 | 分块写入、任务拆解 |
| efficiency | 成功但步数/token 异常 | 合并读取、减少重试 |
