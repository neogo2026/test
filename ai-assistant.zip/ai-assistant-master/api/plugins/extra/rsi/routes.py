# v1/api/plugins/extra/rsi/routes.py
"""RSI HTTP 接口面：状态 / 轨迹 / 失败 / 候选 / 实验 / 版本 / 导出 / 会话模式。"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from plugins.extra.rsi import config
from plugins.extra.rsi.runtime import get_service

router = APIRouter(prefix="/api/rsi")


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


def err(code: int, message: str) -> dict:
    return {"code": code, "message": message}


def _service():
    return get_service()


class ModeBody(BaseModel):
    mode: str = Field(..., description="off | observe | active")


class PromoteBody(BaseModel):
    force: bool = False


class SettingsBody(BaseModel):
    mode: str | None = None
    auto_promote: bool | None = None
    min_samples: int | None = None
    retention_days: int | None = None


def _bad_mode(mode: str) -> bool:
    return mode not in config.VALID_MODES


@router.get("/status")
async def status():
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.status())


@router.get("/episodes")
async def episodes(limit: int = 100, outcome: str = ""):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_episodes(limit=max(1, min(1000, limit)), outcome=outcome or None))


@router.get("/episodes/{episode_id}")
async def episode_detail(episode_id: str):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    item = await service.store.get_episode(episode_id)
    if not item:
        return err(404, "轨迹不存在")
    return ok(item)


@router.get("/failures")
async def failures(limit: int = 100, cluster_id: str = ""):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_failures(limit=max(1, min(1000, limit)), cluster_id=cluster_id or None))


@router.get("/failure-clusters")
async def failure_clusters():
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.failure_clusters())


@router.post("/mine")
async def mine():
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    failures = await service.miner.mine_pending()
    candidates = await service.proposer.propose_from_failures()
    return ok({
        "new_failures": failures,
        "failures": await service.store.list_failures(limit=100),
        "candidates": candidates,
    })


@router.get("/candidates")
async def candidates(limit: int = 100, status: str = ""):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_candidates(limit=max(1, min(1000, limit)), status=status or None))


@router.post("/candidates/{candidate_id}/evaluate")
async def evaluate(candidate_id: str, eval_set: str = ""):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    try:
        return ok(await service.evaluator.evaluate(candidate_id, eval_set))
    except ValueError as exc:
        return err(400, str(exc))


@router.post("/candidates/{candidate_id}/promote")
async def promote(candidate_id: str, payload: PromoteBody | None = None):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    try:
        return ok(await service.promoter.promote(candidate_id, actor="api", force=bool(payload and payload.force)))
    except ValueError as exc:
        return err(400, str(exc))


@router.get("/experiments")
async def experiments(limit: int = 100):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_experiments(limit=max(1, min(1000, limit))))


@router.get("/versions")
async def versions(limit: int = 100):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    active = await service.store.get_setting("active_version", "")
    return ok({"active": active, "items": await service.store.list_versions(limit=max(1, min(1000, limit)))})


@router.post("/versions/{version_id}/rollback")
async def rollback(version_id: str):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.promoter.rollback(version_id, actor="api"))


@router.get("/memories")
async def memories(limit: int = 200, status: str = ""):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_memories(limit=max(1, min(1000, limit)), status=status or None))


@router.get("/audit")
async def audit(limit: int = 100):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    return ok(await service.store.list_audit(limit=max(1, min(1000, limit))))


@router.put("/settings")
async def update_settings(payload: SettingsBody):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    if payload.mode:
        if _bad_mode(payload.mode):
            return err(400, "mode 必须是 off / observe / active")
        await service.store.set_setting("rsi.mode", payload.mode)
        service.global_mode = payload.mode
        service._mode_cache.clear()
    if payload.auto_promote is not None:
        await service.store.set_setting("rsi.auto_promote", "1" if payload.auto_promote else "0")
    if payload.min_samples is not None:
        await service.store.set_setting("rsi.min_samples", str(payload.min_samples))
    if payload.retention_days is not None:
        await service.store.set_setting("rsi.retention_days", str(payload.retention_days))
    await service.store.add_audit("settings", target="rsi", after=payload.model_dump(exclude_none=True), gate="admin")
    return ok(await service.status())


@router.post("/sessions/{session_id}/mode")
async def set_session_mode(session_id: str, payload: ModeBody):
    service = _service()
    if not service:
        return err(503, "RSI 服务未初始化")
    if _bad_mode(payload.mode):
        return err(400, "mode 必须是 off / observe / active")
    await service.set_session_mode(session_id, payload.mode)
    return ok({"session_id": session_id, "mode": payload.mode})


@router.get("/export/{fmt}", response_class=PlainTextResponse)
async def export(fmt: str, limit: int = 2000):
    service = _service()
    if not service:
        return json.dumps(err(503, "RSI 服务未初始化"), ensure_ascii=False)
    try:
        result = await service.exporter.export(fmt, limit=limit)
    except ValueError as exc:
        return json.dumps(err(400, str(exc)), ensure_ascii=False)
    return json.dumps(ok(result), ensure_ascii=False)
