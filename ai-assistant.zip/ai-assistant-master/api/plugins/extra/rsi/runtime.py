# v1/api/plugins/extra/rsi/runtime.py
"""RSI 运行时单例：让路由 / 工具 / 采集器共享同一个服务实例。"""

from __future__ import annotations

from typing import Any

SERVICE: Any = None


def get_service() -> Any:
    return SERVICE


def set_service(service: Any) -> None:
    global SERVICE
    SERVICE = service
