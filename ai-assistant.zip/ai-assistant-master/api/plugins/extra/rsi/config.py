# v1/api/plugins/extra/rsi/config.py
"""RSI 插件配置：全部可通过环境变量覆盖，默认保守。

设计纪律：
- FORGE_RSI_ENABLED=0 时插件不加载（生产事故快速熔断）。
- 默认 observe：只采集、只分析，不注入、不改行为。
- active 需要会话级或全局显式开启。
"""

from __future__ import annotations

import os
import json
from pathlib import Path

from configs.configs import DATA_DIR


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        return default


RSI_DIR = Path(os.getenv("FORGE_RSI_DIR", str(DATA_DIR / "rsi"))).expanduser()
DB_PATH = Path(os.getenv("FORGE_RSI_DB", str(RSI_DIR / "rsi.db"))).expanduser()
EXPORT_DIR = Path(os.getenv("FORGE_RSI_EXPORT_DIR", str(RSI_DIR / "exports"))).expanduser()
SKILL_DIR = Path(os.getenv("FORGE_RSI_SKILL_DIR", str(RSI_DIR / "skills"))).expanduser()
EVAL_SET_DIR = Path(os.getenv("FORGE_RSI_EVAL_SET_DIR", str(RSI_DIR / "eval_sets"))).expanduser()

ENABLED = _env_bool("FORGE_RSI_ENABLED", True)
MODE = os.getenv("FORGE_RSI_MODE", "observe").strip().lower()
if MODE not in {"off", "observe", "active"}:
    MODE = "observe"

AUTO_PROMOTE = _env_bool("FORGE_RSI_AUTO_PROMOTE", False)
MIN_SAMPLES = _env_int("FORGE_RSI_MIN_SAMPLES", 20)
REGRESSION_TOLERANCE = _env_float("FORGE_RSI_REGRESSION_TOLERANCE", 0.02)
DAILY_BUDGET_USD = _env_float("FORGE_RSI_DAILY_BUDGET_USD", 5.0)
MAX_CANDIDATES_PER_DAY = _env_int("FORGE_RSI_MAX_CANDIDATES_PER_DAY", 10)
RETENTION_DAYS = _env_int("FORGE_RSI_RETENTION_DAYS", 90)
WORKER_INTERVAL_S = _env_int("FORGE_RSI_WORKER_INTERVAL_S", 60)
FAILURE_THRESHOLD = _env_float("FORGE_RSI_FAILURE_THRESHOLD", 0.35)
MAX_MEMORY_ITEMS = _env_int("FORGE_RSI_MAX_MEMORY_ITEMS", 4)
MAX_MEMORY_CHARS = _env_int("FORGE_RSI_MAX_MEMORY_CHARS", 2200)
LLM_REFLECT = _env_bool("FORGE_RSI_LLM_REFLECT", False)

# 模式解析：全局 off 优先；会话 off 覆盖全局；active 需显式。
VALID_MODES = {"off", "observe", "active"}


def load_settings_file() -> dict:
    path = RSI_DIR / "config.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
