# v1/api/plugins/extra/rsi/promoter.py
"""门禁、版本晋级与回滚。

版本 components 记录当前 active 的资产集合；回滚只切指针，不删数据。
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.proposer import Proposer
from plugins.extra.rsi.store import RsiStore, new_id, utc_now


class Promoter:
    def __init__(self, store: RsiStore, proposer: Proposer):
        self.store = store
        self.proposer = proposer

    async def _active_version_id(self) -> str:
        return await self.store.get_setting("active_version", "")

    async def ensure_baseline(self) -> dict[str, Any]:
        version_id = await self._active_version_id()
        if version_id:
            version = await self.store.get_version(version_id)
            if version:
                return version
        components = {"memories": []}
        bundle = hashlib.sha1(json.dumps(components, sort_keys=True).encode()).hexdigest()
        version = await self.store.add_version({
            "version_id": "v0",
            "bundle_hash": bundle,
            "components": components,
            "parent": "",
            "status": "active",
            "note": "baseline",
        })
        await self.store.set_setting("active_version", "v0")
        await self.store.add_audit("baseline", target="v0", after=components, gate="system")
        return version

    async def promote(self, candidate_id: str, actor: str = "local", force: bool = False) -> dict[str, Any]:
        candidate = await self.store.get_candidate(candidate_id)
        if not candidate:
            raise ValueError(f"候选不存在: {candidate_id}")
        experiments = await self.store.list_experiments(limit=200)
        related = [e for e in experiments if e.get("candidate_id") == candidate_id]
        verdict = str(related[0].get("verdict") if related else "")
        if not related:
            raise ValueError("候选尚未评测，禁止晋级")
        if verdict != "pass" and not force:
            raise ValueError(f"评测结论为 {verdict}，未通过门禁（可 force 但会写审计）")
        if verdict == "insufficient" and not (config.AUTO_PROMOTE and candidate.get("risk") == "low"):
            if not force:
                raise ValueError("样本量不足，需人工 force 晋级")

        await self.ensure_baseline()
        current_id = await self._active_version_id()
        current = await self.store.get_version(current_id) or {"components": {"memories": []}}

        asset_id = candidate.get("asset_id") or ""
        if asset_id:
            await self.store.set_memory_status(asset_id, "active")
        else:
            asset = await self.proposer.materialize(candidate, status="active")
            asset_id = str(asset["memory_id"])
        await self._export_asset(asset_id)

        components = dict(current.get("components") or {})
        memories = list(components.get("memories") or [])
        if asset_id and asset_id not in memories:
            memories.append(asset_id)
        components["memories"] = memories

        bundle = hashlib.sha1(json.dumps(components, sort_keys=True).encode()).hexdigest()
        version = await self.store.add_version({
            "version_id": new_id("v"),
            "bundle_hash": bundle,
            "components": components,
            "parent": current_id,
            "status": "active",
            "note": f"promote {candidate_id}",
        })
        if current_id and current_id != version["version_id"]:
            await self.store.set_version_status(current_id, "superseded")
        await self.store.set_setting("active_version", version["version_id"])
        await self.store.update_candidate(candidate_id, status="promoted", asset_id=asset_id)
        await self.store.add_audit(
            "promote", target=candidate_id, before=current.get("components") or {},
            after=components, gate="promoter", reason=f"verdict={verdict} actor={actor}",
            actor=actor,
        )
        return version

    async def rollback(self, version_id: str = "", actor: str = "local") -> dict[str, Any]:
        current_id = await self._active_version_id()
        current = await self.store.get_version(current_id) if current_id else None
        target_id = version_id or (str(current.get("parent") or "") if current else "")
        target = await self.store.get_version(target_id) if target_id else None
        if not target:
            # 没有父版本时回滚到 baseline
            target = await self.ensure_baseline()
            target_id = str(target["version_id"])

        if current and current_id != target_id:
            await self.store.set_version_status(current_id, "rolled_back", rolled_back=True)
        await self.store.set_version_status(target_id, "active")
        await self.store.set_setting("active_version", target_id)

        keep = set((target.get("components") or {}).get("memories") or [])
        for memory in await self.store.list_memories(limit=1000):
            desired = "active" if memory.get("memory_id") in keep else "rolled_back"
            if memory.get("status") != desired and memory.get("kind") in {"memory", "skill", "prompt"}:
                if memory.get("status") in {"active", "rolled_back"}:
                    await self.store.set_memory_status(str(memory["memory_id"]), desired)
        await self.store.add_audit(
            "rollback", target=target_id, before=current.get("components") if current else {},
            after=target.get("components") or {}, gate="rollback", reason=f"actor={actor}", actor=actor,
        )
        return target

    async def _export_asset(self, asset_id: str) -> None:
        """把技能资产落成可读 Markdown，便于人工评审与审计。"""
        memory = await self.store.get_memory(asset_id)
        if not memory or memory.get("kind") != "skill":
            return
        try:
            config.SKILL_DIR.mkdir(parents=True, exist_ok=True)
            name = str(memory.get("name") or asset_id)
            path = config.SKILL_DIR / f"{name}.md"
            path.write_text(
                "---\n"
                f"name: {name}\n"
                f"scope: {memory.get('scope', 'org')}\n"
                f"confidence: {memory.get('confidence', 0.8)}\n"
                f"source: {memory.get('source_episode', '')}\n"
                "status: active\n"
                "---\n\n"
                + str(memory.get("content") or ""),
                encoding="utf-8",
            )
        except OSError:
            pass

    async def active_assets(self) -> list[dict[str, Any]]:
        version_id = await self._active_version_id()
        if not version_id:
            return []
        version = await self.store.get_version(version_id)
        if not version:
            return []
        ids = set((version.get("components") or {}).get("memories") or [])
        return [m for m in await self.store.list_memories(limit=1000) if m.get("memory_id") in ids]
