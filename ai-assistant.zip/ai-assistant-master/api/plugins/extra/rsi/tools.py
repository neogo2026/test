# v1/api/plugins/extra/rsi/tools.py
"""注册给模型的 RSI 工具：少而精，避免撑爆工具列表。

工具内部按会话模式守卫：off/observe 时写操作返回「未启用」，不产生副作用。
"""

from __future__ import annotations

from typing import Any

from core.contracts import ToolSpec
from core.exec_context import current_context
from plugins.extra.rsi import config
from plugins.extra.rsi.miner import reflection
from plugins.extra.rsi.runtime import get_service

TOOL_NAMES = [
    "rsi_status", "rsi_recall", "rsi_remember", "rsi_reflect",
    "rsi_report_failure", "rsi_plan_review", "rsi_propose",
    "rsi_evaluate", "rsi_promote", "rsi_rollback",
]


async def _require_active(allow_observe: bool = False) -> Any:
    service = get_service()
    if not service or not service.enabled:
        raise RuntimeError("RSI 插件未启用")
    ctx = current_context()
    mode = await service.get_mode(ctx.session_id) if ctx.session_id else config.MODE
    if mode == "off" or (mode == "observe" and not allow_observe):
        raise RuntimeError(f"当前会话 RSI 模式为 {mode}，该操作不可用")
    return service


async def rsi_status() -> dict[str, Any]:
    service = get_service()
    if not service:
        return {"enabled": False}
    return await service.status()


async def rsi_recall(query: str, limit: int = 4) -> dict[str, Any]:
    service = await _require_active(allow_observe=True)
    ctx = current_context()
    session = await service.harness.storage.get_session(ctx.session_id) or {}
    items = await service.memory.recall(
        query, ctx.session_id, session.get("agent_name") or "coder", session.get("workspace_dir") or "",
        limit=max(1, min(10, int(limit or 4))),
    )
    return {"count": len(items), "items": [
        {"memory_id": i.get("memory_id"), "kind": i.get("kind"), "name": i.get("name"),
         "content": i.get("content"), "confidence": i.get("confidence"), "scope": i.get("scope")}
        for i in items
    ]}


async def rsi_remember(content: str, name: str = "", scope: str = "", confidence: float = 0.8) -> dict[str, Any]:
    service = await _require_active()
    ctx = current_context()
    if not content.strip():
        raise ValueError("content 不能为空")
    session = await service.harness.storage.get_session(ctx.session_id) or {}
    scope = scope or f"session:{ctx.session_id}"
    asset = await service.store.add_memory({
        "kind": "memory",
        "name": name or content.strip().splitlines()[0][:40],
        "scope": scope,
        "content": content.strip()[:4000],
        "confidence": max(0.0, min(1.0, float(confidence))),
        "source_episode": ctx.run_id,
        "status": "draft",
        "metadata": {"workspace": session.get("workspace_dir") or ""},
    })
    await service.store.add_audit("remember", target=str(asset["memory_id"]), after={"scope": scope}, gate="medium")
    return {"memory_id": asset["memory_id"], "status": "draft", "note": "已写入草案，需晋级后才会注入"}


async def rsi_reflect(run_id: str = "") -> dict[str, Any]:
    service = await _require_active(allow_observe=True)
    ctx = current_context()
    target_run = run_id or ctx.run_id
    episode = await service.store.get_episode_by_run(target_run)
    if not episode:
        raise ValueError(f"未找到轨迹: {target_run}")
    related = await service.store.list_failures(limit=20, cluster_id="")
    result = reflection(episode, related[:5])
    await service.store.add_audit("reflect", target=target_run, after={"category": result["root_cause"]["category"]},
                                  gate="low")
    return result


async def rsi_report_failure(category: str, reason: str, evidence: str = "") -> dict[str, Any]:
    service = await _require_active(allow_observe=True)
    ctx = current_context()
    episode = await service.store.get_episode_by_run(ctx.run_id)
    failure = await service.store.add_failure({
        "episode_id": (episode or {}).get("episode_id", ""),
        "session_id": ctx.session_id,
        "category": category or "unknown",
        "root_cause": reason[:600],
        "evidence": (evidence or reason)[:2000],
        "severity": 0.6,
        "confidence": 0.7,
        "cluster_id": f"manual:{category or 'unknown'}",
        "status": "open",
    })
    return {"failure_id": failure["failure_id"], "cluster_id": failure["cluster_id"]}


async def rsi_plan_review(plan: str) -> dict[str, Any]:
    service = await _require_active(allow_observe=True)
    text = plan or ""
    issues = []
    if len(text) < 80:
        issues.append("计划过短，缺少可验证步骤")
    if not any(k in text for k in ("测试", "验证", "pytest", "自查", "check")):
        issues.append("缺少验证点：没有说明如何证明完成")
    if not any(k in text for k in ("文件", "模块", "目录", "file", "module")):
        issues.append("缺少改动范围：没有说明涉及哪些文件")
    if any(k in text for k in ("重构", "重写")) and "最小" not in text:
        issues.append("范围可能失控：重构任务需声明最小改动边界")
    return {
        "verdict": "ok" if not issues else "needs_work",
        "issues": issues,
        "suggestions": [
            "把计划拆成 3-5 个里程碑，每个里程碑有验证命令",
            "先侦察再动手；每完成一个里程碑立即验证",
        ],
    }


async def rsi_propose(limit: int = 3) -> dict[str, Any]:
    service = await _require_active()
    candidates = await service.proposer.propose_from_failures(limit=max(1, min(10, int(limit or 3))))
    return {"created": len(candidates), "candidates": [
        {"candidate_id": c.get("candidate_id"), "type": c.get("type"), "hypothesis": c.get("hypothesis"),
         "risk": c.get("risk"), "status": c.get("status")}
        for c in candidates
    ]}


async def rsi_evaluate(candidate_id: str, eval_set: str = "") -> dict[str, Any]:
    service = await _require_active()
    exp = await service.evaluator.evaluate(candidate_id, eval_set)
    return {"experiment_id": exp.get("experiment_id"), "verdict": exp.get("verdict"),
            "metrics": exp.get("metrics")}


async def rsi_promote(candidate_id: str, force: bool = False) -> dict[str, Any]:
    service = await _require_active()
    version = await service.promoter.promote(candidate_id, actor="model", force=bool(force))
    return {"version_id": version.get("version_id"), "status": version.get("status"),
            "components": version.get("components")}


async def rsi_rollback(version_id: str = "") -> dict[str, Any]:
    service = await _require_active()
    version = await service.promoter.rollback(version_id, actor="model")
    return {"version_id": version.get("version_id"), "status": version.get("status")}


SPECS: dict[str, ToolSpec] = {
    "rsi_status": ToolSpec(
        name="rsi_status",
        description="查询自进化 RSI 开关、会话模式、当前版本、轨迹与候选统计。",
        input_schema={"type": "object", "properties": {}},
        timeout_s=15,
    ),
    "rsi_recall": ToolSpec(
        name="rsi_recall",
        description="检索 RSI 分层记忆与已晋级技能，返回带来源与置信度的摘要。",
        input_schema={
            "type": "object",
            "properties": {"query": {"type": "string"}, "limit": {"type": "integer", "default": 4}},
            "required": ["query"],
        },
        timeout_s=20,
    ),
    "rsi_remember": ToolSpec(
        name="rsi_remember",
        description="写入一条经验记忆草案（scope/confidence/source），晋级后才会自动注入。",
        input_schema={
            "type": "object",
            "properties": {
                "content": {"type": "string"},
                "name": {"type": "string"},
                "scope": {"type": "string"},
                "confidence": {"type": "number", "default": 0.8},
            },
            "required": ["content"],
        },
        risk="medium", side_effect="write", timeout_s=20,
    ),
    "rsi_reflect": ToolSpec(
        name="rsi_reflect",
        description="对当前或指定 Run 做结构化反思：目标、动作、结果、根因、下一步。",
        input_schema={"type": "object", "properties": {"run_id": {"type": "string"}}},
        timeout_s=30,
    ),
    "rsi_report_failure": ToolSpec(
        name="rsi_report_failure",
        description="上报一个高价值失败样本（类别、原因、证据），供失败挖掘与候选生成。",
        input_schema={
            "type": "object",
            "properties": {"category": {"type": "string"}, "reason": {"type": "string"},
                           "evidence": {"type": "string"}},
            "required": ["category", "reason"],
        },
        timeout_s=20,
    ),
    "rsi_plan_review": ToolSpec(
        name="rsi_plan_review",
        description="对长任务计划做 critic：可执行性、验证点、缺失信息、范围风险。",
        input_schema={"type": "object", "properties": {"plan": {"type": "string"}}, "required": ["plan"]},
        timeout_s=20,
    ),
    "rsi_propose": ToolSpec(
        name="rsi_propose",
        description="基于失败簇生成候选资产（技能/记忆/提示词补丁），默认不生效。",
        input_schema={"type": "object", "properties": {"limit": {"type": "integer", "default": 3}}},
        risk="medium", side_effect="write", timeout_s=40,
    ),
    "rsi_evaluate": ToolSpec(
        name="rsi_evaluate",
        description="在历史配对证据/隔离沙箱上评测候选资产，比较基线与变体。",
        input_schema={
            "type": "object",
            "properties": {"candidate_id": {"type": "string"}, "eval_set": {"type": "string"}},
            "required": ["candidate_id"],
        },
        risk="high", timeout_s=120,
    ),
    "rsi_promote": ToolSpec(
        name="rsi_promote",
        description="把通过评测的候选晋级到 canary/active；高风险，需门禁或人工。",
        input_schema={
            "type": "object",
            "properties": {"candidate_id": {"type": "string"}, "force": {"type": "boolean", "default": False}},
            "required": ["candidate_id"],
        },
        risk="high", side_effect="write", timeout_s=30,
    ),
    "rsi_rollback": ToolSpec(
        name="rsi_rollback",
        description="版本指针回退到父版本或指定版本，保留审计与历史数据。",
        input_schema={"type": "object", "properties": {"version_id": {"type": "string"}}},
        risk="high", side_effect="write", timeout_s=30,
    ),
}

HANDLERS = {
    "rsi_status": rsi_status,
    "rsi_recall": rsi_recall,
    "rsi_remember": rsi_remember,
    "rsi_reflect": rsi_reflect,
    "rsi_report_failure": rsi_report_failure,
    "rsi_plan_review": rsi_plan_review,
    "rsi_propose": rsi_propose,
    "rsi_evaluate": rsi_evaluate,
    "rsi_promote": rsi_promote,
    "rsi_rollback": rsi_rollback,
}


def register_tools(ctx: Any) -> None:
    for name in TOOL_NAMES:
        ctx.register_tool(SPECS[name], HANDLERS[name])


def unregister_tools(ctx: Any) -> None:
    for name in TOOL_NAMES:
        ctx.unregister_tool(name)
