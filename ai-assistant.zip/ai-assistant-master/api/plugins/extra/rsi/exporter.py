# v1/api/plugins/extra/rsi/exporter.py
"""RSI 数据导出：SFT / DPO / Eval JSONL + manifest。

导出只消费独立 rsi.db 与主库中已落库的消息；训练端不直接读 SQLite。
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.store import RsiStore


def _sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _assistant_message(row: dict[str, Any]) -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": row.get("content") or None}
    if row.get("reasoning"):
        message["reasoning_content"] = row.get("reasoning")
    calls = row.get("tool_calls") or []
    if calls:
        message["tool_calls"] = [
            {
                "id": call.get("call_id") or f"call_{index}",
                "type": "function",
                "function": {
                    "name": call.get("name") or "",
                    "arguments": json.dumps(call.get("arguments") or {}, ensure_ascii=False),
                },
            }
            for index, call in enumerate(calls)
        ]
    return message


def _tool_message(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "role": "tool",
        "tool_call_id": row.get("tool_call_id") or "",
        "content": row.get("content") or "",
    }


class Exporter:
    def __init__(self, store: RsiStore, harness: Any):
        self.store = store
        self.harness = harness

    async def _run_messages(self, session_id: str, run_id: str) -> list[dict[str, Any]]:
        rows = await self.harness.storage.list_messages(session_id, limit=5000)
        selected = [r for r in rows if r.get("run_id") == run_id]
        messages = []
        for row in selected:
            role = row.get("role")
            if role == "assistant":
                messages.append(_assistant_message(row))
            elif role == "tool":
                messages.append(_tool_message(row))
            else:
                messages.append({"role": role, "content": row.get("content") or ""})
        return messages

    async def export(self, fmt: str = "sft", limit: int = 2000) -> dict[str, Any]:
        fmt = fmt.lower()
        if fmt not in {"sft", "dpo", "eval"}:
            raise ValueError("format 必须是 sft / dpo / eval")
        config.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        path = config.EXPORT_DIR / f"rsi_{fmt}_{stamp}.jsonl"
        episodes = await self.store.list_episodes(limit=limit)
        lines: list[dict[str, Any]] = []

        if fmt == "sft":
            for episode in episodes:
                if episode.get("outcome") != "success":
                    continue
                messages = await self._run_messages(str(episode.get("session_id")), str(episode.get("run_id")))
                if not messages:
                    continue
                lines.append({
                    "id": episode["episode_id"],
                    "messages": messages,
                    "outcome": episode.get("outcome"),
                    "signals": episode.get("signals") or {},
                    "tool_schema_version": "v1",
                    "system_version": "v1",
                })
        elif fmt == "dpo":
            failures = [e for e in episodes if e.get("outcome") in {"failed", "abandoned"}]
            for failed in failures:
                later = [
                    e for e in episodes
                    if e.get("session_id") == failed.get("session_id")
                    and e.get("outcome") == "success"
                    and str(e.get("created_at") or "") > str(failed.get("created_at") or "")
                ]
                if not later:
                    continue
                chosen = later[0]
                lines.append({
                    "id": f"pair_{failed['episode_id']}_{chosen['episode_id']}",
                    "prompt_messages": [{"role": "user", "content": failed.get("input") or ""}],
                    "chosen": {"role": "assistant", "content": chosen.get("output") or ""},
                    "rejected": {"role": "assistant", "content": failed.get("output") or ""},
                    "target": "correctness",
                })
        else:
            for episode in episodes:
                if episode.get("outcome") == "running":
                    continue
                lines.append({
                    "id": episode["episode_id"],
                    "instruction": episode.get("input") or "",
                    "workspace_snapshot": "",
                    "test_cmd": "",
                    "checks": {"success": episode.get("outcome") == "success"},
                    "split": "heldout" if episode.get("episode_id", "").endswith(("0", "1")) else "train",
                    "outcome": episode.get("outcome"),
                })

        with path.open("w", encoding="utf-8") as handle:
            for line in lines:
                handle.write(json.dumps(line, ensure_ascii=False) + "\n")

        manifest = {
            "format": fmt,
            "file": str(path),
            "count": len(lines),
            "sha1": _sha1(path.read_text(encoding="utf-8")),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "tool_schema_version": "v1",
            "system_version": "v1",
        }
        manifest_path = config.EXPORT_DIR / f"rsi_{fmt}_{stamp}.manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        return {**manifest, "manifest": str(manifest_path)}
