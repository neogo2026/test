# v1/api/plugins/extra/rsi/store.py
"""RSI 独立存储：data/rsi/rsi.db。

与主库完全解耦，插件可整体卸载。所有跨表字段用 JSON 文本保存，便于版本化与审计。
"""

from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiosqlite

from plugins.extra.rsi import config


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def _dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def _load(value: Any, default: Any = None) -> Any:
    if value is None or value == "":
        return default if default is not None else {}
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default if default is not None else {}


SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS episodes (
    episode_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    run_id TEXT NOT NULL UNIQUE,
    tenant_id TEXT NOT NULL DEFAULT 'default',
    agent TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT '',
    task_type TEXT NOT NULL DEFAULT 'unknown',
    input TEXT NOT NULL DEFAULT '',
    output TEXT NOT NULL DEFAULT '',
    outcome TEXT NOT NULL DEFAULT 'running',
    steps INTEGER NOT NULL DEFAULT 0,
    tool_calls INTEGER NOT NULL DEFAULT 0,
    tool_errors INTEGER NOT NULL DEFAULT 0,
    tokens INTEGER NOT NULL DEFAULT 0,
    usd REAL NOT NULL DEFAULT 0,
    seconds REAL NOT NULL DEFAULT 0,
    reward REAL NOT NULL DEFAULT 0,
    signals TEXT NOT NULL DEFAULT '{}',
    labels TEXT NOT NULL DEFAULT '{}',
    analyzed INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_episodes_session ON episodes(session_id);
CREATE INDEX IF NOT EXISTS idx_episodes_outcome ON episodes(outcome, analyzed);

CREATE TABLE IF NOT EXISTS failures (
    failure_id TEXT PRIMARY KEY,
    episode_id TEXT NOT NULL,
    session_id TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,
    root_cause TEXT NOT NULL DEFAULT '',
    evidence TEXT NOT NULL DEFAULT '',
    severity REAL NOT NULL DEFAULT 0,
    confidence REAL NOT NULL DEFAULT 0,
    cluster_id TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_failures_cluster ON failures(cluster_id);

CREATE TABLE IF NOT EXISTS candidates (
    candidate_id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    hypothesis TEXT NOT NULL DEFAULT '',
    diff TEXT NOT NULL DEFAULT '{}',
    expected_gain TEXT NOT NULL DEFAULT '{}',
    risk TEXT NOT NULL DEFAULT 'low',
    status TEXT NOT NULL DEFAULT 'draft',
    source_failures TEXT NOT NULL DEFAULT '[]',
    asset_id TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL DEFAULT 'rsi',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiments (
    experiment_id TEXT PRIMARY KEY,
    candidate_id TEXT NOT NULL,
    baseline_version TEXT NOT NULL DEFAULT '',
    variant_version TEXT NOT NULL DEFAULT '',
    eval_set TEXT NOT NULL DEFAULT '',
    metrics TEXT NOT NULL DEFAULT '{}',
    verdict TEXT NOT NULL DEFAULT 'pending',
    cost REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS versions (
    version_id TEXT PRIMARY KEY,
    bundle_hash TEXT NOT NULL DEFAULT '',
    components TEXT NOT NULL DEFAULT '{}',
    parent TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'candidate',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    rolled_back_at TEXT
);

CREATE TABLE IF NOT EXISTS memories (
    memory_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'memory',
    name TEXT NOT NULL DEFAULT '',
    scope TEXT NOT NULL DEFAULT 'org',
    content TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 0.8,
    ttl TEXT NOT NULL DEFAULT '',
    source_episode TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    supersedes TEXT NOT NULL DEFAULT '',
    metadata TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_memories_scope ON memories(scope, status);

CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    actor TEXT NOT NULL DEFAULT 'rsi',
    target TEXT NOT NULL DEFAULT '',
    before TEXT NOT NULL DEFAULT '{}',
    after TEXT NOT NULL DEFAULT '{}',
    gate TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


class RsiStore:
    def __init__(self, db_path: Path | None = None):
        self.db_path = Path(db_path or config.DB_PATH)
        self._init_lock = asyncio.Lock()
        self._ready = False

    async def init(self) -> None:
        async with self._init_lock:
            if self._ready:
                return
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            async with self.connect() as db:
                await db.executescript(SCHEMA)
                await db.commit()
            self._ready = True

    @asynccontextmanager
    async def connect(self):
        db = await aiosqlite.connect(self.db_path)
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA busy_timeout=5000")
        try:
            yield db
        finally:
            await db.close()

    # ------------------------------------------------------------------
    # Episode
    # ------------------------------------------------------------------
    async def upsert_episode(self, episode: dict[str, Any]) -> None:
        now = utc_now()
        episode.setdefault("created_at", now)
        episode["updated_at"] = now
        fields = {
            "episode_id": episode.get("episode_id") or new_id("ep"),
            "session_id": episode.get("session_id", ""),
            "run_id": episode.get("run_id", ""),
            "tenant_id": episode.get("tenant_id", "default"),
            "agent": episode.get("agent", ""),
            "model": episode.get("model", ""),
            "task_type": episode.get("task_type", "unknown"),
            "input": episode.get("input", ""),
            "output": episode.get("output", ""),
            "outcome": episode.get("outcome", "running"),
            "steps": int(episode.get("steps") or 0),
            "tool_calls": int(episode.get("tool_calls") or 0),
            "tool_errors": int(episode.get("tool_errors") or 0),
            "tokens": int(episode.get("tokens") or 0),
            "usd": float(episode.get("usd") or 0),
            "seconds": float(episode.get("seconds") or 0),
            "reward": float(episode.get("reward") or 0),
            "signals": _dump(episode.get("signals") or {}),
            "labels": _dump(episode.get("labels") or {}),
            "analyzed": int(episode.get("analyzed") or 0),
            "created_at": episode["created_at"],
            "updated_at": now,
        }
        episode["episode_id"] = fields["episode_id"]
        columns = ", ".join(fields)
        placeholders = ", ".join("?" for _ in fields)
        updates = ", ".join(f"{key}=excluded.{key}" for key in fields if key not in {"episode_id", "created_at"})
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO episodes({columns}) VALUES ({placeholders}) "
                f"ON CONFLICT(episode_id) DO UPDATE SET {updates}",
                list(fields.values()),
            )
            await db.commit()

    async def get_episode(self, episode_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM episodes WHERE episode_id = ?", (episode_id,)) as cur:
                row = await cur.fetchone()
        return self._decode_episode(row) if row else None

    async def get_episode_by_run(self, run_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM episodes WHERE run_id = ?", (run_id,)) as cur:
                row = await cur.fetchone()
        return self._decode_episode(row) if row else None

    @staticmethod
    def _decode_episode(row: Any) -> dict[str, Any]:
        item = dict(row)
        item["signals"] = _load(item.get("signals"))
        item["labels"] = _load(item.get("labels"))
        return item

    async def list_episodes(self, limit: int = 100, outcome: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM episodes"
        values: list[Any] = []
        if outcome:
            sql += " WHERE outcome = ?"
            values.append(outcome)
        sql += " ORDER BY created_at DESC LIMIT ?"
        values.append(limit)
        async with self.connect() as db:
            async with db.execute(sql, values) as cur:
                rows = await cur.fetchall()
        return [self._decode_episode(r) for r in rows]

    async def list_unanalyzed(self, limit: int = 50) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM episodes WHERE analyzed = 0 AND outcome != 'running' "
                "ORDER BY created_at ASC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
        return [self._decode_episode(r) for r in rows]

    async def mark_analyzed(self, episode_id: str) -> None:
        async with self.connect() as db:
            await db.execute("UPDATE episodes SET analyzed = 1, updated_at = ? WHERE episode_id = ?",
                             (utc_now(), episode_id))
            await db.commit()

    # ------------------------------------------------------------------
    # Failure
    # ------------------------------------------------------------------
    async def add_failure(self, failure: dict[str, Any]) -> dict[str, Any]:
        failure.setdefault("failure_id", new_id("fail"))
        failure.setdefault("created_at", utc_now())
        fields = ["failure_id", "episode_id", "session_id", "category", "root_cause", "evidence",
                  "severity", "confidence", "cluster_id", "status", "created_at"]
        values = [failure.get(f) for f in fields]
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO failures({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})", values
            )
            await db.commit()
        return failure

    async def list_failures(self, limit: int = 100, cluster_id: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM failures"
        values: list[Any] = []
        if cluster_id:
            sql += " WHERE cluster_id = ?"
            values.append(cluster_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        values.append(limit)
        async with self.connect() as db:
            async with db.execute(sql, values) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def failure_clusters(self) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT cluster_id, category, root_cause, COUNT(*) AS count, AVG(severity) AS severity, "
                "MAX(created_at) AS last_seen FROM failures GROUP BY cluster_id "
                "ORDER BY count DESC, last_seen DESC"
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Candidate
    # ------------------------------------------------------------------
    async def add_candidate(self, data: dict[str, Any]) -> dict[str, Any]:
        now = utc_now()
        data.setdefault("candidate_id", new_id("cand"))
        data.setdefault("status", "draft")
        data.setdefault("created_at", now)
        data["updated_at"] = now
        fields = ["candidate_id", "type", "hypothesis", "diff", "expected_gain", "risk", "status",
                  "source_failures", "asset_id", "created_by", "created_at", "updated_at"]
        values = [
            data.get("candidate_id"), data.get("type"), data.get("hypothesis", ""),
            _dump(data.get("diff") or {}), _dump(data.get("expected_gain") or {}),
            data.get("risk", "low"), data.get("status"), _dump(data.get("source_failures") or []),
            data.get("asset_id", ""), data.get("created_by", "rsi"), data.get("created_at"), data["updated_at"],
        ]
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO candidates({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})", values
            )
            await db.commit()
        return await self.get_candidate(data["candidate_id"])

    async def get_candidate(self, candidate_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM candidates WHERE candidate_id = ?", (candidate_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        item["diff"] = _load(item.get("diff"))
        item["expected_gain"] = _load(item.get("expected_gain"))
        item["source_failures"] = _load(item.get("source_failures"), [])
        return item

    async def list_candidates(self, limit: int = 100, status: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM candidates"
        values: list[Any] = []
        if status:
            sql += " WHERE status = ?"
            values.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        values.append(limit)
        async with self.connect() as db:
            async with db.execute(sql, values) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["diff"] = _load(item.get("diff"))
            item["expected_gain"] = _load(item.get("expected_gain"))
            item["source_failures"] = _load(item.get("source_failures"), [])
            result.append(item)
        return result

    async def update_candidate(self, candidate_id: str, **fields: Any) -> dict[str, Any] | None:
        allowed = {"status", "asset_id", "hypothesis", "risk"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return await self.get_candidate(candidate_id)
        updates["updated_at"] = utc_now()
        assignments = ", ".join(f"{k} = ?" for k in updates)
        async with self.connect() as db:
            await db.execute(f"UPDATE candidates SET {assignments} WHERE candidate_id = ?",
                             list(updates.values()) + [candidate_id])
            await db.commit()
        return await self.get_candidate(candidate_id)

    # ------------------------------------------------------------------
    # Experiment
    # ------------------------------------------------------------------
    async def add_experiment(self, data: dict[str, Any]) -> dict[str, Any]:
        data.setdefault("experiment_id", new_id("exp"))
        data.setdefault("created_at", utc_now())
        fields = ["experiment_id", "candidate_id", "baseline_version", "variant_version", "eval_set",
                  "metrics", "verdict", "cost", "created_at"]
        values = [
            data["experiment_id"], data.get("candidate_id", ""), data.get("baseline_version", ""),
            data.get("variant_version", ""), data.get("eval_set", ""), _dump(data.get("metrics") or {}),
            data.get("verdict", "pending"), float(data.get("cost") or 0), data["created_at"],
        ]
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO experiments({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})", values
            )
            await db.commit()
        return data

    async def list_experiments(self, limit: int = 100) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM experiments ORDER BY created_at DESC LIMIT ?", (limit,)) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metrics"] = _load(item.get("metrics"))
            result.append(item)
        return result

    # ------------------------------------------------------------------
    # Version
    # ------------------------------------------------------------------
    async def add_version(self, data: dict[str, Any]) -> dict[str, Any]:
        data.setdefault("version_id", new_id("v"))
        data.setdefault("created_at", utc_now())
        fields = ["version_id", "bundle_hash", "components", "parent", "status", "note", "created_at"]
        values = [data["version_id"], data.get("bundle_hash", ""), _dump(data.get("components") or {}),
                  data.get("parent", ""), data.get("status", "candidate"), data.get("note", ""), data["created_at"]]
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO versions({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})", values
            )
            await db.commit()
        return data

    async def list_versions(self, limit: int = 100) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM versions ORDER BY created_at DESC LIMIT ?", (limit,)) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["components"] = _load(item.get("components"))
            result.append(item)
        return result

    async def get_version(self, version_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM versions WHERE version_id = ?", (version_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        item["components"] = _load(item.get("components"))
        return item

    async def set_version_status(self, version_id: str, status: str, rolled_back: bool = False) -> None:
        async with self.connect() as db:
            await db.execute(
                "UPDATE versions SET status = ?, rolled_back_at = ? WHERE version_id = ?",
                (status, utc_now() if rolled_back else None, version_id),
            )
            await db.commit()

    # ------------------------------------------------------------------
    # Memory / Skill assets
    # ------------------------------------------------------------------
    async def add_memory(self, data: dict[str, Any]) -> dict[str, Any]:
        now = utc_now()
        data.setdefault("memory_id", new_id("mem"))
        data.setdefault("created_at", now)
        data["updated_at"] = now
        fields = ["memory_id", "kind", "name", "scope", "content", "confidence", "ttl",
                  "source_episode", "status", "supersedes", "metadata", "created_at", "updated_at"]
        values = [
            data["memory_id"], data.get("kind", "memory"), data.get("name", ""), data.get("scope", "org"),
            data.get("content", ""), float(data.get("confidence") or 0.8), data.get("ttl", ""),
            data.get("source_episode", ""), data.get("status", "draft"), data.get("supersedes", ""),
            _dump(data.get("metadata") or {}), data["created_at"], data["updated_at"],
        ]
        async with self.connect() as db:
            await db.execute(
                f"INSERT INTO memories({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})", values
            )
            await db.commit()
        return data

    async def get_memory(self, memory_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM memories WHERE memory_id = ?", (memory_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        item["metadata"] = _load(item.get("metadata"))
        return item

    async def list_memories(self, limit: int = 200, status: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM memories"
        values: list[Any] = []
        if status:
            sql += " WHERE status = ?"
            values.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        values.append(limit)
        async with self.connect() as db:
            async with db.execute(sql, values) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metadata"] = _load(item.get("metadata"))
            result.append(item)
        return result

    async def set_memory_status(self, memory_id: str, status: str) -> None:
        async with self.connect() as db:
            await db.execute("UPDATE memories SET status = ?, updated_at = ? WHERE memory_id = ?",
                             (status, utc_now(), memory_id))
            await db.commit()

    async def search_memories(self, keywords: list[str], scopes: list[str], limit: int = 8) -> list[dict[str, Any]]:
        allowed = [s for s in scopes if s]
        placeholders = ", ".join("?" for _ in allowed) if allowed else ""
        sql = "SELECT * FROM memories WHERE status = 'active'"
        values: list[Any] = []
        if allowed:
            sql += f" AND (scope IN ({placeholders}) OR scope = 'org')"
            values.extend(allowed)
        sql += " ORDER BY confidence DESC, updated_at DESC LIMIT 200"
        async with self.connect() as db:
            async with db.execute(sql, values) as cur:
                rows = await cur.fetchall()
        scored: list[tuple[float, dict[str, Any]]] = []
        needle = [k.lower() for k in keywords if k]
        for row in rows:
            item = dict(row)
            item["metadata"] = _load(item.get("metadata"))
            haystack = (item.get("name", "") + " " + item.get("content", "")).lower()
            overlap = sum(1 for k in needle if k in haystack)
            score = overlap * 2.0 + float(item.get("confidence") or 0)
            if overlap or (not needle and item.get("scope") == "org"):
                scored.append((score, item))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _score, item in scored[:limit]]

    # ------------------------------------------------------------------
    # Settings / audit
    # ------------------------------------------------------------------
    async def get_setting(self, key: str, default: str = "") -> str:
        async with self.connect() as db:
            async with db.execute("SELECT value FROM settings WHERE key = ?", (key,)) as cur:
                row = await cur.fetchone()
        return str(row["value"]) if row else default

    async def set_setting(self, key: str, value: str) -> None:
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO settings(key, value, updated_at) VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                (key, value, utc_now()),
            )
            await db.commit()

    async def add_audit(self, action: str, target: str = "", before: Any = None, after: Any = None,
                        gate: str = "", reason: str = "", actor: str = "rsi") -> None:
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO audit(action, actor, target, before, after, gate, reason, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (action, actor, target, _dump(before or {}), _dump(after or {}), gate, reason, utc_now()),
            )
            await db.commit()

    async def list_audit(self, limit: int = 100) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,)) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["before"] = _load(item.get("before"))
            item["after"] = _load(item.get("after"))
            result.append(item)
        return result

    async def stats(self) -> dict[str, Any]:
        async with self.connect() as db:
            async def one(sql: str, values: list[Any] | None = None) -> int:
                async with db.execute(sql, values or []) as cur:
                    row = await cur.fetchone()
                return int(row[0]) if row else 0

            return {
                "episodes": await one("SELECT COUNT(*) FROM episodes"),
                "successes": await one("SELECT COUNT(*) FROM episodes WHERE outcome = 'success'"),
                "failures": await one("SELECT COUNT(*) FROM failures"),
                "candidates": await one("SELECT COUNT(*) FROM candidates"),
                "experiments": await one("SELECT COUNT(*) FROM experiments"),
                "versions": await one("SELECT COUNT(*) FROM versions"),
                "memories": await one("SELECT COUNT(*) FROM memories"),
                "active_memories": await one("SELECT COUNT(*) FROM memories WHERE status = 'active'"),
            }
