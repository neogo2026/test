# v1/api/plugins/extra/rsi/memory.py
"""分层记忆：会话 / 项目 / 员工 / 组织。

只用关键词相关性检索，控制注入 token；不做无限上下文堆叠。
"""

from __future__ import annotations

import re
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.store import RsiStore

ASCII_WORD = re.compile(r"[a-zA-Z0-9_./-]{2,}")
CJK = re.compile(r"[\u4e00-\u9fff]")


def keywords(text: str, limit: int = 16) -> list[str]:
    text = (text or "").lower()
    words = ASCII_WORD.findall(text)
    chars = CJK.findall(text)
    bigrams = ["".join(chars[i:i + 2]) for i in range(max(0, len(chars) - 1))]
    result: list[str] = []
    for token in words + chars + bigrams:
        if token and token not in result:
            result.append(token)
        if len(result) >= limit:
            break
    return result


class MemoryService:
    def __init__(self, store: RsiStore):
        self.store = store

    def scopes(self, session_id: str, agent: str, workspace: str) -> list[str]:
        scopes = ["org", f"agent:{agent or 'coder'}", f"session:{session_id}"]
        if workspace:
            scopes.append(f"project:{workspace.lower()}")
        return scopes

    async def recall(self, query: str, session_id: str, agent: str, workspace: str = "",
                     limit: int | None = None) -> list[dict[str, Any]]:
        tokens = keywords(query)
        items = await self.store.search_memories(
            tokens, self.scopes(session_id, agent, workspace), limit=limit or config.MAX_MEMORY_ITEMS
        )
        return items

    @staticmethod
    def render(items: list[dict[str, Any]]) -> str:
        lines: list[str] = []
        total = 0
        for item in items:
            kind = str(item.get("kind") or "memory")
            name = str(item.get("name") or "")
            content = str(item.get("content") or "").strip()
            if not content:
                continue
            block = f"[{kind}] {name}\n{content}"
            if total + len(block) > config.MAX_MEMORY_CHARS:
                break
            lines.append(block)
            total += len(block)
        return "\n\n".join(lines)
