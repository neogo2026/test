# v1/api/plugins/extra/rsi/plugin.py
"""自进化 RSI 插件入口。

默认 observe：采集轨迹、挖掘失败、生成候选、导出训练数据，但不注入、不改行为。
active：额外注入分层记忆 / 已晋级技能，并在工具失败与截断时给出运行时提示。
停用：摘工具、退订事件、摘上下文/模型/工具中间件，完全回到 baseline。
"""

from __future__ import annotations

import logging

from core import agents as agent_registry
from plugins.base import Plugin, PluginContext, PluginMeta
from plugins.extra.rsi import config
from plugins.extra.rsi.routes import router as rsi_router
from plugins.extra.rsi.runtime import set_service
from plugins.extra.rsi.service import RsiService
from plugins.extra.rsi.tools import TOOL_NAMES, register_tools, unregister_tools

logger = logging.getLogger(__name__)


class RsiPlugin(Plugin):
    meta = PluginMeta(
        name="rsi",
        title="自进化 RSI",
        version="1.0.0",
        description="轨迹采集、失败归因、候选生成、沙箱评测、版本晋级与回滚；默认只观察",
        author="AI助理",
        priority=60,
        tags=["rsi", "evolution", "evaluation", "memory"],
    )

    def __init__(self):
        self.enabled = False
        self.service: RsiService | None = None
        self.ctx: PluginContext | None = None
        self._agent_tools: list[tuple[object, list[str]]] = []

    def register(self, ctx: PluginContext) -> None:
        if not config.ENABLED:
            logger.info("RSI 被 FORGE_RSI_ENABLED=0 禁用，跳过注册")
            return
        self.ctx = ctx
        ctx.register_router(rsi_router)
        register_tools(ctx)
        ctx.subscribe_events(self.on_event)

    async def on_start(self, ctx: PluginContext) -> None:
        if not config.ENABLED:
            return
        self.ctx = ctx
        self.service = RsiService(ctx._harness)
        await self.service.init()
        set_service(self.service)
        self.enabled = True

        ctx.register_context_provider("rsi.memory", self.service.context_provider, priority=40)
        ctx.register_model_middleware("rsi.model", before=None, after=self.service.model_after)
        ctx.register_tool_middleware("rsi.tool", before=None, after=self.service.tool_after)
        self._inject_agent_tools()
        await self.service.worker.start(self.service.get_mode)
        logger.info("RSI 已启动：mode=%s db=%s", self.service.global_mode, config.DB_PATH)

    async def on_stop(self, ctx: PluginContext) -> None:
        self.enabled = False
        if self.service:
            self.service.enabled = False
            await self.service.worker.stop()
        try:
            ctx.unregister_context_provider("rsi.memory")
            ctx.unregister_model_middleware("rsi.model")
            ctx.unregister_tool_middleware("rsi.tool")
        except Exception:  # noqa: BLE001
            logger.exception("RSI 钩子卸载失败")
        self._restore_agent_tools()
        try:
            ctx.unsubscribe_events(self.on_event)
        except Exception:  # noqa: BLE001
            pass
        try:
            unregister_tools(ctx)
        except Exception:  # noqa: BLE001
            pass
        set_service(None)
        logger.info("RSI 已停止，行为回到 baseline")

    def _inject_agent_tools(self) -> None:
        self._agent_tools = []
        for agent in agent_registry.AGENTS.values():
            original = list(agent.tools)
            self._agent_tools.append((agent, original))
            for name in TOOL_NAMES:
                if name not in agent.tools:
                    agent.tools.append(name)

    def _restore_agent_tools(self) -> None:
        for agent, original in self._agent_tools:
            try:
                agent.tools = list(original)
            except Exception:  # noqa: BLE001
                pass
        self._agent_tools = []

    async def on_event(self, session_id: str, event_type: str, payload: dict) -> None:
        if not self.enabled or not self.service or not self.service.collector:
            return
        try:
            await self.service.collector.accept(session_id, event_type, payload)
        except Exception:  # noqa: BLE001
            logger.exception("RSI 采集事件失败: %s", event_type)


PLUGIN = RsiPlugin()
