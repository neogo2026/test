# v1/api/plugins/extra/rsi/service.py
"""RSI 服务组合根：把存储、采集、挖掘、候选、评测、晋级串成一个进化层。"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from core.exec_context import current_context
from plugins.extra.rsi import config
from plugins.extra.rsi.collector import Collector
from plugins.extra.rsi.evaluator import Evaluator
from plugins.extra.rsi.exporter import Exporter
from plugins.extra.rsi.memory import MemoryService
from plugins.extra.rsi.miner import Miner, reflection
from plugins.extra.rsi.promoter import Promoter
from plugins.extra.rsi.proposer import Proposer
from plugins.extra.rsi.store import RsiStore, utc_now
from plugins.extra.rsi.worker import RsiWorker

logger = logging.getLogger(__name__)


class RsiService:
    def __init__(self, harness: Any):
        self.harness = harness
        self.enabled = False
        self.global_mode = config.MODE
        self.store = RsiStore()
        self.memory = MemoryService(self.store)
        self.proposer = Proposer(self.store)
        self.miner = Miner(self.store)
        self.evaluator = Evaluator(self.store, self.proposer)
        self.promoter = Promoter(self.store, self.proposer)
        self.exporter = Exporter(self.store, harness)
        self.worker = RsiWorker(self.store)
        self.collector: Collector | None = None
        self.tool_hints: dict[str, list[str]] = {}
        self._mode_cache: dict[str, tuple[float, str]] = {}
        self._analyze_lock = asyncio.Lock()

    async def init(self) -> None:
        await self.store.init()
        stored_mode = await self.store.get_setting("rsi.mode", "")
        if stored_mode in config.VALID_MODES:
            self.global_mode = stored_mode
        await self.promoter.ensure_baseline()
        self.collector = Collector(self.store, self.harness, self.get_mode, self.on_episode_finalized)
        self.enabled = True

    async def get_mode(self, session_id: str) -> str:
        if not self.enabled:
            return "off"
        if session_id == "*":
            return self.global_mode
        cached = self._mode_cache.get(session_id)
        if cached and time.time() - cached[0] < 5:
            return cached[1]
        mode = self.global_mode
        if self.global_mode != "off":
            try:
                session = await self.harness.storage.get_session(session_id)
            except Exception:  # noqa: BLE001
                session = None
            if session:
                caps = session.get("capabilities") or {}
                value = str(caps.get("rsi_mode") or "").lower()
                if value in config.VALID_MODES:
                    mode = value
                elif caps.get("rsi") is True:
                    mode = "active"
        self._mode_cache[session_id] = (time.time(), mode)
        return mode

    async def set_session_mode(self, session_id: str, mode: str) -> None:
        session = await self.harness.storage.get_session(session_id)
        if not session:
            raise ValueError("会话不存在")
        caps = dict(session.get("capabilities") or {})
        caps["rsi_mode"] = mode
        await self.harness.storage.update_session(session_id, capabilities=caps)
        self._mode_cache.pop(session_id, None)
        await self.store.add_audit("session_mode", target=session_id, after={"mode": mode}, gate="session")

    async def on_episode_finalized(self, episode: dict[str, Any]) -> None:
        if not episode:
            return
        try:
            failure = await self.miner.analyze(episode)
            if failure:
                await self.proposer.propose_from_failures()
        except Exception:  # noqa: BLE001
            logger.exception("RSI 轨迹分析失败")

    # ------------------------------------------------------------------
    # 运行中钩子
    # ------------------------------------------------------------------
    async def context_provider(self, agent: Any, session_id: str, user_input: str,
                               model_profile: str | None = None) -> str | None:
        mode = await self.get_mode(session_id)
        if mode != "active":
            return None
        session = await self.harness.storage.get_session(session_id) or {}
        workspace = str(session.get("workspace_dir") or "")
        items = await self.memory.recall(user_input, session_id, agent.name if agent else "coder", workspace)
        blocks: list[str] = []
        rendered = self.memory.render(items)
        if rendered:
            blocks.append(rendered)
        hints = self.tool_hints.pop(session_id, [])
        if hints:
            blocks.append("【上一步工具失败提示】\n" + "\n".join(hints[-3:]))
        return "\n\n".join(blocks) if blocks else None

    async def model_after(self, profile_name: str, messages: list[dict[str, Any]], response: Any) -> Any:
        try:
            ctx = current_context()
            mode = await self.get_mode(ctx.session_id) if ctx.session_id else self.global_mode
            if mode != "active":
                return response
            if str(getattr(response, "finish_reason", "")) == "length":
                self._push_hint(ctx.session_id, "上一轮输出达到长度上限：下一步请分块 write_file，并在每块后运行验证。")
        except Exception:  # noqa: BLE001
            logger.exception("RSI 模型后置钩子失败")
        return response

    async def tool_after(self, call: Any, result: Any) -> Any:
        try:
            ctx = current_context()
            mode = await self.get_mode(ctx.session_id) if ctx.session_id else self.global_mode
            if mode != "active":
                return result
            if not getattr(result, "ok", True):
                self._push_hint(
                    ctx.session_id,
                    f"工具 {getattr(call, 'name', '')} 失败：{str(getattr(result, 'error', '') or '')[:200]}。"
                    "下次调用前先核对参数 schema；连续两次相同失败必须换思路。",
                )
        except Exception:  # noqa: BLE001
            logger.exception("RSI 工具后置钩子失败")
        return result

    def _push_hint(self, session_id: str, hint: str) -> None:
        if not session_id:
            return
        self.tool_hints.setdefault(session_id, []).append(hint)
        self.tool_hints[session_id] = self.tool_hints[session_id][-5:]

    # ------------------------------------------------------------------
    # 状态
    # ------------------------------------------------------------------
    async def status(self) -> dict[str, Any]:
        stats = await self.store.stats()
        active_version = await self.store.get_setting("active_version", "")
        version = await self.store.get_version(active_version) if active_version else None
        recent_failures = await self.store.list_failures(limit=5)
        recent_candidates = await self.store.list_candidates(limit=5)
        return {
            "enabled": self.enabled,
            "global_mode": self.global_mode,
            "config_mode": config.MODE,
            "active_version": active_version,
            "active_components": (version or {}).get("components") or {},
            "stats": stats,
            "recent_failures": recent_failures,
            "recent_candidates": recent_candidates,
            "config": {
                "auto_promote": (await self.store.get_setting(
                    "rsi.auto_promote", "1" if config.AUTO_PROMOTE else "0"
                )).strip().lower() in {"1", "true", "yes"},
                "min_samples": int(await self.store.get_setting(
                    "rsi.min_samples", str(config.MIN_SAMPLES)
                ) or config.MIN_SAMPLES),
                "retention_days": int(await self.store.get_setting(
                    "rsi.retention_days", str(config.RETENTION_DAYS)
                ) or config.RETENTION_DAYS),
                "llm_reflect": config.LLM_REFLECT,
                "worker_interval_s": config.WORKER_INTERVAL_S,
            },
        }
