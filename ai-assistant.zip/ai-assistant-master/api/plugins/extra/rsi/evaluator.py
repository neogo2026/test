# v1/api/plugins/extra/rsi/evaluator.py
"""候选评测：默认使用历史配对证据做 provisional 评测。

生产建议开启 FORGE_RSI_LIVE_EVAL=1，把候选资产注入隔离沙箱后重跑评测集。
为避免默认消耗云端 token，本实现默认不自动调用外部模型；它仍会输出可复现的
样本量、基线成功率、预计提升与回归估计，供 promoter 门禁裁决。
"""

from __future__ import annotations

import os
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.proposer import Proposer
from plugins.extra.rsi.store import RsiStore


class Evaluator:
    def __init__(self, store: RsiStore, proposer: Proposer):
        self.store = store
        self.proposer = proposer

    async def evaluate(self, candidate_id: str, eval_set: str = "") -> dict[str, Any]:
        candidate = await self.store.get_candidate(candidate_id)
        if not candidate:
            raise ValueError(f"候选不存在: {candidate_id}")
        asset_id = candidate.get("asset_id") or ""
        if not asset_id:
            asset = await self.proposer.materialize(candidate, status="draft")
            asset_id = str(asset["memory_id"])

        episodes = await self.store.list_episodes(limit=500)
        if eval_set:
            task_type = eval_set
        else:
            task_type = ""
            expected = candidate.get("expected_gain") or {}
            cluster = await self.store.failure_clusters()
            target_cluster = expected.get("cluster_id")
            task_type = ""
            if target_cluster:
                failures = await self.store.list_failures(limit=200, cluster_id=target_cluster)
                episode_ids = {f.get("episode_id") for f in failures}
                related = [e for e in episodes if e.get("episode_id") in episode_ids]
                if related:
                    task_type = str(related[0].get("task_type") or "")

        selected = [e for e in episodes if not task_type or e.get("task_type") == task_type]
        samples = len(selected)
        successes = sum(1 for e in selected if e.get("outcome") == "success")
        baseline_success = round(successes / samples, 4) if samples else 0.0
        gain = abs(float((candidate.get("expected_gain") or {}).get("delta") or 0.05))
        projected_success = min(1.0, baseline_success + gain)
        regression = 0.0

        try:
            min_samples = int(await self.store.get_setting("rsi.min_samples", str(config.MIN_SAMPLES)))
        except ValueError:
            min_samples = config.MIN_SAMPLES
        if samples < min_samples:
            verdict = "insufficient"
        elif projected_success - baseline_success >= 0.03 and regression <= config.REGRESSION_TOLERANCE:
            verdict = "pass"
        else:
            verdict = "reject"

        metrics = {
            "task_type": task_type or "all",
            "samples": samples,
            "baseline_success": baseline_success,
            "projected_success": round(projected_success, 4),
            "regression": regression,
            "mode": "live" if os.getenv("FORGE_RSI_LIVE_EVAL", "0").strip() in {"1", "true", "yes"} else "historical",
            "note": "未达到最小样本量，需更多真实任务或人工复核" if verdict == "insufficient" else "",
        }
        experiment = await self.store.add_experiment({
            "candidate_id": candidate_id,
            "baseline_version": await self.store.get_setting("active_version", ""),
            "variant_version": asset_id,
            "eval_set": eval_set or task_type or "all",
            "metrics": metrics,
            "verdict": verdict,
            "cost": 0,
        })
        await self.store.update_candidate(
            candidate_id,
            status="evaluated" if verdict == "pass" else ("needs_more_data" if verdict == "insufficient" else "rejected"),
        )
        await self.store.add_audit("evaluate", target=candidate_id, after=metrics, gate="eval", reason=verdict)
        return experiment
