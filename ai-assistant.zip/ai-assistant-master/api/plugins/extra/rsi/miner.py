# v1/api/plugins/extra/rsi/miner.py
"""失败打分、根因分类与聚类。

先规则后模型：规则便宜且可解释；LLM 反思只在显式开启时调用。
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.store import RsiStore


def failure_score(episode: dict[str, Any]) -> float:
    signals = episode.get("signals") or {}
    outcome = str(episode.get("outcome") or "")
    calls = max(1, int(episode.get("tool_calls") or 0))
    tool_error_rate = min(1.0, int(episode.get("tool_errors") or 0) / calls)
    score = 0.0
    score += 0.25 if outcome == "failed" else 0.0
    score += 0.15 if int(signals.get("nudges") or 0) else 0.0
    score += 0.15 * tool_error_rate
    score += 0.10 if signals.get("retry_loop") else 0.0
    score += 0.10 if signals.get("approval_rejected") else 0.0
    score += 0.10 if signals.get("tests_failed") else 0.0
    score += 0.10 if signals.get("finish_length") else 0.0
    score += 0.05 if int(episode.get("tokens") or 0) > 150_000 else 0.0
    return round(min(1.0, score), 3)


def classify(episode: dict[str, Any]) -> tuple[str, str, str, float]:
    """返回 (category, root_cause, evidence, confidence)。"""
    signals = episode.get("signals") or {}
    tool_names = signals.get("tool_names") or {}
    errors = signals.get("errors") or []
    if signals.get("tests_failed"):
        return (
            "verification",
            "验证不足：运行了测试/自检但失败后未完成修复",
            f"测试失败；工具错误 {episode.get('tool_errors')} 次；最后错误：{errors[-1] if errors else 'n/a'}",
            0.85,
        )
    if signals.get("retry_loop") or int(episode.get("tool_errors") or 0) >= 2:
        return (
            "tool",
            "工具选择或参数错误：重复失败后未换思路",
            f"工具错误 {episode.get('tool_errors')} 次；错误样本：{'; '.join(errors[:2]) or 'n/a'}",
            0.75,
        )
    if signals.get("finish_length"):
        return (
            "model_boundary",
            "输出截断：长输出达到上限后未继续行动",
            f"finish_reason=length 出现 {signals.get('finish_length')} 次；steps={episode.get('steps')}",
            0.8,
        )
    if int(signals.get("nudges") or 0):
        return (
            "planning",
            "规划缺陷：只输出计划或过早结束，需要运行时纠偏",
            f"nudge {signals.get('nudges')} 次；工具调用 {episode.get('tool_calls')} 次",
            0.7,
        )
    if signals.get("approval_rejected"):
        return (
            "safety",
            "审批被拒后未提供替代安全方案",
            "审批拒绝后任务失败或未收尾",
            0.65,
        )
    if str(episode.get("outcome")) == "abandoned":
        return (
            "planning",
            "长任务未收尾：停在审批/规划阶段，未形成可验证产物",
            f"outcome=abandoned；工具 {signals.get('tool_names') or {}}；approvals={signals.get('approvals')}",
            0.55,
        )
    if str(episode.get("task_type")) == "software_dev" and int(episode.get("tool_calls") or 0) == 0:
        return (
            "planning",
            "任务目标理解偏差：软件任务未实际动手",
            f"软件任务但工具调用为 0；input={str(episode.get('input') or '')[:120]}",
            0.8,
        )
    if str(episode.get("outcome")) == "failed":
        return (
            "environment",
            "执行失败：环境、依赖或运行时异常",
            f"outcome=failed；output={str(episode.get('output') or '')[:200]}",
            0.55,
        )
    return (
        "efficiency",
        "效率偏低：成功但成本/步数异常",
        f"tokens={episode.get('tokens')} steps={episode.get('steps')} tool_calls={episode.get('tool_calls')}",
        0.5,
    )


def cluster_id(category: str, root_cause: str) -> str:
    raw = f"{category}:{root_cause}".encode("utf-8")
    return "cl_" + hashlib.sha1(raw).hexdigest()[:10]


class Miner:
    def __init__(self, store: RsiStore):
        self.store = store

    async def analyze(self, episode: dict[str, Any]) -> dict[str, Any] | None:
        score = failure_score(episode)
        outcome = str(episode.get("outcome") or "")
        if outcome == "success" and score < config.FAILURE_THRESHOLD:
            await self.store.mark_analyzed(str(episode["episode_id"]))
            return None
        if outcome == "running":
            return None

        existing = await self.store.list_failures(limit=200)
        if any(item.get("episode_id") == episode.get("episode_id") for item in existing):
            await self.store.mark_analyzed(str(episode["episode_id"]))
            return None

        category, root_cause, evidence, confidence = classify(episode)
        failure = {
            "episode_id": episode["episode_id"],
            "session_id": episode.get("session_id", ""),
            "category": category,
            "root_cause": root_cause,
            "evidence": evidence[:2000],
            "severity": score,
            "confidence": confidence,
            "cluster_id": cluster_id(category, root_cause),
            "status": "open",
        }
        failure = await self.store.add_failure(failure)
        await self.store.mark_analyzed(str(episode["episode_id"]))
        return failure

    async def mine_pending(self, limit: int = 50) -> list[dict[str, Any]]:
        results = []
        for episode in await self.store.list_unanalyzed(limit=limit):
            failure = await self.analyze(episode)
            if failure:
                results.append(failure)
        return results


def reflection(episode: dict[str, Any], related: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """结构化反思：目标 / 动作 / 结果 / 缺陷 / 下一步。"""
    signals = episode.get("signals") or {}
    category, root_cause, evidence, confidence = classify(episode)
    tool_names = signals.get("tool_names") or {}
    return {
        "episode_id": episode.get("episode_id"),
        "goal": str(episode.get("input") or "")[:300],
        "outcome": episode.get("outcome"),
        "metrics": {
            "steps": episode.get("steps"),
            "tool_calls": episode.get("tool_calls"),
            "tool_errors": episode.get("tool_errors"),
            "tokens": episode.get("tokens"),
            "seconds": episode.get("seconds"),
            "reward": episode.get("reward"),
        },
        "tools_used": tool_names,
        "failure_score": failure_score(episode),
        "root_cause": {"category": category, "summary": root_cause, "evidence": evidence,
                       "confidence": confidence},
        "next_actions": _next_actions(category, signals),
        "related_failures": related or [],
    }


def _next_actions(category: str, signals: dict[str, Any]) -> list[str]:
    mapping = {
        "verification": ["失败后先阅读完整 stderr", "修复后重新运行同一测试命令", "完成前检查边界用例"],
        "tool": ["核对工具参数 schema", "连续两次相同失败必须换工具或换思路", "优先 read_file 而不是 shell cat"],
        "planning": ["先列 3 步计划再行动", "每个里程碑必须产生可验证产物", "禁止只输出说明"],
        "model_boundary": ["把长实现分块 write_file", "每块写完立即运行自检", "不要在一次回复里输出全部代码"],
        "safety": ["审批拒绝后生成替代安全方案", "禁止绕过审批"],
        "environment": ["先探测依赖与工作区", "失败时给出环境诊断结论"],
        "efficiency": ["减少重复读取", "合并相似工具调用"],
    }
    return mapping.get(category, ["复盘失败轨迹并补充验证"])
