# v1/api/plugins/extra/rsi/collector.py
"""事件 → Episode 归一化。

订阅 EventBus 旁路事件，把一次 Run 变成可回放、可打分、可导出的轨迹。
采集本身不改变 Agent 行为；是否采集由 session/global mode 决定。
"""

from __future__ import annotations

import re
from typing import Any, Awaitable, Callable

from plugins.extra.rsi.store import RsiStore, new_id, utc_now

ModeFn = Callable[[str], Awaitable[str]]
FinalizedFn = Callable[[dict[str, Any]], Awaitable[None]]

TASK_PATTERNS = [
    ("software_dev", r"(实现|开发|修复|重构|编写|代码|测试|bug|bugfix|写文件|创建文件|写入|编辑文件|implement|develop|fix|refactor|code|pytest|write_file)"),
    ("video", r"(视频|剪辑|字幕|配音|video|ffmpeg|subtitle)"),
    ("plan", r"(方案|计划|计划书|调研|分析|plan|proposal|analysis|research)"),
    ("ops", r"(部署|运维|服务器|docker|k8s|deploy|ops)"),
]


def detect_task_type(text: str) -> str:
    for name, pattern in TASK_PATTERNS:
        if re.search(pattern, text or "", re.I):
            return name
    return "general"


class Collector:
    def __init__(self, store: RsiStore, harness: Any, mode_fn: ModeFn, on_finalized: FinalizedFn | None = None):
        self.store = store
        self.harness = harness
        self.mode_fn = mode_fn
        self.on_finalized = on_finalized
        self._episodes: dict[str, dict[str, Any]] = {}

    async def accept(self, session_id: str, event_type: str, payload: dict[str, Any]) -> bool:
        if event_type in {"model.delta"}:
            return False
        run_id = str(payload.get("_run_id") or payload.get("run_id") or "")
        if not run_id:
            return False
        mode = await self.mode_fn(session_id)
        if mode == "off":
            return False

        if event_type == "run.started":
            await self._start(session_id, run_id, payload)
            return True

        episode = self._episodes.get(run_id)
        if not episode:
            episode = await self.store.get_episode_by_run(run_id)
            if not episode:
                return False
            self._episodes[run_id] = episode
        if episode.get("outcome") not in {"running", None} and event_type not in {
            "run.completed", "run.failed", "run.cancelled"
        }:
            return False

        signals = episode.setdefault("signals", {})

        if event_type == "model.completed":
            episode["steps"] = max(int(episode.get("steps") or 0), int(payload.get("step") or 0))
            usage = payload.get("usage") or {}
            episode["tokens"] = int(episode.get("tokens") or 0) + int(usage.get("total_tokens") or 0)
            signals["model_calls"] = int(signals.get("model_calls") or 0) + 1
            if str(payload.get("finish_reason") or "") == "length":
                signals["finish_length"] = int(signals.get("finish_length") or 0) + 1
            tool_calls = payload.get("tool_calls") or []
            signals.setdefault("tool_names", {})
            for call in tool_calls:
                name = str((call or {}).get("name") or "")
                if name:
                    signals["tool_names"][name] = int(signals["tool_names"].get(name) or 0) + 1

        elif event_type == "tool.requested":
            call_id = str(payload.get("call_id") or "")
            name = str(payload.get("name") or "")
            if call_id and name:
                calls = signals.setdefault("calls", {})
                calls[call_id] = {
                    "name": name,
                    "arguments": str(payload.get("arguments") or "")[:800],
                }
                if len(calls) > 200:
                    for key in list(calls)[:-150]:
                        calls.pop(key, None)

        elif event_type == "tool.result":
            episode["tool_calls"] = int(episode.get("tool_calls") or 0) + 1
            if not payload.get("ok"):
                episode["tool_errors"] = int(episode.get("tool_errors") or 0) + 1
                signals.setdefault("errors", [])
                signals["errors"].append(str(payload.get("error") or payload.get("summary") or "")[:300])
                signals["errors"] = signals["errors"][-20:]
                if "审批拒绝" in str(payload.get("error") or ""):
                    signals["approval_rejected"] = True
            call = (signals.get("calls") or {}).get(str(payload.get("call_id") or "")) or {}
            name = str(payload.get("name") or call.get("name") or "")
            args = str(call.get("arguments") or "")
            if name in {"write_file", "edit_file", "multi_edit", "move_path"} and payload.get("ok"):
                signals["files_written"] = int(signals.get("files_written") or 0) + 1
            if name in {"run_shell", "run_python"}:
                summary = str(payload.get("summary") or "")
                if "pytest" in args or "pytest" in summary or "unittest" in args:
                    signals["test_runs"] = int(signals.get("test_runs") or 0) + 1
                    exit_code = _exit_code(summary)
                    failed = exit_code not in {None, 0} or bool(re.search(r"\b(\d+) failed\b", summary)) \
                        or bool(re.search(r"\b(FAILED|ERROR)\b", summary))
                    if failed:
                        signals["tests_failed"] = True
            # 重试循环：同一工具连续失败 >= 3
            streak = signals.setdefault("error_streak", {})
            if payload.get("ok"):
                streak[name] = 0
            else:
                streak[name] = int(streak.get(name) or 0) + 1
                if streak[name] >= 3:
                    signals["retry_loop"] = True

        elif event_type == "run.nudge":
            signals["nudges"] = int(signals.get("nudges") or 0) + 1

        elif event_type == "approval.required":
            signals["approvals"] = int(signals.get("approvals") or 0) + 1

        elif event_type == "run.completed":
            episode["outcome"] = "success"
            episode["output"] = str(payload.get("output") or "")[:8000]
            await self._finalize(episode)
            return True

        elif event_type == "run.failed":
            episode["outcome"] = "failed"
            episode["output"] = str(payload.get("error") or "")[:8000]
            await self._finalize(episode)
            return True

        elif event_type == "run.cancelled":
            episode["outcome"] = "abandoned"
            await self._finalize(episode)
            return True

        await self.store.upsert_episode(episode)
        return True

    async def _start(self, session_id: str, run_id: str, payload: dict[str, Any]) -> None:
        run = await self.harness.storage.get_run(run_id)
        if not run:
            return
        session = await self.harness.storage.get_session(session_id) or {}
        task_input = str(run.get("input") or "")
        existing = await self.store.get_episode_by_run(run_id)
        episode = {
            "episode_id": (existing or {}).get("episode_id") or new_id("ep"),
            "session_id": session_id,
            "run_id": run_id,
            "tenant_id": run.get("tenant_id") or "default",
            "agent": str(payload.get("agent") or run.get("agent_name") or ""),
            "model": str(payload.get("model") or session.get("model_profile") or ""),
            "task_type": detect_task_type(task_input),
            "input": task_input[:8000],
            "output": "",
            "outcome": "running",
            "steps": 0,
            "tool_calls": 0,
            "tool_errors": 0,
            "tokens": 0,
            "usd": 0,
            "seconds": 0,
            "reward": 0,
            "signals": (existing or {}).get("signals") or {},
            "labels": (existing or {}).get("labels") or {},
            "analyzed": 0,
            "created_at": (existing or {}).get("created_at") or utc_now(),
        }
        self._episodes[run_id] = episode
        await self.store.upsert_episode(episode)

    async def _finalize(self, episode: dict[str, Any]) -> None:
        signals = episode.get("signals") or {}
        try:
            from datetime import datetime, timezone

            created = datetime.fromisoformat(str(episode.get("created_at")))
            episode["seconds"] = round((datetime.now(timezone.utc) - created).total_seconds(), 1)
        except (ValueError, TypeError):
            episode["seconds"] = 0
        base = 1.0 if episode.get("outcome") == "success" else (0.35 if episode.get("outcome") == "abandoned" else 0.0)
        penalty = 0.08 * int(signals.get("nudges") or 0) + 0.04 * int(episode.get("tool_errors") or 0)
        if signals.get("tests_failed"):
            penalty += 0.15
        episode["reward"] = round(max(0.0, min(1.0, base - penalty)), 3)
        self._episodes[episode["run_id"]] = episode
        await self.store.upsert_episode(episode)
        if self.on_finalized:
            await self.on_finalized(episode)


def _exit_code(summary: str) -> int | None:
    match = re.search(r'"exit_code"\s*:\s*(-?\d+)', summary)
    return int(match.group(1)) if match else None
