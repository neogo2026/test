# v1/api/plugins/extra/rsi/worker.py
"""RSI 后台工作者：定时挖掘失败、生成候选、按配置自动晋级。

所有工作都是异步、可中断的；插件停用后 worker 立即退出。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.evaluator import Evaluator
from plugins.extra.rsi.miner import Miner
from plugins.extra.rsi.promoter import Promoter
from plugins.extra.rsi.proposer import Proposer
from plugins.extra.rsi.store import RsiStore

logger = logging.getLogger(__name__)


class RsiWorker:
    def __init__(self, store: RsiStore):
        self.store = store
        self.miner = Miner(store)
        self.proposer = Proposer(store)
        self.evaluator = Evaluator(store, self.proposer)
        self.promoter = Promoter(store, self.proposer)
        self._task: asyncio.Task | None = None
        self._running = False
        self._lock = asyncio.Lock()

    async def start(self, mode_fn: Any) -> None:
        if self._task and not self._task.done():
            return
        self._running = True
        self._task = asyncio.create_task(self._loop(mode_fn))

    async def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        self._task = None

    async def _loop(self, mode_fn: Any) -> None:
        while self._running:
            try:
                await asyncio.sleep(config.WORKER_INTERVAL_S)
                await self.tick(mode_fn)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                logger.exception("RSI worker tick 失败")

    async def tick(self, mode_fn: Any = None) -> dict[str, Any]:
        global_mode = config.MODE
        if mode_fn:
            try:
                global_mode = await mode_fn("*")
            except Exception:  # noqa: BLE001
                pass
        if global_mode == "off":
            return {"skipped": "off"}
        async with self._lock:
            failures = await self.miner.mine_pending()
            candidates = await self.proposer.propose_from_failures()
            auto = []
            auto_setting = await self.store.get_setting(
                "rsi.auto_promote", "1" if config.AUTO_PROMOTE else "0"
            )
            if auto_setting.strip().lower() in {"1", "true", "yes"}:
                for candidate in candidates:
                    if candidate.get("risk") != "low":
                        continue
                    experiment = await self.evaluator.evaluate(str(candidate["candidate_id"]))
                    if experiment.get("verdict") == "pass":
                        await self.promoter.promote(str(candidate["candidate_id"]), actor="worker-auto")
                        auto.append(candidate["candidate_id"])
            return {"failures": len(failures), "candidates": len(candidates), "auto_promoted": auto}
