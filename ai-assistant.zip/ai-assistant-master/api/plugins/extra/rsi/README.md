# 自进化 RSI 插件

`plugins/extra/rsi` 是 AI助理 的进化层：旁路采集真实轨迹 → 失败归因 → 候选生成 →
评测/门禁 → 晋级/回滚；对外提供工具与 HTTP 接口，并可选把已晋级经验注入上下文。

## 开关

```bash
FORGE_RSI_ENABLED=1        # 0 = 插件不加载（熔断）
FORGE_RSI_MODE=observe     # off / observe / active
FORGE_RSI_AUTO_PROMOTE=0   # 仅低风险资产可自动晋级
FORGE_RSI_MIN_SAMPLES=20
FORGE_RSI_WORKER_INTERVAL_S=60
FORGE_RSI_LLM_REFLECT=0    # 默认不调用外部模型做反思
```

全局模式也可通过 `PUT /api/rsi/settings {"mode":"active"}` 修改（落库 `rsi.mode`）。
会话级模式：

```bash
curl -X POST http://127.0.0.1:8036/api/rsi/sessions/<session_id>/mode \
  -H 'Content-Type: application/json' -d '{"mode":"active"}'
```

- `off`：不采集、不注入、工具写操作不可用。
- `observe`：采集 + 分析 + 候选 + 导出，**不注入、不改行为**（默认）。
- `active`：额外注入已晋级记忆/技能；工具失败与输出截断时给出运行时提示。

## 数据

独立 SQLite：`api/data/rsi/rsi.db`。表：episodes / failures / candidates /
experiments / versions / memories / audit / settings。

导出：

```bash
GET /api/rsi/export/sft
GET /api/rsi/export/dpo
GET /api/rsi/export/eval
```

产物在 `api/data/rsi/exports/`，带 sha1 manifest，供
`local-models/Qwen3.5-2B-RSI` 消费。

## 接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/rsi/status` | 开关、模式、版本、统计 |
| GET | `/api/rsi/episodes` | 轨迹列表 |
| GET | `/api/rsi/failures` | 失败列表 |
| GET | `/api/rsi/failure-clusters` | 失败聚类 |
| POST | `/api/rsi/mine` | 手动挖掘 + 生成候选 |
| GET | `/api/rsi/candidates` | 候选资产 |
| POST | `/api/rsi/candidates/{id}/evaluate` | 评测候选 |
| POST | `/api/rsi/candidates/{id}/promote` | 晋级（可 force） |
| GET | `/api/rsi/experiments` | 实验列表 |
| GET | `/api/rsi/versions` | 版本谱系 |
| POST | `/api/rsi/versions/{id}/rollback` | 回滚 |
| PUT | `/api/rsi/settings` | 全局模式/门禁配置 |
| POST | `/api/rsi/sessions/{id}/mode` | 会话模式 |
| GET | `/api/rsi/export/{sft,dpo,eval}` | 导出 JSONL |

## 模型工具

`rsi_status` / `rsi_recall` / `rsi_remember` / `rsi_reflect` / `rsi_report_failure` /
`rsi_plan_review` / `rsi_propose` / `rsi_evaluate` / `rsi_promote` / `rsi_rollback`

插件启用时自动追加到各 Agent 的工具列表；停用时恢复原列表。

## 安全边界

- 默认 observe；active 必须显式开启。
- 候选默认 draft；promote 需要评测通过或人工 force。
- 代码级自改不在本版范围内，只允许技能/记忆/提示词补丁。
- 所有变更写 `audit`；版本回滚只切指针，不删历史。
