# v1/api/plugins/extra/rsi/proposer.py
"""候选生成：一次只改一个变量，先记忆后技能，先技能后提示词。

候选默认 draft，不生效；必须经过 evaluator + promoter。
"""

from __future__ import annotations

import re
from typing import Any

from plugins.extra.rsi import config
from plugins.extra.rsi.store import RsiStore, new_id


def _slug(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9\u4e00-\u9fff]+", "-", text.strip()).strip("-")
    return (text or new_id("asset"))[:48]


TEMPLATES = {
    "verification": {
        "type": "skill",
        "name": "verification-first",
        "hypothesis": "失败集中在测试/自检未闭环；先验证再收尾可显著降低回归",
        "body": (
            "# 验证优先\n\n"
            "适用于软件实现、缺陷修复、重构类任务。\n\n"
            "1. 修改前先运行一次现有测试，记录基线（通过的用例数）。\n"
            "2. 修改后必须重新运行同一命令；失败时阅读完整 stderr，而不是只看最后一行。\n"
            "3. 完成前检查：正常路径、空输入、边界值、异常分支。\n"
            "4. 没有现成测试时，先写 `tests_selfcheck.py`，再实现，再运行。\n"
            "5. 禁止通过修改测试来让测试通过。\n"
        ),
        "triggers": ["测试", "pytest", "修复", "实现", "bug"],
    },
    "tool": {
        "type": "skill",
        "name": "tool-usage-discipline",
        "hypothesis": "工具错误多因参数/schema 不熟或重复失败不换思路",
        "body": (
            "# 工具使用纪律\n\n"
            "- 读文件用 read_file，搜索用 grep/glob，不要用 shell cat/find。\n"
            "- 写文件用 write_file；局部修改用 edit_file/multi_edit。\n"
            "- 同一工具连续两次相同错误：停止重试，检查参数或换工具。\n"
            "- 命令失败时先读 stderr，再决定下一步。\n"
            "在任何会话中遇到 tool error，优先回顾本条。\n"
        ),
        "triggers": ["tool", "参数", "错误", "重试"],
    },
    "planning": {
        "type": "prompt_patch",
        "name": "act-before-explain",
        "hypothesis": "模型倾向只输出计划；强制先行动可降低 nudge 率",
        "body": (
            "执行约束：这是实现类任务时，第一轮必须先调用至少一个工具（list_dir / read_file / grep），"
            "然后立即开始修改；禁止只输出计划、说明或代码片段。每完成一个里程碑就运行验证。"
        ),
        "triggers": ["实现", "开发", "修复"],
    },
    "model_boundary": {
        "type": "prompt_patch",
        "name": "chunked-write",
        "hypothesis": "长输出被截断导致停止行动；分块写入可恢复",
        "body": (
            "当需要输出超过 200 行代码时，必须分块调用 write_file 写入文件，"
            "每块写完后继续下一块；禁止在单条消息里输出完整长代码。"
        ),
        "triggers": ["长文件", "实现", "代码"],
    },
    "safety": {
        "type": "memory",
        "name": "safe-approval-fallback",
        "hypothesis": "审批拒绝后缺少替代方案，任务中断",
        "body": (
            "当高风险操作被审批拒绝时，不要重复请求同一操作；"
            "给出至少一个低风险替代方案（只读分析、生成补丁文件、让用户手动执行命令）。"
        ),
        "triggers": ["审批", "拒绝", "安全"],
    },
}


class Proposer:
    def __init__(self, store: RsiStore):
        self.store = store

    async def propose_from_failures(self, limit: int = 5) -> list[dict[str, Any]]:
        clusters = await self.store.failure_clusters()
        existing = await self.store.list_candidates(limit=500)
        created: list[dict[str, Any]] = []
        for cluster in clusters[:limit]:
            category = str(cluster.get("category") or "")
            template = TEMPLATES.get(category)
            if not template:
                continue
            if any(c.get("type") == template["type"] and
                   (c.get("diff") or {}).get("name") == template["name"] for c in existing):
                continue
            failures = await self.store.list_failures(limit=20, cluster_id=str(cluster.get("cluster_id") or ""))
            diff = {
                "action": "add_" + template["type"],
                "name": template["name"],
                "body": template["body"],
                "triggers": template["triggers"],
                "scope": "org" if template["type"] == "skill" else "agent:coder",
            }
            candidate = await self.store.add_candidate({
                "type": template["type"],
                "hypothesis": template["hypothesis"],
                "diff": diff,
                "expected_gain": {
                    "metric": "repeated_failure_rate",
                    "delta": -0.2,
                    "cluster_id": cluster.get("cluster_id"),
                    "cluster_count": cluster.get("count"),
                },
                "risk": "low" if template["type"] in {"memory", "skill"} else "medium",
                "source_failures": [f.get("failure_id") for f in failures],
                "status": "draft",
                "created_by": "miner",
            })
            created.append(candidate)
        return created

    async def materialize(self, candidate: dict[str, Any], status: str = "draft") -> dict[str, Any]:
        """把候选变成可检索资产（记忆 / 技能 / 提示词补丁）。"""
        diff = candidate.get("diff") or {}
        kind = "memory" if candidate.get("type") == "memory" else "prompt" if candidate.get("type") == "prompt_patch" else "skill"
        name = str(diff.get("name") or _slug(candidate.get("hypothesis", "")))
        content = str(diff.get("body") or "")
        if kind == "prompt":
            content = f"【运行时提示词补丁：{name}】\n{content}"
        asset = await self.store.add_memory({
            "kind": kind,
            "name": name,
            "scope": str(diff.get("scope") or "org"),
            "content": content,
            "confidence": 0.82 if candidate.get("risk") == "low" else 0.7,
            "source_episode": (candidate.get("source_failures") or [""])[0] if candidate.get("source_failures") else "",
            "status": status,
            "metadata": {
                "candidate_id": candidate.get("candidate_id"),
                "triggers": diff.get("triggers") or [],
                "type": candidate.get("type"),
            },
        })
        await self.store.update_candidate(str(candidate.get("candidate_id")), asset_id=str(asset["memory_id"]))
        return asset
