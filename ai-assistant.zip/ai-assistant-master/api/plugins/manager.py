# v1/api/plugins/manager.py
"""
插件管理器。

职责（WordPress 式）：
- 发现：内置插件清单 + plugins/extra/ 目录下第三方插件（future：包安装）
- 启停：data/plugins.json 持久化启用状态；支持运行时 enable / disable
- 生命周期：register → on_start（启动后台任务）；disable → on_stop
- 隔离：单个插件加载失败只告警，不拖垮内核
"""

from __future__ import annotations

import importlib
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter

from configs.configs import PLUGINS_STATE_PATH
from plugins.base import Plugin, PluginContext

logger = logging.getLogger(__name__)

# 内置插件（随产品发布，可停用）：短名 -> plugin 模块路径
BUILTIN_PLUGINS: dict[str, str] = {
    "core_tools": "plugins.builtin.core_tools.plugin",
    "dev_tools": "plugins.builtin.dev_tools.plugin",
    "skills": "plugins.builtin.skills.plugin",
    "usage": "plugins.builtin.usage.plugin",
    "feishu": "plugins.builtin.feishu.plugin",
}


class PluginManager:
    def __init__(self, harness: Any):
        self.harness = harness
        self.plugins: dict[str, Plugin] = {}
        self.contexts: dict[str, PluginContext] = {}
        self.states: dict[str, bool] = {}
        self.errors: dict[str, str] = {}
        self.state_path = Path(PLUGINS_STATE_PATH)

    # ------------------------------------------------------------------
    # 状态持久化
    # ------------------------------------------------------------------
    def _load_states(self) -> None:
        defaults = {name: True for name in BUILTIN_PLUGINS}
        if self.state_path.exists():
            try:
                data = json.loads(self.state_path.read_text(encoding="utf-8"))
                for name, enabled in (data.get("enabled") or {}).items():
                    defaults[name] = bool(enabled)
            except Exception:  # noqa: BLE001
                logger.warning("plugins.json 解析失败，使用默认启用状态")
        self.states = defaults

    def _save_states(self) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(
            json.dumps({"enabled": self.states}, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # ------------------------------------------------------------------
    # 加载与生命周期
    # ------------------------------------------------------------------
    def load_all(self) -> list[APIRouter]:
        """加载所有启用插件，返回收集到的路由列表（供 main 挂载）。"""
        self._load_states()
        routers: list[APIRouter] = []
        modules: dict[str, str] = dict(BUILTIN_PLUGINS)
        # 第三方插件目录：plugins/extra/*/plugin.py
        extra_dir = Path(__file__).parent / "extra"
        if extra_dir.exists():
            for child in sorted(extra_dir.iterdir()):
                if child.is_dir() and (child / "plugin.py").exists():
                    modules.setdefault(child.name, f"plugins.extra.{child.name}.plugin")

        loaded: list[tuple[int, str]] = []
        for short_name, module_path in modules.items():
            if not self.states.get(short_name, True):
                continue
            plugin = self._import_plugin(module_path, short_name)
            if plugin:
                loaded.append((plugin.meta.priority, short_name))
        loaded.sort()

        for _, name in loaded:
            plugin = self.plugins.get(name)
            if not plugin:
                continue
            ctx = PluginContext(self.harness, name)
            try:
                plugin.register(ctx)
                self.contexts[name] = ctx
                routers.extend(ctx.routers)
                logger.info("插件已装载：%s v%s", plugin.meta.name, plugin.meta.version)
            except Exception as exc:  # noqa: BLE001
                self.errors[name] = f"register 失败: {exc}"
                logger.exception("插件 %s 注册失败", name)
        return routers

    def _import_plugin(self, module_path: str, short_name: str) -> Plugin | None:
        if short_name in self.plugins:
            return self.plugins[short_name]
        try:
            module = importlib.import_module(module_path)
            plugin = getattr(module, "PLUGIN", None)
            if not isinstance(plugin, Plugin):
                raise ValueError("未导出 PLUGIN 实例（须为 plugins.base.Plugin 子类）")
            self.plugins[short_name] = plugin
            return plugin
        except Exception as exc:  # noqa: BLE001
            self.errors[short_name] = f"加载失败: {exc}"
            logger.exception("插件 %s 加载失败", short_name)
            return None

    async def start_all(self) -> None:
        for name, ctx in list(self.contexts.items()):
            plugin = self.plugins.get(name)
            if not plugin:
                continue
            try:
                await plugin.on_start(ctx)
            except Exception as exc:  # noqa: BLE001
                self.errors[name] = f"on_start 失败: {exc}"
                logger.exception("插件 %s 启动失败", name)

    async def stop_all(self) -> None:
        for name, ctx in list(self.contexts.items()):
            plugin = self.plugins.get(name)
            if not plugin:
                continue
            try:
                await plugin.on_stop(ctx)
            except Exception:  # noqa: BLE001
                logger.exception("插件 %s 停止失败", name)

    # ------------------------------------------------------------------
    # 运行时启停
    # ------------------------------------------------------------------
    async def enable(self, name: str, mount_router: Any = None) -> dict:
        plugin = self.plugins.get(name)
        if plugin is None:
            module_path = BUILTIN_PLUGINS.get(name)
            if module_path:
                plugin = self._import_plugin(module_path, name)
        if plugin is None:
            return {"ok": False, "error": f"插件不存在: {name}"}
        if name in self.contexts:
            return {"ok": True, "error": "", "note": "已处于启用状态"}
        ctx = PluginContext(self.harness, name)
        try:
            plugin.register(ctx)
            self.contexts[name] = ctx
            if mount_router:
                for router in ctx.routers:
                    mount_router(router)
            await plugin.on_start(ctx)
            self.states[name] = True
            self._save_states()
            return {"ok": True, "error": ""}
        except Exception as exc:  # noqa: BLE001
            self.errors[name] = f"enable 失败: {exc}"
            return {"ok": False, "error": str(exc)}

    async def disable(self, name: str) -> dict:
        ctx = self.contexts.pop(name, None)
        plugin = self.plugins.get(name)
        if ctx and plugin:
            try:
                await plugin.on_stop(ctx)
            except Exception as exc:  # noqa: BLE001
                self.errors[name] = f"on_stop 失败: {exc}"
            # 生命周期修正：管理器自动摘除该插件注册的工具与事件订阅，
            # 保证「关闭插件 = 回到 baseline」，即使插件 on_stop 遗漏也成立。
            for tool_name in list(getattr(ctx, "tool_names", []) or []):
                try:
                    self.harness.tools.unregister(tool_name)
                except Exception:  # noqa: BLE001
                    pass
            for sink in list(getattr(ctx, "_event_sinks", []) or []):
                try:
                    self.harness.events.bus.unsubscribe_sink(sink)
                except Exception:  # noqa: BLE001
                    pass
        self.states[name] = False
        self._save_states()
        return {
            "ok": True,
            "error": "",
            "note": "已停用；HTTP 路由将在重启后完全卸载，工具已即时摘除" if ctx else "已停用（下次启动不再加载）",
        }

    # ------------------------------------------------------------------
    # 信息
    # ------------------------------------------------------------------
    def describe(self) -> list[dict]:
        result = []
        known = set(self.plugins) | set(BUILTIN_PLUGINS)
        for name in sorted(known):
            plugin = self.plugins.get(name)
            entry = {
                "name": name,
                "enabled": bool(self.contexts.get(name)),
                "will_load": bool(self.states.get(name, True)),
                "error": self.errors.get(name, ""),
            }
            if plugin:
                meta = plugin.meta
                entry.update(
                    {
                        "title": meta.title,
                        "version": meta.version,
                        "description": meta.description,
                        "author": meta.author,
                        "tags": meta.tags,
                        "priority": meta.priority,
                    }
                )
            else:
                entry.update({"title": name, "version": "", "description": "", "author": "", "tags": []})
            result.append(entry)
        return result
