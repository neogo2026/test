# v1/api/plugins/base.py
"""
插件契约。

AI助理 采用 WordPress 式「小内核 + 插件」架构，同时吸收 DeepSeek Harness 的
「harness 即插件」思想：

- 内核（core/）只有运行时语义，没有任何业务能力
- 一切能力（工具集、技能、飞书、用量、未来的具身 harness）都是插件
- 插件通过 PluginContext 声明式注册自己的能力：工具/路由/Agent/Provider/Screener/事件订阅

写一个插件只需三步：
1. 在 plugins/ 下建一个包，写 plugin.py
2. 定义 PLUGIN = Plugin 子类实例，实现 register(ctx)
3. 在 data/plugins.json 中启用（或调用 /api/plugins/{name}/enable）
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from fastapi import APIRouter

from core.contracts import AgentSpec, ModelProfile, ToolSpec


@dataclass
class PluginMeta:
    name: str
    title: str
    version: str = "0.1.0"
    description: str = ""
    author: str = ""
    priority: int = 100  # 数字越小越先加载
    tags: list[str] = field(default_factory=list)


class Plugin:
    """插件基类。生命周期：register → on_start → (运行) → on_stop。"""

    meta: PluginMeta

    def register(self, ctx: "PluginContext") -> None:  # noqa: B027
        """声明式注册能力（同步，启动时调用一次）。"""

    async def on_start(self, ctx: "PluginContext") -> None:  # noqa: B027
        """启动钩子（可启动后台任务 / 长连接）。"""

    async def on_stop(self, ctx: "PluginContext") -> None:  # noqa: B027
        """停止钩子（释放资源）。"""


class PluginContext:
    """
    插件能力注册面板。

    由 PluginManager 构造并传入；只暴露注册接口，不暴露内核内部结构。
    """

    def __init__(self, harness: Any, plugin_name: str):
        self._harness = harness
        self.name = plugin_name
        self.routers: list[APIRouter] = []
        self.startup_errors: list[str] = []
        # 生命周期清理：记录本插件注册的资源，停用时自动摘除。
        self.tool_names: list[str] = []
        self._event_sinks: list[Callable[..., Any]] = []

    # ---- 工具 ----
    def register_tool(self, spec: ToolSpec, handler: Callable[..., Any]) -> None:
        self._harness.tools.register(spec, handler)
        if spec.name not in self.tool_names:
            self.tool_names.append(spec.name)

    def unregister_tool(self, name: str) -> None:
        self._harness.tools.unregister(name)
        if name in self.tool_names:
            self.tool_names.remove(name)

    # ---- 路由 ----
    def register_router(self, router: APIRouter) -> None:
        self.routers.append(router)

    # ---- Agent / 模型 ----
    def register_agent(self, spec: AgentSpec) -> None:
        from core import agents as agent_registry

        agent_registry.register_agent(spec)

    def register_model_profile(self, profile: ModelProfile) -> None:
        self._harness.gateway.register_profile(profile)

    def register_provider(self, name: str, provider: Any) -> None:
        self._harness.gateway.register_provider(name, provider)

    # ---- 安全 ----
    def register_screener(self, fn: Callable[[str, dict], "str | None"]) -> None:
        """注册危险内容预检器：返回非空字符串即拒绝理由。"""
        self._harness.policy.register_screener(fn)

    # ---- 事件 ----
    def subscribe_events(self, fn: Callable[[str, str, dict], Awaitable[None]]) -> None:
        """订阅实时事件流：fn(session_id, event_type, payload)。"""
        self._harness.events.bus.subscribe_sink(fn)
        self._event_sinks.append(fn)

    def unsubscribe_events(self, fn: Callable[[str, str, dict], Awaitable[None]]) -> None:
        self._harness.events.bus.unsubscribe_sink(fn)
        if fn in self._event_sinks:
            self._event_sinks.remove(fn)

    # ---- 进化层钩子（V2 内核补齐） ----
    def register_context_provider(self, name: str, fn: Any, priority: int = 100) -> None:
        """上下文 provider 链：RSI 记忆 / 技能 / 项目约束注入。"""
        self._harness.context.add_context_provider(name, fn, priority)

    def unregister_context_provider(self, name: str) -> None:
        self._harness.context.remove_context_provider(name)

    def register_model_middleware(self, name: str, before: Any = None, after: Any = None) -> None:
        """模型调用前后拦截：记忆召回 / 即时反思 / 偏好信号。"""
        self._harness.gateway.register_model_middleware(name, before, after)

    def unregister_model_middleware(self, name: str) -> None:
        self._harness.gateway.remove_model_middleware(name)

    def register_tool_middleware(self, name: str, before: Any = None, after: Any = None) -> None:
        """工具调用前后拦截：工具质量统计 / 沙箱替换副作用工具。"""
        self._harness.tools.register_middleware(name, before, after)

    def unregister_tool_middleware(self, name: str) -> None:
        self._harness.tools.remove_middleware(name)

    # ---- 技能 ----
    def set_skill_provider(self, fn: Callable[[str, int], list]) -> None:
        """注入技能检索函数（内核上下文构建时调用）。"""
        self._harness.context.set_skill_provider(fn)

    # ---- 存储与配置 ----
    @property
    def storage(self) -> Any:
        return self._harness.storage

    @property
    def runtime(self) -> Any:
        return self._harness.runtime
