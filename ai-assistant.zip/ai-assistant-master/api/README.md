# AI助理 API · 后端

以 agent-harness 框架为底座重写的下一代 AI 编程全能工具后端。

## 快速开始

```bash
cd v1/api
python -m venv env1                  # Windows: env1\Scripts\activate
source env1/bin/activate             # Linux
pip install -r requirements.txt
python main.py                       # http://127.0.0.1:8036  (docs: /docs)
```

无任何 Key 时自动进入 mock 模式，全链路（工具/审批/事件/恢复）可跑通。

## 密钥配置

三级回退：**环境变量 > `configs/secrets_local.py` > `../../tool/feishu.local.py`（复用上一代 AI助理）**

```bash
cp configs/secrets_example.py configs/secrets_local.py   # 填入真实 Key
```

`secrets_local.py` 已被 .gitignore 忽略，绝不入库。仓库只提交模板。

## 自测

```bash
python script/selftest.py     # 36 项全链路断言（无需 Key）
python script/rsi_selftest.py # RSI 进化闭环 34 项断言（无需 Key）
python script/ws_smoke.py     # WebSocket 实时流冒烟
```

## 自进化 RSI（插件）

`plugins/extra/rsi` 提供轨迹采集、失败归因、候选生成、历史评测、版本晋级/回滚与
分层记忆；默认 `observe`，会话级可切 `off / observe / active`。

```bash
FORGE_RSI_ENABLED=1
FORGE_RSI_MODE=observe        # off / observe / active
FORGE_RSI_AUTO_PROMOTE=0
```

- 插件开关：`/api/plugins/rsi/{enable,disable}`
- 全局模式：`PUT /api/rsi/settings {"mode":"active"}`
- 会话模式：`POST /api/rsi/sessions/{id}/mode {"mode":"active"}`
- 导出训练数据：`GET /api/rsi/export/{sft,dpo,eval}` → `data/rsi/exports/`
- 详见：`plugins/extra/rsi/README.md`，模型工程：
  `../local-models/Qwen3.5-2B-RSI/`

## 目录结构

```
core/        内核（业务无关）：契约/存储/事件总线/策略/网关/运行时/沙箱
adapters/    LLM Provider 适配：mock + 通用 OpenAI 兼容(MiMo/DeepSeek/GLM/…)
plugins/     插件系统 + 内置插件（core_tools/dev_tools/skills/usage/feishu）
extensions/  内核 HTTP/WS 层（system/sessions/ws/plugins）
configs/     配置与密钥加载
skills/      Markdown 技能包
script/      自测脚本
```

## 环境变量（FORGE_* 前缀）

| 变量 | 默认 | 说明 |
|---|---|---|
| FORGE_PORT | 8036 | 服务端口 |
| FORGE_HOST | 127.0.0.1 | 监听地址 |
| FORGE_DATA_DIR | api/data | 数据目录（SQLite/工作区/插件状态） |
| FORGE_MAX_STEPS | 40 | Agent 最大步数 |
| FORGE_CONCURRENT_SESSIONS | 5 | 并发会话闸 |
| FORGE_GATE_MODE | ask | 默认门禁（ask/allow_all） |
| FORGE_FEISHU_ENABLED | 1 | 飞书长连接总开关 |
| FORGE_MIMO_MODEL | mimo-v2.6-flash | MiMo 快模型 ID（Profile: mimo-v2.6-flash） |
| FORGE_MIMO_PRO_MODEL | mimo-v2.6-pro | MiMo Pro 模型 ID（Profile: mimo-v2.6-pro） |
| FORGE_DEEPSEEK_MODEL | deepseek-flash | DeepSeek 快模型 ID（Profile: deepseek-flash） |
| FORGE_DEEPSEEK_PRO_MODEL | deepseek-v4-pro | DeepSeek Pro 模型 ID（Profile: deepseek-pro） |
| FORGE_DEEPSEEK_THINKING | 0 | 1/true 开启 DeepSeek thinking（更耗 token） |

## 内置模型 Profile

| Profile | 实际模型 | 渠道 | 说明 |
|---|---|---|---|
| `mimo-v2.6-flash` | `mimo-v2.6-flash` | 小米 MiMo | 默认；速度快，支持图像输入 |
| `mimo-v2.6-pro` | `mimo-v2.6-pro` | 小米 MiMo | 强模型；失败回退 flash |
| `deepseek-flash` | `deepseek-flash` | DeepSeek | 速度/成本优先 |
| `deepseek-pro` | `deepseek-v4-pro` | DeepSeek | 更强推理；失败回退 flash |
| `glm-5.3-flash` | `glm-5.3-flash` | 智谱 GLM Coding Plan | 快模型 |
| `glm-5.3` | `glm-5.3` | 智谱 GLM Coding Plan | 强模型 |

只展示已配置 Key 的真实渠道；配置了 MiMo Key 时默认使用 `mimo-v2.6-flash`，多个渠道都配置时可在前端模型选择器中即时切换。
`mock` 仅保留给零密钥自测/离线演示，不在模型选择器展示，也不作为真实模型的自动降级目标。
