# v1/api/main.py
"""
AI助理 API 入口。

装配顺序：
1. lifespan：初始化内核（存储/事件/运行时）→ 装载插件（register → on_start）→ 挂载插件路由
2. 挂载内核路由（system / sessions / ws / plugins）
3. 静态托管 web/dist（单端口部署）：必须在所有 API 路由之后挂载，避免屏蔽动态路由

设计纪律：main.py 只负责装配；业务能力全部在插件里。
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.routing import Mount

from configs.configs import APP_NAME, APP_TITLE, APP_VERSION, HOST, PORT
from core.harness import init_harness
from extensions import fs as fs_ext
from extensions import plugins as plugins_ext
from extensions import sessions as sessions_ext
from extensions import system as system_ext
from extensions import ws as ws_ext
from plugins.manager import PluginManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("forge")

_plugin_manager: PluginManager | None = None

DIST_DIR = Path(__file__).resolve().parent.parent / "web" / "dist"


def get_plugin_manager() -> PluginManager | None:
    return _plugin_manager


def _mount_static() -> None:
    """静态托管前端构建产物；必须在所有 API 路由之后（重复调用幂等）。"""
    existing = getattr(app.state, "_static_mount", None)
    if existing is not None:
        return
    if DIST_DIR.exists():
        mount = Mount("/", app=StaticFiles(directory=str(DIST_DIR), html=True), name="web")
        app.router.routes.append(mount)
        app.state._static_mount = mount


def mount_router_live(router) -> None:
    """运行时启用插件时动态挂载其路由：先摘静态托管再补回，保证 API 路由优先。"""
    existing = getattr(app.state, "_static_mount", None)
    if existing is not None:
        app.router.routes.remove(existing)
        app.state._static_mount = None
    app.include_router(router)
    _mount_static()


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _plugin_manager
    harness = await init_harness()
    _plugin_manager = PluginManager(harness)
    plugin_routers = _plugin_manager.load_all()
    for router in plugin_routers:
        app.include_router(router)
    await _plugin_manager.start_all()
    _mount_static()
    logger.info("AI助理 就绪：%d 个工具，%d 个插件", len(harness.tools.list_specs()), len(_plugin_manager.contexts))
    yield
    await _plugin_manager.stop_all()


app = FastAPI(title=APP_TITLE, version=APP_VERSION, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 内核路由（模块级挂载，先于插件与静态托管）
app.include_router(system_ext.router)
app.include_router(sessions_ext.router)
app.include_router(ws_ext.router)
app.include_router(plugins_ext.router)
app.include_router(fs_ext.router)


@app.get("/api/info")
async def info():
    """服务信息（首页 / 由前端静态托管接管，html=True 返回 web/dist/index.html）。"""
    return {
        "code": 200,
        "name": APP_NAME,
        "title": APP_TITLE,
        "version": APP_VERSION,
        "docs": "/docs",
        "ws": "/ws",
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host=HOST, port=PORT, reload=False)
