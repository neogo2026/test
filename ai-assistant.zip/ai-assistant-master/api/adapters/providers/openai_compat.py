# v1/api/adapters/providers/openai_compat.py
"""
通用 OpenAI 兼容 Provider。

一个适配器覆盖所有 OpenAI 协议渠道：DeepSeek / 智谱GLM / OpenAI / vLLM / Ollama…
差异全部收敛到 ModelProfile（base_url + api_key_env + model）。
只关心供应商协议，不关心业务与 Agent 语义。
"""

from __future__ import annotations

import json
from typing import Any, Awaitable, Callable

import httpx

from configs import secrets
from core.contracts import ModelProfile, ModelResponse, ToolCall

DeltaCallback = Callable[[str], Awaitable[None]] | None


class OpenAICompatProvider:
    name = "openai"

    async def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        profile: ModelProfile,
        on_delta: DeltaCallback = None,
    ) -> ModelResponse:
        api_key = secrets.get_secret(profile.api_key_env or "") if profile.api_key_env else ""
        if not api_key:
            raise RuntimeError(f"未配置 {profile.api_key_env}，无法调用 {profile.name}")

        base_url = (profile.base_url or "https://api.deepseek.com").rstrip("/")
        payload: dict[str, Any] = {
            "model": profile.model,
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": min(profile.max_output, 8192),
        }
        if profile.extra_body:
            payload.update(profile.extra_body)
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        use_stream = bool(profile.stream and on_delta)
        if use_stream:
            payload["stream"] = True
            payload["stream_options"] = {"include_usage": True}
            return await self._stream(base_url, payload, headers, profile, on_delta)  # type: ignore[arg-type]
        return await self._non_stream(base_url, payload, headers, profile)

    async def _non_stream(
        self,
        base_url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        profile: ModelProfile,
    ) -> ModelResponse:
        async with httpx.AsyncClient(timeout=profile.timeout_s) as client:
            response = await client.post(f"{base_url}/chat/completions", json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()
        choice = (data.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        return ModelResponse(
            text=str(message.get("content") or ""),
            reasoning=str(message.get("reasoning_content") or ""),
            tool_calls=self._parse_tool_calls(message.get("tool_calls") or []),
            usage=data.get("usage") or {},
            finish_reason=choice.get("finish_reason") or "stop",
            raw=data,
            model=data.get("model") or profile.model,
        )

    async def _stream(
        self,
        base_url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        profile: ModelProfile,
        on_delta: Callable[[str], Awaitable[None]],
    ) -> ModelResponse:
        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_buffers: dict[int, dict[str, Any]] = {}
        finish_reason = "stop"
        usage: dict[str, Any] = {}

        async with httpx.AsyncClient(timeout=profile.timeout_s) as client:
            async with client.stream(
                "POST", f"{base_url}/chat/completions", json=payload, headers=headers
            ) as response:
                if response.status_code >= 400:
                    raw = await response.aread()
                    raise RuntimeError(
                        f"HTTP {response.status_code}: {raw.decode('utf-8', 'replace')[:800]}"
                    )
                async for line in response.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data_str = line[5:].strip()
                    if data_str == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    if chunk.get("usage"):
                        usage = chunk["usage"]
                    choices = chunk.get("choices") or []
                    if not choices:
                        continue
                    choice = choices[0]
                    finish_reason = choice.get("finish_reason") or finish_reason
                    delta = choice.get("delta") or {}
                    reasoning = delta.get("reasoning_content")
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    content = delta.get("content")
                    if content:
                        text_parts.append(content)
                        await on_delta(content)
                    # 部分渠道（如 DeepSeek 思考模式）返回 reasoning_content，忽略不回传
                    for item in delta.get("tool_calls") or []:
                        index = int(item.get("index", 0))
                        buf = tool_buffers.setdefault(index, {"id": "", "name": "", "arguments": ""})
                        if item.get("id"):
                            buf["id"] = item["id"]
                        function = item.get("function") or {}
                        if function.get("name"):
                            buf["name"] += function["name"]
                        if function.get("arguments"):
                            buf["arguments"] += function["arguments"]

        calls = []
        for index in sorted(tool_buffers):
            buf = tool_buffers[index]
            if not buf["name"]:
                continue
            calls.append(
                ToolCall(
                    call_id=buf["id"] or f"call_{index}",
                    name=buf["name"],
                    arguments=self._loads_args(buf["arguments"]),
                )
            )
        return ModelResponse(
            text="".join(text_parts),
            reasoning="".join(reasoning_parts),
            tool_calls=calls,
            usage=usage,
            finish_reason=finish_reason,
            model=profile.model,
        )

    @staticmethod
    def _parse_tool_calls(items: list[dict[str, Any]]) -> list[ToolCall]:
        calls = []
        for index, item in enumerate(items):
            function = item.get("function") or {}
            calls.append(
                ToolCall(
                    call_id=item.get("id") or f"call_{index}",
                    name=function.get("name") or "",
                    arguments=OpenAICompatProvider._loads_args(function.get("arguments") or "{}"),
                )
            )
        return calls

    @staticmethod
    def _loads_args(raw: str | dict[str, Any]) -> dict[str, Any]:
        if isinstance(raw, dict):
            return raw
        try:
            value = json.loads(raw or "{}")
            return value if isinstance(value, dict) else {"value": value}
        except json.JSONDecodeError:
            return {"_parse_error": True, "_raw": raw}
