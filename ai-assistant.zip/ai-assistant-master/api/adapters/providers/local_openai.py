"""
本地 OpenAI 兼容 Provider（无 Key / 本地免鉴权）。

用于接入本地部署的 Qwen3.5-2B-RSI 服务（:9065/v1）或其他无需鉴权的
OpenAI 兼容端点。与 OpenAICompatProvider 的差异只有鉴权：默认发送
`Authorization: Bearer local`，可用 LOCAL_LLM_API_KEY 覆盖。
"""

from __future__ import annotations

import os

from adapters.providers.openai_compat import OpenAICompatProvider
from core.contracts import ModelProfile


class LocalOpenAIProvider(OpenAICompatProvider):
    name = "local"

    async def complete(self, messages, tools, profile: ModelProfile, on_delta=None):
        key = os.getenv("LOCAL_LLM_API_KEY", "").strip() or "local"
        os.environ["LOCAL_LLM_API_KEY_EFFECTIVE"] = key
        local_profile = profile.model_copy(update={"api_key_env": "LOCAL_LLM_API_KEY_EFFECTIVE"})
        return await super().complete(messages, tools, local_profile, on_delta)
