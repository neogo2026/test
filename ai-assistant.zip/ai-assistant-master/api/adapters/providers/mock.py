# v1/api/adapters/providers/mock.py
"""
确定性 Mock Provider。

- 无 API Key 时跑通完整链路（自测 / 演示 / 回归）
- 不是「假回答」：按用户意图触发真实工具调用（含审批流）

自测触发词：计算 / 写文件 / 读取 / 列目录 / 搜索 / 执行 / shell / 现在几点
"""

from __future__ import annotations

import re
from typing import Any, Awaitable, Callable

from core.contracts import ModelProfile, ModelResponse, ToolCall

DeltaCallback = Callable[[str], Awaitable[None]] | None


class MockProvider:
    name = "mock"

    async def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        profile: ModelProfile,
        on_delta: DeltaCallback = None,
    ) -> ModelResponse:
        names = {
            (tool.get("function") or {}).get("name")
            for tool in tools
            if isinstance(tool, dict)
        }
        # 工具观察后：直接总结收尾
        last = messages[-1] if messages else {}
        if last.get("role") == "tool":
            content = str(last.get("content") or "")
            text = f"工具执行完成。结果：{content[:400]}"
            await self._emit(text, on_delta)
            return self._done(profile, text)

        user_text = ""
        for message in reversed(messages):
            if message.get("role") == "user":
                user_text = str(message.get("content") or "")
                break

        call = self._decide(user_text, names)
        if call:
            preamble = f"我将调用 {call.name} 工具。"
            await self._emit(preamble, on_delta)
            return ModelResponse(
                text=preamble,
                tool_calls=[call],
                finish_reason="tool_calls",
                model=profile.model,
                usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            )

        text = (
            f"（mock 模式）已收到：{user_text}\n"
            "未触发工具调用。可试试：计算 3+4 · 列出目录 · 写文件 hello.txt · 搜索 pattern · shell echo ok。"
            "配置 LLM API Key 后将切换为真实模型。"
        )
        await self._emit(text, on_delta)
        return self._done(profile, text)

    @staticmethod
    def _done(profile: ModelProfile, text: str) -> ModelResponse:
        return ModelResponse(
            text=text,
            finish_reason="stop",
            model=profile.model,
            usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        )

    def _decide(self, text: str, names: set) -> ToolCall | None:
        lowered = text.lower()

        if ("计算" in text or "算一下" in text or "calculate" in lowered) and "calculator" in names:
            match = re.search(r"([0-9][0-9\s+\-*/().%]*[0-9]|[0-9])", text)
            expression = match.group(1).strip() if match else "1+1"
            return ToolCall(call_id="call_calc", name="calculator", arguments={"expression": expression})
        if ("写文件" in text or "保存文件" in text or "创建文件" in text) and "write_file" in names:
            match = re.search(r"[\w./-]+\.\w+", text)
            path = match.group(0) if match else "notes/demo.txt"
            return ToolCall(
                call_id="call_write",
                name="write_file",
                arguments={"path": path, "content": "AI助理 mock write.\n"},
            )
        if ("读取" in text or "读文件" in text) and "read_file" in names:
            match = re.search(r"[\w./-]+\.\w+", text)
            return ToolCall(call_id="call_read", name="read_file", arguments={"path": match.group(0) if match else "notes/demo.txt"})
        if ("搜索" in text or "查找" in text or "grep" in lowered) and "grep" in names:
            match = re.search(r"搜索\s+(\S+)|查找\s+(\S+)", text)
            pattern = (match.group(1) or match.group(2)) if match else "def"
            return ToolCall(call_id="call_grep", name="grep", arguments={"pattern": pattern, "path": "."})
        if ("列目录" in text or "列出" in text or "list" in lowered) and "list_dir" in names:
            return ToolCall(call_id="call_list", name="list_dir", arguments={"path": "."})
        if ("shell" in lowered or "命令行" in text or "执行命令" in text) and "run_shell" in names:
            for sep in ("shell", "shell：", "shell:", "命令行", "执行命令"):
                if sep in lowered and sep in text.lower():
                    cmd = text.lower().split(sep, 1)[1].strip(" ：:")
                    return ToolCall(call_id="call_shell", name="run_shell",
                                    arguments={"command": cmd or "echo forge-ok"})
            return ToolCall(call_id="call_shell", name="run_shell", arguments={"command": "echo forge-ok"})
        if ("执行" in text and ("python" in lowered or "代码" in text)) and "run_python" in names:
            return ToolCall(call_id="call_python", name="run_python", arguments={"code": "print('sandbox-ok')"})
        if "echo" in lowered and "echo" in names:
            value = text.split("echo", 1)[-1].strip(" ：:") or "hello forge"
            return ToolCall(call_id="call_echo", name="echo", arguments={"text": value})
        if ("时间" in text or "几点" in text or "现在" in text) and "now" in names:
            return ToolCall(call_id="call_now", name="now", arguments={})
        return None

    @staticmethod
    async def _emit(text: str, on_delta: DeltaCallback) -> None:
        if not on_delta:
            return
        chunks = [text[i : i + 24] for i in range(0, len(text), 24)] or [""]
        for chunk in chunks:
            await on_delta(chunk)
