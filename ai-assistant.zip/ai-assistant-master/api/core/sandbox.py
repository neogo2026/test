# v1/api/core/sandbox.py
"""
工作区沙箱：所有路径必须落在 workspace 根目录内，防止 ../ 越界。
"""

from __future__ import annotations

from pathlib import Path


class WorkspaceError(Exception):
    """工作区路径或文件操作异常。"""


class SafeWorkspace:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def resolve(self, relative_path: str | None) -> Path:
        raw = (relative_path or ".").strip()
        candidate = Path(raw)
        if candidate.is_absolute():
            raise WorkspaceError("不允许使用绝对路径")
        target = (self.root / candidate).resolve()
        if target != self.root and self.root not in target.parents:
            raise WorkspaceError("路径越界：必须位于 workspace 内")
        return target

    def read_text(self, relative_path: str, max_chars: int = 400_000) -> str:
        target = self.resolve(relative_path)
        if not target.exists():
            raise WorkspaceError(f"文件不存在: {relative_path}")
        if not target.is_file():
            raise WorkspaceError(f"不是文件: {relative_path}")
        text = target.read_text(encoding="utf-8", errors="replace")
        if len(text) > max_chars:
            return text[:max_chars] + f"\n... [已截断，原始长度 {len(text)} 字符]"
        return text

    def write_text(self, relative_path: str, content: str) -> Path:
        target = self.resolve(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target

    def list_dir(self, relative_path: str | None = None) -> list[dict[str, object]]:
        target = self.resolve(relative_path)
        if not target.exists():
            raise WorkspaceError(f"目录不存在: {relative_path or '.'}")
        if not target.is_dir():
            raise WorkspaceError(f"不是目录: {relative_path or '.'}")
        items = []
        for child in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            try:
                size = child.stat().st_size if child.is_file() else 0
            except OSError:
                size = 0
            items.append({"name": child.name, "type": "dir" if child.is_dir() else "file", "size": size})
        return items
