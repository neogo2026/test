# v1/api/core/events.py
"""
事件服务 + 实时事件总线。

纪律（承接上一代 AI助理 V0.01 防卡死设计 + agent-harness 事件溯源）：
- 事实源：重要事件落 events 表（append-only，按 run 严格递增序号）
- 实时流：model.delta 等高频事件只广播不落库（最终 assistant 消息会持久化，回放仍完整）
- 广播永不阻塞 Agent 主循环：每客户端内存队列 put_nowait，慢客户端只丢自己的帧
- 旁路订阅者（飞书回传 / 用量记账）：异步派发，异常不影响主流程
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

from core.contracts import Event
from core.storage import Storage, utc_now

logger = logging.getLogger(__name__)

# 只广播不落库的高频事件类型
TRANSIENT_EVENTS = {"model.delta"}

# 旁路订阅者签名：fn(session_id, event_type, payload) -> coroutine
EventSink = Callable[[str, str, dict], Awaitable[None]]


class EventBus:
    """WebSocket 客户端注册表 + 非阻塞广播。"""

    def __init__(self, queue_max: int = 2000):
        self._clients: dict[int, tuple[asyncio.Queue, asyncio.Task]] = {}
        self._next_key = 0
        self._queue_max = queue_max
        self._sinks: list[EventSink] = []

    def subscribe_sink(self, fn: EventSink) -> None:
        if fn not in self._sinks:
            self._sinks.append(fn)

    def unsubscribe_sink(self, fn: EventSink) -> None:
        """插件停用时摘除事件订阅，保证关闭后完全回到 baseline。"""
        try:
            self._sinks.remove(fn)
        except ValueError:
            pass

    def register_client(self, send_text: Callable[[str], Awaitable[None]]) -> int:
        """注册一个客户端（send_text 协程），返回句柄 key。"""
        self._next_key += 1
        key = self._next_key
        queue: asyncio.Queue = asyncio.Queue(maxsize=self._queue_max)
        task = asyncio.create_task(self._sender(key, send_text, queue))
        self._clients[key] = (queue, task)
        return key

    def unregister_client(self, key: int) -> None:
        entry = self._clients.pop(key, None)
        if entry:
            entry[1].cancel()

    async def _sender(self, key: int, send_text: Callable[[str], Awaitable[None]], queue: asyncio.Queue) -> None:
        try:
            while True:
                frame = await queue.get()
                try:
                    await asyncio.wait_for(send_text(frame), timeout=10)
                except asyncio.CancelledError:
                    raise
                except Exception:
                    break
        except asyncio.CancelledError:
            raise
        finally:
            self._clients.pop(key, None)

    def publish(self, session_id: str, event_type: str, payload: dict[str, Any]) -> None:
        """非阻塞广播：只入队，任何客户端都不会阻塞调用方。"""
        if not self._clients:
            self._dispatch_sinks(session_id, event_type, payload)
            return
        frame = json.dumps(
            {"session_id": session_id, "event": event_type, "payload": payload, "time": utc_now()},
            ensure_ascii=False,
        )
        dead: list[int] = []
        for key, (queue, _task) in list(self._clients.items()):
            try:
                queue.put_nowait(frame)
            except asyncio.QueueFull:
                dead.append(key)
        for key in dead:
            self.unregister_client(key)
        self._dispatch_sinks(session_id, event_type, payload)

    def _dispatch_sinks(self, session_id: str, event_type: str, payload: dict[str, Any]) -> None:
        if not self._sinks:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        for fn in list(self._sinks):
            loop.create_task(self._safe_sink(fn, session_id, event_type, payload))

    @staticmethod
    async def _safe_sink(fn: EventSink, session_id: str, event_type: str, payload: dict[str, Any]) -> None:
        try:
            await fn(session_id, event_type, payload)
        except Exception:  # noqa: BLE001 - 订阅者异常不影响主流程
            logger.exception("事件订阅者执行失败")


class EventService:
    def __init__(self, storage: Storage):
        self.storage = storage
        self.bus = EventBus()

    async def append(
        self,
        run_id: str,
        session_id: str,
        tenant_id: str,
        trace_id: str,
        event_type: str,
        payload: dict[str, Any] | None = None,
        step_id: str | None = None,
    ) -> Event:
        payload = payload or {}
        # 旁路订阅者需要 run_id 才能把事件归并成 episode；落库 payload 保持原样。
        sink_payload = dict(payload)
        sink_payload.setdefault("_run_id", run_id)
        sink_payload.setdefault("_session_id", session_id)
        # 实时广播（含旁路订阅者）：永远执行，绝不等慢客户端
        self.bus.publish(session_id, event_type, sink_payload)
        # 高频 token 事件不落库，防止 SQLite 写放大
        if event_type in TRANSIENT_EVENTS:
            from core.contracts import Event as _E

            return _E(
                event_id="",
                tenant_id=tenant_id,
                session_id=session_id,
                run_id=run_id,
                seq=0,
                type=event_type,
                step_id=step_id,
                payload=payload,
                trace_id=trace_id,
                created_at=utc_now(),
            )
        return await self.storage.append_event(
            run_id=run_id,
            session_id=session_id,
            tenant_id=tenant_id,
            trace_id=trace_id,
            event_type=event_type,
            payload=payload,
            step_id=step_id,
        )

    async def list_run_events(self, run_id: str, after_seq: int = 0) -> list[dict[str, Any]]:
        return await self.storage.list_events(run_id, after_seq=after_seq)

    async def list_session_events(self, session_id: str, after_id: int = 0) -> list[dict[str, Any]]:
        return await self.storage.list_session_events(session_id, after_id=after_id)
