# v1/api/core/context.py
"""
上下文构建与压缩。

分层：
1. 系统层：Agent 指令 + 运行时约束 + 工作区信息
2. Skill 层：按用户输入命中的方法论摘要（由 skills 插件注入检索函数）
3. 对话层：近期消息
4. 工具观察层：tool 消息

压缩：超预算时保留系统消息 + 最近消息，更早的压成摘要（原文仍在消息库，可回放）。
"""

from __future__ import annotations

import inspect
import json
from typing import Any, Callable

from configs.models import get_profile
from core.contracts import AgentSpec
from core.storage import Storage

SkillSearchFn = Callable[[str, int], list[Any]]
ContextProviderFn = Callable[..., Any]

# 历史上下文压缩：最近若干条消息保持原样，更早的大体积工具参数/结果只保留预览。
KEEP_RECENT_MESSAGES = 10
MAX_TOOL_CHARS = 3000
MAX_ASSISTANT_CHARS = 4000
MAX_ARG_CHARS = 1200


def estimate_tokens(text: str) -> int:
    """粗略 token 估算：中文 1 字 ≈ 0.6 token，英文 4 字符 ≈ 1 token。"""
    if not text:
        return 0
    chinese = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    other = len(text) - chinese
    return max(1, int(chinese * 0.6 + other / 4))


class ContextBuilder:
    def __init__(self, storage: Storage):
        self.storage = storage
        self._skill_search: SkillSearchFn | None = None
        # 上下文 provider 链：技能、RSI 记忆、项目约束、组织规范……
        self._providers: list[tuple[int, str, ContextProviderFn]] = []

    def set_skill_provider(self, fn: SkillSearchFn) -> None:
        """由 skills 插件注入检索函数；内核不直接依赖技能实现。"""
        self._skill_search = fn

    def add_context_provider(self, name: str, fn: ContextProviderFn, priority: int = 100) -> None:
        """注册上下文 provider（数字越小越先注入）。插件可返回 str / dict / list。"""
        self.remove_context_provider(name)
        self._providers.append((priority, name, fn))
        self._providers.sort(key=lambda item: item[0])

    def remove_context_provider(self, name: str) -> None:
        self._providers = [item for item in self._providers if item[1] != name]

    async def _provider_snippets(
        self, agent: AgentSpec, session_id: str, user_input: str, model_profile: str | None
    ) -> list[str]:
        snippets: list[str] = []
        for _priority, _name, fn in list(self._providers):
            try:
                result = fn(agent, session_id, user_input, model_profile)
                if inspect.isawaitable(result):
                    result = await result
                if not result:
                    continue
                if isinstance(result, str):
                    snippets.append(result)
                elif isinstance(result, dict):
                    text = result.get("content") or result.get("text")
                    if text:
                        snippets.append(str(text))
                elif isinstance(result, (list, tuple)):
                    snippets.extend(str(item) for item in result if item)
            except Exception:  # noqa: BLE001 - provider 异常不能污染主循环
                continue
        return snippets

    async def build(
        self,
        agent: AgentSpec,
        session_id: str,
        user_input: str,
        workspace_hint: str = "",
        model_profile: str | None = None,
    ) -> list[dict[str, Any]]:
        rows = await self.storage.list_messages(session_id)
        messages: list[dict[str, Any]] = [
            {
                "role": "system",
                "content": self._system_prompt(agent, workspace_hint, model_profile),
            }
        ]

        if agent.auto_skills and self._skill_search:
            matched = self._skill_search(user_input, limit=2)
            if matched:
                summaries = []
                for skill in matched:
                    summary = getattr(skill, "summary", None)
                    summaries.append(summary() if callable(summary) else str(skill))
                messages.append(
                    {
                        "role": "system",
                        "content": "以下是可能相关的方法论 Skill，请按需遵循，不要照搬无关内容：\n\n"
                        + "\n\n".join(summaries),
                    }
                )

        snippets = await self._provider_snippets(agent, session_id, user_input, model_profile)
        if snippets:
            messages.append(
                {
                    "role": "system",
                    "content": "以下是进化层注入的可复用经验与约束（按相关性检索，冲突时以用户最新指令为准）：\n\n"
                    + "\n\n".join(snippets),
                }
            )

        converted = [self._to_provider_message(row) for row in rows]
        converted = self._compact_history(converted)
        messages.extend(self._compress(converted, agent.max_context_tokens))
        return messages

    @staticmethod
    def _preview(text: str, limit: int) -> str:
        if len(text) <= limit:
            return text
        head = limit // 2
        tail = min(200, limit // 4)
        omitted = len(text) - head - tail
        return (
            text[:head]
            + f"\n...<已省略 {omitted} 字符；完整内容已落盘，可用 read_file 查看>...\n"
            + text[-tail:]
        )

    @classmethod
    def _compact_value(cls, value: Any) -> Any:
        if isinstance(value, str):
            return cls._preview(value, MAX_ARG_CHARS)
        if isinstance(value, dict):
            return {key: cls._compact_value(val) for key, val in value.items()}
        if isinstance(value, list):
            return [cls._compact_value(item) for item in value]
        return value

    @classmethod
    def _compact_arguments(cls, arguments: Any) -> str:
        try:
            data = json.loads(arguments) if isinstance(arguments, str) else arguments
        except (TypeError, json.JSONDecodeError):
            text = str(arguments or "")
            return cls._preview(text, MAX_ARG_CHARS)
        return json.dumps(cls._compact_value(data), ensure_ascii=False)

    @classmethod
    def _compact_history(cls, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """最近消息不压缩；更早的大体积工具参数/结果仅保留预览，控制上下文成本。"""
        if len(messages) <= KEEP_RECENT_MESSAGES:
            return messages
        cut = len(messages) - KEEP_RECENT_MESSAGES
        out: list[dict[str, Any]] = []
        for index, message in enumerate(messages):
            if index >= cut:
                out.append(message)
                continue
            item = dict(message)
            if item.get("role") == "assistant":
                if item.get("tool_calls"):
                    item["tool_calls"] = [
                        {
                            **call,
                            "function": {
                                **call.get("function", {}),
                                "arguments": cls._compact_arguments(
                                    (call.get("function") or {}).get("arguments")
                                ),
                            },
                        }
                        for call in item["tool_calls"]
                    ]
                content = item.get("content")
                if isinstance(content, str) and len(content) > MAX_ASSISTANT_CHARS:
                    item["content"] = cls._preview(content, MAX_ASSISTANT_CHARS)
            elif item.get("role") == "tool":
                content = item.get("content")
                if isinstance(content, str) and len(content) > MAX_TOOL_CHARS:
                    item["content"] = cls._preview(content, MAX_TOOL_CHARS)
            out.append(item)
        return out

    @staticmethod
    def _system_prompt(agent: AgentSpec, workspace_hint: str = "", model_profile: str | None = None) -> str:
        lines = [
            f"你是 {agent.title}（{agent.name}），一个专业可靠的 AI 工程师。",
            agent.instructions,
            "",
            "运行时约束：",
            "- 需要外部信息或执行动作时，优先调用提供的工具，不要编造工具结果。",
            "- 工具返回失败时，阅读错误原因，必要时调整参数或向用户说明。",
            "- 修改文件、执行命令等高风险动作会触发人工审批；在审批完成前不要假设动作已执行。",
            "- 最终回答要简洁：已完成什么、验证了什么、还有什么风险。",
        ]
        if workspace_hint:
            lines.append(f"- 当前工作区：{workspace_hint}")
        # 身份锚定：只注入运行时接入的端点（来自 profile 配置，不写死型号），
        # 由模型结合端点与自身权重自行判断身份，避免长 agent 转录下误认成其他厂商。
        base_url = ""
        if model_profile:
            base_url = get_profile(model_profile).base_url or ""
        if base_url:
            lines.append(
                f"- 接入信息：当前 LLM API 端点为 {base_url}；"
                "被问及身份时，基于该接入信息与你对自身权重的认知如实回答，"
                "不要套用其他厂商身份，不要编造。"
            )
        return "\n".join(lines)

    @staticmethod
    def _to_provider_message(row: dict[str, Any]) -> dict[str, Any]:
        role = row["role"]
        content = row.get("content") or ""
        if role == "assistant":
            message: dict[str, Any] = {"role": "assistant", "content": content or None}
            if row.get("reasoning"):
                message["reasoning_content"] = row["reasoning"]
            if not row.get("tool_calls"):
                message["content"] = content
                return message
            message["tool_calls"] = [
                {
                    "id": call["call_id"],
                    "type": "function",
                    "function": {
                        "name": call["name"],
                        "arguments": json.dumps(call.get("arguments") or {}, ensure_ascii=False),
                    },
                }
                for call in row["tool_calls"]
            ]
            return message
        if role == "tool":
            return {
                "role": "tool",
                "tool_call_id": row.get("tool_call_id") or "",
                "content": content,
            }
        return {"role": role, "content": content}

    @staticmethod
    def _message_tokens(message: dict[str, Any]) -> int:
        total = estimate_tokens(str(message.get("content") or ""))
        for call in message.get("tool_calls") or []:
            total += estimate_tokens(str((call.get("function") or {}).get("arguments") or ""))
        return total

    def _compress(self, messages: list[dict[str, Any]], budget: int) -> list[dict[str, Any]]:
        total = sum(self._message_tokens(m) for m in messages)
        if total <= budget or len(messages) <= 12:
            return messages

        keep = messages[-20:]
        older = messages[:-20]
        summary_lines = []
        for message in older[-24:]:
            content = str(message.get("content") or "").replace("\n", " ")[:160]
            if content:
                summary_lines.append(f"- {message.get('role')}: {content}")
        summary = "早期对话摘要（原文仍保存在消息库，可回放）：\n" + "\n".join(summary_lines)

        # 去掉开头孤立的 tool 消息，避免缺少对应的 assistant tool_calls
        while keep and keep[0].get("role") == "tool":
            keep.pop(0)

        return [{"role": "system", "content": summary}] + keep
