# v1/api/core/gateway.py
"""
模型网关。

- 按 Profile 选择 provider（插件可通过 ctx.register_provider 扩展）
- 主模型失败时沿 fallback 链降级
- 把供应商差异关在适配器内
"""

from __future__ import annotations

import inspect
import logging
import asyncio
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

from adapters.providers.local_openai import LocalOpenAIProvider
from adapters.providers.mock import MockProvider
from adapters.providers.openai_compat import OpenAICompatProvider
from configs.models import MODEL_PROFILES, get_profile
from core.contracts import ModelProfile, ModelResponse

DeltaCallback = Callable[[str], Awaitable[None]] | None


class ModelGateway:
    def __init__(self):
        self.providers: dict[str, Any] = {
            "mock": MockProvider(),
            "openai": OpenAICompatProvider(),
            "local": LocalOpenAIProvider(),
        }
        # ??????RSI ??????????? / ?? / ???????
        self._model_middleware: list[tuple[str, Any, Any]] = []

    def register_model_middleware(self, name: str, before: Any = None, after: Any = None) -> None:
        self.remove_model_middleware(name)
        if before or after:
            self._model_middleware.append((name, before, after))

    def remove_model_middleware(self, name: str) -> None:
        self._model_middleware = [item for item in self._model_middleware if item[0] != name]

    def register_provider(self, name: str, provider: Any) -> None:
        self.providers[name] = provider

    def register_profile(self, profile: ModelProfile) -> None:
        MODEL_PROFILES[profile.name] = profile

    async def complete(
        self,
        profile_name: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        on_delta: DeltaCallback = None,
    ) -> ModelResponse:
        profile = get_profile(profile_name)
        messages = await self._run_before_model(profile_name, messages, tools)
        result = await self._try_profile(profile, messages, tools, on_delta)
        if result is not None:
            result = await self._run_after_model(profile_name, messages, result)
        if result is not None:
            return result

        fallbacks: list[str] = []
        last_error: Exception | None = None
        for name in profile.fallback:
            fallback = MODEL_PROFILES.get(name)
            if not fallback:
                continue
            fallbacks.append(name)
            try:
                fb_messages = await self._run_before_model(fallback.name, messages, tools)
                result = await self._try_profile(fallback, fb_messages, tools, on_delta)
                if result is not None:
                    result.fallbacks = fallbacks
                    result = await self._run_after_model(fallback.name, fb_messages, result)
                    return result
            except Exception as exc:  # noqa: BLE001 - fallback 需要吞掉主错误
                last_error = exc
        if last_error:
            raise last_error
        raise RuntimeError(f"模型 {profile_name} 调用失败，且没有可用 fallback")

    async def _try_profile(
        self,
        profile: ModelProfile,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        on_delta: DeltaCallback,
    ) -> ModelResponse | None:
        provider = self.providers.get(profile.provider)
        if not provider:
            raise RuntimeError(f"未知 provider: {profile.provider}")
        attempts = 3
        last_exc: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                return await provider.complete(messages, tools, profile, on_delta)
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if attempt < attempts and self._is_transient(exc):
                    logger.warning("模型 %s 瞬时失败（第 %d 次），重试：%s", profile.name, attempt, exc)
                    await asyncio.sleep(1.2 * attempt)
                    continue
                logger.warning("模型 %s 调用失败：%s: %s | body=%s", profile.name, type(exc).__name__, exc, (getattr(getattr(exc, "response", None), "text", "") or "")[:600])
                if profile.fallback:
                    return None
                raise
        if last_exc:
            raise last_exc
        return None

    async def _run_before_model(
        self, profile_name: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        current = messages
        for _name, before, _after in list(self._model_middleware):
            if not before:
                continue
            try:
                outcome = before(profile_name, current, tools)
                if inspect.isawaitable(outcome):
                    outcome = await outcome
                if isinstance(outcome, list):
                    current = outcome
                elif isinstance(outcome, dict) and isinstance(outcome.get("messages"), list):
                    current = outcome["messages"]
            except Exception:  # noqa: BLE001 - ???????????
                logger.exception("???????????")
        return current

    async def _run_after_model(self, profile_name: str, messages: list[dict[str, Any]], response: Any) -> Any:
        current = response
        for _name, _before, after in list(self._model_middleware):
            if not after:
                continue
            try:
                outcome = after(profile_name, messages, current)
                if inspect.isawaitable(outcome):
                    outcome = await outcome
                if outcome is not None:
                    current = outcome
            except Exception:  # noqa: BLE001
                logger.exception("???????????")
        return current

    @staticmethod
    def _is_transient(exc: Exception) -> bool:
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if isinstance(status, int) and (status == 429 or status >= 500):
            return True
        name = type(exc).__name__.lower()
        return any(k in name for k in ("timeout", "connection", "connect"))
