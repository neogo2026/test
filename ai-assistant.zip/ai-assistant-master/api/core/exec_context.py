# v1/api/core/exec_context.py
"""
执行上下文（ContextVar）。

工具 handler 在注册表层面是全局的，但每个会话有独立工作区/配置。
Runtime 在执行工具前把会话上下文写入 ContextVar；
asyncio.to_thread 会自动拷贝上下文，线程内同样可读。
"""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ExecContext:
    session_id: str = ""
    run_id: str = ""
    workspace_dir: str = ""
    gate_mode: str = "ask"
    extras: dict[str, Any] = field(default_factory=dict)

    def workspace_root(self) -> Path:
        return Path(self.workspace_dir) if self.workspace_dir else Path(".").resolve()


_current: ContextVar[ExecContext | None] = ContextVar("forge_exec_context", default=None)


def set_context(ctx: ExecContext) -> Any:
    return _current.set(ctx)


def reset_context(token: Any) -> None:
    _current.reset(token)


def current_context() -> ExecContext:
    ctx = _current.get()
    return ctx if ctx else ExecContext()
