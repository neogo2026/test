# v1/api/core/agents.py
"""
Agent 注册表。

内核只内置最小 Agent；主力 Agent（coder）由 dev-tools 插件注册——
体现「harness 即插件」的设计：能力组合而不是内核硬编码。
插件通过 ctx.register_agent() 扩展。
"""

from __future__ import annotations

from configs.configs import MAX_CONTEXT_TOKENS, MAX_STEPS
from configs.models import DEFAULT_MODEL_PROFILE
from core.contracts import AgentSpec

AGENTS: dict[str, AgentSpec] = {
    "assistant": AgentSpec(
        name="assistant",
        title="通用助理",
        description="面向日常问答与轻量工具调用的通用 Agent。",
        instructions=(
            "你是一个可靠的 AI 助理。先理解目标，再选择最小必要的工具。"
            "涉及写入、执行命令等高风险动作时，等待系统审批；不要假设审批一定通过。"
            "回答时给出结论、验证证据和残余风险。"
        ),
        model_profile=DEFAULT_MODEL_PROFILE,
        tools=["echo", "calculator", "now"],
        max_steps=8,
        max_context_tokens=16_000,
        auto_skills=True,
    ),
}


def register_agent(spec: AgentSpec) -> None:
    AGENTS[spec.name] = spec


def unregister_agent(name: str) -> None:
    AGENTS.pop(name, None)


def get_agent(name: str | None) -> AgentSpec:
    return AGENTS.get(name or "", AGENTS.get("coder") or AGENTS["assistant"])


def list_agents() -> list[dict]:
    return [
        {
            "name": a.name,
            "title": a.title,
            "description": a.description,
            "model_profile": a.model_profile,
            "tools": a.tools,
            "max_steps": a.max_steps,
        }
        for a in AGENTS.values()
    ]
