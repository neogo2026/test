# v1/api/core/tools.py
"""
工具注册与执行。

- 注册 ToolSpec 与 handler（插件的主要扩展点之一）
- 生成 OpenAI function calling schema
- 参数校验、超时、异常归一化，返回统一 ToolResult
- 支持 unregister：插件停用时摘除工具
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from typing import Any, Awaitable, Callable

from core.contracts import ToolCall, ToolResult, ToolSpec

ToolHandler = Callable[..., Any] | Callable[..., Awaitable[Any]]
logger = logging.getLogger(__name__)


class ToolRegistry:
    def __init__(self):
        self._specs: dict[str, ToolSpec] = {}
        self._handlers: dict[str, ToolHandler] = {}
        # ??????RSI ?????????????????????????????
        self._tool_middleware: list[tuple[str, Any, Any]] = []

    def register_middleware(self, name: str, before: Any = None, after: Any = None) -> None:
        self.remove_middleware(name)
        if before or after:
            self._tool_middleware.append((name, before, after))

    def remove_middleware(self, name: str) -> None:
        self._tool_middleware = [item for item in self._tool_middleware if item[0] != name]

    def register(self, spec: ToolSpec, handler: ToolHandler) -> None:
        if spec.name in self._specs:
            raise ValueError(f"工具重复注册: {spec.name}")
        self._specs[spec.name] = spec
        self._handlers[spec.name] = handler

    def unregister(self, name: str) -> bool:
        self._specs.pop(name, None)
        return self._handlers.pop(name, None) is not None

    def get(self, name: str) -> ToolSpec | None:
        return self._specs.get(name)

    def list_specs(self) -> list[ToolSpec]:
        return list(self._specs.values())

    def openai_tools(self, names: list[str] | None = None) -> list[dict[str, Any]]:
        if names is None:
            selected = list(self._specs.values())
        else:
            selected = [self._specs[n] for n in names if n in self._specs]
        return [
            {
                "type": "function",
                "function": {
                    "name": spec.name,
                    "description": spec.description,
                    "parameters": spec.input_schema,
                },
            }
            for spec in selected
        ]

    async def execute(self, call: ToolCall, timeout_s: float | None = None) -> ToolResult:
        blocked_reason = ""
        for _name, before, _after in list(self._tool_middleware):
            if not before:
                continue
            try:
                outcome = before(call)
                if inspect.isawaitable(outcome):
                    outcome = await outcome
                if isinstance(outcome, ToolCall):
                    call = outcome
                elif isinstance(outcome, str) and outcome:
                    blocked_reason = outcome
                    break
            except Exception:  # noqa: BLE001
                logger.exception("???????????")
        if blocked_reason:
            return ToolResult(
                call_id=call.call_id, name=call.name, ok=False,
                error=blocked_reason, summary=f"{call.name} ??????",
            )

        spec = self._specs.get(call.name)
        if not spec:
            return ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=False,
                error=f"未知工具: {call.name}",
                summary=f"未知工具 {call.name}",
            )

        missing = self._validate_args(spec, call.arguments)
        if missing:
            return ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=False,
                error=f"缺少参数: {', '.join(missing)}",
                summary=f"参数校验失败: 缺少 {', '.join(missing)}",
            )

        handler = self._handlers[call.name]
        limit = timeout_s or spec.timeout_s
        try:
            if inspect.iscoroutinefunction(handler):
                output = await asyncio.wait_for(handler(**call.arguments), timeout=limit)
            else:
                output = await asyncio.wait_for(asyncio.to_thread(handler, **call.arguments), timeout=limit)
            if inspect.isawaitable(output):
                output = await asyncio.wait_for(output, timeout=limit)
            result = ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=True,
                result=output,
                summary=self._summarize(output),
            )
            return await self._run_after(call, result)
        except asyncio.TimeoutError:
            return ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=False,
                error=f"工具执行超时（>{limit}s）",
                summary=f"{call.name} 超时",
            )
        except Exception as exc:  # noqa: BLE001 - 工具异常必须归一化后回给模型
            return ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=False,
                error=f"{type(exc).__name__}: {exc}",
                summary=f"{call.name} 执行失败",
            )

    async def _run_after(self, call: ToolCall, result: ToolResult) -> ToolResult:
        current = result
        for _name, _before, after in list(self._tool_middleware):
            if not after:
                continue
            try:
                outcome = after(call, current)
                if inspect.isawaitable(outcome):
                    outcome = await outcome
                if isinstance(outcome, ToolResult):
                    current = outcome
            except Exception:  # noqa: BLE001
                logger.exception("???????????")
        return current

    @staticmethod
    def _validate_args(spec: ToolSpec, arguments: dict[str, Any]) -> list[str]:
        required = spec.input_schema.get("required", [])
        return [key for key in required if key not in arguments]

    @staticmethod
    def _summarize(output: Any, max_chars: int = 1200) -> str:
        if isinstance(output, str):
            text = output
        else:
            try:
                text = json.dumps(output, ensure_ascii=False, default=str)
            except TypeError:
                text = str(output)
        return text[:max_chars] + ("..." if len(text) > max_chars else "")
