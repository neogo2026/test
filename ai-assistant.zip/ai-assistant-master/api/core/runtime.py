# v1/api/core/runtime.py
"""
Agent Runtime —— AI助理 的执行心脏。

在 agent-harness 同步阻塞 Run 的基础上做了三项架构升级（对齐上一代 AI助理 的生产能力）：

1. 后台异步 Run：start_run 立即返回，_drive 在独立 asyncio.Task 中推进；
2. 会话级 FIFO 调度：同一会话串行排队，跨会话天然并行（配合并发闸 CONCURRENT_SESSIONS）；
3. 实时流式事件：model.delta 通过 EventBus 非阻塞广播到 WebSocket，永不反压 Agent 循环。

保留 agent-harness 的核心语义：事件溯源、Step 检查点、审批暂停/恢复、fallback 降级。
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from pathlib import Path

from configs.configs import WORKSPACE_DIR
from core import agents as agent_registry
from core.checkpoints import CheckpointService
from core.context import ContextBuilder
from core.contracts import Message, ToolCall, ToolResult
from core.events import EventService
from core.exec_context import ExecContext, reset_context, set_context
from core.gateway import ModelGateway
from core.hitl import ApprovalService
from core.policy import PolicyEngine
from core.storage import Storage, new_id
from core.tools import ToolRegistry

logger = logging.getLogger(__name__)

TERMINAL_STATUSES = {"COMPLETED", "FAILED", "CANCELLED"}


class AgentRuntime:
    def __init__(
        self,
        storage: Storage,
        events: EventService,
        context: ContextBuilder,
        tools: ToolRegistry,
        policy: PolicyEngine,
        gateway: ModelGateway,
        checkpoints: CheckpointService,
        approvals: ApprovalService,
        max_concurrent_sessions: int = 5,
    ):
        self.storage = storage
        self.events = events
        self.context = context
        self.tools = tools
        self.policy = policy
        self.gateway = gateway
        self.checkpoints = checkpoints
        self.approvals = approvals

        # 会话级调度：同会话 FIFO 串行；不同会话并行
        self._semaphore = asyncio.Semaphore(max_concurrent_sessions)
        self._queues: dict[str, list[str]] = {}      # session_id -> [run_id]
        self._active: dict[str, str] = {}            # session_id -> run_id
        self._tasks: dict[str, asyncio.Task] = {}    # run_id -> task

    # ------------------------------------------------------------------
    # 会话
    # ------------------------------------------------------------------
    async def create_session(self, **kwargs: Any) -> dict[str, Any]:
        return await self.storage.create_session(**kwargs)

    # ------------------------------------------------------------------
    # Run 生命周期
    # ------------------------------------------------------------------
    async def start_run(
        self,
        session_id: str,
        user_input: str,
        agent_name: str | None = None,
        model_profile: str | None = None,
    ) -> dict[str, Any]:
        session = await self.storage.get_session(session_id)
        if not session:
            raise ValueError(f"会话不存在: {session_id}")

        agent_name = agent_name or session["agent_name"]
        run = await self.storage.create_run(
            session_id=session_id,
            tenant_id=session["tenant_id"],
            user_id=session["user_id"],
            agent_name=agent_name,
            user_input=user_input,
            trace_id=new_id("t"),
        )
        await self.storage.add_message(session_id, run["run_id"], Message(role="user", content=user_input))
        if model_profile:
            await self.storage.update_session(session_id, model_profile=model_profile)
        await self.storage.touch_session(session_id)
        await self._enqueue(run["run_id"])
        return await self.storage.get_run(run["run_id"])  # type: ignore[return-value]

    async def resume_run(self, run_id: str) -> dict[str, Any] | None:
        """断点续跑：审批已通过的等待态 / 中断的 Run，从检查点恢复。"""
        run = await self.storage.get_run(run_id)
        if not run or run["status"] in TERMINAL_STATUSES:
            return run
        await self._enqueue(run_id)
        return await self.storage.get_run(run_id)

    async def cancel_run(self, run_id: str) -> dict[str, Any] | None:
        run = await self.storage.get_run(run_id)
        if not run:
            return None
        if run["status"] in TERMINAL_STATUSES:
            return run
        task = self._tasks.get(run_id)
        if task and not task.done():
            task.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=5)
            except (asyncio.CancelledError, asyncio.TimeoutError, Exception):  # noqa: BLE001
                pass
        # 兜底：任务竞态自行退出时，确保终态落库
        run = await self.storage.get_run(run_id)
        if run and run["status"] not in TERMINAL_STATUSES:
            await self._finish_cancelled(run)
            session_id = run["session_id"]
            queue = self._queues.get(session_id) or []
            self._queues[session_id] = [r for r in queue if r != run_id]
            if self._active.get(session_id) == run_id:
                self._active.pop(session_id, None)
                self._pump(session_id)
        return await self.storage.get_run(run_id)

    # ------------------------------------------------------------------
    # 调度器
    # ------------------------------------------------------------------
    async def _enqueue(self, run_id: str) -> None:
        run = await self.storage.get_run(run_id)
        if not run:
            return
        session_id = run["session_id"]
        await self.storage.update_run(run_id, status="QUEUED")
        await self.events.append(
            run_id, session_id, run["tenant_id"], run["trace_id"], "run.queued", {"input": run["input"][:200]}
        )
        self._queues.setdefault(session_id, []).append(run_id)
        self._pump(session_id)

    def _pump(self, session_id: str) -> None:
        """会话队列泵：无活动 Run 时取下一个，启动后台任务。"""
        if self._active.get(session_id):
            return
        queue = self._queues.get(session_id) or []
        while queue:
            run_id = queue.pop(0)
            task = asyncio.create_task(self._run_guarded(session_id, run_id))
            self._tasks[run_id] = task
            self._active[session_id] = run_id
            return

    async def _run_guarded(self, session_id: str, run_id: str) -> None:
        try:
            async with self._semaphore:
                await self._drive(run_id)
        except asyncio.CancelledError:
            run = await self.storage.get_run(run_id)
            if run and run["status"] not in TERMINAL_STATUSES:
                await self._finish_cancelled(run)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Run %s crashed", run_id)
            run = await self.storage.get_run(run_id)
            if run and run["status"] not in TERMINAL_STATUSES:
                await self._fail_run(run_id, run, f"{type(exc).__name__}: {exc}")
        finally:
            self._tasks.pop(run_id, None)
            if self._active.get(session_id) == run_id:
                self._active.pop(session_id, None)
            # 会话状态回落 + 继续泵队列
            asyncio.get_running_loop().call_soon(self._pump, session_id)

    async def _finish_cancelled(self, run: dict[str, Any]) -> None:
        await self.storage.finish_run(run["run_id"], "CANCELLED", error="用户取消")
        await self.events.append(
            run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
            "run.cancelled", {"reason": "用户取消"},
        )
        await self._set_session_status(run["session_id"], "idle")

    async def _fail_run(self, run_id: str, run: dict[str, Any], message: str) -> None:
        await self.storage.finish_run(run_id, "FAILED", error=message)
        await self.events.append(
            run_id, run["session_id"], run["tenant_id"], run["trace_id"],
            "run.failed", {"error": message},
        )
        await self._set_session_status(run["session_id"], "error")

    async def _set_session_status(self, session_id: str, status: str) -> None:
        session = await self.storage.update_session(session_id, status=status)
        if session:
            await self.events.append(
                "*", session_id, session["tenant_id"], "", "session.status",
                {"session_id": session_id, "status": status},
            )

    # ------------------------------------------------------------------
    # 主循环
    # ------------------------------------------------------------------
    async def _drive(self, run_id: str) -> None:
        run = await self.storage.get_run(run_id)
        if not run or run["status"] in TERMINAL_STATUSES:
            return
        session = await self.storage.get_session(run["session_id"])
        if not session:
            await self._fail_run(run_id, run, "会话不存在")
            return

        agent = agent_registry.get_agent(run["agent_name"])
        model_profile = session.get("model_profile") or agent.model_profile
        remembered = await self.storage.get_setting("workspace.default", "")
        workspace_dir = session.get("workspace_dir") or remembered or str(WORKSPACE_DIR)
        if workspace_dir and not Path(workspace_dir).exists():
            workspace_dir = str(WORKSPACE_DIR)
        gate_mode = session.get("gate_mode") or "ask"

        await self.storage.update_run(run_id, status="RUNNING", pending_approval_id=None)
        await self._set_session_status(run["session_id"], "running")
        await self.events.append(
            run_id, run["session_id"], run["tenant_id"], run["trace_id"],
            "run.started", {"agent": agent.name, "model": model_profile},
        )

        checkpoint = await self.checkpoints.latest(run_id)
        state: dict[str, Any] = checkpoint["state"] if checkpoint else {"step": 0, "pending_calls": []}
        state.setdefault("step", 0)
        state.setdefault("pending_calls", [])

        exec_ctx = ExecContext(
            session_id=run["session_id"], run_id=run_id, workspace_dir=workspace_dir, gate_mode=gate_mode
        )
        ctx_token = set_context(exec_ctx)
        try:
            while state["step"] < agent.max_steps:
                if state["pending_calls"]:
                    outcome = await self._handle_pending(run, state)
                    if outcome == "waiting":
                        return

                messages = await self.context.build(
                    agent, run["session_id"], run["input"],
                    workspace_hint=workspace_dir, model_profile=model_profile,
                )
                step_no = int(state["step"]) + 1
                step_id = f"step-{step_no}"
                await self.events.append(
                    run_id, run["session_id"], run["tenant_id"], run["trace_id"],
                    "step.started", {"step": step_no, "agent": agent.name}, step_id,
                )

                async def on_delta(text: str) -> None:
                    await self.events.append(
                        run_id, run["session_id"], run["tenant_id"], run["trace_id"],
                        "model.delta", {"text": text, "run_id": run_id}, step_id,
                    )

                response = await self.gateway.complete(
                    profile_name=model_profile,
                    messages=messages,
                    tools=self.tools.openai_tools(agent.tools),
                    on_delta=on_delta,
                )
                await self.storage.add_message(
                    run["session_id"], run_id,
                    Message(role="assistant", content=response.text,
                            reasoning=response.reasoning or None, tool_calls=response.tool_calls),
                )
                await self.events.append(
                    run_id, run["session_id"], run["tenant_id"], run["trace_id"],
                    "model.completed",
                    {
                        "step": step_no,
                        "finish_reason": response.finish_reason,
                        "usage": response.usage,
                        "model": response.model or model_profile,
                        "tool_calls": [c.model_dump() for c in response.tool_calls],
                        "fallbacks": response.fallbacks,
                    },
                    step_id,
                )

                if not response.tool_calls:
                    if await self._maybe_nudge(run, state, response, step_no, step_id):
                        state["step"] = step_no
                        await self.storage.update_run(run_id, step_count=step_no, status="RUNNING")
                        await self.checkpoints.save(run_id, step_no, state)
                        continue
                    await self.storage.update_run(run_id, step_count=step_no)
                    await self.checkpoints.save(run_id, step_no, state)
                    await self.storage.finish_run(run_id, "COMPLETED", output=response.text)
                    await self.events.append(
                        run_id, run["session_id"], run["tenant_id"], run["trace_id"],
                        "run.completed", {"output": response.text, "usage": response.usage}, step_id,
                    )
                    await self._auto_title(run["session_id"], run["input"])
                    await self._refresh_session_status(run["session_id"])
                    return

                for index, call in enumerate(response.tool_calls):
                    outcome = await self._process_call(
                        run=run,
                        gate_mode=gate_mode,
                        state=state,
                        call=call,
                        step_id=step_id,
                        step_no=step_no,
                        remaining_calls=response.tool_calls[index + 1:],
                    )
                    if outcome == "waiting":
                        return

                state["step"] = step_no
                await self.storage.update_run(run_id, step_count=step_no, status="RUNNING")
                await self.checkpoints.save(run_id, step_no, state)
                await self.events.append(
                    run_id, run["session_id"], run["tenant_id"], run["trace_id"],
                    "checkpoint.saved", {"step": step_no}, step_id,
                )

            await self._fail_run(run_id, run, f"达到最大步数 {agent.max_steps}")
        finally:
            reset_context(ctx_token)

    # ------------------------------------------------------------------
    # 运行时纠偏：截断恢复 / 实现类任务强制动手
    # ------------------------------------------------------------------
    async def _maybe_nudge(self, run: dict[str, Any], state: dict[str, Any], response: Any,
                           step_no: int, step_id: str) -> bool:
        """返回 True 表示已注入提醒并继续循环。"""
        import os
        import re

        limit = int(os.getenv("FORGE_NUDGE_MAX", "2"))
        nudges = int(state.get("nudges") or 0)
        if nudges >= limit:
            return False
        reason = None
        if str(getattr(response, "finish_reason", "")) == "length":
            reason = (
                "运行时提醒：上一条回复因输出长度上限被截断。下一步必须直接调用 write_file 工具"
                "把实现写入工作区文件（可分段多次写入），本轮禁止只输出文字；"
                "写入后用 run_shell 运行自测/验证，最后给出简短结论。"
            )
        elif not await self._run_used_tools(
            run, {"write_file", "edit_file", "multi_edit", "delete_path", "move_path", "run_shell", "run_python"}
        ):
            task_like = re.search(
                r"(实现|开发|修复|修改|重构|完成|添加|编写|创建|优化|测试|写一个|写一份|设计|迁移|升级|"
                r"implement|develop|fix|refactor|build|create|write|add|migrate|optimi[sz]e)",
                str(run.get("input") or ""), re.I,
            )
            if task_like:
                reason = (
                    "运行时提醒：这是软件实现任务，必须实际动手。请立即使用工具"
                    "（list_dir / read_file / write_file / edit_file / run_shell 等）完成实现与验证，"
                    "不要只输出计划或说明。"
                )
        if not reason:
            return False
        state["nudges"] = nudges + 1
        await self.storage.add_message(
            run["session_id"], run["run_id"], Message(role="system", content=reason)
        )
        await self.events.append(
            run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
            "run.nudge", {"attempt": nudges + 1, "reason": reason[:120]}, step_id,
        )
        return True

    async def _run_used_tools(self, run: dict[str, Any], names: set[str] | None = None) -> bool:
        rows = await self.storage.list_messages(run["session_id"], limit=500)
        for m in rows:
            if m.get("role") != "tool" or m.get("run_id") != run["run_id"]:
                continue
            if names is None or (m.get("name") in names):
                return True
        return False
    async def _refresh_session_status(self, session_id: str) -> None:
        """Run 结束后会话状态回落（队列里还有 Run 则由 _pump 推进）。"""
        queue = self._queues.get(session_id) or []
        if queue:
            await self._set_session_status(session_id, "queued")
        else:
            await self._set_session_status(session_id, "idle")

    async def _auto_title(self, session_id: str, first_input: str) -> None:
        """首个 Run 完成后自动命名会话（取用户输入前 18 字，避免额外 LLM 开销）。"""
        session = await self.storage.get_session(session_id)
        if not session:
            return
        title = (session.get("title") or "").strip()
        if not title or title.startswith("新任务"):
            auto = first_input.strip().replace("\n", " ")[:18] or "新任务"
            updated = await self.storage.update_session(session_id, title=auto)
            if updated:
                await self.events.append(
                    "*", session_id, session["tenant_id"], "", "session.updated",
                    {"session_id": session_id, "title": auto},
                )

    # ------------------------------------------------------------------
    # 工具调用与审批
    # ------------------------------------------------------------------
    async def _process_call(
        self,
        run: dict[str, Any],
        gate_mode: str,
        state: dict[str, Any],
        call: ToolCall,
        step_id: str,
        step_no: int,
        remaining_calls: list[ToolCall],
    ) -> str:
        decision = await self._authorize(run, gate_mode, call)
        if decision.requires_approval:
            approval = await self.approvals.create(
                tenant_id=run["tenant_id"],
                run_id=run["run_id"],
                session_id=run["session_id"],
                call=call,
                step_id=step_id,
            )
            call_data = call.model_dump()
            call_data["approval_id"] = approval["approval_id"]
            state["pending_calls"] = [call_data] + [c.model_dump() for c in remaining_calls]
            state["step"] = step_no
            await self.checkpoints.save(run["run_id"], step_no, state)
            await self.storage.update_run(
                run["run_id"], status="WAITING_APPROVAL", step_count=step_no,
                pending_approval_id=approval["approval_id"],
            )
            await self._set_session_status(run["session_id"], "waiting_approval")
            await self.events.append(
                run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                "tool.requested",
                {"call_id": call.call_id, "name": call.name, "arguments": call.arguments, "requires_approval": True},
                step_id,
            )
            await self.events.append(
                run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                "approval.required",
                {
                    "approval_id": approval["approval_id"],
                    "tool": call.name,
                    "arguments": call.arguments,
                    "reason": decision.reason,
                },
                step_id,
            )
            return "waiting"

        if not decision.allowed:
            result = ToolResult(
                call_id=call.call_id,
                name=call.name,
                ok=False,
                error=decision.reason,
                summary=f"策略拒绝 {call.name}",
            )
            await self.events.append(
                run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                "tool.requested",
                {"call_id": call.call_id, "name": call.name, "arguments": call.arguments, "denied": True},
                step_id,
            )
            await self._record_tool_result(run, call, result, step_id)
            return "done"

        await self._execute_call(run, call, step_id, approved=False)
        return "done"

    async def _handle_pending(self, run: dict[str, Any], state: dict[str, Any]) -> str:
        session = await self.storage.get_session(run["session_id"])
        gate_mode = (session or {}).get("gate_mode") or "ask"
        pending: list[dict[str, Any]] = state.get("pending_calls") or []
        for index, item in enumerate(pending):
            call = ToolCall(
                call_id=item["call_id"],
                name=item["name"],
                arguments=item.get("arguments") or {},
            )
            approval_id = item.get("approval_id")

            if approval_id:
                approval = await self.approvals.get(approval_id)
                if not approval or approval["status"] == "pending":
                    state["pending_calls"] = pending[index:]
                    await self.checkpoints.save(run["run_id"], int(state["step"]), state)
                    await self.storage.update_run(
                        run["run_id"], status="WAITING_APPROVAL", pending_approval_id=approval_id
                    )
                    await self._set_session_status(run["session_id"], "waiting_approval")
                    return "waiting"
                if approval["status"] == "rejected":
                    reason = approval.get("reason") or "未提供原因"
                    result = ToolResult(
                        call_id=call.call_id,
                        name=call.name,
                        ok=False,
                        error=f"审批拒绝: {reason}",
                        summary=f"{call.name} 审批未通过",
                    )
                    await self._record_tool_result(run, call, result, f"step-{state['step']}")
                    continue
                await self.events.append(
                    run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                    "tool.approved", {"approval_id": approval_id, "tool": call.name},
                    f"step-{state['step']}",
                )
                await self._execute_call(run, call, f"step-{state['step']}", approved=True)
                continue

            decision = await self._authorize(run, gate_mode, call)
            if decision.requires_approval:
                approval = await self.approvals.create(
                    tenant_id=run["tenant_id"],
                    run_id=run["run_id"],
                    session_id=run["session_id"],
                    call=call,
                    step_id=f"step-{state['step']}",
                )
                item["approval_id"] = approval["approval_id"]
                pending[index] = item
                state["pending_calls"] = pending[index:]
                await self.checkpoints.save(run["run_id"], int(state["step"]), state)
                await self.storage.update_run(
                    run["run_id"], status="WAITING_APPROVAL",
                    pending_approval_id=approval["approval_id"],
                )
                await self._set_session_status(run["session_id"], "waiting_approval")
                await self.events.append(
                    run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                    "approval.required",
                    {
                        "approval_id": approval["approval_id"],
                        "tool": call.name,
                        "arguments": call.arguments,
                        "reason": decision.reason,
                    },
                    f"step-{state['step']}",
                )
                return "waiting"
            if not decision.allowed:
                result = ToolResult(
                    call_id=call.call_id,
                    name=call.name,
                    ok=False,
                    error=decision.reason,
                    summary=f"策略拒绝 {call.name}",
                )
                await self._record_tool_result(run, call, result, f"step-{state['step']}")
                continue
            await self._execute_call(run, call, f"step-{state['step']}", approved=False)

        state["pending_calls"] = []
        await self.checkpoints.save(run["run_id"], int(state["step"]), state)
        await self.storage.update_run(run["run_id"], pending_approval_id=None)
        await self.storage.update_run(run["run_id"], status="RUNNING")
        await self._set_session_status(run["session_id"], "running")
        return "continue"

    async def _authorize(self, run: dict[str, Any], gate_mode: str, call: ToolCall):
        spec = self.tools.get(call.name)
        if not spec:
            from core.contracts import PolicyDecision

            return PolicyDecision(allowed=False, reason=f"未知工具: {call.name}")
        agent = agent_registry.get_agent(run["agent_name"])
        return await self.policy.authorize(
            spec,
            call,
            context={
                "tenant_id": run["tenant_id"],
                "user_id": run["user_id"],
                "agent_name": run["agent_name"],
                "allowed_tools": agent.tools,
                "gate_mode": gate_mode,
            },
        )

    async def _execute_call(self, run: dict[str, Any], call: ToolCall, step_id: str, approved: bool) -> ToolResult:
        await self.events.append(
            run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
            "tool.requested",
            {"call_id": call.call_id, "name": call.name, "arguments": call.arguments, "approved": approved},
            step_id,
        )
        result = await self.tools.execute(call)

        # 写文件类工具成功 → 登记产物
        if result.ok and call.name in {"write_file", "edit_file", "multi_edit"} and isinstance(result.result, dict):
            data = result.result
            path_text = str(data.get("path") or data.get("absolute_path") or "artifact.txt")
            try:
                from pathlib import Path

                artifact = await self.storage.create_artifact(
                    tenant_id=run["tenant_id"],
                    run_id=run["run_id"],
                    session_id=run["session_id"],
                    name=Path(path_text).name,
                    path=str(data.get("absolute_path") or path_text),
                    mime="text/plain",
                    size=int(data.get("size") or 0),
                    metadata={"tool": call.name},
                )
                result.artifact_id = artifact["artifact_id"]
                await self.events.append(
                    run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
                    "artifact.created",
                    {"artifact_id": artifact["artifact_id"], "name": artifact["name"],
                     "path": artifact["path"], "size": artifact["size"]},
                    step_id,
                )
            except Exception:  # noqa: BLE001 - 产物登记失败不影响工具结果
                pass

        await self._record_tool_result(run, call, result, step_id)
        return result

    async def _record_tool_result(
        self, run: dict[str, Any], call: ToolCall, result: ToolResult, step_id: str
    ) -> None:
        content = json.dumps(
            {"ok": result.ok, "result": result.result, "error": result.error,
             "artifact_id": result.artifact_id},
            ensure_ascii=False, default=str,
        )
        await self.storage.add_message(
            run["session_id"], run["run_id"],
            Message(role="tool", content=content, name=call.name, tool_call_id=call.call_id),
        )
        await self.events.append(
            run["run_id"], run["session_id"], run["tenant_id"], run["trace_id"],
            "tool.result",
            {
                "call_id": result.call_id,
                "name": result.name,
                "ok": result.ok,
                "summary": result.summary[:800],
                "error": result.error,
                "artifact_id": result.artifact_id,
            },
            step_id,
        )

    # ------------------------------------------------------------------
    # 恢复中断（服务重启后）
    # ------------------------------------------------------------------
    async def recover_interrupted(self) -> int:
        """启动时把遗留的非终态 Run 标记为 PAUSED，等待用户手动 resume。"""
        count = 0
        for run in await self.storage.list_active_runs():
            await self.storage.update_run(run["run_id"], status="PAUSED", pending_approval_id=None)
            session = await self.storage.get_session(run["session_id"])
            if session and session.get("status") in ("running", "queued", "waiting_approval"):
                await self._set_session_status(run["session_id"], "idle")
            count += 1
        return count
