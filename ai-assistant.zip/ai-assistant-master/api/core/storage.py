# v1/api/core/storage.py
"""
SQLite 存储层。

表结构带 tenant_id，为后续切换 Postgres + RLS 留出空间。
每操作独立短连接（WAL + busy_timeout），避免长连接跨事件循环问题。
"""

from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiosqlite

from core.contracts import Event, Message


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'idle',
    model_profile TEXT NOT NULL DEFAULT '',
    workspace_dir TEXT NOT NULL DEFAULT '',
    gate_mode TEXT NOT NULL DEFAULT 'ask',
    source TEXT NOT NULL DEFAULT 'web',
    hidden INTEGER NOT NULL DEFAULT 0,
    capabilities TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_tenant ON sessions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sessions_updated ON sessions(updated_at);

CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    status TEXT NOT NULL,
    input TEXT NOT NULL,
    output TEXT,
    error TEXT,
    step_count INTEGER NOT NULL DEFAULT 0,
    pending_approval_id TEXT,
    trace_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_runs_session ON runs(session_id);
CREATE INDEX IF NOT EXISTS idx_runs_tenant_status ON runs(tenant_id, status);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    type TEXT NOT NULL,
    step_id TEXT,
    payload TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(run_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_events_run_seq ON events(run_id, seq);
CREATE INDEX IF NOT EXISTS idx_events_session_id ON events(session_id, id);

CREATE TABLE IF NOT EXISTS messages (
    message_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    reasoning TEXT,
    name TEXT,
    tool_call_id TEXT,
    tool_calls TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);

CREATE TABLE IF NOT EXISTS checkpoints (
    run_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    state TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY(run_id, seq)
);

CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    session_id TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    mime TEXT,
    path TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    metadata TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_artifacts_run ON artifacts(run_id);

CREATE TABLE IF NOT EXISTS approvals (
    approval_id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    session_id TEXT NOT NULL DEFAULT '',
    step_id TEXT,
    tool_name TEXT NOT NULL,
    arguments TEXT NOT NULL,
    status TEXT NOT NULL,
    reason TEXT,
    resolver TEXT,
    created_at TEXT NOT NULL,
    resolved_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_approvals_run ON approvals(run_id);
CREATE INDEX IF NOT EXISTS idx_approvals_status ON approvals(tenant_id, status);

CREATE TABLE IF NOT EXISTS usage_daily (
    day TEXT NOT NULL,
    model TEXT NOT NULL,
    session_id TEXT NOT NULL,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(day, model, session_id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feishu_links (
    chat_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


class Storage:
    """轻量异步存储。"""

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)

    async def init(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        async with self.connect() as db:
            await db.executescript(SCHEMA)
            try:
                await db.execute("ALTER TABLE messages ADD COLUMN reasoning TEXT")
            except Exception:  # noqa: BLE001 - 旧库已存在该列
                pass
            try:
                await db.execute("ALTER TABLE sessions ADD COLUMN capabilities TEXT NOT NULL DEFAULT '{}'")
            except Exception:  # noqa: BLE001 - 旧库已存在该列
                pass
            await db.commit()

    @asynccontextmanager
    async def connect(self):
        db = await aiosqlite.connect(self.db_path)
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA busy_timeout=5000")
        try:
            yield db
        finally:
            await db.close()

    # ------------------------------------------------------------------
    # Session
    # ------------------------------------------------------------------
    async def create_session(
        self,
        tenant_id: str = "default",
        user_id: str = "local",
        agent_name: str = "coder",
        title: str = "",
        model_profile: str = "",
        workspace_dir: str = "",
        gate_mode: str = "ask",
        source: str = "web",
        session_id: str | None = None,
        capabilities: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        sid = session_id or new_id("s")
        ts = utc_now()
        caps = json.dumps(capabilities or {}, ensure_ascii=False)
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO sessions(session_id, tenant_id, user_id, agent_name, title, status, "
                "model_profile, workspace_dir, gate_mode, source, capabilities, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, 'idle', ?, ?, ?, ?, ?, ?, ?)",
                (sid, tenant_id, user_id, agent_name, title, model_profile, workspace_dir, gate_mode, source, caps, ts, ts),
            )
            await db.commit()
        return await self.get_session(sid)  # type: ignore[return-value]

    async def get_session(self, session_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        try:
            item["capabilities"] = json.loads(item.get("capabilities") or "{}")
        except (TypeError, json.JSONDecodeError):
            item["capabilities"] = {}
        return item

    async def touch_session(self, session_id: str) -> None:
        async with self.connect() as db:
            await db.execute("UPDATE sessions SET updated_at = ? WHERE session_id = ?", (utc_now(), session_id))
            await db.commit()

    async def list_sessions(self, include_hidden: bool = False, limit: int = 200) -> list[dict[str, Any]]:
        where = "" if include_hidden else "WHERE hidden = 0"
        async with self.connect() as db:
            async with db.execute(
                f"SELECT * FROM sessions {where} ORDER BY updated_at DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def update_session(self, session_id: str, **fields: Any) -> dict[str, Any] | None:
        allowed = {"title", "status", "model_profile", "workspace_dir", "gate_mode", "hidden", "agent_name", "capabilities"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if "capabilities" in updates and not isinstance(updates["capabilities"], str):
            updates["capabilities"] = json.dumps(updates["capabilities"], ensure_ascii=False)
        if not updates:
            return await self.get_session(session_id)
        updates["updated_at"] = utc_now()
        assignments = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [session_id]
        async with self.connect() as db:
            await db.execute(f"UPDATE sessions SET {assignments} WHERE session_id = ?", values)
            await db.commit()
        return await self.get_session(session_id)

    async def delete_session(self, session_id: str, purge: bool = False) -> None:
        async with self.connect() as db:
            if purge:
                for table in ("runs", "events", "messages", "artifacts", "approvals", "checkpoints"):
                    col = "session_id" if table != "checkpoints" else "run_id"
                    if table == "checkpoints":
                        await db.execute(
                            "DELETE FROM checkpoints WHERE run_id IN (SELECT run_id FROM runs WHERE session_id = ?)",
                            (session_id,),
                        )
                    else:
                        await db.execute(f"DELETE FROM {table} WHERE {col} = ?", (session_id,))
                await db.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
            else:
                await db.execute(
                    "UPDATE sessions SET hidden = 1, updated_at = ? WHERE session_id = ?",
                    (utc_now(), session_id),
                )
            await db.commit()

    async def count_sessions(self) -> int:
        async with self.connect() as db:
            async with db.execute("SELECT COUNT(*) FROM sessions") as cur:
                row = await cur.fetchone()
        return int(row[0]) if row else 0

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------
    async def create_run(
        self,
        session_id: str,
        tenant_id: str,
        user_id: str,
        agent_name: str,
        user_input: str,
        trace_id: str,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        rid = run_id or new_id("r")
        ts = utc_now()
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO runs(run_id, session_id, tenant_id, user_id, agent_name, status, input, "
                "trace_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (rid, session_id, tenant_id, user_id, agent_name, "CREATED", user_input, trace_id, ts, ts),
            )
            await db.commit()
        return await self.get_run(rid)  # type: ignore[return-value]

    async def get_run(self, run_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM runs WHERE run_id = ?", (run_id,)) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None

    async def last_run(self, session_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM runs WHERE session_id = ? ORDER BY created_at DESC LIMIT 1", (session_id,)
            ) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None

    async def list_runs(self, session_id: str, limit: int = 100) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM runs WHERE session_id = ? ORDER BY created_at DESC LIMIT ?",
                (session_id, limit),
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def list_active_runs(self) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM runs WHERE status IN ('CREATED','QUEUED','RUNNING','WAITING_APPROVAL','PAUSED')"
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def update_run(self, run_id: str, **fields: Any) -> None:
        allowed = {"status", "output", "error", "step_count", "pending_approval_id", "agent_name"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return
        updates["updated_at"] = utc_now()
        assignments = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [run_id]
        async with self.connect() as db:
            await db.execute(f"UPDATE runs SET {assignments} WHERE run_id = ?", values)
            await db.commit()

    async def finish_run(self, run_id: str, status: str, output: str | None = None, error: str | None = None) -> None:
        await self.update_run(run_id, status=status, output=output, error=error, pending_approval_id=None)

    # ------------------------------------------------------------------
    # Event（run 内严格递增序号；session 级回放按自增 id 游标）
    # ------------------------------------------------------------------
    async def append_event(
        self,
        run_id: str,
        session_id: str,
        tenant_id: str,
        trace_id: str,
        event_type: str,
        payload: dict[str, Any] | None = None,
        step_id: str | None = None,
    ) -> Event:
        payload = payload or {}
        event_id = new_id("e")
        created_at = utc_now()
        async with self.connect() as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                async with db.execute(
                    "SELECT COALESCE(MAX(seq), 0) + 1 FROM events WHERE run_id = ?", (run_id,)
                ) as cur:
                    row = await cur.fetchone()
                seq = int(row[0])
                await db.execute(
                    "INSERT INTO events(event_id, tenant_id, session_id, run_id, seq, type, step_id, payload, trace_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        event_id,
                        tenant_id,
                        session_id,
                        run_id,
                        seq,
                        event_type,
                        step_id,
                        json.dumps(payload, ensure_ascii=False),
                        trace_id,
                        created_at,
                    ),
                )
                await db.commit()
            except Exception:
                await db.rollback()
                raise
        return Event(
            event_id=event_id,
            tenant_id=tenant_id,
            session_id=session_id,
            run_id=run_id,
            seq=seq,
            type=event_type,
            step_id=step_id,
            payload=payload,
            trace_id=trace_id,
            created_at=created_at,
        )

    async def list_events(self, run_id: str, after_seq: int = 0, limit: int = 2000) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM events WHERE run_id = ? AND seq > ? ORDER BY seq ASC LIMIT ?",
                (run_id, after_seq, limit),
            ) as cur:
                rows = await cur.fetchall()
        return self._decode_events(rows)

    async def list_session_events(self, session_id: str, after_id: int = 0, limit: int = 1000) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM events WHERE session_id = ? AND id > ? ORDER BY id ASC LIMIT ?",
                (session_id, after_id, limit),
            ) as cur:
                rows = await cur.fetchall()
        return self._decode_events(rows)

    @staticmethod
    def _decode_events(rows: list[Any]) -> list[dict[str, Any]]:
        result = []
        for row in rows:
            item = dict(row)
            item["payload"] = json.loads(item["payload"])
            result.append(item)
        return result

    # ------------------------------------------------------------------
    # Message
    # ------------------------------------------------------------------
    async def add_message(self, session_id: str, run_id: str, message: Message) -> dict[str, Any]:
        message_id = new_id("m")
        created_at = utc_now()
        tool_calls = [c.model_dump() for c in message.tool_calls]
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO messages(message_id, session_id, run_id, role, content, reasoning, name, tool_call_id, tool_calls, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    message_id,
                    session_id,
                    run_id,
                    message.role,
                    message.content,
                    message.reasoning,
                    message.name,
                    message.tool_call_id,
                    json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                    created_at,
                ),
            )
            await db.commit()
        return {
            "message_id": message_id,
            "session_id": session_id,
            "run_id": run_id,
            **message.model_dump(),
            "created_at": created_at,
        }

    async def list_messages(self, session_id: str, limit: int = 500) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM messages WHERE session_id = ? ORDER BY created_at ASC, message_id ASC LIMIT ?",
                (session_id, limit),
            ) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["tool_calls"] = json.loads(item["tool_calls"]) if item.get("tool_calls") else []
            result.append(item)
        return result

    # ------------------------------------------------------------------
    # Checkpoint
    # ------------------------------------------------------------------
    async def save_checkpoint(self, run_id: str, seq: int, state: dict[str, Any]) -> None:
        async with self.connect() as db:
            await db.execute(
                "INSERT OR REPLACE INTO checkpoints(run_id, seq, state, created_at) VALUES (?, ?, ?, ?)",
                (run_id, seq, json.dumps(state, ensure_ascii=False), utc_now()),
            )
            await db.commit()

    async def latest_checkpoint(self, run_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM checkpoints WHERE run_id = ? ORDER BY seq DESC LIMIT 1", (run_id,)
            ) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        item["state"] = json.loads(item["state"])
        return item

    # ------------------------------------------------------------------
    # Artifact
    # ------------------------------------------------------------------
    async def create_artifact(
        self,
        tenant_id: str,
        run_id: str,
        session_id: str,
        name: str,
        path: str,
        mime: str = "text/plain",
        size: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        artifact_id = new_id("a")
        created_at = utc_now()
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO artifacts(artifact_id, tenant_id, run_id, session_id, name, mime, path, size, metadata, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    artifact_id,
                    tenant_id,
                    run_id,
                    session_id,
                    name,
                    mime,
                    path,
                    size,
                    json.dumps(metadata or {}, ensure_ascii=False),
                    created_at,
                ),
            )
            await db.commit()
        return {
            "artifact_id": artifact_id,
            "tenant_id": tenant_id,
            "run_id": run_id,
            "session_id": session_id,
            "name": name,
            "mime": mime,
            "path": path,
            "size": size,
            "metadata": metadata or {},
            "created_at": created_at,
        }

    async def list_artifacts(self, run_id: str) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT * FROM artifacts WHERE run_id = ? ORDER BY created_at ASC", (run_id,)
            ) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metadata"] = json.loads(item["metadata"]) if item.get("metadata") else {}
            result.append(item)
        return result

    # ------------------------------------------------------------------
    # Approval
    # ------------------------------------------------------------------
    async def create_approval(
        self,
        tenant_id: str,
        run_id: str,
        session_id: str,
        tool_name: str,
        arguments: dict[str, Any],
        step_id: str | None = None,
    ) -> dict[str, Any]:
        approval_id = new_id("ap")
        created_at = utc_now()
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO approvals(approval_id, tenant_id, run_id, session_id, step_id, tool_name, arguments, status, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)",
                (approval_id, tenant_id, run_id, session_id, step_id, tool_name, json.dumps(arguments, ensure_ascii=False), created_at),
            )
            await db.commit()
        return await self.get_approval(approval_id)  # type: ignore[return-value]

    async def get_approval(self, approval_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM approvals WHERE approval_id = ?", (approval_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        item = dict(row)
        item["arguments"] = json.loads(item["arguments"])
        return item

    async def list_approvals(
        self,
        tenant_id: str | None = None,
        status: str | None = None,
        session_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        clauses, values = [], []
        if tenant_id:
            clauses.append("tenant_id = ?")
            values.append(tenant_id)
        if status:
            clauses.append("status = ?")
            values.append(status)
        if session_id:
            clauses.append("session_id = ?")
            values.append(session_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        values.append(limit)
        async with self.connect() as db:
            async with db.execute(
                f"SELECT * FROM approvals {where} ORDER BY created_at DESC LIMIT ?", values
            ) as cur:
                rows = await cur.fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["arguments"] = json.loads(item["arguments"])
            result.append(item)
        return result

    async def resolve_approval(
        self,
        approval_id: str,
        approved: bool,
        reason: str = "",
        resolver: str = "local",
    ) -> dict[str, Any] | None:
        status = "approved" if approved else "rejected"
        async with self.connect() as db:
            await db.execute(
                "UPDATE approvals SET status = ?, reason = ?, resolver = ?, resolved_at = ? "
                "WHERE approval_id = ? AND status = 'pending'",
                (status, reason, resolver, utc_now(), approval_id),
            )
            await db.commit()
        return await self.get_approval(approval_id)

    # ------------------------------------------------------------------
    # Usage
    # ------------------------------------------------------------------
    async def add_usage(
        self, day: str, model: str, session_id: str, prompt_tokens: int, completion_tokens: int, total_tokens: int
    ) -> None:
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO usage_daily(day, model, session_id, prompt_tokens, completion_tokens, total_tokens, calls) "
                "VALUES (?, ?, ?, ?, ?, ?, 1) "
                "ON CONFLICT(day, model, session_id) DO UPDATE SET "
                "prompt_tokens = prompt_tokens + excluded.prompt_tokens, "
                "completion_tokens = completion_tokens + excluded.completion_tokens, "
                "total_tokens = total_tokens + excluded.total_tokens, "
                "calls = calls + 1",
                (day, model, session_id, prompt_tokens, completion_tokens, total_tokens),
            )
            await db.commit()

    async def usage_daily(self, limit: int = 30) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT day, SUM(prompt_tokens) AS prompt_tokens, SUM(completion_tokens) AS completion_tokens, "
                "SUM(total_tokens) AS total_tokens, SUM(calls) AS calls FROM usage_daily "
                "GROUP BY day ORDER BY day DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def usage_by_model(self, limit: int = 30) -> list[dict[str, Any]]:
        async with self.connect() as db:
            async with db.execute(
                "SELECT model, SUM(prompt_tokens) AS prompt_tokens, SUM(completion_tokens) AS completion_tokens, "
                "SUM(total_tokens) AS total_tokens, SUM(calls) AS calls FROM usage_daily "
                "GROUP BY model ORDER BY total_tokens DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def usage_today(self) -> dict[str, Any]:
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        async with self.connect() as db:
            async with db.execute(
                "SELECT COALESCE(SUM(prompt_tokens),0) AS prompt_tokens, COALESCE(SUM(completion_tokens),0) AS completion_tokens, "
                "COALESCE(SUM(total_tokens),0) AS total_tokens, COALESCE(SUM(calls),0) AS calls "
                "FROM usage_daily WHERE day = ?", (day,)
            ) as cur:
                row = await cur.fetchone()
        return dict(row) if row else {}

    # ------------------------------------------------------------------
    # Settings KV
    # ------------------------------------------------------------------
    async def get_setting(self, key: str, default: str = "") -> str:
        async with self.connect() as db:
            async with db.execute("SELECT value FROM settings WHERE key = ?", (key,)) as cur:
                row = await cur.fetchone()
        return str(row["value"]) if row else default

    async def set_setting(self, key: str, value: str) -> None:
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO settings(key, value, updated_at) VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                (key, value, utc_now()),
            )
            await db.commit()

    # ------------------------------------------------------------------
    # Feishu links
    # ------------------------------------------------------------------
    async def get_feishu_link(self, chat_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM feishu_links WHERE chat_id = ?", (chat_id,)) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None

    async def upsert_feishu_link(self, chat_id: str, session_id: str, title: str = "") -> None:
        ts = utc_now()
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO feishu_links(chat_id, session_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(chat_id) DO UPDATE SET session_id = excluded.session_id, title = excluded.title, updated_at = excluded.updated_at",
                (chat_id, session_id, title, ts, ts),
            )
            await db.commit()

    async def find_feishu_link_by_session(self, session_id: str) -> dict[str, Any] | None:
        async with self.connect() as db:
            async with db.execute("SELECT * FROM feishu_links WHERE session_id = ? LIMIT 1", (session_id,)) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None

    async def wait_for_db(self) -> None:
        await asyncio.sleep(0)
