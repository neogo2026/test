# v1/api/core/contracts.py
"""
AI助理 核心契约。

这些对象是内核、插件层、HTTP 层共同依赖的最小集合。
只放数据契约，不放业务逻辑，避免内核被产品细节污染。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

RiskLevel = Literal["low", "medium", "high"]
SideEffect = Literal["none", "write", "irreversible"]
MessageRole = Literal["system", "user", "assistant", "tool"]
RunStatus = Literal[
    "CREATED",
    "QUEUED",
    "RUNNING",
    "WAITING_APPROVAL",
    "PAUSED",
    "COMPLETED",
    "FAILED",
    "CANCELLED",
]
SessionStatus = Literal["idle", "queued", "running", "waiting_approval", "done", "error"]


class ModelProfile(BaseModel):
    """模型能力矩阵，供应商差异在这里显式声明。"""

    name: str
    provider: str = "mock"
    model: str = "mock"
    base_url: str | None = None
    api_key_env: str | None = None  # 从 secrets 加载器取哪个环境变量名
    context_window: int = 32_000
    max_output: int = 4_096
    stream: bool = True
    tool_call: Literal["native", "json", "none"] = "native"
    parallel_tool_calls: bool = False
    vision: bool = False
    timeout_s: float = 60
    fallback: list[str] = Field(default_factory=list)
    extra_body: dict[str, Any] = Field(default_factory=dict)  # 透传供应商私有参数（如 DeepSeek thinking）


class AgentSpec(BaseModel):
    """Agent 的静态定义，运行时不修改。插件可注册更多 Agent。"""

    name: str
    title: str
    description: str = ""
    instructions: str
    model_profile: str = "mock"
    tools: list[str] = Field(default_factory=list)
    max_steps: int = 40
    max_context_tokens: int = 60_000
    auto_skills: bool = True


class ToolSpec(BaseModel):
    """工具契约：schema、风险、副作用、超时与幂等策略。"""

    name: str
    description: str
    input_schema: dict[str, Any] = Field(default_factory=lambda: {"type": "object", "properties": {}})
    risk: RiskLevel = "low"
    side_effect: SideEffect = "none"
    timeout_s: float = 60
    idempotency: Literal["none", "key", "natural"] = "none"
    concurrency_safe: bool = False


class ToolCall(BaseModel):
    """归一化后的工具调用。"""

    call_id: str
    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class Message(BaseModel):
    """统一消息模型。"""

    role: MessageRole
    content: str = ""
    reasoning: str | None = None
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[ToolCall] = Field(default_factory=list)


class Event(BaseModel):
    """追加式事件。事件是事实源，快照只是加速。"""

    event_id: str
    tenant_id: str
    session_id: str
    run_id: str
    seq: int
    type: str
    step_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    trace_id: str
    created_at: str


class ModelResponse(BaseModel):
    """模型网关的统一返回。"""

    text: str = ""
    reasoning: str = ""
    tool_calls: list[ToolCall] = Field(default_factory=list)
    usage: dict[str, Any] = Field(default_factory=dict)
    finish_reason: str = "stop"
    raw: dict[str, Any] | None = None
    model: str = ""
    fallbacks: list[str] = Field(default_factory=list)


class ToolResult(BaseModel):
    """工具执行结果。"""

    call_id: str
    name: str
    ok: bool
    result: Any = None
    error: str | None = None
    summary: str = ""
    artifact_id: str | None = None


class PolicyDecision(BaseModel):
    """权限判定结果。"""

    allowed: bool
    requires_approval: bool = False
    reason: str = ""
    risk: RiskLevel = "low"


class SessionCreate(BaseModel):
    title: str = ""
    agent_name: str = "coder"
    model_profile: str | None = None
    workspace_dir: str | None = None
    gate_mode: str = "ask"
    source: str = "web"
    tenant_id: str = "default"
    user_id: str = "local"
    capabilities: dict[str, Any] = Field(default_factory=dict)


class SessionUpdate(BaseModel):
    title: str | None = None
    model_profile: str | None = None
    workspace_dir: str | None = None
    gate_mode: str | None = None
    hidden: bool | None = None
    capabilities: dict[str, Any] | None = None


class MessageRequest(BaseModel):
    text: str
    agent_name: str | None = None
    model_profile: str | None = None


class ApprovalResolve(BaseModel):
    approved: bool
    reason: str = ""
    resolver: str = "local"
