# v1/api/core/hitl.py
"""
Human-in-the-loop 审批服务。

审批落库（pending → approved/rejected），Run 暂停并释放执行资源；
人工裁决后由 Runtime 从检查点恢复。
"""

from __future__ import annotations

from typing import Any

from core.contracts import ToolCall
from core.storage import Storage


class ApprovalService:
    def __init__(self, storage: Storage):
        self.storage = storage

    async def create(
        self,
        tenant_id: str,
        run_id: str,
        session_id: str,
        call: ToolCall,
        step_id: str | None = None,
    ) -> dict[str, Any]:
        return await self.storage.create_approval(
            tenant_id=tenant_id,
            run_id=run_id,
            session_id=session_id,
            tool_name=call.name,
            arguments=call.arguments,
            step_id=step_id,
        )

    async def get(self, approval_id: str) -> dict[str, Any] | None:
        return await self.storage.get_approval(approval_id)

    async def list(self, tenant_id: str | None = None, status: str | None = None, session_id: str | None = None) -> list[dict[str, Any]]:
        return await self.storage.list_approvals(tenant_id=tenant_id, status=status, session_id=session_id)

    async def resolve(
        self,
        approval_id: str,
        approved: bool,
        reason: str = "",
        resolver: str = "local",
    ) -> dict[str, Any] | None:
        return await self.storage.resolve_approval(
            approval_id=approval_id,
            approved=approved,
            reason=reason,
            resolver=resolver,
        )
