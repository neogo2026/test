# v1/api/core/policy.py
"""
权限策略引擎。

分层判定顺序：
1. Agent 工具白名单（allowed_tools）
2. 插件 Screener 预检（如：危险命令黑名单、git push 禁用）——命中直接拒绝
3. 风险分级：
   - low：放行
   - medium：放行（可由策略收紧为审批）
   - high：门禁裁决——gate_mode=allow_all 或全局 AUTO_APPROVE 时放行，否则需人工审批

会话级 gate_mode（ask / allow_all）经由 authorize 的 context 传入，
实现上一代 AI助理 的门禁档位能力，但判定收敛在单一引擎内。
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable

from core.contracts import PolicyDecision, ToolCall, ToolSpec

Screener = Callable[[str, dict[str, Any]], "str | None | Any"]


class PolicyEngine:
    def __init__(self, auto_approve_high_risk: bool = False):
        self.auto_approve_high_risk = auto_approve_high_risk
        self._screeners: list[Screener] = []

    def register_screener(self, fn: Screener) -> None:
        """插件注册危险内容预检器：返回非空字符串即拒绝理由。"""
        if fn not in self._screeners:
            self._screeners.append(fn)

    async def authorize(
        self,
        tool: ToolSpec,
        call: ToolCall,
        context: dict[str, Any] | None = None,
    ) -> PolicyDecision:
        context = context or {}

        # 1. Agent 工具白名单
        allowed_tools = context.get("allowed_tools")
        if allowed_tools is not None and tool.name not in allowed_tools:
            return PolicyDecision(allowed=False, reason=f"Agent 未授权工具 {tool.name}", risk=tool.risk)

        denied = context.get("denied_tools") or []
        if tool.name in denied:
            return PolicyDecision(allowed=False, reason=f"策略拒绝工具 {tool.name}", risk=tool.risk)

        # 2. Screener 预检（黑名单等，直接拒绝，不进入审批流程）
        for screener in list(self._screeners):
            try:
                if inspect.iscoroutinefunction(screener):
                    reason = await screener(tool.name, call.arguments)
                else:
                    reason = screener(tool.name, call.arguments)
                    if inspect.isawaitable(reason):
                        reason = await reason
            except Exception:  # noqa: BLE001 - screener 异常不应阻断工具
                continue
            if reason:
                return PolicyDecision(
                    allowed=False,
                    reason=str(reason),
                    risk=tool.risk,
                )

        # 3. 风险分级
        if tool.risk == "low":
            return PolicyDecision(allowed=True, reason="低风险工具", risk=tool.risk)

        if tool.risk == "medium":
            if context.get("require_medium_approval"):
                return PolicyDecision(
                    allowed=False,
                    requires_approval=True,
                    reason="策略要求中风险工具审批",
                    risk=tool.risk,
                )
            return PolicyDecision(allowed=True, reason="中风险工具", risk=tool.risk)

        # high：门禁裁决
        gate_mode = context.get("gate_mode") or "ask"
        if self.auto_approve_high_risk or context.get("auto_approve_high_risk") or gate_mode == "allow_all":
            return PolicyDecision(allowed=True, reason="门禁 allow_all：自动批准", risk=tool.risk)
        return PolicyDecision(
            allowed=False,
            requires_approval=True,
            reason=f"高风险工具 {tool.name} 需要人工批准（会话门禁 ask）",
            risk=tool.risk,
        )
