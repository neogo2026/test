# v1/api/core/harness.py
"""
Harness 组合根（DI 容器的手写版）。

内核只组装通用服务；所有业务能力（dev 工具、技能、飞书、用量…）
由 PluginManager 在此之上装载——WordPress 式「小内核 + 插件」架构。
"""

from __future__ import annotations

import asyncio
import logging

from configs.configs import (
    AUTO_APPROVE_HIGH_RISK,
    CONCURRENT_SESSIONS,
    DB_PATH,
)
from core.checkpoints import CheckpointService
from core.context import ContextBuilder
from core.events import EventService
from core.gateway import ModelGateway
from core.hitl import ApprovalService
from core.policy import PolicyEngine
from core.runtime import AgentRuntime
from core.storage import Storage
from core.tools import ToolRegistry

logger = logging.getLogger(__name__)


class Harness:
    def __init__(self):
        self.storage = Storage(DB_PATH)
        self.events = EventService(self.storage)
        self.tools = ToolRegistry()
        self.policy = PolicyEngine(auto_approve_high_risk=AUTO_APPROVE_HIGH_RISK)
        self.gateway = ModelGateway()
        self.context = ContextBuilder(self.storage)
        self.checkpoints = CheckpointService(self.storage)
        self.approvals = ApprovalService(self.storage)
        self.runtime = AgentRuntime(
            storage=self.storage,
            events=self.events,
            context=self.context,
            tools=self.tools,
            policy=self.policy,
            gateway=self.gateway,
            checkpoints=self.checkpoints,
            approvals=self.approvals,
            max_concurrent_sessions=CONCURRENT_SESSIONS,
        )
        self._initialized = False

    async def init(self) -> None:
        if self._initialized:
            return
        await self.storage.init()
        recovered = await self.runtime.recover_interrupted()
        if recovered:
            logger.info("恢复中断 Run %d 个（已标记 PAUSED，可手动续跑）", recovered)
        self._initialized = True


_harness: Harness | None = None
_init_lock = asyncio.Lock()


async def init_harness() -> Harness:
    global _harness
    async with _init_lock:
        if _harness is None:
            _harness = Harness()
        await _harness.init()
    return _harness


async def get_harness() -> Harness:
    if _harness is None:
        return await init_harness()
    return _harness


async def reset_harness() -> None:
    """测试辅助：清空单例，下次重新装配。"""
    global _harness
    _harness = None
