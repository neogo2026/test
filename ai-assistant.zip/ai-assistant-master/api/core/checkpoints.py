# v1/api/core/checkpoints.py
"""
检查点服务：Step 边界保存 Run 控制状态（步数、待审批工具调用、恢复游标）。
"""

from __future__ import annotations

from typing import Any

from core.storage import Storage


class CheckpointService:
    def __init__(self, storage: Storage):
        self.storage = storage

    async def save(self, run_id: str, step: int, state: dict[str, Any]) -> None:
        await self.storage.save_checkpoint(run_id, step, state)

    async def latest(self, run_id: str) -> dict[str, Any] | None:
        return await self.storage.latest_checkpoint(run_id)
