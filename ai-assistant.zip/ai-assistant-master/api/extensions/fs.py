# v1/api/extensions/fs.py
"""本地目录浏览接口（供前端选择工作空间）。仅本机使用。"""
from __future__ import annotations

import os
import string
from pathlib import Path
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from configs.configs import API_PREFIX

router = APIRouter(prefix=API_PREFIX)

_INVALID = set('\\/:*?"<>|')


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


def err(code: int, message: str) -> dict:
    return {"code": code, "message": message}


def _roots() -> list[dict]:
    roots: list[dict] = []
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            drive = Path(f"{letter}:\\")
            try:
                if drive.exists():
                    roots.append({"name": f"{letter}:\\", "path": str(drive)})
            except OSError:
                continue
    else:
        roots.append({"name": "/", "path": "/"})
    home = Path.home()
    try:
        if home.exists():
            roots.append({"name": f"用户目录 · {home.name}", "path": str(home)})
    except OSError:
        pass
    return roots


@router.get("/fs/list")
async def fs_list(path: str = ""):
    """path 为空：返回根（磁盘/用户目录）；否则列出子目录。"""
    if not path.strip():
        return ok({"path": "", "parent": None, "roots": _roots(), "entries": []})
    try:
        target = Path(path).expanduser().resolve()
    except OSError as exc:
        return err(400, f"无效路径: {exc}")
    if not target.exists():
        return err(404, f"路径不存在: {path}")
    if target.is_file():
        target = target.parent
    entries: list[dict] = []
    try:
        children = sorted(target.iterdir(), key=lambda c: c.name.lower())
    except PermissionError:
        return err(403, f"没有权限访问: {target}")
    except OSError as exc:
        return err(400, f"读取失败: {exc}")
    for child in children:
        try:
            if child.is_dir() and not child.name.startswith("$"):
                entries.append({"name": child.name, "path": str(child)})
        except OSError:
            continue
    parent = str(target.parent) if target.parent != target else None
    return ok({"path": str(target), "parent": parent, "roots": _roots(), "entries": entries[:800]})


class MkdirRequest(BaseModel):
    path: str
    name: str


@router.post("/fs/mkdir")
async def fs_mkdir(payload: MkdirRequest):
    name = (payload.name or "").strip()
    if not name or any(ch in name for ch in _INVALID):
        return err(400, "文件夹名非法")
    try:
        base = Path(payload.path).expanduser().resolve()
    except OSError as exc:
        return err(400, f"无效路径: {exc}")
    if not base.exists() or not base.is_dir():
        return err(404, f"父目录不存在: {base}")
    target = base / name
    if target.exists():
        return err(400, "同名文件夹已存在")
    try:
        target.mkdir(parents=True)
    except OSError as exc:
        return err(400, f"创建失败: {exc}")
    return ok({"path": str(target)})
