# v1/api/extensions/ws.py
"""
WebSocket 端点：单条连接多路复用所有会话事件。

下行帧：{session_id, event, payload, time}
上行帧：{type: "ping"} → 回 {type: "pong"}

客户端注册到 EventBus（内存队列 + 专属发送协程），慢客户端只丢自己的帧。
"""

from __future__ import annotations

import json

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    from core.harness import get_harness

    harness = await get_harness()

    async def send_text(frame: str) -> None:
        await ws.send_text(frame)

    key = harness.events.bus.register_client(send_text)
    try:
        await ws.send_text(json.dumps({"session_id": "*", "event": "hello", "payload": {"ok": True}, "time": ""}))
        while True:
            raw = await ws.receive_text()
            try:
                message = json.loads(raw)
            except (ValueError, TypeError):
                continue
            if message.get("type") == "ping":
                await ws.send_text(json.dumps({"session_id": "*", "event": "pong", "payload": {}, "time": ""}))
    except WebSocketDisconnect:
        pass
    finally:
        harness.events.bus.unregister_client(key)
