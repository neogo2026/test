# v1/api/extensions/plugins.py
"""插件管理接口：清单 / 启用 / 停用（WordPress 式 activate / deactivate）。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from configs.configs import API_PREFIX

router = APIRouter(prefix=API_PREFIX)


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


def _manager():
    from main import get_plugin_manager

    return get_plugin_manager()


@router.get("/plugins")
async def list_plugins():
    manager = _manager()
    if not manager:
        return ok([])
    return ok(manager.describe())


@router.post("/plugins/{name}/enable")
async def enable_plugin(name: str):
    manager = _manager()
    if not manager:
        return {"code": 500, "message": "插件管理器未初始化"}
    from main import mount_router_live

    result = await manager.enable(name, mount_router=mount_router_live)
    if not result.get("ok"):
        return {"code": 400, "message": result.get("error", "启用失败")}
    return ok(manager.describe())


@router.post("/plugins/{name}/disable")
async def disable_plugin(name: str):
    manager = _manager()
    if not manager:
        return {"code": 500, "message": "插件管理器未初始化"}
    result = await manager.disable(name)
    return ok({"result": result, "plugins": manager.describe()})
