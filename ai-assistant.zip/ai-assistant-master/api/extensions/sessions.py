# v1/api/extensions/sessions.py
"""
会话核心接口：会话 CRUD / 发消息 / 事件回放 / 审批 / 取消 / 续跑。

发送消息后立即返回（Run 在后台队列推进），前端通过 /ws 实时接收事件流。
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Query
from fastapi.responses import PlainTextResponse

from configs.configs import API_PREFIX, DEFAULT_GATE_MODE, DEFAULT_TENANT_ID, DEFAULT_USER_ID, WORKSPACE_DIR
from configs.models import DEFAULT_MODEL_PROFILE, available_profiles
from core.contracts import ApprovalResolve, MessageRequest, SessionCreate, SessionUpdate
from core.harness import get_harness

router = APIRouter(prefix=API_PREFIX)


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


def err(code: int, message: str) -> dict:
    return {"code": code, "message": message}


def _caps(session: dict) -> dict:
    caps = session.get("capabilities")
    if isinstance(caps, dict):
        return caps
    try:
        return json.loads(caps or "{}")
    except (TypeError, json.JSONDecodeError):
        return {}


def _session_view(session: dict, harness: Any) -> dict:
    return {
        "session_id": session["session_id"],
        "title": session.get("title") or "",
        "status": session.get("status") or "idle",
        "agent_name": session.get("agent_name") or "coder",
        "model_profile": session.get("model_profile") or "",
        "workspace_dir": session.get("workspace_dir") or "",
        "gate_mode": session.get("gate_mode") or DEFAULT_GATE_MODE,
        "source": session.get("source") or "web",
        "hidden": bool(session.get("hidden")),
        "capabilities": _caps(session),
        "created_at": session.get("created_at"),
        "updated_at": session.get("updated_at"),
    }


@router.post("/sessions")
async def create_session(payload: SessionCreate):
    harness = await get_harness()
    session = await harness.runtime.create_session(
        tenant_id=payload.tenant_id or DEFAULT_TENANT_ID,
        user_id=payload.user_id or DEFAULT_USER_ID,
        agent_name=payload.agent_name or "coder",
        title=payload.title or "",
        model_profile=payload.model_profile or "",
        workspace_dir=payload.workspace_dir or "",
        gate_mode=payload.gate_mode or DEFAULT_GATE_MODE,
        source=payload.source or "web",
        capabilities=payload.capabilities or {},
    )
    return ok(_session_view(session, harness))


@router.get("/sessions")
async def list_sessions(include_hidden: bool = Query(False)):
    harness = await get_harness()
    sessions = await harness.storage.list_sessions(include_hidden=include_hidden)
    return ok([_session_view(s, harness) for s in sessions])


@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    view = _session_view(session, harness)
    run = await harness.storage.last_run(session_id)
    if run:
        view["last_run"] = {
            "run_id": run["run_id"],
            "status": run["status"],
            "step_count": run["step_count"],
            "error": run.get("error"),
        }
    return ok(view)


@router.patch("/sessions/{session_id}")
async def update_session(session_id: str, payload: SessionUpdate):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    fields = payload.model_dump(exclude_none=True)
    if not fields:
        return ok(_session_view(session, harness))
    updated = await harness.storage.update_session(session_id, **fields)
    harness.events.bus.publish(session_id, "session.updated", {"session_id": session_id, **fields})
    return ok(_session_view(updated or session, harness))


@router.delete("/sessions/{session_id}")
async def delete_session(session_id: str, purge: bool = Query(False)):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    # 先停掉活跃 Run
    run = await harness.storage.last_run(session_id)
    if run and run["status"] not in ("COMPLETED", "FAILED", "CANCELLED"):
        await harness.runtime.cancel_run(run["run_id"])
    await harness.storage.delete_session(session_id, purge=purge)
    harness.events.bus.publish(session_id, "session.deleted", {"session_id": session_id})
    return ok({"deleted": session_id, "purged": purge})


@router.post("/sessions/{session_id}/unhide")
async def unhide_session(session_id: str):
    harness = await get_harness()
    session = await harness.storage.update_session(session_id, hidden=False)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    return ok(_session_view(session, harness))


@router.post("/sessions/{session_id}/messages")
async def send_message(session_id: str, payload: MessageRequest):
    harness = await get_harness()
    text = (payload.text or "").strip()
    if not text:
        return err(400, "消息不能为空")
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    try:
        run = await harness.runtime.start_run(
            session_id,
            text,
            agent_name=payload.agent_name,
            model_profile=payload.model_profile,
        )
    except ValueError as exc:
        return err(400, str(exc))
    return ok({"run_id": run["run_id"], "status": run["status"], "session_id": session_id})


@router.get("/sessions/{session_id}/messages")
async def get_messages(session_id: str, limit: int = 500):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    messages = await harness.storage.list_messages(session_id, limit=limit)
    return ok(messages)


@router.get("/sessions/{session_id}/events")
async def get_events(session_id: str, after_id: int = Query(0)):
    harness = await get_harness()
    events = await harness.events.list_session_events(session_id, after_id=after_id)
    return ok(events)


@router.post("/sessions/{session_id}/cancel")
async def cancel_session(session_id: str):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    run = await harness.storage.last_run(session_id)
    if not run or run["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
        return ok({"cancelled": False, "note": "没有可取消的任务"})
    result = await harness.runtime.cancel_run(run["run_id"])
    return ok({"cancelled": True, "run": result})


@router.post("/sessions/{session_id}/resume")
async def resume_session(session_id: str):
    harness = await get_harness()
    session = await harness.storage.get_session(session_id)
    if not session:
        return err(404, f"会话不存在: {session_id}")
    run = await harness.storage.last_run(session_id)
    if not run:
        return err(400, "会话还没有执行记录")
    if run["status"] not in ("WAITING_APPROVAL", "PAUSED", "QUEUED"):
        return err(400, f"当前状态 {run['status']} 不可续跑")
    result = await harness.runtime.resume_run(run["run_id"])
    return ok(result)


@router.get("/runs/{run_id}")
async def get_run(run_id: str):
    harness = await get_harness()
    run = await harness.storage.get_run(run_id)
    if not run:
        return err(404, f"Run 不存在: {run_id}")
    return ok(run)


@router.get("/runs/{run_id}/events")
async def get_run_events(run_id: str, after_seq: int = Query(0)):
    harness = await get_harness()
    events = await harness.events.list_run_events(run_id, after_seq=after_seq)
    return ok(events)


@router.get("/runs/{run_id}/artifacts")
async def get_run_artifacts(run_id: str):
    harness = await get_harness()
    return ok(await harness.storage.list_artifacts(run_id))


# ----------------------------------------------------------------------
# 审批
# ----------------------------------------------------------------------
@router.get("/approvals")
async def list_approvals(status: str = Query("pending")):
    harness = await get_harness()
    items = await harness.storage.list_approvals(status=None if status == "all" else status)
    return ok(items)


@router.post("/approvals/{approval_id}/resolve")
async def resolve_approval(approval_id: str, payload: ApprovalResolve):
    harness = await get_harness()
    approval = await harness.approvals.get(approval_id)
    if not approval:
        return err(404, f"审批不存在: {approval_id}")
    if approval["status"] != "pending":
        return err(400, f"该审批已处理（{approval['status']}）")
    resolved = await harness.approvals.resolve(
        approval_id, payload.approved, payload.reason, payload.resolver
    )
    # 批准与拒绝都恢复 Run：拒绝时模型会看到「审批拒绝」的观察并自行收尾
    await harness.runtime.resume_run(approval["run_id"])
    return ok(resolved)


# ----------------------------------------------------------------------
# 元数据
# ----------------------------------------------------------------------
@router.get("/tools")
async def list_tools():
    harness = await get_harness()
    return ok(
        [
            {
                "name": s.name,
                "description": s.description,
                "risk": s.risk,
                "side_effect": s.side_effect,
                "timeout_s": s.timeout_s,
            }
            for s in harness.tools.list_specs()
        ]
    )


@router.get("/agents")
async def list_agents():
    from core.agents import list_agents

    return ok(list_agents())


@router.get("/models")
async def list_models():
    return ok({"default": DEFAULT_MODEL_PROFILE, "profiles": available_profiles()})


@router.get("/workspace/root")
async def workspace_root():
    return ok({"root": str(WORKSPACE_DIR)})


@router.get("/usage/export.csv", response_class=PlainTextResponse)
async def export_usage_csv():
    harness = await get_harness()
    rows = await harness.storage.usage_daily(limit=365)
    lines = ["day,model,session_id,prompt_tokens,completion_tokens,total_tokens,calls"]
    for r in rows:
        lines.append(
            f"{r['day']},{r['model']},{r['session_id']},{r['prompt_tokens']},{r['completion_tokens']},{r['total_tokens']},{r['calls']}"
        )
    return "\n".join(lines)
