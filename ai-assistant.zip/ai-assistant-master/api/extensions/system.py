# v1/api/extensions/system.py
"""系统接口：探针 + 健康检查（密钥脱敏）。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from configs import secrets
from configs.configs import API_PREFIX, APP_NAME, APP_TITLE, APP_VERSION
from configs.configs import WORKSPACE_DIR
from configs.models import DEFAULT_MODEL_PROFILE, available_profiles

router = APIRouter(prefix=API_PREFIX)


def ok(data: Any = None) -> dict:
    return {"code": 200, "data": data}


class WorkspaceSetting(BaseModel):
    path: str


@router.get("/settings/workspace")
async def get_workspace():
    from core.harness import get_harness

    harness = await get_harness()
    saved = await harness.storage.get_setting("workspace.default", "")
    current = saved or str(WORKSPACE_DIR)
    return ok({"path": current, "saved": bool(saved), "default": str(WORKSPACE_DIR)})


@router.put("/settings/workspace")
async def set_workspace(payload: WorkspaceSetting):
    from pathlib import Path

    from core.harness import get_harness

    raw = (payload.path or "").strip()
    if not raw:
        return {"code": 400, "message": "工作空间路径不能为空"}
    try:
        target = Path(raw).expanduser().resolve()
    except OSError as exc:
        return {"code": 400, "message": f"无效路径: {exc}"}
    if not target.exists() or not target.is_dir():
        return {"code": 400, "message": f"目录不存在: {target}"}
    harness = await get_harness()
    await harness.storage.set_setting("workspace.default", str(target))
    return ok({"path": str(target)})


@router.get("/ping")
async def ping():
    return ok("pong")


@router.get("/system/health")
async def health():
    from core.harness import get_harness

    harness = await get_harness()

    def key_info(env_name: str) -> dict:
        value = secrets.get_secret(env_name, "")
        return {
            "configured": bool(value),
            "source": secrets.secret_source(env_name) if value else "default",
            "masked": secrets.mask_secret(value),
        }

    feishu = {"configured": False, "sdk_installed": False}
    try:
        from plugins.builtin.feishu import ws_client

        feishu = {
            "configured": ws_client.is_configured(),
            "sdk_installed": ws_client.sdk_available(),
            **{k: v for k, v in ws_client.status().items()},
        }
    except Exception:  # noqa: BLE001
        pass

    plugins_info: list[dict] = []
    try:
        from main import get_plugin_manager

        manager = get_plugin_manager()
        if manager:
            plugins_info = manager.describe()
    except Exception:  # noqa: BLE001
        pass

    return ok(
        {
            "app": {"name": APP_NAME, "title": APP_TITLE, "version": APP_VERSION},
            "default_model": DEFAULT_MODEL_PROFILE,
            "models": available_profiles(),
            "keys": {
                "MIMO_API_KEY": key_info("MIMO_API_KEY"),
                "DEEPSEEK_API_KEY": key_info("DEEPSEEK_API_KEY"),
                "ZHIPU_API_KEY": key_info("ZHIPU_API_KEY"),
                "FEISHU_APP_ID": key_info("FEISHU_APP_ID"),
                "FEISHU_APP_SECRET": key_info("FEISHU_APP_SECRET"),
            },
            "feishu": feishu,
            "plugins": plugins_info,
            "workspace": {
                "current": await harness.storage.get_setting("workspace.default", "") or str(WORKSPACE_DIR),
                "default": str(WORKSPACE_DIR),
            },
            "tools": len(harness.tools.list_specs()),
            "sessions": await harness.storage.count_sessions(),
        }
    )
