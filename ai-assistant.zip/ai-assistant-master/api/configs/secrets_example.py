# v1/api/configs/secrets_example.py
"""
参考配置模板（可提交）。

使用方法：
1. 复制本文件为同目录下的 secrets_local.py
2. 填入真实密钥（secrets_local.py 已被 .gitignore 忽略，绝不会提交）
3. 或直接使用环境变量 / 上一代 AI助理 的 tool/feishu.local.py（自动兼容读取）

获取渠道：
- 小米MiMo:  https://mimo.xiaomi.com
- DeepSeek:  https://platform.deepseek.com
- 智谱GLM:   https://open.bigmodel.cn
- 飞书开放平台: https://open.feishu.cn （创建自建应用，开通「事件订阅-长连接」+ IM 收发消息权限）
"""

# ---- LLM 供应商（按需填写，至少配一个即可驱动真实模型；不配则使用内置 mock 模式）----
# 小米MiMo：https://mimo.xiaomi.com
# 可选模型：mimo-v2.6-flash / mimo-v2.6-pro（Profile: mimo-v2.6-flash / mimo-v2.6-pro）
MIMO_API_KEY = ""
MIMO_BASE_URL = "https://token-plan-cn.xiaomimimo.com/v1"

# DeepSeek：https://platform.deepseek.com
# 可选模型：deepseek-flash / deepseek-v4-pro（Profile: deepseek-flash / deepseek-pro）
DEEPSEEK_API_KEY = ""
DEEPSEEK_BASE_URL = "https://api.deepseek.com"

# 智谱GLM Coding Plan：https://open.bigmodel.cn
# 可选模型：glm-5.3-flash / glm-5.3
ZHIPU_API_KEY = ""
ZHIPU_BASE_URL = "https://open.bigmodel.cn/api/coding/paas/v4"

# ---- 飞书自建应用（长连接模式，无需公网 IP）----
FEISHU_APP_ID = ""
FEISHU_APP_SECRET = ""
# 长连接模式留空即可，仅 Webhook 模式需要
FEISHU_VERIFICATION_TOKEN = ""
