# v1/api/configs/secrets.py
"""
密钥加载器（本文件可提交，不含真实密钥）。

加载优先级：
1. 环境变量（最高）
2. configs/secrets_local.py（本插件目录私有文件，已被 .gitignore 忽略）
3. ../../tool/feishu.local.py（上一代 AI助理 的本机私有凭据文件，向后兼容）
4. 代码内默认值

仓库只提交 configs/secrets_example.py 作为参考模板。
"""

from __future__ import annotations

import importlib.util
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent          # v1/api
TOOL_LOCAL = BASE_DIR.parent.parent / "tool" / "feishu.local.py"  # ai-assistant/tool/feishu.local.py

_local = None
if (BASE_DIR / "configs" / "secrets_local.py").exists():
    _spec = importlib.util.spec_from_file_location(
        "forge_secrets_local", BASE_DIR / "configs" / "secrets_local.py"
    )
    if _spec and _spec.loader:
        _local = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_local)

_tool_local = None
if TOOL_LOCAL.exists():
    _spec = importlib.util.spec_from_file_location("forge_tool_local", TOOL_LOCAL)
    if _spec and _spec.loader:
        _tool_local = importlib.util.module_from_spec(_spec)
        try:
            _spec.loader.exec_module(_tool_local)
        except Exception:  # noqa: BLE001 - 旧文件语法不兼容时安全降级
            _tool_local = None


def _get(name: str, default: str = "") -> str:
    # 测试/自测隔离开关：FORGE_SECRETS_OFF=1 时忽略所有本地密钥（强制 mock 链路，零消费）
    if os.getenv("FORGE_SECRETS_OFF", "").strip() in {"1", "true", "yes"}:
        return default
    env_value = os.getenv(name)
    if env_value is not None and env_value.strip():
        return env_value.strip()
    for source in (_local, _tool_local):
        if source is not None:
            value = getattr(source, name, None)
            if value is not None and str(value).strip():
                return str(value).strip()
    return default


# ---- LLM 供应商密钥 ----
MIMO_API_KEY = _get("MIMO_API_KEY", "")
MIMO_BASE_URL = _get("MIMO_BASE_URL", "https://token-plan-cn.xiaomimimo.com/v1").rstrip("/")
DEEPSEEK_API_KEY = _get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = _get("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
ZHIPU_API_KEY = _get("ZHIPU_API_KEY", "")
ZHIPU_BASE_URL = _get("ZHIPU_BASE_URL", "https://open.bigmodel.cn/api/coding/paas/v4").rstrip("/")

# ---- 飞书（长连接模式只需要 App ID / Secret）----
FEISHU_APP_ID = _get("FEISHU_APP_ID", "")
FEISHU_APP_SECRET = _get("FEISHU_APP_SECRET", "")
FEISHU_VERIFICATION_TOKEN = _get("FEISHU_VERIFICATION_TOKEN", "")


def get_secret(name: str, default: str = "") -> str:
    return _get(name, default)


def secret_source(name: str) -> str:
    """返回密钥来源（排障用），不返回密钥本身。"""
    if os.getenv(name, "").strip():
        return "env"
    if _local is not None and str(getattr(_local, name, "") or "").strip():
        return "configs/secrets_local.py"
    if _tool_local is not None and str(getattr(_tool_local, name, "") or "").strip():
        return "tool/feishu.local.py"
    return "default"


def is_configured(name: str) -> bool:
    return bool(_get(name, ""))


def mask_secret(value: str | None, visible: int = 4) -> str:
    if not value:
        return ""
    if len(value) <= visible * 2:
        return "*" * len(value)
    return value[:visible] + "*" * (len(value) - visible * 2) + value[-visible:]
