# v1/api/configs/models.py
"""
模型 Profile 注册表。

供应商差异只出现在这里和 adapters/providers 中；内核与业务不写 if model == ...。
profile.provider 指向适配器名；api_key_env 指明取哪个密钥（由 secrets 加载器解析）。
未配置任何 Key 时回退 mock，保证 clone 后零密钥可跑通全链路。

内置 Profile：
- mimo-v2.6-flash      -> 小米 MiMo 快模型（默认）
- mimo-v2.6-pro        -> 小米 MiMo 强模型（fallback 到 flash）
- deepseek-flash       -> deepseek-flash（快）
- deepseek-pro         -> deepseek-v4-pro（更强推理，fallback 到 flash）
- glm-5.3-flash        -> 智谱 GLM Coding Plan 快模型
- glm-5.3              -> 智谱 GLM Coding Plan 强模型
- mock                 -> 离线确定性 mock
"""

import os
import time

from configs import secrets
from core.contracts import ModelProfile

MIMO_BASE_URL = secrets.MIMO_BASE_URL
DEEPSEEK_BASE_URL = secrets.DEEPSEEK_BASE_URL
ZHIPU_BASE_URL = secrets.ZHIPU_BASE_URL

_DS_MODEL = os.getenv("FORGE_DEEPSEEK_MODEL", "deepseek-flash").strip()
_DS_PRO_MODEL = os.getenv("FORGE_DEEPSEEK_PRO_MODEL", "deepseek-v4-pro").strip()
# 思考模式（参考 asr-tts/llm/deepseek-flash.py：extra_body={"thinking": {"type": "enabled"}}）
# 默认关闭：思考型输出含 reasoning_content，与工具调用回传协议存在兼容成本，且更耗 token
_DS_THINKING = os.getenv("FORGE_DEEPSEEK_THINKING", "0").strip() in {"1", "true", "yes"}
_DS_EXTRA = {"thinking": {"type": "enabled"}} if _DS_THINKING else {}


def _zhipu_model(default: str) -> str:
    return os.getenv("FORGE_ZHIPU_MODEL", default).strip()


def _mimo_model(default: str) -> str:
    return os.getenv("FORGE_MIMO_MODEL", default).strip()


def _mimo_pro_model(default: str) -> str:
    return os.getenv("FORGE_MIMO_PRO_MODEL", default).strip()


# ?????low / medium / high?MiMo OpenAI ?????? reasoning_effort?
_MIMO_REASONING = os.getenv("FORGE_MIMO_REASONING", "").strip().lower()
_MIMO_EXTRA = {"reasoning_effort": _MIMO_REASONING} if _MIMO_REASONING else {}


if secrets.MIMO_API_KEY:
    DEFAULT_MODEL_PROFILE = "mimo-v2.6-flash"
elif secrets.DEEPSEEK_API_KEY:
    DEFAULT_MODEL_PROFILE = "deepseek-flash"
elif secrets.ZHIPU_API_KEY:
    DEFAULT_MODEL_PROFILE = "glm-5.3-flash"
else:
    DEFAULT_MODEL_PROFILE = "mock"

# 显式覆盖（最高优先级）：FORGE_MODEL_PROFILE=mock 可强制 mock 链路（自测/离线演示）
DEFAULT_MODEL_PROFILE = os.getenv("FORGE_MODEL_PROFILE", DEFAULT_MODEL_PROFILE).strip() or DEFAULT_MODEL_PROFILE

MODEL_PROFILES: dict[str, ModelProfile] = {
    "mimo-v2.6-flash": ModelProfile(
        name="mimo-v2.6-flash",
        provider="openai",
        model=_mimo_model("mimo-v2.6-flash"),
        base_url=MIMO_BASE_URL,
        api_key_env="MIMO_API_KEY",
        context_window=1_048_576,
        max_output=131_072,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        vision=True,
        timeout_s=180,
        fallback=[],
        extra_body=_MIMO_EXTRA,
    ),
    "mimo-v2.6-pro": ModelProfile(
        name="mimo-v2.6-pro",
        provider="openai",
        model=_mimo_pro_model("mimo-v2.6-pro"),
        base_url=MIMO_BASE_URL,
        api_key_env="MIMO_API_KEY",
        context_window=1_048_576,
        max_output=131_072,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        vision=True,
        timeout_s=180,
        fallback=["mimo-v2.6-flash"],
        extra_body=_MIMO_EXTRA,
    ),
    "mock": ModelProfile(
        name="mock",
        provider="mock",
        model="mock-deterministic",
        context_window=32_000,
        max_output=4_096,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        timeout_s=10,
        fallback=[],
    ),
    "deepseek-flash": ModelProfile(
        name="deepseek-flash",
        provider="openai",
        model=_DS_MODEL,
        base_url=DEEPSEEK_BASE_URL,
        api_key_env="DEEPSEEK_API_KEY",
        context_window=1_048_576,
        max_output=393_216,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        timeout_s=180,
        fallback=[],
        extra_body=_DS_EXTRA,
    ),
    "deepseek-pro": ModelProfile(
        name="deepseek-pro",
        provider="openai",
        model=_DS_PRO_MODEL,
        base_url=DEEPSEEK_BASE_URL,
        api_key_env="DEEPSEEK_API_KEY",
        context_window=1_048_576,
        max_output=393_216,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        timeout_s=180,
        fallback=["deepseek-flash"],
        extra_body=_DS_EXTRA,
    ),
    "glm-5.3-flash": ModelProfile(
        name="glm-5.3-flash",
        provider="openai",
        model=_zhipu_model("glm-5.3-flash"),
        base_url=ZHIPU_BASE_URL,
        api_key_env="ZHIPU_API_KEY",
        context_window=1_000_000,
        max_output=128_000,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        timeout_s=180,
        fallback=[],
    ),
    "qwen35-2b-rsi": ModelProfile(
        name="qwen35-2b-rsi",
        provider="local",
        model="qwen3.5-2b-rsi",
        base_url=os.getenv("FORGE_RSI_MODEL_URL", "http://127.0.0.1:9065/v1").rstrip("/"),
        api_key_env="LOCAL_LLM_API_KEY",
        context_window=32_768,
        max_output=4_096,
        stream=True,
        tool_call="native",
        parallel_tool_calls=False,
        timeout_s=180,
        fallback=[],
        extra_body={"adapter": os.getenv("FORGE_RSI_ADAPTER", "sft")},
    ),
    "glm-5.3": ModelProfile(
        name="glm-5.3",
        provider="openai",
        model=_zhipu_model("glm-5.3"),
        base_url=ZHIPU_BASE_URL,
        api_key_env="ZHIPU_API_KEY",
        context_window=1_000_000,
        max_output=128_000,
        stream=True,
        tool_call="native",
        parallel_tool_calls=True,
        timeout_s=180,
        fallback=["glm-5.3-flash"],
    ),
}


def get_profile(name: str | None) -> ModelProfile:
    """按名称获取模型 Profile，未知名称回退默认。"""
    return MODEL_PROFILES.get(name or "", MODEL_PROFILES[DEFAULT_MODEL_PROFILE])


# 本地 RSI 模型服务探测结果缓存：避免每次 /api/models 都发探测请求
_LOCAL_PROBE_CACHE = {"running": False, "ts": 0.0, "detail": {}}
_LOCAL_PROBE_TTL_S = 10.0


def probe_local_rsi(force: bool = False) -> dict:
    """探测本地 Qwen3.5-2B-RSI 服务（:9065）是否在运行。

    探测其 /api/rsi/health；结果短缓存（TTL 10s），
    服务未启动时最多增加一次 0.8s 超时，不影响模型列表响应。
    """
    import httpx

    now = time.time()
    if not force and (now - float(_LOCAL_PROBE_CACHE["ts"])) < _LOCAL_PROBE_TTL_S:
        return {"running": bool(_LOCAL_PROBE_CACHE["running"]), **dict(_LOCAL_PROBE_CACHE["detail"])}

    profile = MODEL_PROFILES["qwen35-2b-rsi"]
    base = (profile.base_url or "http://127.0.0.1:9065/v1").rstrip("/")
    if base.endswith("/v1"):
        base = base[: -len("/v1")]
    running = False
    detail: dict = {}
    try:
        resp = httpx.get(f"{base}/api/rsi/health", timeout=0.8)
        if resp.status_code == 200:
            payload = resp.json()
            if payload.get("code") == 200:
                running = True
                detail = payload.get("data") or {}
    except Exception:  # noqa: BLE001 - 本地服务未启动是常态，静默处理
        running = False
    _LOCAL_PROBE_CACHE.update({"running": running, "ts": now, "detail": detail})
    return {"running": running, **detail}


def available_profiles() -> list[dict]:
    """前端模型选择器数据：仅展示已配置密钥的真实渠道，不展示 mock。

    mock 仍保留在 MODEL_PROFILES 中，用于零密钥自测/离线演示；
    仅当没有任何真实渠道可用时，才把它作为最后的占位选项返回，
    避免全新环境里选择器为空。

    本地 qwen35-2b-rsi：服务在运行（自动探测）或显式设置
    FORGE_RSI_MODEL_ENABLED=1 时出现在选择器中。
    """
    result = []
    local_probe = probe_local_rsi()
    local_enabled = local_probe.get("running") or os.getenv(
        "FORGE_RSI_MODEL_ENABLED", "0"
    ).strip() in {"1", "true", "yes"}
    for profile in MODEL_PROFILES.values():
        if profile.name == "mock":
            continue
        if profile.provider == "openai":
            if not secrets.get_secret(profile.api_key_env or ""):
                continue
        # local：服务在运行（自动探测）或显式开启时才展示；附带加载状态供前端提示
        if profile.provider == "local":
            if not local_enabled:
                continue
            result.append(
                {
                    "name": profile.name,
                    "provider": profile.provider,
                    "model": profile.model,
                    "context_window": profile.context_window,
                    "rsi_model_loaded": bool(local_probe.get("loaded")),
                    "rsi_adapter": local_probe.get("current_adapter") or "",
                }
            )
            continue
        result.append(
            {
                "name": profile.name,
                "provider": profile.provider,
                "model": profile.model,
                "context_window": profile.context_window,
            }
        )
    if not result:
        mock = MODEL_PROFILES["mock"]
        result.append(
            {
                "name": mock.name,
                "provider": mock.provider,
                "model": mock.model,
                "context_window": mock.context_window,
            }
        )
    return result
