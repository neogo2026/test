﻿# v1/api/configs/configs.py
"""
AI助理 全局配置。

所有路径与关键参数均支持环境变量覆盖（FORGE_* 前缀），便于 Windows / Linux 部署。
密钥不在此处出现：统一由 configs/secrets.py 加载。
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent  # v1/api

APP_NAME = "AI助理"
APP_TITLE = "AI助理 · AI 编程全能工作台"
APP_VERSION = "1.0.0"

HOST = os.getenv("FORGE_HOST", "127.0.0.1")
PORT = int(os.getenv("FORGE_PORT", "8036"))

API_PREFIX = "/api"


def _path_from_env(name: str, default: Path) -> Path:
    value = os.getenv(name, "").strip()
    return Path(value).expanduser().resolve() if value else default


DATA_DIR = _path_from_env("FORGE_DATA_DIR", BASE_DIR / "data")
DB_PATH = _path_from_env("FORGE_DB_PATH", DATA_DIR / "forge.db")
WORKSPACE_DIR = _path_from_env("FORGE_WORKSPACE_DIR", DATA_DIR / "workspace")
SKILLS_DIR = _path_from_env("FORGE_SKILLS_DIR", BASE_DIR / "skills")
PLUGINS_STATE_PATH = _path_from_env("FORGE_PLUGINS_STATE", DATA_DIR / "plugins.json")

DEFAULT_TENANT_ID = os.getenv("FORGE_TENANT_ID", "default")
DEFAULT_USER_ID = os.getenv("FORGE_USER_ID", "local")

# ---- Agent 预算 ----
MAX_STEPS = int(os.getenv("FORGE_MAX_STEPS", "40"))
MAX_CONTEXT_TOKENS = int(os.getenv("FORGE_MAX_CONTEXT_TOKENS", "60000"))
TOOL_TIMEOUT_S = float(os.getenv("FORGE_TOOL_TIMEOUT_S", "60"))
SHELL_TIMEOUT_S = float(os.getenv("FORGE_SHELL_TIMEOUT_S", "180"))
CONCURRENT_SESSIONS = int(os.getenv("FORGE_CONCURRENT_SESSIONS", "5"))

# 门禁：ask（高风险工具需人工批准，默认）/ allow_all（自动批准，信任环境使用）
DEFAULT_GATE_MODE = os.getenv("FORGE_GATE_MODE", "ask")
AUTO_APPROVE_HIGH_RISK = os.getenv("FORGE_AUTO_APPROVE_HIGH_RISK", "0").strip() in {"1", "true", "yes"}

# 飞书长连接总开关
FEISHU_ENABLED = os.getenv("FORGE_FEISHU_ENABLED", "1").strip() not in {"0", "false", "no"}
