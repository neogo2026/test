# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from uvicorn import run
from configs.modules import modules
import traceback

app = FastAPI()

# 允许前端跨域调用
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有来源,也可以设置具体的来源列表
    allow_credentials=True,
    allow_methods=["*"],  # 允许所有 HTTP 方法
    allow_headers=["*"],  # 允许所有请求头
)

# 自动加载模块路由，处理导入错误
loaded_modules = []
for module_name, module_path in modules.items():
    try:
        module = __import__(module_path, fromlist=['router'])
        app.include_router(module.router)
        loaded_modules.append(module_name)
        print(f"[OK] 成功加载模块: {module_name}")
    except Exception as e:
        print(f"[ERROR] 加载模块失败: {module_name}")
        print(f"错误详情: {e}")
        traceback.print_exc()
        print(f"跳过模块: {module_name}，服务将继续运行其他功能")

print(f"已成功加载 {len(loaded_modules)}/{len(modules)} 个模块: {loaded_modules}")

if __name__ == '__main__':
    run(app, host='0.0.0.0', port=8060)
