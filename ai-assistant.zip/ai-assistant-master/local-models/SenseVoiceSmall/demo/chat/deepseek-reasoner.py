# demo/deepseek-reasoner.py
import os
from openai import OpenAI

client = OpenAI(
    api_key="sk-1acb05d0a9aa4c4f8c24192ce135cfe5",
    base_url="https://api.deepseek.com")

response = client.chat.completions.create(
    model="deepseek-reasoner", # 支持 deepseek-chat 或 deepseek-reasoner
    messages=[
        {"role": "system", "content": "你是一个有用的助手"},
        {"role": "user", "content": "你好，你叫什么名字"},
    ],
    stream=False
)

print(response.choices[0].message.content)