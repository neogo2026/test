# DeepSeek FastAPI 服务

将 DeepSeek API 封装为 FastAPI 服务，提供 RESTful 接口访问。

## 文件说明

- `deepseek-fastapi.py` - FastAPI 服务端，提供 DeepSeek API 接口
- `deepseek-api.py` - 客户端库，用于访问 FastAPI 服务
- `requirements.txt` - 依赖包列表
- `test_api.py` - 测试脚本

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 启动 FastAPI 服务

```bash
python deepseek-fastapi.py
```

服务将在 `http://localhost:8000` 启动。

### 2. 使用客户端访问

#### 方法一：直接运行客户端示例

```bash
python deepseek-api.py
```

#### 方法二：在代码中使用客户端库

```python
from deepseek_api import DeepSeekAPIClient

# 创建客户端实例
client = DeepSeekAPIClient(base_url="http://localhost:8000")

# 健康检查
health = client.health_check()
print(f"服务状态: {health}")

# 获取可用模型
models = client.get_models()
print(f"可用模型: {models}")

# 发送聊天请求
messages = [
    {"role": "system", "content": "你是一个有用的助手"},
    {"role": "user", "content": "你好，你叫什么名字"}
]

response = client.chat(
    messages=messages,
    model="deepseek-chat",  # 或 "deepseek-reasoner"
    temperature=0.7,
    max_tokens=1000
)

print(f"模型: {response['model']}")
print(f"回复: {response['content']}")
if response.get('usage'):
    print(f"使用情况: {response['usage']}")
```

## API 接口

### 健康检查
```
GET /
```

### 获取模型列表
```
GET /models
```

### 聊天接口
```
POST /chat
```

请求体：
```json
{
  "model": "deepseek-chat",
  "messages": [
    {"role": "system", "content": "你是一个有用的助手"},
    {"role": "user", "content": "你好"}
  ],
  "stream": false,
  "temperature": 0.7,
  "max_tokens": 1000
}
```

响应：
```json
{
  "content": "你好！我是DeepSeek，一个AI助手。",
  "model": "deepseek-chat",
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 15,
    "total_tokens": 25
  }
}
```

## 配置说明

默认使用 DeepSeek API 密钥：`sk-1acb05d0a9aa4c4f8c24192ce135cfe5`

如需更换 API 密钥，请修改 `deepseek-fastapi.py` 文件中的 `api_key` 参数。

## 测试

运行测试脚本检查配置：

```bash
python test_api.py
```

## 注意事项

1. 确保已安装所有依赖包
2. 启动服务前确保网络连接正常
3. API 密钥有使用限制，请合理使用
4. 服务默认运行在 8000 端口，如需更改请修改 `deepseek-fastapi.py` 文件
