# llms/deepseek-fastapi.py
# FastAPI 版本的 DeepSeek API 服务
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
import json
import time
import uuid
from typing import List, Optional

app = FastAPI(title="DeepSeek FastAPI Service")

# 添加 CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有来源，生产环境应该限制
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化 OpenAI 客户端
client = OpenAI(
    api_key="sk-1acb05d0a9aa4c4f8c24192ce135cfe5",
    base_url="https://api.deepseek.com"
)

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    data_source: Optional[str] = None
    model: Optional[str] = "deepseek-chat"
    messages: List[ChatMessage]

@app.post("/deepseek_chat")
async def deepseek_chat(request: ChatRequest):
    """
    处理 DeepSeek 聊天请求，返回 SSE 流式响应
    响应格式与 deepseek-api.py 期望的格式一致
    """
    try:
        # 准备消息，添加系统提示
        messages = [{"role": "system", "content": "你是一个有用的助手"}] + [
            {"role": msg.role, "content": msg.content} for msg in request.messages
        ]
        
        # 调用 DeepSeek API
        response = client.chat.completions.create(
            model=request.model or "deepseek-chat",
            messages=messages,
            stream=True
        )
        
        # 生成会话 ID
        session_id = f"chatcmpl-{uuid.uuid4()}"
        created_time = int(time.time())
        
        async def generate_sse():
            """生成 SSE 格式的响应"""
            for chunk in response:
                if chunk.choices and chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    
                    # 创建 SSE 格式的数据
                    data = {
                        "content": content
                    }
                    
                    # 输出 SSE 格式: data: {json}\n\n
                    yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
                
                # 检查是否结束
                if chunk.choices and chunk.choices[0].finish_reason:
                    # 发送结束标记
                    yield f"data: [DONE]\n\n"
        
        return StreamingResponse(
            generate_sse(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Content-Encoding": "none",  # 不压缩，以便客户端可以实时接收
            }
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"调用 DeepSeek API 失败: {str(e)}")

@app.get("/")
async def root():
    return {"message": "DeepSeek FastAPI Service is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, log_level="info")
