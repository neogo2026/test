# llms/deepseek-api.py
import http.client
import json
import gzip
from io import BytesIO
import sys

# 设置标准输出编码为 UTF-8
sys.stdout.reconfigure(encoding='utf-8') if hasattr(sys.stdout, 'reconfigure') else None

conn = http.client.HTTPConnection("127.0.0.1:8001") # 正式环境
# 使用json.dumps()来确保payload是一个有效的JSON格式字符串
# 然后使用encode('utf-8')来将其转换为字节对象
payload = json.dumps({
        "data_source": "byd",
        "model": "",
        "messages": [
                {
                        "role": "user",
                        "content": "天神之眼"
                },
                {
                        "role": "assistant",
                        "content": "你好，有什么可以帮到您？"
                },
                {
                        "role": "user",
                        "content": "汉ev"
                }
        ]
}).encode('utf-8')
headers = {
    'Content-Type': "application/json"
}
# 现在payload是一个字节对象，可以正确地发送请求
conn.request("POST", "/deepseek_chat", payload, headers)
res = conn.getresponse()

# 读取并输出响应数据（SSE格式）
try:
    while True:
        line = res.readline()
        if not line:
            break
        # 解码为字符串
        try:
            decoded_line = line.decode('utf-8').rstrip('\n\r')
        except UnicodeDecodeError:
            # 如果UTF-8解码失败，尝试其他编码
            decoded_line = line.decode('latin-1').rstrip('\n\r')
        
        # 输出行
        if decoded_line:  # 跳过空行
            print(decoded_line)
except Exception as e:
    print(f"读取响应时出错: {e}")

# 关闭连接
conn.close()
