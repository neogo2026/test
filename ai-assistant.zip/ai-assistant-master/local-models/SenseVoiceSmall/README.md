# SenseVoiceSmall 多语言语音理解模型服务

基于阿里云通义实验室的 SenseVoice-Small 模型，提供多语言语音识别、情感识别和音频事件检测的API服务。


## Python虚拟环境

```
python -m venv env1
env1\Scripts\activate
source env1/bin/activate
```


### Docker部署（可选）

```
docker build -t sensevoicesmall .
docker run -d --network=host --restart=always --name sensevoicesmall sensevoicesmall

# docker run -d -p 8060:8060 --restart=always --name sensevoicesmall sensevoicesmall
```
