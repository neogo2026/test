from .env import env

db_config = {
    'local': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'Az123456-',
        'database': 'voice'
    },
    'dev': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'Az123456-',
        'database': 'voice'
    },
    'production': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'Az123456-',
        'database': 'voice'
    },
}

# 根据环境选择配置
db_config = db_config[env]