# voice-algorithm-audio-foundation/configs/modules.py
modules = {
    "demo.setup": "extensions.demo.setup",
    "asr.sensevoice_small": "extensions.asr.sensevoice_small",
}
