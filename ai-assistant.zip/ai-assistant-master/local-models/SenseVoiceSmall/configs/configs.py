import os
from configs.env import env  # 导入环境变量

# 根据环境变量设置路由前缀
if env == "local":
    LOCAL_GETEWAY = "yes"
else:
    LOCAL_GETEWAY = "no"

if LOCAL_GETEWAY == "yes":
    prefix = ""
else:
    prefix = ""
