# configs/env.py
from common.utils import get_ip

# 生产环境IP列表
production_ips = ['127.0.0.11']
# 开发环境IP列表
development_ips = ['127.0.0.20']
# UAT环境IP列表
uat_ips = ['127.0.0.21']

current_ip = get_ip()

if current_ip in production_ips:
    # 生产环境配置
    env = 'production'

    redis_host = '127.0.0.1'
    redis_port = '6379'
    redis_password='redis-password'
    redis_db = 1
    
elif current_ip in development_ips:
    # 开发环境配置
    env = 'dev'

    redis_host = '127.0.0.1'
    redis_port = '6379'
    redis_password='redis-password'
    redis_db = 0
    
else:
    # 本地环境配置
    env = 'local'

    redis_host = '127.0.0.1'
    redis_port = '6379'
    redis_password='redis-password'
    redis_db = 0
    