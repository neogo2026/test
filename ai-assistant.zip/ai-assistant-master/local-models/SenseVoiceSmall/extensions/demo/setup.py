# api/extensions/demo/setup.py
from fastapi import APIRouter
from pydantic import BaseModel
from configs.configs import prefix

router = APIRouter(prefix=prefix)


class RequestData(BaseModel):
    text: str


@router.get("/demo")
async def root():
    return {"code": 200, "result": "部署成功"}
