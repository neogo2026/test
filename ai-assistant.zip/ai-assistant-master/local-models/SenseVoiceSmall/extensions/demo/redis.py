# extensions/redis_demo/setup.py
from fastapi import APIRouter, HTTPException
import redis
from configs.configs import prefix
import uuid
from pydantic import BaseModel

router = APIRouter(prefix=prefix)

# 初始化Redis连接
redis_client = redis.Redis(
    host='127.0.0.1',
    port=6379,
    password='redis-password',
    decode_responses=True,  # 自动解码返回字符串
    socket_connect_timeout=5
)

class RedisData(BaseModel):
    key: str = None
    value: str

@router.post("/redis/create")
async def create_key(data: RedisData):
    """
    创建Redis key，有效时间30分钟
    """
    try:
        # 如果没有提供key，生成一个随机的
        if not data.key:
            data.key = f"temp_key_{uuid.uuid4().hex[:8]}"
        
        # 设置key-value，有效时间1800秒（30分钟）
        result = redis_client.setex(data.key, 1800, data.value)
        
        if result:
            return {
                "code": 200, 
                "message": "Key created successfully", 
                "key": data.key, 
                "ttl": 1800
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create key")
            
    except redis.RedisError as e:
        raise HTTPException(status_code=500, detail=f"Redis error: {str(e)}")

@router.get("/redis/info")
async def redis_info():
    """
    获取Redis服务器信息
    """
    try:
        info = redis_client.info()
        return {
            "code": 200,
            "redis_version": info.get('redis_version'),
            "connected_clients": info.get('connected_clients'),
            "used_memory": info.get('used_memory_human'),
            "db_size": info.get('db0', {}).get('keys', 0)
        }
    except redis.RedisError as e:
        raise HTTPException(status_code=500, detail=f"Redis error: {str(e)}")