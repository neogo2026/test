# voice-backend-main/extensions/chat/chat.py
# 语音机器人-关键链路
# 1. ASR - MRCPv2 协议
# 2. 用户权限认证
# 3. 意图识别
# 4. AI工作流-场景识别
# 5. 机器人知识库
# 6. LLM（qwen2.5）
# 7. edge-tts MRCPv2 协议

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from configs.configs import prefix
from extensions.llm.qwen2_5 import llm_stream
from extensions.chat.functions import text_to_speech_stream

router = APIRouter(prefix=prefix)


class RequestData(BaseModel):
    messages: list


def process_chat_messages(messages):
    """
    处理聊天消息的共享函数
    包括ASR模型环节的步骤1-5
    """
    # 1.接收 ASR 是不是的文本
    # messages = messages  # 已传入

    # 2. 用户权限（30ms内，200ms超时处理）：调用用户权限识别接口

    # 3. 意图情绪（100ms内，250ms超时处理）：调用意图情绪识别函数，函数包括算法规则+算法模型

    # 4. AI工作流（300ms内，500ms超时处理）：调用AI工作流函数，函数包括场景识别算法+步骤定位算法

    # 5. RAG（150ms内，300ms超时处理）：调用RAG检索函数+向量模型
    # - 选项1：RAG命中高精度FQA，直接出首token
    # - 选项2：RAG没有命中高精度FQA，命中高精度RAG（配置引用分片），进入大模型环节
    # - 选项3：RAG没有命中高精度FQA，没有命中高精度RAG（配置引用分片），进入大模型环节

    return messages

# 包括ASR+TTS，完整对话过程出首token：2秒内
# 当前文本完整处理过程，目标在1秒以内出首token，严格控制在1.5秒出首token
@router.post("/chat")
async def root(request: RequestData):
    # 调用共享函数处理消息
    messages = process_chat_messages(request.messages)

    # 6. 大模型（500ms内，1000ms超时处理）：输出 TTS 需要的流式文本
    stream_text = ""
    for chunk in llm_stream(messages):
        stream_text += chunk
    
    # （子项目外）TTS模型环节，上面会传入：意图情绪+流式文本
    # 先采用edge-tts
    
    return {"code": 200, "result": stream_text}


@router.post("/chat_tts")
async def chat_with_tts(request: RequestData):
    """
    聊天接口，返回流式语音响应
    
    Args:
        request: 包含 messages 列表的请求数据
    
    Returns:
        StreamingResponse: 流式音频响应
    """
    # 调用共享函数处理消息
    messages = process_chat_messages(request.messages)

    # 6. 大模型（500ms内，1000ms超时处理）：输出 TTS 需要的流式文本
    stream_text = ""
    for chunk in llm_stream(messages):
        stream_text += chunk
    
    # 7. TTS模型环节：将文本转换为流式语音
    return StreamingResponse(
        text_to_speech_stream(stream_text),
        media_type="audio/mpeg",
        headers={
            "Content-Disposition": "attachment; filename=response.mp3",
            "Transfer-Encoding": "chunked"
        }
    )
