# voice-backend-main/extensions/chat/chat_text.py
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from configs.configs import prefix
# from extensions.llm.llm_it_qwen3_stream import llm_stream
from extensions.llm.qwen2_5 import llm_stream
from extensions.chat.chat import process_chat_messages

router = APIRouter(prefix=prefix)


class RequestData(BaseModel):
    messages: list

# 包括ASR+TTS，完整对话过程出首token：2秒内
# 当前文本完整处理过程，目标在1秒以内出首token，严格控制在1.5秒出首token
@router.post("/chat_text")
async def root(request: RequestData):
    # 调用共享函数处理消息
    messages = process_chat_messages(request.messages)

    async def stream_generator():
        # 6. 配合前端 流式文本
        for chunk in llm_stream(messages):
            import json
            yield f"data: {json.dumps({'content': chunk}, ensure_ascii=False)}\n\n"
        yield f"data: {json.dumps({'done': True}, ensure_ascii=False)}\n\n"

    return StreamingResponse(stream_generator(), media_type="text/event-stream")
