# voice-backend-main/extensions/chat/functions.py
# 语音机器人-辅助函数模块

import edge_tts
import asyncio
import os
from datetime import datetime
from pathlib import Path


async def _save_audio_async(audio_data: bytes, file_path: str):
    """
    异步保存音频数据到文件
    
    Args:
        audio_data: 音频二进制数据
        file_path: 保存路径
    """
    try:
        # 确保目录存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        # 异步写入文件
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: open(file_path, 'wb').write(audio_data))
    except Exception as e:
        # 保存失败不影响流式输出，仅记录错误
        print(f"保存音频文件失败: {e}")


async def text_to_speech_stream(text: str, voice: str = "zh-CN-XiaoxiaoNeural", save_audio: bool = True):
    """
    使用 edge-tts 将文本转换为流式语音
    
    Args:
        text: 要转换的文本
        voice: 语音模型，默认使用中文女声
        save_audio: 是否保存音频文件，默认为True
    
    Yields:
        bytes: 音频数据块
    """
    communicate = edge_tts.Communicate(text, voice)
    
    # 收集音频数据用于保存（异步保存，不阻塞流式输出）
    audio_chunks = []
    
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio_data = chunk["data"]
            audio_chunks.append(audio_data)
            yield audio_data
    
    # 流式输出完成后，异步保存音频文件
    if save_audio and audio_chunks:
        # 生成保存路径: resources/tts/年-月-日/时间戳.wav
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        timestamp = int(now.timestamp() * 1000)  # 毫秒级时间戳
        
        # 构建完整路径
        base_dir = Path(__file__).parent.parent.parent / "resources" / "tts" / date_str
        file_path = base_dir / f"{timestamp}.wav"
        
        # 合并所有音频块
        full_audio = b"".join(audio_chunks)
        
        # 异步保存，不阻塞响应
        asyncio.create_task(_save_audio_async(full_audio, str(file_path)))
