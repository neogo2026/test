# asr-tts/asr/SenseVoiceSmall/extensions/chat/chat.py

asr-tts/asr/SenseVoiceSmall/extensions/asr/sensevoice_small.py接收前端语音，进行识别，
然后调用