# voice-backend-main/extensions/llm/deepseek-stream.py
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
import os
from openai import OpenAI
from configs.configs import prefix
import json

router = APIRouter(prefix=prefix)


class ChatMessage(BaseModel):
    role: str  # "system", "user", "assistant"
    content: str


class ChatRequest(BaseModel):
    data_source: Optional[str] = ""
    model: str = "deepseek-chat"  # 支持 deepseek-chat 或 deepseek-reasoner
    messages: List[ChatMessage]


@router.post("/deepseek_chat")
async def deepseek_chat_stream(request: ChatRequest):
    """
    DeepSeek 流式对话接口
    支持实时流式输出，前端通过 SSE 接收
    """
    # 从环境变量获取 API 密钥，如果没有则使用默认值
    api_key = os.getenv("DEEPSEEK_API_KEY", "sk-1acb05d0a9aa4c4f8c24192ce135cfe5")
    
    # 初始化 OpenAI 客户端（配置为 DeepSeek API）
    client = OpenAI(
        api_key=api_key,
        base_url="https://api.deepseek.com"
    )
    
    # 准备消息格式
    messages = [{"role": msg.role, "content": msg.content} for msg in request.messages]
    
    try:
        # 调用 DeepSeek API 进行流式对话，设置超时
        import asyncio
        from functools import partial
        
        # 使用线程池执行同步的OpenAI调用，避免阻塞事件循环
        import concurrent.futures
        
        def create_stream():
            return client.chat.completions.create(
                model=request.model,
                messages=messages,
                stream=True,  # 启用流式输出
                max_tokens=512,  # 减少最大token数，加快响应速度
                temperature=0.7
            )
        
        # 创建流式响应生成器
        async def generate():
            # 立即发送一个空数据包，让前端知道连接已建立
            yield f"data: {{}}\n\n"
            
            try:
                # 使用线程池执行同步调用
                loop = asyncio.get_event_loop()
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    # 创建流
                    response = await loop.run_in_executor(pool, create_stream)
                    
                    # 处理流式响应
                    for chunk in response:
                        if chunk.choices and chunk.choices[0].delta.content is not None:
                            # 构建 SSE 格式数据
                            data = json.dumps({
                                "content": chunk.choices[0].delta.content,
                                "finish_reason": chunk.choices[0].finish_reason
                            })
                            yield f"data: {data}\n\n"
                        
                        # 添加小延迟，避免过快
                        await asyncio.sleep(0.01)
                    
                    # 发送结束标记
                    yield "data: [DONE]\n\n"
                    
            except asyncio.TimeoutError:
                yield f"data: {json.dumps({'content': '请求超时，请稍后重试', 'finish_reason': 'timeout'})}\n\n"
                yield "data: [DONE]\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'content': f'API调用错误: {str(e)}', 'finish_reason': 'error'})}\n\n"
                yield "data: [DONE]\n\n"
        
        # 返回流式响应
        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",  # 禁用 Nginx 缓冲
                "Transfer-Encoding": "chunked"
            }
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DeepSeek API 调用失败: {str(e)}")


@router.get("/deepseek_chat/health")
async def health_check():
    """健康检查接口"""
    return {
        "code": 200,
        "status": "healthy",
        "service": "deepseek-chat-stream",
        "model": "deepseek-chat"
    }


@router.get("/deepseek_chat/info")
async def api_info():
    """API 信息接口"""
    return {
        "code": 200,
        "name": "DeepSeek Chat Stream API",
        "version": "1.0.0",
        "description": "基于 FastAPI 的 DeepSeek 流式对话接口",
        "endpoints": {
            "stream_chat": "POST /deepseek_chat",
            "health_check": "GET /deepseek_chat/health",
            "api_info": "GET /deepseek_chat/info"
        },
        "supported_models": ["deepseek-chat", "deepseek-reasoner"]
    }
