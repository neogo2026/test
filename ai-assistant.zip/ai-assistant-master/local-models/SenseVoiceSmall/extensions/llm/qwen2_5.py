# voice-backend-main/extensions/llm/qwen2_5.py
# -*- coding: utf-8 -*-

import http.client
import json
from fastapi import APIRouter
from pydantic import BaseModel
from configs.configs import prefix

router = APIRouter(prefix=prefix)


class Message(BaseModel):
    role: str
    content: str


class RequestData(BaseModel):
    messages: list[Message]


def llm_call(messages):
    """
    调用远程 Qwen2.5 服务生成响应内容
    
    Args:
        messages: OpenAI 格式的消息列表，可以是字典列表或 Message 对象列表，例如：
            [
                {"role": "user", "content": "你好"},
                {"role": "assistant", "content": "你好，有什么可以帮到您？"},
                {"role": "user", "content": "什么是家桩共享服务"}
            ]
    
    Returns:
        dict: 包含 code 和 result 的响应字典
    """
    # 远程服务配置
    host = "43.134.133.37"
    port = 8121
    
    # 添加 system 消息
    system_message = {
        "role": "system",
        "content": (
            "你是一个客服语音机器人，你的回答总是容易理解的、正确的、有用的和内容非常精简。"
            "作为客服人员你业务精熟，总是能解答用户关于车的各种知识、结构和理论，以及用车过程中的问题；"
            "而且富有经验与耐心，擅长帮助用户排查各种故障，定位关键问题所在，并最多给出80字以内的恰当建议。"
        )
    }
    
    # 转换 messages 为字典列表（支持字典和 Message 对象）
    llm_messages = [system_message]
    for msg in messages:
        if isinstance(msg, dict):
            llm_messages.append({"role": msg.get("role"), "content": msg.get("content")})
        else:
            llm_messages.append({"role": msg.role, "content": msg.content})
    
    # 在最后一条用户消息后添加 /no_think
    if llm_messages and llm_messages[-1]["role"] == "user":
        llm_messages[-1]["content"] += "/no_think"
    
    try:
        # 连接到远程 API 服务
        conn = http.client.HTTPConnection(host, port)
        
        # 准备请求数据
        payload = json.dumps({
            "messages": llm_messages
        }).encode('utf-8')
        
        headers = {
            'Content-Type': "application/json"
        }
        
        # 发送 POST 请求
        conn.request("POST", "/chat", payload, headers)
        
        # 获取响应
        res = conn.getresponse()
        
        # 读取流式响应并组合完整内容
        full_content = ""
        while True:
            chunk = res.read(1024).decode('utf-8')
            if not chunk:
                break
            
            # 处理 SSE 格式的数据
            lines = chunk.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('data: '):
                    data_str = line[6:]  # 去掉 'data: ' 前缀
                    if data_str:
                        try:
                            data_json = json.loads(data_str)
                            content = data_json.get("content", "")
                            full_content += content
                        except json.JSONDecodeError:
                            pass
        
        # 关闭连接
        conn.close()
        
        # 返回结果
        if full_content:
            return {"code": 200, "result": full_content}
        else:
            return {"code": 500, "result": "未获取到响应内容"}
                
    except Exception as e:
        return {"code": 500, "result": f"错误: {str(e)}"}


def llm_stream(messages):
    """
    调用远程 Qwen2.5 服务生成流式响应内容，
    返回一个生成器对象，依次输出数据块。
    
    Args:
        messages: OpenAI 格式的消息列表，可以是字典列表或 Message 对象列表，例如：
            [
                {"role": "user", "content": "你好"},
                {"role": "assistant", "content": "你好，有什么可以帮到您？"},
                {"role": "user", "content": "什么是家桩共享服务"}
            ]
    
    Yields:
        str: 流式输出的文本字符
    """
    # 远程服务配置
    host = "10.167.50.138"
    port = 8121
    
    # 添加 system 消息
    system_message = {
        "role": "system",
        "content": (
            "你是一个客服语音机器人，你的回答总是容易理解的、正确的、有用的和内容非常精简。"
            "作为客服人员你业务精熟，总是能解答用户关于车的各种知识、结构和理论，以及用车过程中的问题；"
            "而且富有经验与耐心，擅长帮助用户排查各种故障，定位关键问题所在，并最多给出80字以内的恰当建议。"
        )
    }
    
    # 转换 messages 为字典列表（支持字典和 Message 对象）
    llm_messages = [system_message]
    for msg in messages:
        if isinstance(msg, dict):
            llm_messages.append({"role": msg.get("role"), "content": msg.get("content")})
        else:
            llm_messages.append({"role": msg.role, "content": msg.content})
    
    # 在最后一条用户消息后添加 /no_think
    if llm_messages and llm_messages[-1]["role"] == "user":
        llm_messages[-1]["content"] += "/no_think"
    
    try:
        # 连接到远程 API 服务
        conn = http.client.HTTPConnection(host, port)
        
        # 准备请求数据
        payload = json.dumps({
            "messages": llm_messages
        }).encode('utf-8')
        
        headers = {
            'Content-Type': "application/json"
        }
        
        # 发送 POST 请求
        conn.request("POST", "/chat", payload, headers)
        
        # 获取响应
        res = conn.getresponse()
        
        # 读取流式响应并逐字符输出
        while True:
            chunk = res.read(1024).decode('utf-8')
            if not chunk:
                break
            
            # 处理 SSE 格式的数据
            lines = chunk.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('data: '):
                    data_str = line[6:]  # 去掉 'data: ' 前缀
                    if data_str:
                        try:
                            data_json = json.loads(data_str)
                            content = data_json.get("content", "")
                            # 逐字符流式输出
                            for char in content:
                                yield char
                        except json.JSONDecodeError:
                            pass
        
        # 关闭连接
        conn.close()
                
    except Exception as e:
        yield f"错误: {str(e)}"


@router.post("/qwen2_5")
async def root(request_data: RequestData):
    """
    Qwen2.5 LLM 调用接口
    
    Args:
        request_data: 包含 messages 列表的请求数据
    
    Returns:
        dict: 包含 code 和 result 的响应
    """
    result = llm_call(request_data.messages)
    return result
