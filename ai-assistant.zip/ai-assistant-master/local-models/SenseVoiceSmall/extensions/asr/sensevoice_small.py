# asr-tts/asr/SenseVoiceSmall/extensions/asr/sensevoice_small.py
# SenseVoice-Small 多语言语音理解模型服务
import os
import uuid
import tempfile
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from configs.configs import prefix

# 尝试导入必要的库
torch = None
np = None

try:
    import torch
    print(f"Torch 导入成功，版本: {torch.__version__}")
except Exception as e:
    print(f"警告: 无法导入 torch: {e}")
    print("SenseVoiceSmall 模型可能需要 torch 才能正常工作")
    torch = None

try:
    import numpy as np
    print(f"NumPy 导入成功，版本: {np.__version__}")
except Exception as e:
    print(f"警告: 无法导入 numpy: {e}")
    np = None

router = APIRouter(prefix=prefix)

# SenseVoiceSmall 模型信息
MODEL_ID = "iic/SenseVoiceSmall"
MODEL_NAME = "SenseVoice-Small"
LOCAL_MODEL_DIR = "models"  # 本地模型目录

# --- 模型加载与初始化 ---
model = None
model_loaded = False

def get_local_model_path():
    """获取本地模型路径"""
    import os
    local_path = os.path.join(LOCAL_MODEL_DIR, MODEL_ID)
    return local_path

def check_local_model():
    """检查本地是否存在模型"""
    import os
    local_path = get_local_model_path()
    
    if os.path.exists(local_path):
        # 检查是否有模型文件
        model_files = [f for f in os.listdir(local_path) if f.endswith(('.pth', '.safetensors', '.bin', '.pt'))]
        if model_files:
            print(f"发现本地模型: {local_path}")
            return local_path
    
    print(f"未找到本地模型: {local_path}")
    return None

def download_model_to_local():
    """下载模型到本地目录"""
    import os
    from pathlib import Path
    
    local_path = get_local_model_path()
    
    print(f"正在下载模型到本地目录: {local_path}")
    print(f"模型大小约940MB，下载可能需要一些时间...")
    
    try:
        # 确保目录存在
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        
        # 使用 ModelScope 下载
        from modelscope.hub.snapshot_download import snapshot_download
        
        downloaded_path = snapshot_download(
            model_id=MODEL_ID,
            cache_dir=LOCAL_MODEL_DIR,
            revision="master"
        )
        
        print(f"模型下载完成: {downloaded_path}")
        return downloaded_path
        
    except Exception as e:
        print(f"模型下载失败: {e}")
        print("请检查网络连接，或手动下载模型")
        return None

def load_sensevoice_model():
    """
    加载 SenseVoiceSmall 模型
    先检查本地模型，如果没有则下载到本地
    严格遵循：有本地模型用本地，没有则下载，下载失败则报错
    """
    global model, model_loaded
    
    try:
        print(f"正在加载 {MODEL_NAME} 模型...")
        
        # 检查本地模型
        local_model_path = check_local_model()
        
        # 如果没有本地模型，则下载
        if not local_model_path:
            print("未找到本地模型，开始下载到本地目录...")
            local_model_path = download_model_to_local()
            if not local_model_path:
                error_msg = "模型下载失败，无法加载模型。请检查网络连接或手动下载模型。"
                print(error_msg)
                raise RuntimeError(error_msg)
        
        print(f"使用本地模型路径: {local_model_path}")
        
        # 方法1: 使用 ModelScope pipeline
        try:
            from modelscope.pipelines import pipeline
            from modelscope.utils.constant import Tasks
            
            model = pipeline(
                task=Tasks.auto_speech_recognition,
                model=local_model_path,
                model_revision="master",
                device="cpu" if torch is None or not torch.cuda.is_available() else "cuda:0",
            )
            print(f"{MODEL_NAME} 模型加载成功 (ModelScope pipeline)")
            model_loaded = True
            return True
        except Exception as e:
            print(f"ModelScope pipeline 加载失败: {e}")
        
        # 方法2: 使用 FunASR AutoModel
        try:
            from funasr import AutoModel
            from funasr.utils.postprocess_utils import rich_transcription_postprocess
            
            # 创建模型实例
            model = AutoModel(
                model=local_model_path,
                trust_remote_code=True,
                device="cpu" if torch is None or not torch.cuda.is_available() else "cuda:0",
                vad_model="fsmn-vad",
                vad_kwargs={"max_single_segment_time": 30000},
            )
            print(f"{MODEL_NAME} 模型加载成功 (FunASR AutoModel)")
            model_loaded = True
            return True
        except Exception as e:
            print(f"FunASR AutoModel 加载失败: {e}")
        
        print(f"{MODEL_NAME} 模型加载失败，所有方法都尝试过了")
        return False
        
    except RuntimeError as e:
        # 重新抛出下载失败的异常
        raise e
    except Exception as e:
        print(f"加载 {MODEL_NAME} 模型时发生错误: {e}")
        return False

# --- 文本清理函数 ---
def clean_sensevoice_output(text: str) -> str:
    """
    清理SenseVoice模型输出的特殊标记
    
    SenseVoice模型输出可能包含以下标记：
    <|zh|><|NEUTRAL|><|Speech|><|withitn|>
    
    这些标记需要被移除，只保留纯文本内容。
    """
    if not text:
        return text
    
    # 移除常见的SenseVoice标记
    markers = [
        # 语言标记
        "<|zh|>", "<|en|>", "<|yue|>", "<|ja|>", "<|ko|>", "<|nospeech|>",
        # 情感标记
        "<|NEUTRAL|>", "<|HAPPY|>", "<|SAD|>", "<|ANGRY|>", "<|SURPRISE|>",
        "<|FEAR|>", "<|DISGUST|>", "<|CONTEMPT|>", "<|EMO_UNKNOWN|>",
        # 音频类型标记
        "<|Speech|>", "<|Music|>", "<|Noise|>", "<|Other|>", "<|BGM|>",
        # 处理标记
        "<|withitn|>", "<|withoutitn|>"
    ]
    
    cleaned = text
    for marker in markers:
        cleaned = cleaned.replace(marker, "")
    
    # 使用正则表达式移除所有<|...|>格式的标记（作为备用方案）
    import re
    cleaned = re.sub(r'<\|.*?\|>', '', cleaned)
    
    # 移除多余的空格和换行
    cleaned = cleaned.strip()
    
    return cleaned

# --- 请求和响应模型 ---
class ASRRequest(BaseModel):
    """ASR 请求模型"""
    language: str = "auto"  # "auto", "zh", "en", "yue", "ja", "ko", "nospeech"
    use_itn: bool = True    # 是否启用逆文本正则化
    vad_enabled: bool = True  # 是否启用VAD
    batch_size_s: int = 60   # 动态batch大小（秒）
    merge_vad: bool = True   # 是否合并VAD片段
    merge_length_s: int = 15 # 合并长度（秒）

class ASRBase64Request(ASRRequest):
    """Base64音频数据ASR请求模型"""
    audio_data: str  # Base64编码的音频数据

class ASRResponse(BaseModel):
    """ASR 响应模型"""
    success: bool
    text: str = ""
    language: Optional[str] = None
    emotion: Optional[str] = None
    events: Optional[List[str]] = None
    rich_text: Optional[str] = None
    processing_time: Optional[float] = None
    error: Optional[str] = None

class HealthResponse(BaseModel):
    """健康检查响应模型"""
    status: str
    model_loaded: bool
    model_name: str
    model_location: str  # "local" 或 "remote"
    device: str
    supported_languages: List[str]

# --- 音频文件处理函数 ---
def get_save_path() -> Path:
    """
    获取语音文件保存路径：resources/asr/年份/月份-日期
    例如：resources/asr/2025/02-13/
    """
    now = datetime.now()
    save_dir = Path("resources") / "audio" / str(now.year) / f"{now.month:02d}-{now.day:02d}"
    
    # 创建目录（如果不存在）
    save_dir.mkdir(parents=True, exist_ok=True)
    
    return save_dir

def save_audio_file(audio_data: bytes, file_extension: str = "wav") -> str:
    """
    保存语音文件到指定路径
    
    :param audio_data: 音频数据字节
    :param file_extension: 文件扩展名
    :return: 保存的文件路径
    """
    save_dir = get_save_path()
    
    # 生成唯一文件名
    filename = f"{uuid.uuid4().hex}.{file_extension}"
    file_path = save_dir / filename
    
    # 保存文件
    with open(file_path, "wb") as f:
        f.write(audio_data)
    
    print(f"语音文件已保存到: {file_path}")
    return str(file_path)

def get_file_extension(content_type: str) -> str:
    """
    根据 Content-Type 获取文件扩展名
    """
    if content_type:
        if "wav" in content_type:
            return "wav"
        elif "mp3" in content_type:
            return "mp3"
        elif "webm" in content_type:
            return "webm"
        elif "ogg" in content_type:
            return "ogg"
        elif "flac" in content_type:
            return "flac"
    return "wav"

# --- API 路由 ---
def get_model_location():
    """获取模型位置信息"""
    import os
    local_path = get_local_model_path()
    
    if os.path.exists(local_path):
        # 检查是否有模型文件
        model_files = [f for f in os.listdir(local_path) if f.endswith(('.pth', '.safetensors', '.bin', '.pt'))]
        if model_files:
            return "local"
    
    return "remote"

@router.get("/asr/sensevoice/health")
async def health_check():
    """
    健康检查端点
    """
    device = "cpu"
    if torch is not None and torch.cuda.is_available():
        device = f"cuda:{torch.cuda.current_device()}"
    
    model_location = get_model_location()
    
    return HealthResponse(
        status="healthy" if model_loaded else "model_not_loaded",
        model_loaded=model_loaded,
        model_name=MODEL_NAME,
        model_location=model_location,
        device=device,
        supported_languages=["auto", "zh", "en", "yue", "ja", "ko", "nospeech"]
    )

@router.post("/asr/sensevoice/file")
async def transcribe_audio_file(
    audio_file: UploadFile = File(...),
    language: str = Form("auto"),
    use_itn: bool = Form(True),
    vad_enabled: bool = Form(True),
    batch_size_s: int = Form(60),
    merge_vad: bool = Form(True),
    merge_length_s: int = Form(15)
):
    """
    通过上传音频文件进行语音识别
    
    :param audio_file: 上传的音频文件
    :param language: 语言代码
    :param use_itn: 是否启用逆文本正则化
    :param vad_enabled: 是否启用VAD
    :param batch_size_s: 动态batch大小（秒）
    :param merge_vad: 是否合并VAD片段
    :param merge_length_s: 合并长度（秒）
    """
    import time
    start_time = time.time()
    
    # 检查模型是否已加载
    if not model_loaded:
        load_sensevoice_model()
        if not model_loaded:
            raise HTTPException(status_code=503, detail="模型未加载，请稍后重试")
    
    try:
        # 读取音频文件
        audio_data = await audio_file.read()
        if not audio_data:
            raise HTTPException(status_code=400, detail="音频文件为空")
        
        # 保存临时文件
        file_extension = get_file_extension(audio_file.content_type)
        temp_file_path = None
        
        with tempfile.NamedTemporaryFile(suffix=f".{file_extension}", delete=False) as temp_file:
            temp_file.write(audio_data)
            temp_file_path = temp_file.name
        
        try:
            # 根据模型类型进行推理
            processing_time = time.time() - start_time
            
            # 方法1: 使用 ModelScope pipeline
            if hasattr(model, '__class__') and model.__class__.__name__ == 'Pipeline':
                result = model(temp_file_path)
                text = result.get('text', '')
                
                # 尝试提取情感和事件信息
                emotion = result.get('emotion')
                events = result.get('events')
                rich_text = text
                
            # 方法2: 使用 FunASR AutoModel
            elif hasattr(model, 'generate'):
                from funasr.utils.postprocess_utils import rich_transcription_postprocess
                
                # 准备生成参数
                generate_kwargs = {
                    "input": temp_file_path,
                    "cache": {},
                    "language": language,
                    "use_itn": use_itn,
                    "batch_size_s": batch_size_s,
                }
                
                if vad_enabled:
                    generate_kwargs["merge_vad"] = merge_vad
                    generate_kwargs["merge_length_s"] = merge_length_s
                
                # 执行推理
                res = model.generate(**generate_kwargs)
                
                if res and len(res) > 0:
                    text = res[0].get("text", "")
                    # 富文本后处理
                    rich_text = rich_transcription_postprocess(text) if use_itn else text
                    
                    # 尝试提取情感和事件信息
                    emotion = res[0].get("emotion")
                    events = res[0].get("events")
                else:
                    text = ""
                    rich_text = ""
                    emotion = None
                    events = None
                    
            else:
                # 未知模型类型
                text = f"音频文件已接收，但模型类型未知。文件大小: {len(audio_data)} 字节"
                rich_text = text
                emotion = None
                events = None
            
            processing_time = time.time() - start_time
            
            # 清理SenseVoice模型输出的特殊标记
            if text:
                text = clean_sensevoice_output(text)
            if rich_text:
                rich_text = clean_sensevoice_output(rich_text)
            
            return ASRResponse(
                success=True,
                text=text,
                language=language,
                emotion=emotion,
                events=events,
                rich_text=rich_text,
                processing_time=processing_time
            )
            
        finally:
            # 清理临时文件
            if temp_file_path and os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
                
    except Exception as e:
        print(f"语音识别失败: {e}")
        raise HTTPException(status_code=500, detail=f"语音识别失败: {str(e)}")

@router.post("/asr/sensevoice/transcribe")
async def transcribe_audio_data(
    request: ASRBase64Request
):
    """
    通过Base64编码的音频数据进行语音识别
    
    :param request: ASR请求参数，包含Base64音频数据
    """
    import time
    import base64
    start_time = time.time()
    
    # 检查模型是否已加载
    if not model_loaded:
        load_sensevoice_model()
        if not model_loaded:
            raise HTTPException(status_code=503, detail="模型未加载，请稍后重试")
    
    try:
        # 解码Base64数据
        try:
            audio_bytes = base64.b64decode(request.audio_data)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Base64解码失败: {str(e)}")
        
        if not audio_bytes:
            raise HTTPException(status_code=400, detail="音频数据为空")
        
        # 保存临时文件
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
            temp_file.write(audio_bytes)
            temp_file_path = temp_file.name
        
        try:
            # 使用 FunASR AutoModel 进行推理
            if hasattr(model, 'generate'):
                from funasr.utils.postprocess_utils import rich_transcription_postprocess
                
                # 准备生成参数
                generate_kwargs = {
                    "input": temp_file_path,
                    "cache": {},
                    "language": request.language,
                    "use_itn": request.use_itn,
                    "batch_size_s": request.batch_size_s,
                }
                
                if request.vad_enabled:
                    generate_kwargs["merge_vad"] = request.merge_vad
                    generate_kwargs["merge_length_s"] = request.merge_length_s
                
                # 执行推理
                res = model.generate(**generate_kwargs)
                
                if res and len(res) > 0:
                    text = res[0].get("text", "")
                    # 富文本后处理
                    rich_text = rich_transcription_postprocess(text) if request.use_itn else text
                    
                    # 尝试提取情感和事件信息
                    emotion = res[0].get("emotion")
                    events = res[0].get("events")
                else:
                    text = ""
                    rich_text = ""
                    emotion = None
                    events = None
            else:
                text = "音频数据已接收，但模型不支持此功能"
                rich_text = text
                emotion = None
                events = None
            
            processing_time = time.time() - start_time
            
            # 清理SenseVoice模型输出的特殊标记
            if text:
                text = clean_sensevoice_output(text)
            if rich_text:
                rich_text = clean_sensevoice_output(rich_text)
            
            return ASRResponse(
                success=True,
                text=text,
                language=request.language,
                emotion=emotion,
                events=events,
                rich_text=rich_text,
                processing_time=processing_time
            )
            
        finally:
            # 清理临时文件
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
                
    except Exception as e:
        print(f"语音识别失败: {e}")
        raise HTTPException(status_code=500, detail=f"语音识别失败: {str(e)}")

# 初始化时加载模型
@router.on_event("startup")
async def startup_event():
    """应用启动时加载模型"""
    print(f"正在初始化 {MODEL_NAME} 服务...")
    try:
        success = load_sensevoice_model()
        if success and model_loaded:
            print(f"{MODEL_NAME} 服务初始化完成")
        else:
            print(f"{MODEL_NAME} 服务初始化失败，将在首次请求时重试")
    except RuntimeError as e:
        print(f"{MODEL_NAME} 服务初始化失败: {e}")
        print("请确保网络连接正常，或手动下载模型到 models/ 目录")
    except Exception as e:
        print(f"{MODEL_NAME} 服务初始化时发生未知错误: {e}")