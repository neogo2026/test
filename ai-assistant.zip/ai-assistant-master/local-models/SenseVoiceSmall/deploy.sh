git pull

docker cp common sensevoicesmall:/app
docker cp configs sensevoicesmall:/app
docker cp extensions sensevoicesmall:/app
docker cp demo sensevoicesmall:/app
docker cp .gitignore sensevoicesmall:/app
docker cp copy_to_contain.sh sensevoicesmall:/app
docker cp Dockerfile sensevoicesmall:/app
docker cp main.py sensevoicesmall:/app
docker cp README.md sensevoicesmall:/app
docker cp requirements.txt sensevoicesmall:/app

docker restart sensevoicesmall

docker logs -f --tail 20 sensevoicesmall
# docker exec -it sensevoicesmall /bin/bash

docker stop sensevoicesmall
docker rm sensevoicesmall
docker rmi sensevoicesmall

docker build -t sensevoicesmall .
docker run -d --network=host --restart=always --name sensevoicesmall sensevoicesmall
