# common/redis_client.py
import redis
import logging
from configs.env import redis_host, redis_port, redis_password, redis_db

# 配置日志
logger = logging.getLogger(__name__)

# 创建Redis客户端实例
redis_client = redis.Redis(
    host=redis_host,
    port=redis_port,
    password=redis_password,
    db=redis_db,
    decode_responses=True,  # 自动解码返回字符串
    socket_connect_timeout=5
)

def get_redis_client():
    """
    获取Redis客户端实例
    """
    return redis_client

def test_redis_connection():
    """
    测试Redis连接
    """
    try:
        redis_client.ping()
        logger.info("Redis连接成功")
        return True
    except redis.RedisError as e:
        logger.error(f"Redis连接失败: {str(e)}")
        return False

def set_cache(key, value, expire_time=3600):
    """
    设置缓存
    """
    try:
        result = redis_client.setex(key, expire_time, value)
        logger.info(f"Redis缓存设置成功 - key: {key}, expire: {expire_time}s")
        return result
    except redis.RedisError as e:
        logger.error(f"Redis缓存设置失败 - key: {key}, error: {str(e)}")
        return False

def get_cache(key):
    """
    获取缓存
    """
    try:
        value = redis_client.get(key)
        if value:
            logger.info(f"Redis缓存命中 - key: {key}")
        else:
            logger.info(f"Redis缓存未命中 - key: {key}")
        return value
    except redis.RedisError as e:
        logger.error(f"Redis缓存获取失败 - key: {key}, error: {str(e)}")
        return None
