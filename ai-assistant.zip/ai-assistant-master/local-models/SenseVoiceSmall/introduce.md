# SenseVoiceSmall 多语言语音理解模型服务

基于阿里云通义实验室的 SenseVoice-Small 模型，提供多语言语音识别、情感识别和音频事件检测的API服务。

## 特性

- **多语言语音识别**: 支持超过50种语言，包括中文、英文、粤语、日语、韩语等
- **情感识别 (SER)**: 识别语音中的情感状态（高兴、悲伤、愤怒等）
- **音频事件检测 (AED)**: 检测音频中的事件（笑声、掌声、音乐等）
- **逆文本正则化 (ITN)**: 自动将识别结果转换为规范文本格式
- **富文本输出**: 包含情感标签和事件信息的完整转录结果
- **高效推理**: 非自回归架构，推理速度比Whisper-Large快15倍
- **RESTful API**: 提供完整的HTTP API接口

## 快速开始

## Python虚拟环境

```
python -m venv env1

# Windows进入虚拟环境
env1\Scripts\activate

# Linux进入虚拟环境
source env1/bin/activate
```

### 1. 安装依赖

```bash
# 方法1: 使用安装脚本（推荐）
python install_dependencies.py

# 方法2: 手动安装
pip install -r requirements.txt

# 根据SenseVoice文档，确保更新funasr和modelscope
pip install -U funasr modelscope
```

### 2. 启动服务

```bash
python main.py
```

服务将在 `http://127.0.0.1:8060` 启动。

### 3. 下载模型

SenseVoiceSmall模型需要单独下载（约940MB）。首次运行服务时会自动下载，但如果遇到网络问题，可以手动下载：

#### 自动下载（推荐）
```bash
# 使用Python脚本下载（需要已安装modelscope）
python download_model_simple.py

# 或使用Git方式（无需Python依赖）
# Windows批处理
download_model_git.bat

# PowerShell
.\download_model_git.ps1
```

#### 手动下载
如果自动下载失败，可以手动下载：
1. 访问: https://modelscope.cn/models/iic/SenseVoiceSmall
2. 点击"模型文件"标签页
3. 下载所有文件到 `models/iic/SenseVoiceSmall/` 目录

或使用Git命令：
```bash
mkdir -p models
cd models
git clone https://www.modelscope.cn/iic/SenseVoiceSmall.git
```

### 4. 测试服务

```bash
# 运行测试脚本
python script/api/sensevoice_small.py

# 或手动测试健康检查
curl http://127.0.0.1:8060/api/asr/sensevoice/health
```

## API接口

### 健康检查
```
GET /api/asr/sensevoice/health
```

响应示例:
```json
{
  "status": "healthy",
  "model_loaded": true,
  "model_name": "SenseVoice-Small",
  "device": "cuda:0",
  "supported_languages": ["auto", "zh", "en", "yue", "ja", "ko", "nospeech"]
}
```

### 文件上传语音识别
```
POST /api/asr/sensevoice/file
```

参数:
- `audio_file`: 音频文件（支持wav, mp3, webm等格式）
- `language`: 语言代码（默认: "auto"）
- `use_itn`: 是否启用逆文本正则化（默认: true）
- `vad_enabled`: 是否启用语音活动检测（默认: true）
- `batch_size_s`: 动态batch大小（秒，默认: 60）
- `merge_vad`: 是否合并VAD片段（默认: true）
- `merge_length_s`: 合并长度（秒，默认: 15）

响应示例:
```json
{
  "success": true,
  "text": "你好，这是一个测试音频。",
  "language": "zh",
  "emotion": "neutral",
  "events": ["speech"],
  "rich_text": "你好，这是一个测试音频。",
  "processing_time": 0.85
}
```

### Base64音频数据识别
```
POST /api/asr/sensevoice/transcribe
```

参数:
- `audio_data`: Base64编码的音频数据
- 其他参数与文件上传接口相同

## 前端集成

### 语音机器人测试页面

前端项目 `voice-frontend-main` 已集成SenseVoiceSmall ASR服务：

1. 启动前端服务:
```bash
cd voice-frontend-main
npm run dev
```

2. 访问测试页面:
```
http://localhost:8020/voice-robot-test
```

3. 使用方式:
   - 点击麦克风按钮开始录音
   - 说话后停止录音
   - 系统自动调用SenseVoiceSmall进行语音识别
   - 识别结果自动填充到输入框并发送

### 代码修改

前端ASR调用接口已从FunASR改为SenseVoiceSmall:

**修改文件**: `voice-frontend-main/src/composables/useChat.js`

```javascript
// 修改前
const response = await fetch('http://127.0.0.1:8060/api/asr/funasr/file', {

// 修改后
const response = await fetch('http://127.0.0.1:8060/api/asr/sensevoice/file', {
```

## 项目结构

```
SenseVoiceSmall/
├── main.py                          # 主服务入口
├── requirements.txt                 # Python依赖
├── install_dependencies.py         # 依赖安装脚本
├── README.md                       # 本文档
├── configs/
│   ├── configs.py                  # 配置文件
│   ├── env.py                      # 环境配置
│   ├── database.py                 # 数据库配置
│   └── modules.py                  # 模块配置（已包含sensevoice_small）
├── extensions/
│   └── asr/
│       ├── sensevoice_small.py     # SenseVoiceSmall ASR模块
│       └── fun_asr_nano_2512.py    # 其他ASR模块
├── script/
│   └── api/
│       └── sensevoice_small.py     # API测试脚本
├── common/
│   ├── redis_client.py             # Redis客户端
│   └── utils.py                    # 工具函数
└── demo/                           # 演示文件
```

## 模型信息

### SenseVoiceSmall 模型特性

- **模型名称**: iic/SenseVoiceSmall
- **框架**: PyTorch
- **协议**: Apache License 2.0
- **参数量**: 约250M
- **训练数据**: 超过40万小时的多语言音频数据
- **支持语言**: 50+种语言
- **推理速度**: 10秒音频仅需70ms（比Whisper-Large快15倍）

### 模型能力对比

| 能力 | SenseVoice-Small | Whisper-Large |
|------|------------------|---------------|
| 多语言支持 | 50+种语言 | 99种语言 |
| 情感识别 | ✅ 支持 | ❌ 不支持 |
| 事件检测 | ✅ 支持 | ❌ 不支持 |
| 推理速度 | ⚡ 极快（70ms/10s） | 较慢（1050ms/10s） |
| 中文识别 | ✅ 优秀 | ✅ 良好 |
| 模型大小 | 约250M | 约1.5B |

## 部署说明

### Docker部署（可选）

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
RUN pip install -U funasr modelscope

COPY . .

EXPOSE 8041

CMD ["python", "main.py"]
```

### 生产环境建议

1. **GPU加速**: 建议使用CUDA环境以获得最佳性能
2. **模型缓存**: 首次运行会自动下载模型（约940MB）
3. **并发处理**: 服务支持多并发请求，建议使用Nginx反向代理
4. **监控**: 建议监控服务健康状态和推理延迟

## 故障排除

### 常见问题

1. **模型加载失败**
   - 检查网络连接，确保可以访问ModelScope
   - 尝试手动下载模型: `python -c "from modelscope import snapshot_download; snapshot_download('iic/SenseVoiceSmall')"`

2. **音频处理错误**
   - 确保音频文件格式正确（支持wav, mp3, webm等）
   - 检查音频采样率（建议16kHz）

3. **依赖冲突**
   - 使用虚拟环境隔离依赖
   - 按照requirements.txt顺序安装

4. **CUDA错误**
   - 检查CUDA版本兼容性
   - 尝试使用CPU版本: `device="cpu"`

### 日志查看

服务启动时会显示加载日志:
```
[OK] 成功加载模块: demo.setup
[OK] 成功加载模块: asr.sensevoice_small
SenseVoice-Small 服务初始化完成
```

## 开发指南

### 添加新功能

1. 在 `extensions/asr/` 目录下创建新的模块
2. 在 `configs/modules.py` 中添加模块配置
3. 实现FastAPI路由和业务逻辑
4. 创建测试脚本验证功能

### 代码规范

- 使用Python 3.8+语法
- 遵循PEP 8代码风格
- 添加类型注解
- 编写文档字符串

## 许可证

本项目基于Apache License 2.0开源协议。

## 致谢

- 阿里云通义实验室提供SenseVoiceSmall模型
- ModelScope平台提供模型托管
- FunASR团队提供推理框架

## 联系我们

如有问题或建议，请通过项目issue反馈。
