# 拉取最新Redis镜像
```
docker pull redis:latest
```

# 运行Redis容器，设置密码为redis-password
```
# 运行Redis容器，允许远程连接
docker run -d \
  --name redis \
  -p 6379:6379 \
  -v redis_data:/data \
  redis:latest \
  --requirepass "redis-password" \
  --appendonly yes \
  --bind 0.0.0.0 \
  --protected-mode no
```

测试docker访问
```
redis-cli -h 127.0.0.1 -p 6379 -a redis-password
exit
```
