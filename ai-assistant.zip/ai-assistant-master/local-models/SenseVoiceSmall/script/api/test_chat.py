# voice-backend-main/script/api/test_chat.py
import http.client
import json
import gzip
import time
from io import BytesIO

# 记录开始时间
start_time = time.time()

payload = json.dumps({
        "messages": [
                {
                        "role": "user",
                        "content": "天神之眼"
                },
                {
                        "role": "assistant",
                        "content": "你好，有什么可以帮到您？"
                },
                {
                        "role": "user",
                        "content": "什么是家桩共享服务"
                }
        ]
}).encode('utf-8')
headers = {
    'Content-Type': "application/json"
}

# conn = http.client.HTTPConnection("10.167.45.91") # 测试环境
# conn.request("POST", "/main/chat", payload, headers)

conn = http.client.HTTPConnection("127.0.0.1:8060") # 本地环境
conn.request("POST", "/api/chat_tts", payload, headers)

res = conn.getresponse()

# 检测响应类型
content_type = res.getheader('Content-Type')
if content_type and 'audio' in content_type:
    # 音频响应，保存为文件
    audio_data = res.read()
    with open('test_response.mp3', 'wb') as f:
        f.write(audio_data)
    print(f"音频响应已保存为 test_response.mp3，大小: {len(audio_data)} 字节")
    print(f"响应状态: {res.status} {res.reason}")
else:
    # 文本响应
    if res.getheader('Content-Encoding') == 'gzip':
        # 使用gzip来解压数据
        data = gzip.GzipFile(fileobj=BytesIO(res.read())).read().decode('utf-8')
    else:
        data = res.read().decode('utf-8')
    print(data)

# 记录结束时间
end_time = time.time()

# 计算耗时
elapsed_time = end_time - start_time
print(f"\n耗时: {elapsed_time:.2f} 秒")

# 关闭连接
conn.close()
