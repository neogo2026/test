# asr-tts/asr/SenseVoiceSmall/script/api/sensevoice_small.py
import http.client
import json
import os
import base64

# 创建HTTP连接
conn = http.client.HTTPConnection("127.0.0.1", 8041)

def test_health_check():
    """测试健康检查接口"""
    print("=== 测试健康检查接口 ===")
    try:
        conn.request("GET", "/api/asr/sensevoice/health")
        res = conn.getresponse()
        data = res.read()
        response_text = data.decode('utf-8')
        response_json = json.loads(response_text)
        
        print(f"状态码: {res.status}")
        print(f"响应: {json.dumps(response_json, indent=2, ensure_ascii=False)}")
        
        if response_json.get('status') == 'healthy' and response_json.get('model_loaded'):
            print("[OK] 健康检查通过，模型已加载")
            return True
        else:
            print("[ERROR] 健康检查失败，模型未加载")
            return False
            
    except Exception as e:
        print(f"健康检查请求失败: {e}")
        return False

def test_file_transcription():
    """测试文件转录接口"""
    print("\n=== 测试文件转录接口 ===")
    
    # 检查测试音频文件是否存在
    test_audio_path = "test_audio.wav"
    if not os.path.exists(test_audio_path):
        print(f"测试音频文件不存在: {test_audio_path}")
        print("正在创建测试音频文件...")
        # 创建一个简单的WAV文件头（空音频）
        create_test_wav_file(test_audio_path)
    
    try:
        # 读取音频文件
        with open(test_audio_path, 'rb') as f:
            audio_data = f.read()
        
        # 准备请求头和数据
        boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'
        headers = {
            'Content-Type': f'multipart/form-data; boundary={boundary}',
        }
        
        # 构建multipart/form-data请求体
        body = f'--{boundary}\r\n'
        body += 'Content-Disposition: form-data; name="audio_file"; filename="test_audio.wav"\r\n'
        body += 'Content-Type: audio/wav\r\n\r\n'
        body = body.encode('utf-8') + audio_data + f'\r\n--{boundary}'.encode('utf-8')
        
        # 添加其他参数
        params = [
            ('language', 'auto'),
            ('use_itn', 'true'),
            ('vad_enabled', 'true'),
            ('batch_size_s', '60'),
            ('merge_vad', 'true'),
            ('merge_length_s', '15'),
        ]
        
        for name, value in params:
            body += f'\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n--{boundary}'.encode('utf-8')
        
        body += '--\r\n'.encode('utf-8')
        
        print(f"发送文件转录请求，文件大小: {len(audio_data)} 字节")
        conn.request("POST", "/api/asr/sensevoice/file", body, headers)
        res = conn.getresponse()
        data = res.read()
        response_text = data.decode('utf-8')
        
        print(f"状态码: {res.status}")
        
        if res.status == 200:
            response_json = json.loads(response_text)
            # 使用 ensure_ascii=True 避免Windows控制台编码问题
            print(f"响应: {json.dumps(response_json, indent=2, ensure_ascii=True)}")
            
            if response_json.get('success'):
                text = response_json.get('text', '')
                rich_text = response_json.get('rich_text', '')
                emotion = response_json.get('emotion')
                events = response_json.get('events')
                processing_time = response_json.get('processing_time')
                
                print(f"\n[OK] 文件转录成功")
                print(f"识别文本: {text}")
                if rich_text and rich_text != text:
                    # 过滤掉非ASCII字符，避免Windows控制台编码问题
                    try:
                        safe_rich_text = rich_text.encode('ascii', 'ignore').decode('ascii')
                        if safe_rich_text:
                            print(f"富文本: {safe_rich_text}")
                        else:
                            print(f"富文本: [包含非ASCII字符]")
                    except:
                        print(f"富文本: [包含非ASCII字符]")
                if emotion:
                    print(f"情感识别: {emotion}")
                if events:
                    print(f"事件检测: {events}")
                if processing_time:
                    print(f"处理时间: {processing_time:.2f}秒")
                return True
            else:
                print(f"[ERROR] 文件转录失败: {response_json.get('error')}")
                return False
        else:
            print(f"[ERROR] 请求失败: {res.status} {res.reason}")
            print(f"响应内容: {response_text[:200]}...")
            return False
            
    except Exception as e:
        print(f"文件转录请求失败: {e}")
        return False

def test_base64_transcription():
    """测试Base64音频数据转录接口"""
    print("\n=== 测试Base64音频数据转录接口 ===")
    
    # 读取测试音频文件并转换为Base64
    test_audio_path = "test_audio.wav"
    if not os.path.exists(test_audio_path):
        print(f"测试音频文件不存在: {test_audio_path}")
        return False
    
    try:
        with open(test_audio_path, 'rb') as f:
            audio_data = f.read()
        
        audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        
        # 尝试使用JSON请求体，而不是form-data
        # 根据FastAPI文档，当使用Pydantic模型作为参数时，它期望从请求体解析JSON
        
        request_data = {
            "language": "auto",
            "use_itn": True,
            "vad_enabled": True,
            "batch_size_s": 60,
            "merge_vad": True,
            "merge_length_s": 15,
            "audio_data": audio_base64
        }
        
        headers = {
            'Content-Type': 'application/json',
        }
        
        print(f"发送Base64转录请求，数据大小: {len(audio_base64)} 字符")
        conn.request("POST", "/api/asr/sensevoice/transcribe",
                    json.dumps(request_data).encode('utf-8'), headers)
        res = conn.getresponse()
        data = res.read()
        response_text = data.decode('utf-8')
        
        print(f"状态码: {res.status}")
        
        if res.status == 200:
            response_json = json.loads(response_text)
            # 使用 ensure_ascii=True 避免Windows控制台编码问题
            print(f"响应: {json.dumps(response_json, indent=2, ensure_ascii=True)}")
            
            if response_json.get('success'):
                print(f"\n[OK] Base64转录成功")
                print(f"识别文本: {response_json.get('text', '')}")
                return True
            else:
                print(f"[ERROR] Base64转录失败: {response_json.get('error')}")
                return False
        else:
            print(f"[ERROR] 请求失败: {res.status} {res.reason}")
            print(f"响应内容: {response_text[:200]}...")
            return False
            
    except Exception as e:
        print(f"Base64转录请求失败: {e}")
        return False

def create_test_wav_file(filename):
    """创建一个简单的测试WAV文件"""
    import struct
    import math
    
    # WAV文件参数
    sample_rate = 16000
    duration = 1.0  # 1秒
    frequency = 440.0  # A4音调
    amplitude = 0.5
    
    # 生成正弦波
    num_samples = int(sample_rate * duration)
    samples = []
    for i in range(num_samples):
        # 计算正弦波值
        t = i / sample_rate
        sine_value = math.sin(2.0 * math.pi * frequency * t)
        sample = amplitude * sine_value
        samples.append(sample)
    
    # 写入WAV文件
    with open(filename, 'wb') as f:
        # RIFF头
        f.write(b'RIFF')
        f.write(struct.pack('<I', 36 + len(samples) * 2))  # 文件大小
        f.write(b'WAVE')
        
        # fmt子块
        f.write(b'fmt ')
        f.write(struct.pack('<I', 16))  # PCM格式大小
        f.write(struct.pack('<H', 1))   # 音频格式 (PCM)
        f.write(struct.pack('<H', 1))   # 声道数
        f.write(struct.pack('<I', sample_rate))  # 采样率
        f.write(struct.pack('<I', sample_rate * 2))  # 字节率
        f.write(struct.pack('<H', 2))   # 块对齐
        f.write(struct.pack('<H', 16))  # 位深度
        
        # data子块
        f.write(b'data')
        f.write(struct.pack('<I', len(samples) * 2))  # 数据大小
        
        # 写入样本数据
        for sample in samples:
            f.write(struct.pack('<h', int(sample * 32767.0)))
    
    print(f"创建测试音频文件: {filename}")

def main():
    """主测试函数"""
    print("SenseVoiceSmall ASR API 测试")
    print("=" * 50)
    
    try:
        # 测试健康检查
        health_ok = test_health_check()
        
        if health_ok:
            # 测试文件转录
            file_ok = test_file_transcription()
            
            # 测试Base64转录
            base64_ok = test_base64_transcription()
            
            # 总结
            print("\n" + "=" * 50)
            print("测试总结:")
            print(f"健康检查: {'[OK] 通过' if health_ok else '[ERROR] 失败'}")
            print(f"文件转录: {'[OK] 通过' if file_ok else '[ERROR] 失败'}")
            print(f"Base64转录: {'[OK] 通过' if base64_ok else '[ERROR] 失败'}")
            
            if health_ok and file_ok:
                print("\n[OK] 所有关键测试通过，SenseVoiceSmall ASR服务运行正常")
            else:
                print("\n[ERROR] 部分测试失败，请检查服务状态")
        else:
            print("\n[ERROR] 健康检查失败，请确保SenseVoiceSmall服务已启动")
            print("启动命令: cd asr-tts/asr/SenseVoiceSmall && python main.py")
            
    except ConnectionRefusedError:
        print("\n错误: 无法连接到API服务 (连接被拒绝)")
        print("请确保SenseVoiceSmall服务正在运行在 127.0.0.1:8060")
        print("启动命令: cd asr-tts/asr/SenseVoiceSmall && python main.py")
        
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")
        
    finally:
        # 关闭连接
        conn.close()

if __name__ == '__main__':
    main()