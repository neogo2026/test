# api/script/api/bge_embedding.py
import http.client
import json
import gzip
from io import BytesIO

# 创建HTTP连接
conn = http.client.HTTPConnection("127.0.0.1:8020")

# 准备请求数据 - 符合bge_embedding.py期望的格式
# bge_embedding.py期望的格式: {"input": ["文本1", "文本2"]}
payload = json.dumps({
    "input": ["天神之眼", "你好，有什么可以帮到您？", "汉ev"]
}).encode('utf-8')

headers = {
    'Content-Type': "application/json",
    'Accept-Encoding': 'gzip'  # 接受gzip压缩响应
}

try:
    # 发送POST请求
    print("正在调用BGE嵌入API...")
    print(f"请求URL: http://127.0.0.1:8020/api/embedding/bge")
    print(f"请求数据: {payload.decode('utf-8')}")
    
    conn.request("POST", "/api/embedding/bge", payload, headers)
    res = conn.getresponse()
    
    # 读取响应数据
    raw_data = res.read()
    
    # 检测响应是否压缩
    if res.getheader('Content-Encoding') == 'gzip':
        # 使用gzip解压数据
        data = gzip.decompress(raw_data)
        print("响应使用gzip压缩")
    else:
        data = raw_data
    
    # 解码为字符串并解析JSON
    response_text = data.decode('utf-8')
    response_json = json.loads(response_text)
    
    # 打印响应状态和结果
    print(json.dumps(response_json, indent=2, ensure_ascii=False))
    
    # 提取并打印嵌入向量信息
    if response_json.get('data'):
        print("\n嵌入向量详情:")
        for item in response_json['data']:
            print(f"索引: {item['index']}")
            print(f"对象类型: {item['object']}")
            print(f"向量维度: {len(item['embedding'])}")
            print(f"前5个向量值: {item['embedding'][:5]}")
            print("-" * 50)
    
    print("\nAPI调用成功完成！")
    
except ConnectionRefusedError:
    print("\n错误: 无法连接到API服务 (连接被拒绝)")
    
except Exception as e:
    print(f"\n请求失败: {e}")
    
finally:
    # 关闭连接
    conn.close()
