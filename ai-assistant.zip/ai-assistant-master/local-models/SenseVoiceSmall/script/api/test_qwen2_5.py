# voice-algorithm-audio-internal/chat/chat1/api/test_qwen2_5.py
import http.client
import json
import gzip
import time
from io import BytesIO

# 记录开始时间
start_time = time.time()

payload = json.dumps({
    "messages": [
        {
            "role": "user",
            "content": "天神之眼"
        },
        {
            "role": "assistant",
            "content": "你好，有什么可以帮到您？"
        },
        {
            "role": "user",
            "content": "今天天气多少度"
        }
    ]
}).encode('utf-8')
headers = {
    'Content-Type': "application/json"
}

conn = http.client.HTTPConnection("43.134.133.37:8121")
# conn = http.client.HTTPConnection("127.0.0.1:8121") # 本地环境
conn.request("POST", "/qwen2_5", payload, headers)

res = conn.getresponse()

# 检测响应是否压缩
if res.getheader('Content-Encoding') == 'gzip':
    # 使用gzip来解压数据
    data = gzip.GzipFile(fileobj=BytesIO(res.read())).read().decode('utf-8')
else:
    data = res.read().decode('utf-8')

print(data)

# 记录结束时间
end_time = time.time()

# 计算耗时
elapsed_time = end_time - start_time
print(f"\n耗时: {elapsed_time:.2f} 秒")

# 关闭连接
conn.close()
