# extensions/rsi_train/eval.py
"""真实任务回放评测：base vs adapter，输出可复现 JSON / Markdown。

支持：
- checks.contains / checks.not_contains
- checks.test_cmd：在工作区执行命令，exit_code==0 视为通过
- checks.min_chars
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from configs.models import get_model
from extensions.rsi_engine.engine import get_engine
from extensions.rsi_train import import_export


def _evaluate_output(output: str, checks: dict[str, Any], workspace: str) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    ok = True
    for needle in checks.get("contains") or []:
        if needle not in output:
            ok = False
            reasons.append(f"missing:{needle}")
    for needle in checks.get("not_contains") or []:
        if needle in output:
            ok = False
            reasons.append(f"unexpected:{needle}")
    min_chars = int(checks.get("min_chars") or 0)
    if min_chars and len(output) < min_chars:
        ok = False
        reasons.append(f"too_short:{len(output)}<{min_chars}")
    test_cmd = checks.get("test_cmd") or ""
    if test_cmd:
        try:
            proc = subprocess.run(
                test_cmd, shell=True, cwd=workspace or None,
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
            )
            if proc.returncode != 0:
                ok = False
                reasons.append(f"test_cmd_exit:{proc.returncode}")
        except Exception as exc:  # noqa: BLE001
            ok = False
            reasons.append(f"test_cmd_error:{type(exc).__name__}")
    return ok, reasons


def run(
    model_name: str,
    adapter: str = "",
    eval_path: str = "data/processed/eval.jsonl",
    report_dir: str = "reports",
    limit: int = 0,
) -> dict[str, Any]:
    items = import_export.read_jsonl(eval_path)
    if limit > 0:
        items = items[:limit]
    if not items:
        raise ValueError(f"没有评测数据: {eval_path}")
    engine = get_engine()
    if not adapter:
        engine.ensure_loaded()
    rows = []
    started = time.time()
    for item in items:
        workspace = item.get("workspace_snapshot") or tempfile.mkdtemp(prefix="rsi-eval-")
        prompt = [{"role": "user", "content": item.get("instruction") or ""}]
        result = engine.generate(prompt, adapter=adapter or None, max_new_tokens=512, temperature=0.2)
        ok, reasons = _evaluate_output(result.get("text") or "", item.get("checks") or {}, workspace)
        rows.append({
            "id": item.get("id"),
            "ok": ok,
            "reasons": reasons,
            "adapter": result.get("adapter", ""),
            "usage": result.get("usage") or {},
            "elapsed_s": 0,
        })
    passed = sum(1 for row in rows if row["ok"])
    report = {
        "model": model_name,
        "adapter": adapter,
        "eval_set": eval_path,
        "tasks": len(rows),
        "passed": passed,
        "success_rate": round(passed / len(rows), 4) if rows else 0.0,
        "elapsed_s": round(time.time() - started, 1),
        "rows": rows,
    }
    out = Path(report_dir)
    out.mkdir(parents=True, exist_ok=True)
    name = f"eval_{Path(eval_path).stem}_{adapter or 'base'}_{int(time.time())}"
    (out / f"{name}.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / f"{name}.md").write_text(
        "# RSI 模型评测\n\n"
        f"- model: {model_name}\n- adapter: {adapter or 'base'}\n- tasks: {len(rows)}\n"
        f"- passed: {passed}\n- success_rate: {report['success_rate']}\n\n"
        + "\n".join(f"- {row['id']}: {'PASS' if row['ok'] else 'FAIL'} {', '.join(row['reasons'])}" for row in rows),
        encoding="utf-8",
    )
    return report
