# extensions/rsi_train/train.py
"""训练/评测 CLI。

用法：
  python -m extensions.rsi_train.train prepare --sft data/exports/sft.jsonl --dpo data/exports/dpo.jsonl --eval data/exports/eval.jsonl
  python -m extensions.rsi_train.train sft --model qwen3.5-2b --data data/processed/sft.jsonl
  python -m extensions.rsi_train.train dpo --model qwen3.5-2b --data data/processed/dpo.jsonl
  python -m extensions.rsi_train.train eval --model qwen3.5-2b --adapter sft
  python -m extensions.rsi_train.train grpo --model qwen3.5-2b --reward-file reward.py
"""

from __future__ import annotations

import argparse
import json
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def main() -> int:
    parser = argparse.ArgumentParser(description="Qwen3.5-2B-RSI training")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare")
    p.add_argument("--sft", default="")
    p.add_argument("--dpo", default="")
    p.add_argument("--eval", default="")
    p.add_argument("--output", default="data/processed")

    for name in ("sft", "dpo", "grpo"):
        p = sub.add_parser(name)
        p.add_argument("--model", default="qwen3.5-2b")
        p.add_argument("--recipe", default="rsi-v1")
        p.add_argument("--data", default=f"data/processed/{name}.jsonl")
        p.add_argument("--output", default="")
        if name in ("dpo", "grpo"):
            p.add_argument("--init-adapter", default="")
        if name == "grpo":
            p.add_argument("--reward-file", default="")
            p.add_argument("--max-samples", type=int, default=-1)
        if name == "sft":
            p.add_argument("--max-steps", type=int, default=-1)

    p = sub.add_parser("eval")
    p.add_argument("--model", default="qwen3.5-2b")
    p.add_argument("--adapter", default="")
    p.add_argument("--eval-set", default="data/processed/eval.jsonl")
    p.add_argument("--report-dir", default="reports")
    p.add_argument("--limit", type=int, default=0)

    args = parser.parse_args()
    if args.command == "prepare":
        from extensions.rsi_train import import_export
        report = import_export.prepare(args.sft or None, args.dpo or None, args.eval or None, args.output)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    if args.command == "sft":
        from extensions.rsi_train import sft
        print(json.dumps(sft.run(args.model, args.recipe, args.data, args.output, args.max_steps), ensure_ascii=False, indent=2))
        return 0
    if args.command == "dpo":
        from extensions.rsi_train import dpo
        print(json.dumps(dpo.run(args.model, args.recipe, args.data, args.output, args.init_adapter), ensure_ascii=False, indent=2))
        return 0
    if args.command == "grpo":
        from extensions.rsi_train import grpo
        print(json.dumps(grpo.run(args.model, args.recipe, args.data, args.reward_file, args.output,
                                  args.init_adapter, args.max_samples), ensure_ascii=False, indent=2))
        return 0
    if args.command == "eval":
        from extensions.rsi_train import eval as rsi_eval
        print(json.dumps(rsi_eval.run(args.model, args.adapter, args.eval_set, args.report_dir, args.limit),
                         ensure_ascii=False, indent=2))
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
