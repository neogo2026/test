# extensions/rsi_train/dpo.py
"""轮级 DPO：chosen=修复后成功，rejected=修复前失败。

- 可用 SFT adapter 初始化策略；reference 用 disable_adapter() 得到，省显存。
- 单卡 batch=1，梯度累积；4bit 基座可用。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from configs.models import ModelSpec, get_model
from configs.recipes import RecipeSpec, get_recipe
from extensions.rsi_train import import_export
from extensions.rsi_train.manifest import build_manifest, write_manifest

logger = logging.getLogger(__name__)


def _encode(tokenizer: Any, prompt_messages: list[dict[str, Any]], response: str, max_len: int):
    from extensions.rsi_train.sft import to_ids

    prompt_ids = to_ids(
        tokenizer.apply_chat_template(prompt_messages, tokenize=True, add_generation_prompt=True)
    )
    response_ids = to_ids(tokenizer(response, add_special_tokens=False))
    eos = tokenizer.eos_token_id
    if eos is not None:
        response_ids = response_ids + [eos]
    input_ids = (prompt_ids + response_ids)[:max_len]
    labels = ([-100] * len(prompt_ids) + response_ids)[:max_len]
    return input_ids, labels


def _response_logps(model: Any, input_ids: list[int], labels: list[int]) -> Any:
    import torch

    device = next(model.parameters()).device
    ids = torch.tensor([input_ids], dtype=torch.long, device=device)
    mask = torch.tensor([labels], dtype=torch.long, device=device)
    outputs = model(input_ids=ids)
    logits = outputs.logits[:, :-1, :]
    targets = ids[:, 1:]
    log_probs = torch.log_softmax(logits, dim=-1)
    token_logps = log_probs.gather(-1, targets.unsqueeze(-1)).squeeze(-1)
    mask = mask[:, 1:]
    valid = (mask != -100).float()
    return (token_logps * valid).sum() / valid.sum().clamp(min=1.0)


def run(
    model_name: str,
    recipe_name: str = "rsi-v1",
    data_path: str = "data/processed/dpo.jsonl",
    output_dir: str = "",
    init_adapter: str = "",
) -> dict[str, Any]:
    import torch
    from peft import PeftModel

    spec = get_model(model_name)
    recipe: RecipeSpec = get_recipe(recipe_name)
    items = import_export.read_jsonl(data_path)
    if len(items) < 1:
        raise ValueError(f"没有 DPO 数据: {data_path}")

    from extensions.rsi_train.sft import build_lora, load_base_for_training

    tokenizer, base = load_base_for_training(spec)
    init_dir = Path(init_adapter or f"adapters/{spec.name}/{recipe.name}/sft")
    if (init_dir / "adapter_config.json").exists():
        model = PeftModel.from_pretrained(base, str(init_dir), is_trainable=True)
        logger.info("DPO 从 SFT adapter 初始化: %s", init_dir)
    else:
        model = build_lora(base, spec)
        logger.info("未找到 SFT adapter，DPO 从基座 LoRA 开始")
    model.train()
    device = next(model.parameters()).device
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=recipe.dpo_lr)
    target = Path(output_dir or f"adapters/{spec.name}/{recipe.name}/dpo")
    target.mkdir(parents=True, exist_ok=True)

    step = 0
    for epoch in range(recipe.dpo_epochs):
        for item in items:
            prompt = item.get("prompt_messages") or []
            chosen = str((item.get("chosen") or {}).get("content") or "")
            rejected = str((item.get("rejected") or {}).get("content") or "")
            if not chosen or not rejected:
                continue
            c_ids, c_labels = _encode(tokenizer, prompt, chosen, spec.max_seq_len)
            r_ids, r_labels = _encode(tokenizer, prompt, rejected, spec.max_seq_len)
            policy_c = _response_logps(model, c_ids, c_labels)
            policy_r = _response_logps(model, r_ids, r_labels)
            with torch.no_grad():
                with model.disable_adapter():
                    ref_c = _response_logps(model, c_ids, c_labels)
                    ref_r = _response_logps(model, r_ids, r_labels)
            margin = (policy_c - policy_r) - (ref_c - ref_r)
            loss = -torch.nn.functional.logsigmoid(recipe.dpo_beta * margin)
            loss.backward()
            if (step + 1) % 8 == 0:
                torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
            step += 1
            if step % 10 == 0:
                logger.info("DPO epoch=%d step=%d loss=%.4f", epoch + 1, step, float(loss))
    optimizer.step()
    optimizer.zero_grad(set_to_none=True)
    model.save_pretrained(str(target))
    tokenizer.save_pretrained(str(target))
    manifest = build_manifest(
        spec, recipe, "dpo", target, [data_path],
        {"pairs": len(items), "beta": recipe.dpo_beta}, alias="dpo",
    )
    write_manifest(target, manifest)
    logger.info("DPO adapter 保存到 %s", target)
    return {"adapter": str(target), "manifest": manifest}
