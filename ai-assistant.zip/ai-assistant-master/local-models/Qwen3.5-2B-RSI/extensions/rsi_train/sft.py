# extensions/rsi_train/sft.py
"""LoRA / QLoRA SFT：只对 assistant 片段计算 loss。

输入为 import_export 产出的 sft.jsonl：
{"messages":[{role,content,...}], ...}
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from configs.models import ModelSpec, get_model
from configs.recipes import RecipeSpec, get_recipe
from extensions.rsi_train import import_export
from extensions.rsi_train.manifest import build_manifest, write_manifest

logger = logging.getLogger(__name__)


def to_ids(encoded: Any) -> list[int]:
    """?? transformers 4.x?list?? 5.x?BatchEncoding / Encoding??"""
    if hasattr(encoded, "keys") and "input_ids" in encoded:
        ids = encoded["input_ids"]
    else:
        ids = encoded
    if ids and isinstance(ids[0], (list, tuple)):
        ids = ids[0]
    return [int(item) for item in ids]


class SftDataset:
    def __init__(self, items: list[dict[str, Any]], tokenizer: Any, max_seq_len: int):
        self.items = items
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> dict[str, Any]:
        import torch

        messages = self.items[index]["messages"]
        ids = to_ids(
            self.tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=False)
        )
        labels = [-100] * len(ids)
        cursor = 0
        for message in messages:
            content = str(message.get("content") or "")
            if message.get("role") != "assistant" or not content:
                continue
            piece = to_ids(self.tokenizer(content, add_special_tokens=False))
            if not piece:
                continue
            start = _find_subsequence(ids, piece, cursor)
            if start < 0:
                continue
            end = start + len(piece)
            labels[start:end] = ids[start:end]
            cursor = end
        ids = ids[: self.max_seq_len]
        labels = labels[: self.max_seq_len]
        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "attention_mask": torch.ones(len(ids), dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


def _find_subsequence(haystack: list[int], needle: list[int], start: int = 0) -> int:
    if not needle:
        return -1
    limit = len(haystack) - len(needle) + 1
    first = needle[0]
    for index in range(start, max(start, limit)):
        if haystack[index] == first and haystack[index:index + len(needle)] == needle:
            return index
    return -1


class PadCollator:
    def __init__(self, pad_token_id: int):
        self.pad_token_id = pad_token_id

    def __call__(self, features: list[dict[str, Any]]):
        import torch

        max_len = max(len(feature["input_ids"]) for feature in features)
        input_ids, attention, labels = [], [], []
        for feature in features:
            pad = max_len - len(feature["input_ids"])
            input_ids.append(torch.cat([feature["input_ids"], torch.full((pad,), self.pad_token_id, dtype=torch.long)]))
            attention.append(torch.cat([feature["attention_mask"], torch.zeros(pad, dtype=torch.long)]))
            labels.append(torch.cat([feature["labels"], torch.full((pad,), -100, dtype=torch.long)]))
        return {
            "input_ids": torch.stack(input_ids),
            "attention_mask": torch.stack(attention),
            "labels": torch.stack(labels),
        }


def load_base_for_training(spec: ModelSpec):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    path = spec.resolved_dir()
    if not (path / "config.json").exists():
        raise FileNotFoundError(f"模型不存在: {path}")
    tokenizer = AutoTokenizer.from_pretrained(str(path), trust_remote_code=spec.trust_remote_code)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    kwargs: dict[str, Any] = {"trust_remote_code": spec.trust_remote_code}
    if spec.quantization == "4bit":
        try:
            from transformers import BitsAndBytesConfig

            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_quant_type="nf4",
            )
            kwargs["device_map"] = "auto"
        except Exception:  # noqa: BLE001
            logger.warning("bitsandbytes 不可用，回退普通 LoRA")
    try:
        kwargs["dtype"] = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        model = AutoModelForCausalLM.from_pretrained(str(path), **kwargs)
    except TypeError:
        kwargs.pop("dtype", None)
        kwargs["torch_dtype"] = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        model = AutoModelForCausalLM.from_pretrained(str(path), **kwargs)
    return tokenizer, model


def build_lora(model: Any, spec: ModelSpec):
    from peft import LoraConfig, get_peft_model

    available = {name.split(".")[-1] for name, _ in model.named_modules()}
    targets = [target for target in spec.lora_targets if target in available]
    if spec.lora_target_regex:
        import re

        pattern = re.compile(spec.lora_target_regex)
        for name, _module in model.named_modules():
            if pattern.search(name):
                targets.append(name.split(".")[-1])
    targets = sorted(set(targets)) or "all-linear"
    config = LoraConfig(
        r=spec.lora_r,
        lora_alpha=spec.lora_alpha,
        lora_dropout=spec.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=targets,
    )
    return get_peft_model(model, config)


def run(
    model_name: str,
    recipe_name: str = "rsi-v1",
    data_path: str = "data/processed/sft.jsonl",
    output_dir: str = "",
    max_steps: int = -1,
) -> dict[str, Any]:
    from transformers import Trainer, TrainingArguments

    spec = get_model(model_name)
    recipe: RecipeSpec = get_recipe(recipe_name)
    items = import_export.read_jsonl(data_path)
    if not items:
        raise ValueError(f"没有 SFT 数据: {data_path}")
    tokenizer, base = load_base_for_training(spec)
    model = build_lora(base, spec)
    model.print_trainable_parameters()
    dataset = SftDataset(items, tokenizer, min(spec.max_seq_len, recipe.max_seq_len))
    target = Path(output_dir or f"adapters/{spec.name}/{recipe.name}/sft")
    target.mkdir(parents=True, exist_ok=True)
    args = TrainingArguments(
        output_dir=str(target / "checkpoints"),
        num_train_epochs=recipe.sft_epochs,
        max_steps=max_steps,
        per_device_train_batch_size=recipe.sft_batch_size,
        gradient_accumulation_steps=recipe.sft_grad_accum,
        learning_rate=recipe.sft_lr,
        logging_steps=5,
        save_strategy="epoch",
        save_total_limit=2,
        bf16=__import__("torch").cuda.is_available(),
        report_to=[],
        remove_unused_columns=False,
    )
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=dataset,
        data_collator=PadCollator(tokenizer.pad_token_id),
    )
    trainer.train()
    model.save_pretrained(str(target))
    tokenizer.save_pretrained(str(target))
    manifest = build_manifest(spec, recipe, "sft", target, [data_path], {"train_samples": len(items)}, alias="sft")
    write_manifest(target, manifest)
    logger.info("SFT adapter 保存到 %s", target)
    return {"adapter": str(target), "manifest": manifest}
