# extensions/rsi_train/import_export.py
"""AI助理 RSI 导出 JSONL → 训练/评测标准格式。

纪律：
- 去重（同一 messages 只保留一条）
- 去污染（eval 的 instruction 不出现在 SFT/DPO）
- 只接受带外部验证信号的样本（outcome=success / tests_passed / user_accepted）
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    items = []
    with Path(path).open("r", encoding="utf-8-sig") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                items.append(value)
    return items


def write_jsonl(path: str | Path, items: list[dict[str, Any]]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for item in items:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    return path


def _digest(value: Any) -> str:
    return hashlib.sha1(json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def _valid_message(item: dict[str, Any]) -> bool:
    return isinstance(item.get("role"), str) and "content" in item


def normalize_sft(items: list[dict[str, Any]], eval_instructions: set[str] | None = None) -> tuple[list[dict[str, Any]], dict[str, int]]:
    eval_instructions = eval_instructions or set()
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    stats = {"input": len(items), "kept": 0, "duplicate": 0, "contaminated": 0, "invalid": 0, "unverified": 0}
    for item in items:
        messages = item.get("messages") or []
        if not messages or not all(_valid_message(m) for m in messages):
            stats["invalid"] += 1
            continue
        signals = item.get("signals") or {}
        verified = (
            item.get("outcome") == "success"
            or signals.get("tests_passed") is True
            or signals.get("user_accepted") is True
        )
        if not verified:
            stats["unverified"] += 1
            continue
        user_text = next((str(m.get("content") or "") for m in messages if m.get("role") == "user"), "")
        if user_text in eval_instructions:
            stats["contaminated"] += 1
            continue
        key = _digest(messages)
        if key in seen:
            stats["duplicate"] += 1
            continue
        seen.add(key)
        result.append({
            "id": item.get("id") or key[:16],
            "messages": messages,
            "outcome": "success",
            "tool_schema_version": item.get("tool_schema_version", "v1"),
            "system_version": item.get("system_version", "v1"),
        })
        stats["kept"] += 1
    return result, stats


def normalize_dpo(items: list[dict[str, Any]], eval_instructions: set[str] | None = None) -> tuple[list[dict[str, Any]], dict[str, int]]:
    eval_instructions = eval_instructions or set()
    result = []
    stats = {"input": len(items), "kept": 0, "contaminated": 0, "invalid": 0}
    for item in items:
        prompt = item.get("prompt_messages") or []
        chosen = item.get("chosen") or {}
        rejected = item.get("rejected") or {}
        if not prompt or not chosen.get("content") or not rejected.get("content"):
            stats["invalid"] += 1
            continue
        user_text = " ".join(str(m.get("content") or "") for m in prompt if m.get("role") == "user")
        if user_text in eval_instructions:
            stats["contaminated"] += 1
            continue
        result.append({
            "id": item.get("id") or _digest(item)[:16],
            "prompt_messages": prompt,
            "chosen": {"role": "assistant", "content": chosen["content"]},
            "rejected": {"role": "assistant", "content": rejected["content"]},
            "target": item.get("target", "correctness"),
        })
        stats["kept"] += 1
    return result, stats


def normalize_eval(items: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, int]]:
    result = []
    stats = {"input": len(items), "kept": 0, "invalid": 0}
    for item in items:
        instruction = str(item.get("instruction") or "").strip()
        if not instruction:
            stats["invalid"] += 1
            continue
        result.append({
            "id": item.get("id") or _digest(item)[:16],
            "instruction": instruction,
            "workspace_snapshot": item.get("workspace_snapshot", ""),
            "test_cmd": item.get("test_cmd", ""),
            "checks": item.get("checks") or {},
            "split": item.get("split", "heldout"),
        })
        stats["kept"] += 1
    return result, stats


def prepare(
    sft_path: str | None = None,
    dpo_path: str | None = None,
    eval_path: str | None = None,
    output_dir: str | Path = "data/processed",
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    eval_items, eval_stats = normalize_eval(read_jsonl(eval_path)) if eval_path and Path(eval_path).exists() else ([], {})
    eval_instructions = {item["instruction"] for item in eval_items}
    report: dict[str, Any] = {"eval": eval_stats, "files": {}}

    if eval_items:
        path = write_jsonl(output_dir / "eval.jsonl", eval_items)
        report["files"]["eval"] = str(path)

    if sft_path and Path(sft_path).exists():
        sft_items, sft_stats = normalize_sft(read_jsonl(sft_path), eval_instructions)
        path = write_jsonl(output_dir / "sft.jsonl", sft_items)
        report["sft"] = sft_stats
        report["files"]["sft"] = str(path)

    if dpo_path and Path(dpo_path).exists():
        dpo_items, dpo_stats = normalize_dpo(read_jsonl(dpo_path), eval_instructions)
        path = write_jsonl(output_dir / "dpo.jsonl", dpo_items)
        report["dpo"] = dpo_stats
        report["files"]["dpo"] = str(path)

    manifest = output_dir / "manifest.json"
    manifest.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    report["manifest"] = str(manifest)
    return report
