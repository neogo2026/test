# extensions/rsi_train/manifest.py
"""训练 / 评测 manifest：记录模型、数据、模板与指标的可复现快照。"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sha1_file(path: str | Path, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha1()
    with Path(path).open("rb") as handle:
        while True:
            data = handle.read(chunk)
            if not data:
                break
            digest.update(data)
    return digest.hexdigest()


def sha1_text(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def build_manifest(
    model: Any,
    recipe: Any,
    stage: str,
    adapter_dir: str | Path,
    data_files: list[str | Path] | None = None,
    metrics: dict[str, Any] | None = None,
    status: str = "candidate",
    alias: str = "",
) -> dict[str, Any]:
    base = model.resolved_dir()
    tokenizer_file = base / "tokenizer.json"
    template_file = base / "chat_template.jinja"
    data_hashes = {}
    for path in data_files or []:
        path = Path(path)
        if path.exists():
            data_hashes[path.name] = sha1_file(path)
    manifest = {
        "run_id": f"{model.name}-rsi-{stage}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}",
        "recipe": recipe.name,
        "model": model.name,
        "model_id": model.model_id,
        "base_hash": sha1_file(base / "config.json") if (base / "config.json").exists() else "",
        "tokenizer_hash": sha1_file(tokenizer_file) if tokenizer_file.exists() else "",
        "chat_template_hash": sha1_file(template_file) if template_file.exists() else "",
        "data": data_hashes,
        "tool_schema_version": recipe.tool_schema_version,
        "system_version": recipe.system_prompt_version,
        "stage": stage,
        "adapter": str(adapter_dir).replace("\\", "/"),
        "alias": alias or stage,
        "metrics": metrics or {},
        "eval": metrics or {},
        "status": status,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return manifest


def write_manifest(adapter_dir: str | Path, manifest: dict[str, Any]) -> Path:
    path = Path(adapter_dir) / "manifest.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
