# extensions/rsi_train/grpo.py
"""GRPO（实验性）：可验证奖励 + group 相对优势 + KL 锚。

奖励来自外部 Python 文件：
    def reward(response: str, sample: dict) -> float: ...
用于有测试命令 / 可执行校验的 RSI 任务。默认不启用，避免无验证奖励的自我强化。
"""

from __future__ import annotations

import importlib.util
import logging
from pathlib import Path
from typing import Any, Callable

from configs.models import get_model
from configs.recipes import get_recipe
from extensions.rsi_train import import_export
from extensions.rsi_train.manifest import build_manifest, write_manifest

logger = logging.getLogger(__name__)


def load_reward(path: str) -> Callable[[str, dict], float]:
    spec = importlib.util.spec_from_file_location("rsi_reward", path)
    if not spec or not spec.loader:
        raise ValueError(f"无法加载奖励文件: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fn = getattr(module, "reward", None)
    if not callable(fn):
        raise ValueError("奖励文件必须定义 reward(response, sample) -> float")
    return fn


def _sequence_logp(model: Any, input_ids: list[int], response_start: int) -> Any:
    import torch

    device = next(model.parameters()).device
    ids = torch.tensor([input_ids], dtype=torch.long, device=device)
    outputs = model(input_ids=ids)
    logits = outputs.logits[:, :-1, :]
    targets = ids[:, 1:]
    log_probs = torch.log_softmax(logits, dim=-1).gather(-1, targets.unsqueeze(-1)).squeeze(-1)
    mask = torch.zeros_like(targets, dtype=torch.float)
    start = max(0, response_start - 1)
    mask[:, start:] = 1.0
    return (log_probs * mask).sum() / mask.sum().clamp(min=1.0)


def run(
    model_name: str,
    recipe_name: str = "rsi-v1",
    data_path: str = "data/processed/eval.jsonl",
    reward_file: str = "",
    output_dir: str = "",
    init_adapter: str = "",
    max_samples: int = -1,
) -> dict[str, Any]:
    import torch
    from peft import PeftModel

    if not reward_file:
        raise ValueError("GRPO 需要 --reward-file（定义 reward(response, sample)）")
    reward_fn = load_reward(reward_file)
    spec = get_model(model_name)
    recipe = get_recipe(recipe_name)
    items = import_export.read_jsonl(data_path)
    if max_samples > 0:
        items = items[:max_samples]
    if not items:
        raise ValueError(f"没有 GRPO 数据: {data_path}")

    from extensions.rsi_train.sft import build_lora, load_base_for_training

    tokenizer, base = load_base_for_training(spec)
    init_dir = Path(init_adapter or f"adapters/{spec.name}/{recipe.name}/sft")
    if (init_dir / "adapter_config.json").exists():
        model = PeftModel.from_pretrained(base, str(init_dir), is_trainable=True)
    else:
        model = build_lora(base, spec)
    model.train()
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=recipe.dpo_lr)
    target = Path(output_dir or f"adapters/{spec.name}/{recipe.name}/grpo")
    target.mkdir(parents=True, exist_ok=True)

    step = 0
    for item in items:
        instruction = str(item.get("instruction") or "")
        if not instruction:
            continue
        messages = [{"role": "user", "content": instruction}]
        prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        prompt_ids = tokenizer(prompt, return_tensors="pt").input_ids.to(next(model.parameters()).device)
        samples: list[tuple[str, list[int], float]] = []
        for _ in range(recipe.grpo_group_size):
            with torch.inference_mode():
                output = model.generate(
                    prompt_ids,
                    max_new_tokens=256,
                    do_sample=True,
                    temperature=0.9,
                    top_p=0.95,
                    pad_token_id=tokenizer.pad_token_id,
                )
            ids = output[0].tolist()
            response = tokenizer.decode(ids[prompt_ids.shape[1]:], skip_special_tokens=True)
            score = float(reward_fn(response, item))
            samples.append((response, ids, score))
        scores = torch.tensor([s[2] for s in samples], dtype=torch.float)
        if float(scores.std()) < 1e-6:
            continue
        advantages = (scores - scores.mean()) / (scores.std() + 1e-6)
        losses = []
        for (response, ids, _score), advantage in zip(samples, advantages):
            input_ids = ids[: spec.max_seq_len]
            policy_logp = _sequence_logp(model, input_ids, prompt_ids.shape[1])
            with torch.no_grad():
                with model.disable_adapter():
                    ref_logp = _sequence_logp(model, input_ids, prompt_ids.shape[1])
            kl = policy_logp - ref_logp
            loss = -(advantage.to(policy_logp.device) * policy_logp) + recipe.grpo_beta * kl * kl
            losses.append(loss)
        loss = torch.stack(losses).mean()
        loss.backward()
        if (step + 1) % 4 == 0:
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
        step += 1
        logger.info("GRPO step=%d loss=%.4f mean_reward=%.3f", step, float(loss), float(scores.mean()))
    optimizer.step()
    model.save_pretrained(str(target))
    tokenizer.save_pretrained(str(target))
    manifest = build_manifest(
        spec, recipe, "grpo", target, [data_path],
        {"prompts": len(items), "group_size": recipe.grpo_group_size, "beta": recipe.grpo_beta},
        alias="grpo",
    )
    write_manifest(target, manifest)
    return {"adapter": str(target), "manifest": manifest}
