# extensions/rsi_engine/codec.py
"""OpenAI 消息 ↔ Qwen 对话模板 / 工具调用编解码。

关键兼容点：
1. OpenAI 历史里 assistant.tool_calls[].function.arguments 是 JSON 字符串；
   Qwen3.5 模板要求它是 dict（`arguments|items`），这里统一转换。
2. Qwen3.5 原生工具输出是 `<tool_call><function=name><parameter=k>v</parameter>...</function></tool_call>`；
   同时兼容旧式 JSON 工具调用，统一解析为 OpenAI tool_calls。
"""

from __future__ import annotations

import json
import re
import uuid
from typing import Any

# 旧式 JSON 工具调用：<tool_call>{"name":..., "arguments":{...}}</tool_call>
TOOL_TAG = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.S)
JSON_OBJECT = re.compile(r"\{.*\}", re.S)
# Qwen3.5 原生格式：<tool_call>...<function=name>...<parameter=k>v</parameter>...</function>...</tool_call>
QWEN_TOOL_BLOCK = re.compile(r"<tool_call>(.*?)</tool_call>", re.S)
QWEN_FUNCTION = re.compile(r"<function=([^>\n]+)>(.*?)</function>", re.S)
QWEN_PARAM = re.compile(r"<parameter=([^>\n]+)>\s*(.*?)\s*</parameter>", re.S)


def _loads_object(raw: str) -> dict[str, Any] | None:
    raw = raw.strip()
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else None
    except json.JSONDecodeError:
        match = JSON_OBJECT.search(raw)
        if not match:
            return None
        try:
            value = json.loads(match.group(0))
            return value if isinstance(value, dict) else None
        except json.JSONDecodeError:
            return None


def _coerce_value(raw: str) -> Any:
    """参数值：JSON 字面量优先，否则保留原始字符串（保留多行）。"""
    text = raw.strip()
    if not text:
        return ""
    if text[:1] in {"{", "[", '"'} or text in {"true", "false", "null"} or re.match(r"^-?\d+(\.\d+)?$", text):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    return text


def _normalize_tool_calls(tool_calls: Any) -> list[dict[str, Any]]:
    """把 OpenAI tool_calls 的 arguments（str/dict）归一为 dict，供 Qwen 模板渲染。"""
    fixed: list[dict[str, Any]] = []
    for call in tool_calls or []:
        if not isinstance(call, dict):
            continue
        new_call = dict(call)
        fn = new_call.get("function")
        if isinstance(fn, dict):
            new_fn = dict(fn)
            args = new_fn.get("arguments", new_call.get("arguments"))
            if isinstance(args, str):
                parsed = _loads_object(args)
                args = parsed if parsed is not None else {"_raw": args}
            if not isinstance(args, dict):
                args = {"value": args}
            new_fn["arguments"] = args
            new_call["function"] = new_fn
        elif "arguments" in new_call:
            args = new_call.get("arguments")
            if isinstance(args, str):
                parsed = _loads_object(args)
                new_call["arguments"] = parsed if parsed is not None else {"_raw": args}
        fixed.append(new_call)
    return fixed


def normalize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """归一为 Qwen3.5 模板可接受的结构。

    - 模板只允许开头一条 system：把所有 system（含技能注入 / 上下文压缩摘要
      出现在中途的 system）合并为开头单条。
    - assistant.tool_calls 的 arguments（str/dict）统一转为 dict。
    """
    items: list[dict[str, Any]] = []
    system_parts: list[str] = []
    for message in messages or []:
        role = str(message.get("role") or "user")
        content = message.get("content")
        if isinstance(content, list):
            content = "".join(str(part.get("text") or "") for part in content if isinstance(part, dict))
        text = content or ""
        if role == "system":
            if text.strip():
                system_parts.append(text.strip())
            continue
        item: dict[str, Any] = {"role": role, "content": text}
        if role == "assistant" and message.get("tool_calls"):
            item["tool_calls"] = _normalize_tool_calls(message["tool_calls"])
        if role == "tool":
            item["name"] = message.get("name") or message.get("tool_name") or "tool"
        items.append(item)
    if system_parts:
        items.insert(0, {"role": "system", "content": "\n\n".join(system_parts)})
    return items


def apply_chat_template(tokenizer: Any, messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None = None,
                        add_generation_prompt: bool = True) -> str:
    kwargs: dict[str, Any] = {
        "tokenize": False,
        "add_generation_prompt": add_generation_prompt,
    }
    if tools:
        kwargs["tools"] = tools
    try:
        return tokenizer.apply_chat_template(messages, **kwargs)
    except TypeError:
        # 老版本 template 不接受 tools：退回纯文本模板，工具 schema 由调用方放进 system
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=add_generation_prompt)


def _parse_qwen_blocks(text: str) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for block_match in QWEN_TOOL_BLOCK.finditer(text or ""):
        block = block_match.group(1)
        for fn_match in QWEN_FUNCTION.finditer(block):
            name = fn_match.group(1).strip()
            body = fn_match.group(2)
            if not name:
                continue
            arguments: dict[str, Any] = {}
            for param_match in QWEN_PARAM.finditer(body):
                key = param_match.group(1).strip()
                if not key:
                    continue
                arguments[key] = _coerce_value(param_match.group(2))
            calls.append({
                "id": f"call_{uuid.uuid4().hex[:12]}",
                "type": "function",
                "function": {"name": name, "arguments": json.dumps(arguments, ensure_ascii=False)},
            })
    return calls


def _parse_json_blocks(text: str) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for match in TOOL_TAG.finditer(text or ""):
        data = _loads_object(match.group(1))
        if not data:
            continue
        name = str(data.get("name") or data.get("tool") or "")
        arguments = data.get("arguments") or data.get("parameters") or {}
        if not name:
            continue
        calls.append({
            "id": f"call_{uuid.uuid4().hex[:12]}",
            "type": "function",
            "function": {
                "name": name,
                "arguments": json.dumps(arguments, ensure_ascii=False) if isinstance(arguments, dict) else str(arguments),
            },
        })
    return calls


def parse_tool_calls(text: str) -> tuple[str, list[dict[str, Any]]]:
    """从模型输出解析工具调用，返回 (清理后的文本, OpenAI tool_calls)。"""
    text = text or ""
    calls = _parse_qwen_blocks(text) + _parse_json_blocks(text)
    cleaned = QWEN_TOOL_BLOCK.sub("", text)
    cleaned = TOOL_TAG.sub("", cleaned).strip()
    return cleaned, calls


def build_usage(prompt_tokens: int, completion_tokens: int) -> dict[str, int]:
    return {
        "prompt_tokens": int(prompt_tokens),
        "completion_tokens": int(completion_tokens),
        "total_tokens": int(prompt_tokens) + int(completion_tokens),
    }
