# extensions/rsi_engine/router.py
"""OpenAI 兼容推理接口 + RSI 版本/健康检查。"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field

from configs import configs
from extensions.rsi_engine.engine import get_engine

router = APIRouter()


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="allow")
    role: str
    content: Any = ""
    name: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="allow")
    model: str = "qwen3.5-2b-rsi"
    messages: list[ChatMessage] = Field(default_factory=list)
    tools: list[dict[str, Any]] | None = None
    tool_choice: Any = None
    temperature: float | None = 0.7
    top_p: float | None = 0.8
    max_tokens: int | None = None
    max_new_tokens: int | None = None
    stream: bool = False
    adapter: str | None = None
    stream_options: dict[str, Any] | None = None


def _resolve_adapter(request: ChatRequest) -> str | None:
    if request.adapter:
        return request.adapter
    info = get_engine().registry.resolve_for_model(request.model)
    return info["alias"] if info else (configs.DEFAULT_ADAPTER or None)


def _model_alias(request: ChatRequest) -> str:
    adapter = _resolve_adapter(request)
    return f"{configs.DEFAULT_MODEL}-rsi" + (f"-{adapter}" if adapter else "")


def _completion_payload(request: ChatRequest, result: dict[str, Any]) -> dict[str, Any]:
    text = result.get("text") or ""
    calls = result.get("tool_calls") or []
    message: dict[str, Any] = {"role": "assistant", "content": None if calls else text}
    if calls:
        message["tool_calls"] = calls
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": _model_alias(request),
        "choices": [{
            "index": 0,
            "message": message,
            "finish_reason": "tool_calls" if calls else "stop",
        }],
        "usage": result.get("usage") or {},
        "rsi": {"adapter": result.get("adapter", "")},
    }


@router.post("/v1/chat/completions")
async def chat_completions(request: ChatRequest):
    engine = get_engine()
    messages = [m.model_dump(exclude_none=True) for m in request.messages]
    adapter = _resolve_adapter(request)
    if request.stream:
        return StreamingResponse(
            _stream(request, messages, adapter),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    result = await asyncio.to_thread(
        engine.generate,
        messages,
        request.tools,
        adapter,
        request.max_new_tokens or request.max_tokens,
        request.temperature,
        request.top_p,
    )
    return _completion_payload(request, result)


def _stream(request: ChatRequest, messages: list[dict[str, Any]], adapter: str | None):
    created = int(time.time())
    completion_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
    model = _model_alias(request)

    def frame(delta: dict[str, Any], finish_reason: str | None = None, usage: dict | None = None) -> str:
        payload: dict[str, Any] = {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
        }
        if usage:
            payload["usage"] = usage
        return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"

    yield frame({"role": "assistant", "content": ""})
    for event in get_engine().stream(
        messages,
        tools=request.tools,
        adapter=adapter,
        max_new_tokens=request.max_new_tokens or request.max_tokens,
        temperature=request.temperature,
        top_p=request.top_p,
    ):
        if "delta" in event:
            yield frame({"content": event["delta"]})
        elif "final" in event:
            final = event["final"]
            calls = final.get("tool_calls") or []
            if calls:
                yield frame({"tool_calls": calls}, finish_reason="tool_calls", usage=final.get("usage"))
            else:
                yield frame({}, finish_reason="stop", usage=final.get("usage"))
    yield "data: [DONE]\n\n"


@router.get("/v1/models")
async def models():
    engine = get_engine()
    items = [{
        "id": f"{configs.DEFAULT_MODEL}-rsi",
        "object": "model",
        "created": int(time.time()),
        "owned_by": "ai-assistant",
        "rsi": {"adapter": ""},
    }]
    for adapter in engine.registry.list():
        items.append({
            "id": f"{configs.DEFAULT_MODEL}-rsi-{adapter['alias']}",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "ai-assistant",
            "rsi": {"adapter": adapter["alias"], "status": adapter.get("status")},
        })
    return {"object": "list", "data": items}


@router.get("/api/rsi/health")
async def health():
    return {"code": 200, "data": get_engine().status()}


@router.get("/api/rsi/versions")
async def versions():
    engine = get_engine()
    return {"code": 200, "data": {
        "models": engine.registry.list(),
        "current_adapter": engine._current_adapter,
        "loaded": engine._loaded,
    }}


@router.post("/api/rsi/reload")
async def reload_adapter():
    engine = get_engine()
    engine.registry.scan()
    return {"code": 200, "data": {"adapters": engine.registry.list()}}


@router.get("/api/rsi/health/live")
async def live():
    return {"status": "ok", "model": configs.DEFAULT_MODEL}
