# extensions/rsi_engine/registry.py
"""Adapter 注册表：扫描 adapters 目录，解析别名与 manifest。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from configs.configs import ADAPTERS_DIR


def _load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


class AdapterRegistry:
    def __init__(self, root: Path | None = None):
        self.root = Path(root or ADAPTERS_DIR)
        self._items: dict[str, dict[str, Any]] = {}
        self.scan()

    def scan(self) -> dict[str, dict[str, Any]]:
        self._items = {}
        if not self.root.exists():
            return self._items
        for config_path in self.root.rglob("adapter_config.json"):
            adapter_dir = config_path.parent
            manifest_path = adapter_dir / "manifest.json"
            manifest = _load_json(manifest_path) if manifest_path.exists() else {}
            alias = str(manifest.get("alias") or adapter_dir.name)
            rel = str(adapter_dir.relative_to(self.root)).replace("\\", "/")
            item = {
                "alias": alias,
                "name": rel,
                "path": str(adapter_dir),
                "stage": manifest.get("stage") or adapter_dir.name,
                "model": manifest.get("model", ""),
                "status": manifest.get("status", "candidate"),
                "metrics": manifest.get("eval") or {},
                "manifest": manifest,
            }
            self._items[alias] = item
            # 同时允许用相对路径作为别名（适配多模型并存）
            self._items.setdefault(rel, item)
        return self._items

    def list(self) -> list[dict[str, Any]]:
        seen = set()
        result = []
        for item in self._items.values():
            key = item["path"]
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def resolve(self, alias: str | None) -> dict[str, Any] | None:
        if not alias:
            return None
        return self._items.get(alias)

    def resolve_for_model(self, model_alias: str, extra_adapter: str | None = None) -> dict[str, Any] | None:
        """支持 qwen3.5-2b-rsi / qwen3.5-2b-rsi-sft / qwen3.5-2b-rsi-dpo 等别名。"""
        if extra_adapter:
            return self.resolve(extra_adapter)
        alias = (model_alias or "").strip()
        for prefix in ("qwen3.5-2b-rsi-", "qwen3.5-2b-rsi"):
            if alias.startswith(prefix):
                suffix = alias[len(prefix):].lstrip("-")
                if suffix:
                    return self.resolve(suffix)
        return self.resolve(alias)
