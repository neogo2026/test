# extensions/rsi_engine/engine.py
"""基座 + 多 adapter 推理引擎。

- 基座只加载一次；adapter 通过 PEFT 多适配器加载，按请求 set_adapter。
- 所有生成串行化（一把锁），避免多 AI 员工并发时 adapter 串线。
- 未安装 transformer 依赖或模型缺失时给出可诊断错误，health 仍可用。
"""

from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Any, Iterator

from configs import configs
from configs.models import ModelSpec, get_model
from extensions.rsi_engine import codec
from extensions.rsi_engine.registry import AdapterRegistry

logger = logging.getLogger(__name__)


class RsiEngine:
    def __init__(self, spec: ModelSpec | None = None, registry: AdapterRegistry | None = None):
        self.spec = spec or get_model()
        self.registry = registry or AdapterRegistry()
        self.tokenizer: Any = None
        self.model: Any = None
        self.base_model: Any = None
        self._loaded = False
        self._peft = False
        self._current_adapter: str = ""
        self._loading = False
        self._lock = threading.RLock()
        self._loaded_at = 0.0
        self.last_error = ""

    # ------------------------------------------------------------------
    # 加载
    # ------------------------------------------------------------------
    def ensure_loaded(self) -> None:
        with self._lock:
            if self._loaded:
                return
            self._loading = True
            try:
                self._load()
            finally:
                self._loading = False

    def _resolve_dir(self) -> Path:
        path = self.spec.resolved_dir()
        if (path / "config.json").exists():
            return path
        if configs.AUTO_DOWNLOAD:
            logger.info("本地模型不存在，从 ModelScope 下载 %s", self.spec.model_id)
            from modelscope import snapshot_download  # type: ignore

            path.mkdir(parents=True, exist_ok=True)
            snapshot_download(self.spec.model_id, local_dir=str(path))
            return path
        raise FileNotFoundError(
            f"未找到模型 {self.spec.name}: {path}。请先下载 {self.spec.model_id} 到该目录，"
            "或设置 RSI_AUTO_DOWNLOAD=1。"
        )

    def _load(self) -> None:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        path = self._resolve_dir()
        self.tokenizer = AutoTokenizer.from_pretrained(str(path), trust_remote_code=self.spec.trust_remote_code)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        if torch.cuda.is_available():
            device = "cuda"
            dtype = torch.bfloat16 if self.spec.dtype == "bfloat16" else torch.float16
        else:
            device = "cpu"
            dtype = torch.float32

        load_kwargs: dict[str, Any] = {"trust_remote_code": self.spec.trust_remote_code}
        try:
            load_kwargs["dtype"] = dtype
            model = AutoModelForCausalLM.from_pretrained(str(path), **load_kwargs)
        except TypeError:
            load_kwargs.pop("dtype", None)
            load_kwargs["torch_dtype"] = dtype
            model = AutoModelForCausalLM.from_pretrained(str(path), **load_kwargs)
        if self.spec.arch == "dense" and self.spec.name.endswith("2b"):
            model = model.to(device)
        else:
            try:
                model = model.to(device)
            except Exception:  # noqa: BLE001 - 大模型显存不足时保留在 CPU/加速卡默认设备
                logger.warning("模型搬到 %s 失败，保留默认设备", device)
        model.eval()
        self.base_model = model
        self.model = model
        self._loaded = True
        self._loaded_at = time.time()
        self.last_error = ""
        logger.info("基座加载完成：%s (%s)", self.spec.name, device)

    # ------------------------------------------------------------------
    # Adapter
    # ------------------------------------------------------------------
    def activate_adapter(self, alias: str | None) -> str:
        """返回实际激活的 adapter 别名（空字符串表示基座）。"""
        alias = (alias or "").strip()
        if not alias:
            if self._peft and self.model is not None:
                try:
                    self.model.set_adapter(self._current_adapter)
                except Exception:  # noqa: BLE001
                    pass
            return self._current_adapter
        info = self.registry.resolve(alias)
        if not info:
            logger.warning("未找到 adapter %s，使用基座", alias)
            return self._current_adapter
        if self._current_adapter == alias:
            return alias
        from peft import PeftModel

        adapter_path = info["path"]
        if not self._peft:
            self.model = PeftModel.from_pretrained(self.base_model, adapter_path, adapter_name=alias)
            self._peft = True
        else:
            self.model.load_adapter(adapter_path, adapter_name=alias)
            self.model.set_adapter(alias)
        self._current_adapter = alias
        logger.info("adapter 已激活：%s (%s)", alias, adapter_path)
        return alias

    # ------------------------------------------------------------------
    # 生成
    # ------------------------------------------------------------------
    def _prepare(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None):
        import torch

        prompt = codec.apply_chat_template(self.tokenizer, codec.normalize_messages(messages), tools)
        inputs = self.tokenizer(prompt, return_tensors="pt")
        device = next(self.model.parameters()).device
        inputs = {key: value.to(device) for key, value in inputs.items()}
        return prompt, inputs

    def generate(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        adapter: str | None = None,
        max_new_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> dict[str, Any]:
        import torch

        with self._lock:
            self.ensure_loaded()
            self.activate_adapter(adapter)
            prompt, inputs = self._prepare(messages, tools)
            max_tokens = int(max_new_tokens or configs.MAX_NEW_TOKENS)
            temp = configs.TEMPERATURE if temperature is None else float(temperature)
            top = configs.TOP_P or float(top_p or configs.TOP_P)
            with torch.inference_mode():
                output = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temp,
                    top_p=top,
                    do_sample=temp > 0,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
            prompt_tokens = int(inputs["input_ids"].shape[1])
            completion_tokens = int(output.shape[1] - prompt_tokens)
            raw = self.tokenizer.decode(output[0][prompt_tokens:], skip_special_tokens=True).strip()
            if "<｜end▁of▁thinking｜>" in raw:
                raw = raw.split("<｜end▁of▁thinking｜>")[-1].strip()
            text, calls = codec.parse_tool_calls(raw)
            return {
                "text": text,
                "raw": raw,
                "tool_calls": calls,
                "usage": codec.build_usage(prompt_tokens, completion_tokens),
                "adapter": self._current_adapter,
            }

    def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        adapter: str | None = None,
        max_new_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> Iterator[dict[str, Any]]:
        """同步流式生成：先逐段 yield {"delta": str}，最后 yield {"final": result}。"""
        import torch
        from transformers import TextIteratorStreamer

        with self._lock:
            self.ensure_loaded()
            self.activate_adapter(adapter)
            prompt, inputs = self._prepare(messages, tools)
            max_tokens = int(max_new_tokens or configs.MAX_NEW_TOKENS)
            temp = configs.TEMPERATURE if temperature is None else float(temperature)
            top = configs.TOP_P or float(top_p or configs.TOP_P)
            streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True, skip_special_tokens=True)
            error: list[Exception] = []

            def _run() -> None:
                try:
                    with torch.inference_mode():
                        self.model.generate(
                            **inputs,
                            streamer=streamer,
                            max_new_tokens=max_tokens,
                            temperature=temp,
                            top_p=top,
                            do_sample=temp > 0,
                            pad_token_id=self.tokenizer.pad_token_id,
                            eos_token_id=self.tokenizer.eos_token_id,
                        )
                except Exception as exc:  # noqa: BLE001
                    error.append(exc)
                    streamer.end()

            thread = threading.Thread(target=_run, daemon=True)
            thread.start()
            parts: list[str] = []
            for piece in streamer:
                if not piece:
                    continue
                parts.append(piece)
                yield {"delta": piece}
            thread.join(timeout=5)
            if error:
                raise error[0]
            raw = "".join(parts).strip()
            if "<｜end▁of▁thinking｜>" in raw:
                raw = raw.split("<｜end▁of▁thinking｜>")[-1].strip()
            text, calls = codec.parse_tool_calls(raw)
            prompt_tokens = int(inputs["input_ids"].shape[1])
            completion_tokens = len(self.tokenizer(raw).get("input_ids") or [])
            yield {
                "final": {
                    "text": text,
                    "raw": raw,
                    "tool_calls": calls,
                    "usage": codec.build_usage(prompt_tokens, completion_tokens),
                    "adapter": self._current_adapter,
                }
            }

    # ------------------------------------------------------------------
    # 状态
    # ------------------------------------------------------------------
    def status(self) -> dict[str, Any]:
        base = self.spec.resolved_dir()
        return {
            "model": self.spec.to_dict(),
            "base_exists": (base / "config.json").exists(),
            "base_dir": str(base),
            "loaded": self._loaded,
            "loading": self._loading,
            "loaded_at": self._loaded_at,
            "peft": self._peft,
            "current_adapter": self._current_adapter,
            "adapters": self.registry.list(),
            "last_error": self.last_error,
            "preload": configs.PRELOAD,
        }


_engine: RsiEngine | None = None


def get_engine() -> RsiEngine:
    global _engine
    if _engine is None:
        _engine = RsiEngine()
    return _engine
