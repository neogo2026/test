# main.py
# Qwen3.5-2B-RSI 私有化模型服务：OpenAI 兼容推理 + Adapter 版本 + 健康检查
from contextlib import asynccontextmanager
import logging
import threading

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from configs import configs
from configs.modules import modules

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("rsi-model")


@asynccontextmanager
async def lifespan(app):
    if configs.PRELOAD:
        from extensions.rsi_engine.engine import get_engine
        logger.info("RSI_PRELOAD=1，预加载基座")
        get_engine().ensure_loaded()
    yield


app = FastAPI(title=configs.APP_TITLE, version=configs.APP_VERSION, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for module_path in modules.values():
    module = __import__(module_path, fromlist=["router"])
    app.include_router(module.router)


@app.get("/")
async def root():
    return {"name": configs.APP_NAME, "version": configs.APP_VERSION, "docs": "/docs"}


if __name__ == "__main__":
    uvicorn.run("main:app", host=configs.HOST, port=configs.PORT, reload=False)
