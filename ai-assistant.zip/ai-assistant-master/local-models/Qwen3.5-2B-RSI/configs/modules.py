# configs/modules.py
"""模块注册表：main.py 自动挂载各扩展路由。"""

modules = {
    "rsi_engine.router": "extensions.rsi_engine.router",
}
