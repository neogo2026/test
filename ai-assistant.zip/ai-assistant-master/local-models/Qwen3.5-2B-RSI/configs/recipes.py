# configs/recipes.py
"""RecipeSpec：模型无关的 RSI 训练配方。"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class RecipeSpec:
    name: str = "rsi-v1"
    system_prompt_version: str = "v1"
    tool_schema_version: str = "v1"
    sft_epochs: int = 2
    sft_lr: float = 1e-4
    sft_batch_size: int = 1
    sft_grad_accum: int = 8
    dpo_beta: float = 0.1
    dpo_epochs: int = 1
    dpo_lr: float = 5e-5
    dpo_min_pairs: int = 500
    grpo_beta: float = 0.04
    grpo_group_size: int = 4
    eval_min_tasks: int = 50
    gate_success_delta: float = 0.05
    gate_regression_max: float = 0.02
    max_seq_len: int = 4096

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


RECIPES: dict[str, RecipeSpec] = {
    "rsi-v1": RecipeSpec(),
}


def get_recipe(name: str | None = None) -> RecipeSpec:
    from configs.configs import DEFAULT_RECIPE

    return RECIPES.get(name or DEFAULT_RECIPE, RECIPES[DEFAULT_RECIPE])
