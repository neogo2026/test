# configs/configs.py
"""Qwen3.5-2B-RSI 全局配置。"""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
APP_NAME = "Qwen3.5-2B-RSI"
APP_TITLE = "Qwen3.5-2B-RSI · 自进化本地模型服务"
APP_VERSION = "1.0.0"

HOST = os.getenv("RSI_HOST", "127.0.0.1")
PORT = int(os.getenv("RSI_PORT", "9065"))

DATA_DIR = Path(os.getenv("RSI_DATA_DIR", str(BASE_DIR / "data"))).expanduser()
MODELS_DIR = Path(os.getenv("RSI_MODELS_DIR", str(BASE_DIR / "models"))).expanduser()
ADAPTERS_DIR = Path(os.getenv("RSI_ADAPTERS_DIR", str(BASE_DIR / "adapters"))).expanduser()
OUTPUTS_DIR = Path(os.getenv("RSI_OUTPUTS_DIR", str(BASE_DIR / "outputs"))).expanduser()
REPORTS_DIR = Path(os.getenv("RSI_REPORTS_DIR", str(BASE_DIR / "reports"))).expanduser()

DEFAULT_MODEL = os.getenv("RSI_MODEL", "qwen3.5-2b").strip()
DEFAULT_RECIPE = os.getenv("RSI_RECIPE", "rsi-v1").strip()
DEFAULT_ADAPTER = os.getenv("RSI_DEFAULT_ADAPTER", "").strip()
PRELOAD = os.getenv("RSI_PRELOAD", "0").strip() in {"1", "true", "yes"}
AUTO_DOWNLOAD = os.getenv("RSI_AUTO_DOWNLOAD", "0").strip() in {"1", "true", "yes"}

# 参考工程里已下载好的基座，可作为本项目的只读回退路径
FALLBACK_BASE_2B = os.getenv(
    "RSI_BASE_2B_FALLBACK",
    r"D:\Env\git\ai-models\Qwen3.5-2B\models\Qwen\Qwen3.5-2B",
).strip()

DEFAULT_SYSTEM_PROMPT = os.getenv(
    "RSI_SYSTEM_PROMPT",
    "你是 AI助理的 RSI 智能体模型，擅长规划、工具调用、验证与自我修正。"
    "优先实际执行而不是只输出计划；失败后阅读错误并换思路；完成前必须验证。",
)

MAX_NEW_TOKENS = int(os.getenv("RSI_MAX_NEW_TOKENS", "2048"))
TEMPERATURE = float(os.getenv("RSI_TEMPERATURE", "0.7"))
TOP_P = float(os.getenv("RSI_TOP_P", "0.8"))
MAX_SEQ_LEN = int(os.getenv("RSI_MAX_SEQ_LEN", "4096"))
