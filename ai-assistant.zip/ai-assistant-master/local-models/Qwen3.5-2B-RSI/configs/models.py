# configs/models.py
"""ModelSpec：换模型只改这里。

2B 首版验证闭环；9B / 35B-A3B 通过新增 spec 与并行/量化/服务后端适配，
数据契约、Recipe、训练脚本、评测与 OpenAI 接口保持不变。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

from configs.configs import FALLBACK_BASE_2B, MODELS_DIR


@dataclass
class ModelSpec:
    name: str
    model_id: str
    local_dir: str
    arch: str = "dense"              # dense | moe
    dtype: str = "bfloat16"
    quantization: str | None = None  # None | 4bit | 8bit
    lora_r: int = 64
    lora_alpha: int = 128
    lora_dropout: float = 0.05
    max_seq_len: int = 4096
    lora_targets: list[str] = field(default_factory=list)
    lora_target_regex: str = ""
    parallel: str = "none"           # none | ddp | fsdp | deepspeed
    serve_backend: str = "transformers"
    trust_remote_code: bool = True
    fallback_dir: str = ""
    notes: str = ""

    def resolved_dir(self) -> Path:
        path = Path(self.local_dir).expanduser()
        if path.exists():
            return path
        if self.fallback_dir and Path(self.fallback_dir).expanduser().exists():
            return Path(self.fallback_dir).expanduser()
        return path

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


DENSE_TARGETS = [
    "q_proj", "k_proj", "v_proj", "o_proj",
    "in_proj_qkv", "out_proj",
    "gate_proj", "up_proj", "down_proj",
]

MOE_TARGET_REGEX = r"(q_proj|k_proj|v_proj|o_proj|in_proj_qkv|out_proj|shared_expert\.(gate_proj|up_proj|down_proj))$"


MODELS: dict[str, ModelSpec] = {
    "qwen3.5-2b": ModelSpec(
        name="qwen3.5-2b",
        model_id="Qwen/Qwen3.5-2B",
        local_dir=os.getenv("RSI_MODEL_DIR_2B", str(MODELS_DIR / "Qwen" / "Qwen3.5-2B")),
        arch="dense",
        lora_r=64,
        lora_alpha=128,
        max_seq_len=4096,
        lora_targets=DENSE_TARGETS,
        parallel="none",
        serve_backend="transformers",
        trust_remote_code=True,
        fallback_dir=FALLBACK_BASE_2B,
        notes="首版：16G 级显存可 LoRA SFT/DPO，CPU 可慢速推理",
    ),
    "qwen3.5-9b": ModelSpec(
        name="qwen3.5-9b",
        model_id="Qwen/Qwen3.5-9B",
        local_dir=os.getenv("RSI_MODEL_DIR_9B", str(MODELS_DIR / "Qwen" / "Qwen3.5-9B")),
        arch="dense",
        lora_r=32,
        lora_alpha=64,
        max_seq_len=8192,
        lora_targets=DENSE_TARGETS,
        parallel="ddp",
        serve_backend="vllm",
        quantization="4bit",
        notes="QLoRA 4bit，建议 24-48G 显存",
    ),
    "qwen3.5-35b-a3b": ModelSpec(
        name="qwen3.5-35b-a3b",
        model_id="Qwen/Qwen3.5-35B-A3B",
        local_dir=os.getenv("RSI_MODEL_DIR_35B", str(MODELS_DIR / "Qwen" / "Qwen3.5-35B-A3B")),
        arch="moe",
        lora_r=32,
        lora_alpha=64,
        max_seq_len=8192,
        lora_targets=[],
        lora_target_regex=MOE_TARGET_REGEX,
        parallel="fsdp",
        serve_backend="vllm",
        quantization="4bit",
        notes="MoE：首版只训 attention + linear_attn + shared_expert，避免 256 experts 打爆规模",
    ),
}


def get_model(name: str | None = None) -> ModelSpec:
    from configs.configs import DEFAULT_MODEL

    return MODELS.get(name or DEFAULT_MODEL, MODELS[DEFAULT_MODEL])


def list_models() -> list[dict[str, Any]]:
    from configs.configs import DEFAULT_MODEL

    result = []
    for name, spec in MODELS.items():
        path = spec.resolved_dir()
        result.append({
            "name": name,
            "model_id": spec.model_id,
            "arch": spec.arch,
            "local_dir": str(path),
            "exists": (path / "config.json").exists(),
            "default": name == DEFAULT_MODEL,
        })
    return result
