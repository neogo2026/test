# Qwen3.5-2B-RSI

AI助理的私有化自进化模型工程。首版只做 **Qwen3.5-2B**，9B / 35B-A3B 通过
`ModelSpec` 迁移，数据契约、Recipe、评测与 OpenAI 接口保持不变。

```text
AI助理真实轨迹 ──RSI 插件导出──▶ sft / dpo / eval JSONL
                                      │
                              归一化 / 去重 / 去污染
                                      │
                         SFT(LoRA) → DPO(轮级) → GRPO(实验)
                                      │
                            adapter + manifest + 评测
                                      │
                        OpenAI /v1/chat/completions （:9065）
                                      │
                            AI助理 ModelProfile 调用
```

## 目录

```text
main.py                     FastAPI 入口
configs/
  configs.py                路径 / 端口 / 默认参数
  models.py                 ModelSpec：2B / 9B / 35B-A3B
  recipes.py                RecipeSpec：rsi-v1 数据与训练配方
  modules.py                路由注册表
extensions/rsi_engine/
  engine.py                 基座 + 多 adapter 推理（串行锁）
  codec.py                  OpenAI 消息 / Qwen 模板 / tool_calls 编解码
  registry.py               adapter 扫描与别名解析
  router.py                 OpenAI 兼容 + 版本/健康接口
extensions/rsi_train/
  import_export.py          RSI JSONL → 标准格式（去重/去污染）
  sft.py                    LoRA / QLoRA SFT（assistant-only loss）
  dpo.py                    轮级 DPO（ref 用 disable_adapter）
  grpo.py                   可验证奖励 + group 优势 + KL
  eval.py                   真实任务回放评测
  manifest.py               数据/模型/模板 hash
  train.py                  CLI
  serve.py / scripts/
data/                       导出、processed、manifests
adapters/                   产物 adapter（含 manifest.json）
reports/                    评测报告
scripts/selftest.py         工程自测（不加载权重）
```

## 快速开始

### 一键启动

Windows：

```bat
deploy\start.bat
deploy\stop.bat
deploy\restart.bat
```

Linux / macOS：

```bash
chmod +x deploy/*.sh
./deploy/start.sh
./deploy/stop.sh
./deploy/restart.sh
```

脚本会自动：
- 切到项目目录，优先使用 `.venv`（存在时）
- 设置 `RSI_HOST` / `RSI_PORT` / `RSI_MODEL` / `RSI_RECIPE`
- **默认 `RSI_PRELOAD=0`：服务立即启动，`/docs` 与 `/api/rsi/health` 马上可访问；首次推理时再加载模型**
- 如需启动时就加载基座，显式设置 `RSI_PRELOAD=1`（启动会等待模型加载完）
- 检查 `fastapi / uvicorn / torch / transformers / peft` 依赖

可覆盖的环境变量：

```bash
RSI_HOST=0.0.0.0
RSI_PORT=9065
RSI_MODEL=qwen3.5-2b
RSI_PRELOAD=1
RSI_AUTO_DOWNLOAD=1
PYTHON=/path/to/python
```

### 手动启动

```bash
cd local-models/Qwen3.5-2B-RSI
pip install -r requirements.txt

# 1) 下载基座（二选一）
#    a. ModelScope
python -c "from modelscope import snapshot_download; snapshot_download('Qwen/Qwen3.5-2B', local_dir='models/Qwen/Qwen3.5-2B')"
#    b. 复用本机参考工程
set RSI_BASE_2B_FALLBACK=D:\Env\git\ai-models\Qwen3.5-2B\models\Qwen\Qwen3.5-2B

# 2) 启动 OpenAI 兼容服务
python main.py            # http://127.0.0.1:9065/docs

# 3) 工程自测（无权重）
python scripts/selftest.py
```

> **已验证：** 本项目在 `transformers 5.22.1 + torch 2.11 (CUDA)` 下完成基座加载与
> 真实生成（2B 权重约 4.5GB，首轮加载约 170s，未安装 causal_conv1d /
> flash-linear-attention 时走参考实现）。工程自测 16/16 通过；LoRA SFT 1 步训练
> 成功（trainable 57.8M / 2.98%，1.9B 总参数），保存的 adapter 可被推理引擎加载并生成。

健康检查：

```bash
curl http://127.0.0.1:9065/api/rsi/health
curl http://127.0.0.1:9065/v1/models
```

## 数据链路

AI助理 RSI 插件导出（默认在 `api/data/rsi/exports/`）：

```bash
GET http://127.0.0.1:8036/api/rsi/export/sft
GET http://127.0.0.1:8036/api/rsi/export/dpo
GET http://127.0.0.1:8036/api/rsi/export/eval
```

拷贝到 `data/exports/` 后归一化：

```bash
python -m extensions.rsi_train.train prepare \
  --sft data/exports/sft.jsonl \
  --dpo data/exports/dpo.jsonl \
  --eval data/exports/eval.jsonl \
  --output data/processed
```

纪律：评测集与训练集隔离；失败轨迹不直接进 SFT；DPO chosen 必须有外部验证依据；
模型自产数据必须经过测试/人工复核。

## 训练

```bash
# SFT（2B，16G 级显存）
python -m extensions.rsi_train.train sft --model qwen3.5-2b --data data/processed/sft.jsonl

# DPO（从 SFT adapter 初始化）
python -m extensions.rsi_train.train dpo --model qwen3.5-2b --data data/processed/dpo.jsonl

# 评测（base vs adapter）
python -m extensions.rsi_train.train eval --model qwen3.5-2b --adapter sft

# GRPO（实验性；必须提供可验证奖励函数）
python -m extensions.rsi_train.train grpo --model qwen3.5-2b --reward-file reward_example.py
```

产物：`adapters/qwen3.5-2b/rsi-v1/{sft,dpo,grpo}/`，包含 adapter 权重、tokenizer、
`manifest.json`（模型/数据/模板 hash + 指标 + status）。

## 服务与 AI助理接入

```python
# ai-assistant/api/configs/models.py
"qwen35-2b-rsi": ModelProfile(
    name="qwen35-2b-rsi",
    provider="local",
    base_url="http://127.0.0.1:9065/v1",
    model="qwen3.5-2b-rsi",
    context_window=32768,
    max_output=4096,
    tool_call="native",
    extra_body={"adapter": "sft"},   # 或使用模型别名 qwen3.5-2b-rsi-sft
)
```

AI助理侧需设置 `FORGE_RSI_MODEL_ENABLED=1` 才会在模型选择器展示本地 RSI 模型。

## 迁移 9B / 35B-A3B

```bash
# 9B：QLoRA 4bit
python -m extensions.rsi_train.train sft --model qwen3.5-9b --data data/processed/sft.jsonl

# 35B-A3B：MoE + FSDP + QLoRA
python -m extensions.rsi_train.train sft --model qwen3.5-35b-a3b --data data/processed/sft.jsonl
```

只需新增/调整 `configs/models.py` 的 `lora_targets` / `lora_target_regex` / `parallel` /
`quantization` / `serve_backend`。**不要**对 35B-A3B 使用 `all-linear`，否则 256 个
experts 会把 LoRA 规模打爆；首版只覆盖 attention + linear_attn + shared_expert。

硬件现实：2B 16G 级可 LoRA；9B 通常 24-48G 做 QLoRA；35B-A3B 需要多卡或云端。
数据、Recipe、评测、OpenAI 接口可以完全复用。

## 安全

- 训练/评测默认离线；不自动上传数据。
- adapter 默认 `candidate`，通过评测与门禁后才在 AI助理侧灰度。
- 每个 adapter 带 manifest，可追溯 base / tokenizer / chat template / 数据 hash。
- 本服务只做推理与离线训练，不在线自改代码。
