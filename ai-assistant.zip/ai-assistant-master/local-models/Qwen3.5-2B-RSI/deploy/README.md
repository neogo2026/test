# Qwen3.5-2B-RSI 部署脚本

统一在 `deploy/` 下管理启动、停止、重启。服务默认后台运行，日志和 PID 在 `deploy/run/`。

## Windows

```bat
deploy\start.bat
deploy\stop.bat
deploy\restart.bat
```

- `start.bat`：后台启动，等待健康检查后返回
- `stop.bat`：按 PID 文件 + 端口查找，只终止命令行包含 `main.py` 的 Python 进程
- `restart.bat`：停止 → 等待 2 秒 → 启动

日志：

```text
deploy\run\server.out.log
deploy\run\server.err.log
deploy\run\qwen35-rsi.pid
```

## Linux / macOS

```bash
chmod +x deploy/*.sh
./deploy/start.sh
./deploy/stop.sh
./deploy/restart.sh
```

日志与 PID 同上。

## 环境变量

脚本支持通过环境变量覆盖：

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `RSI_HOST` | `127.0.0.1` | 监听地址；对外服务可设 `0.0.0.0` |
| `RSI_PORT` | `9065` | 服务端口 |
| `RSI_MODEL` | `qwen3.5-2b` | ModelSpec 名称 |
| `RSI_RECIPE` | `rsi-v1` | 训练/推理配方 |
| `RSI_PRELOAD` | `0` | 1=启动时加载基座；0=首次推理再加载（推荐，服务立即可访问） |
| `RSI_AUTO_DOWNLOAD` | `0` | 1=模型缺失时从 ModelScope 下载 |
| `PYTHON` | 自动 | 指定 Python 可执行文件（Linux） |

示例：

```bat
set RSI_PORT=9070
set RSI_PRELOAD=0
deploy\start.bat
```

```bash
RSI_PORT=9070 RSI_PRELOAD=0 ./deploy/start.sh
```

## 就绪检查

```text
http://127.0.0.1:9065/api/rsi/health
http://127.0.0.1:9065/docs
```

`loaded=false` 表示服务已启动、模型尚未加载；发一次推理请求后会自动加载。

> 说明：Windows 批处理/脚本输出使用英文，避免 cmd 中文编码问题；中文说明以本文件为准。
