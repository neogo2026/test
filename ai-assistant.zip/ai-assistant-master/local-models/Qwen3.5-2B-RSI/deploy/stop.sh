#!/usr/bin/env bash
# Qwen3.5-2B-RSI 停止服务（Linux / macOS）
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DEPLOY/.." && pwd)"
cd "$ROOT"

RUN_DIR="$DEPLOY/run"
PID_FILE="$RUN_DIR/qwen35-rsi.pid"
PORT="${RSI_PORT:-9065}"

candidate_pids=()
if [ -f "$PID_FILE" ]; then
  pid="$(cat "$PID_FILE" 2>/dev/null | head -n1 || true)"
  if [[ "$pid" =~ ^[0-9]+$ ]]; then
    candidate_pids+=("$pid")
  fi
fi
if command -v lsof >/dev/null 2>&1; then
  while IFS= read -r pid; do
    [ -n "$pid" ] && candidate_pids+=("$pid")
  done < <(lsof -ti "tcp:$PORT" 2>/dev/null || true)
fi

# 去重
unique_pids=()
for pid in "${candidate_pids[@]:-}"; do
  [ -z "$pid" ] && continue
  skip=0
  for seen in "${unique_pids[@]:-}"; do
    [ "$seen" = "$pid" ] && skip=1 && break
  done
  [ "$skip" = 0 ] && unique_pids+=("$pid")
done

stopped=()
skipped=()
for pid in "${unique_pids[@]:-}"; do
  [ -z "$pid" ] && continue
  if ! kill -0 "$pid" 2>/dev/null; then
    continue
  fi
  cmd=""
  if [ -r "/proc/$pid/cmdline" ]; then
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
  else
    cmd="$(ps -p "$pid" -o command= 2>/dev/null || true)"
  fi
  if [[ "$cmd" != *main.py* ]]; then
    skipped+=("$pid")
    continue
  fi
  kill "$pid" 2>/dev/null || true
  for _ in $(seq 1 30); do
    if ! kill -0 "$pid" 2>/dev/null; then
      break
    fi
    sleep 0.5
  done
  if kill -0 "$pid" 2>/dev/null; then
    kill -9 "$pid" 2>/dev/null || true
  fi
  stopped+=("$pid")
done

rm -f "$PID_FILE"

if [ "${#stopped[@]}" -gt 0 ]; then
  echo "[OK] 已停止 Qwen3.5-2B-RSI（PID: ${stopped[*]}）"
elif [ "${#skipped[@]}" -gt 0 ]; then
  echo "[WARN] 端口 $PORT 被非匹配进程占用（PID: ${skipped[*]}），未终止。"
else
  echo "[INFO] Qwen3.5-2B-RSI 未在运行。"
fi
