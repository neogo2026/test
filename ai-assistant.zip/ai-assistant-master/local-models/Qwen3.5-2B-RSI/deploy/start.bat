@echo off
setlocal EnableExtensions
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0win_start.ps1"
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" (
  pause
) else if /i not "%1"=="/nopause" (
  pause
)
endlocal & exit /b %CODE%
