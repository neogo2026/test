# Qwen3.5-2B-RSI Windows stop helper
$ErrorActionPreference = "SilentlyContinue"

$Deploy = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Deploy
Set-Location $Root

$RunDir = Join-Path $Deploy "run"
$PidFile = Join-Path $RunDir "qwen35-rsi.pid"
$Port = if ($env:RSI_PORT) { [int]$env:RSI_PORT } else { 9065 }

$CandidatePids = @()
if (Test-Path $PidFile) {
    $raw = Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($raw -match '^\d+$') { $CandidatePids += [int]$raw }
}
$conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($conns) {
    $CandidatePids += $conns | Select-Object -ExpandProperty OwningProcess
}
$CandidatePids = $CandidatePids | Where-Object { $_ -and $_ -gt 0 } | Sort-Object -Unique

$Stopped = @()
$Skipped = @()
foreach ($procId in $CandidatePids) {
    $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction SilentlyContinue
    if (-not $proc) { continue }
    # Safety: only kill a Python process whose command line contains main.py
    $isOurs = $false
    if ($proc.CommandLine) {
        if ($proc.CommandLine -match 'main\.py' -and $proc.Name -match '^python') { $isOurs = $true }
    }
    if ($isOurs) {
        taskkill /PID $procId /T /F 2>$null | Out-Null
        $Stopped += $procId
    } else {
        $Skipped += $procId
    }
}

Remove-Item $PidFile -ErrorAction SilentlyContinue

if ($Stopped.Count -gt 0) {
    Write-Host "[OK] Stopped Qwen3.5-2B-RSI (PID: $($Stopped -join ', '))"
} elseif ($Skipped.Count -gt 0) {
    Write-Host "[WARN] Port $Port is used by non-matching process(es): $($Skipped -join ', '); not killed."
} else {
    Write-Host "[INFO] Qwen3.5-2B-RSI is not running."
}
exit 0
