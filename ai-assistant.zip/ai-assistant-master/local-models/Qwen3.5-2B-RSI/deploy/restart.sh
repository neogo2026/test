#!/usr/bin/env bash
# Qwen3.5-2B-RSI 重启服务（Linux / macOS）
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
"$DEPLOY/stop.sh"
sleep 1
exec "$DEPLOY/start.sh"
