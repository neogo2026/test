#!/usr/bin/env bash
# Qwen3.5-2B-RSI 一键启动（Linux / macOS，后台运行）
set -euo pipefail

DEPLOY="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DEPLOY/.." && pwd)"
cd "$ROOT"

RUN_DIR="$DEPLOY/run"
mkdir -p "$RUN_DIR"
PID_FILE="$RUN_DIR/qwen35-rsi.pid"
OUT_LOG="$RUN_DIR/server.out.log"
ERR_LOG="$RUN_DIR/server.err.log"

if [ -x ".venv/bin/python" ]; then
  PYTHON="${PYTHON:-$ROOT/.venv/bin/python}"
else
  PYTHON="${PYTHON:-python3}"
fi
if ! command -v "$PYTHON" >/dev/null 2>&1; then
  echo "[ERROR] 未找到 $PYTHON，请安装 Python 3.10+ 或设置 PYTHON 环境变量。"
  exit 1
fi

export RSI_HOST="${RSI_HOST:-127.0.0.1}"
export RSI_PORT="${RSI_PORT:-9065}"
export RSI_MODEL="${RSI_MODEL:-qwen3.5-2b}"
export RSI_RECIPE="${RSI_RECIPE:-rsi-v1}"
export RSI_PRELOAD="${RSI_PRELOAD:-0}"
export PYTHONUTF8="${PYTHONUTF8:-1}"
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"

HOST_ADDR="$RSI_HOST"
PORT="$RSI_PORT"
if [ "$HOST_ADDR" = "0.0.0.0" ] || [ "$HOST_ADDR" = "::" ]; then
  PROBE_HOST="127.0.0.1"
else
  PROBE_HOST="$HOST_ADDR"
fi

# 已经在运行？
if [ -f "$PID_FILE" ]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "[INFO] Qwen3.5-2B-RSI 已在运行（PID: $OLD_PID），地址：http://$PROBE_HOST:$PORT/docs"
    exit 0
  fi
  rm -f "$PID_FILE"
fi
if command -v lsof >/dev/null 2>&1 && lsof -ti "tcp:$PORT" >/dev/null 2>&1; then
  echo "[INFO] 端口 $PORT 已有监听进程，视为已运行：http://$PROBE_HOST:$PORT/docs"
  exit 0
fi

if ! "$PYTHON" -c "import fastapi, uvicorn, torch, transformers, peft" >/dev/null 2>&1; then
  echo "[ERROR] 缺少运行依赖。请先执行："
  echo "        $PYTHON -m pip install -r requirements.txt"
  exit 1
fi

cat <<EOF
============================================================
 Qwen3.5-2B-RSI
 Model  : $RSI_MODEL    Recipe: $RSI_RECIPE
 Host   : $RSI_HOST:$RSI_PORT
 Preload: $RSI_PRELOAD  (1=启动时加载基座，首次请求不等待)
============================================================
EOF

echo "[INFO] 后台启动中..."
nohup "$PYTHON" main.py >>"$OUT_LOG" 2>&1 &
PID=$!
echo "$PID" > "$PID_FILE"

READY=0
for _ in $(seq 1 40); do
  if ! kill -0 "$PID" 2>/dev/null; then
    break
  fi
  if command -v curl >/dev/null 2>&1; then
    if curl -sf "http://$PROBE_HOST:$PORT/api/rsi/health" >/dev/null 2>&1; then
      READY=1
      break
    fi
  else
    if "$PYTHON" -c "import sys,urllib.request; urllib.request.urlopen('http://'+sys.argv[1]+':'+sys.argv[2]+'/api/rsi/health', timeout=1)" "$PROBE_HOST" "$PORT" >/dev/null 2>&1; then
      READY=1
      break
    fi
  fi
  sleep 0.5
done

if ! kill -0 "$PID" 2>/dev/null; then
  echo "[ERROR] 服务启动失败，请查看日志："
  echo "        $OUT_LOG"
  echo "        $ERR_LOG"
  rm -f "$PID_FILE"
  exit 1
fi

if [ "$READY" = "1" ]; then
  echo "[OK] 已启动（PID: $PID）"
else
  echo "[WARN] 进程已启动（PID: $PID），但健康检查尚未就绪。"
fi
echo "     URL    : http://$PROBE_HOST:$PORT/docs"
echo "     日志   : $OUT_LOG"
echo "    停止   : $DEPLOY/stop.sh"
echo "    重启   : $DEPLOY/restart.sh"
