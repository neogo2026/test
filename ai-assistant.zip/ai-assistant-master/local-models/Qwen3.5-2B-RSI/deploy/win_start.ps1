# Qwen3.5-2B-RSI Windows background launcher
$ErrorActionPreference = "Stop"

$Deploy = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Deploy
Set-Location $Root

$RunDir = Join-Path $Deploy "run"
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$PidFile = Join-Path $RunDir "qwen35-rsi.pid"
$OutLog = Join-Path $RunDir "server.out.log"
$ErrLog = Join-Path $RunDir "server.err.log"

function Set-DefaultEnv([string]$Name, [string]$Value) {
    if (-not [Environment]::GetEnvironmentVariable($Name)) {
        [Environment]::SetEnvironmentVariable($Name, $Value, "Process")
    }
}

Set-DefaultEnv "RSI_HOST" "127.0.0.1"
Set-DefaultEnv "RSI_PORT" "9065"
Set-DefaultEnv "RSI_MODEL" "qwen3.5-2b"
Set-DefaultEnv "RSI_RECIPE" "rsi-v1"
Set-DefaultEnv "RSI_PRELOAD" "0"
Set-DefaultEnv "PYTHONUTF8" "1"
Set-DefaultEnv "PYTHONIOENCODING" "utf-8"

$HostAddr = $env:RSI_HOST
$Port = $env:RSI_PORT
$ProbeHost = if ($HostAddr -eq "0.0.0.0" -or $HostAddr -eq "::") { "127.0.0.1" } else { $HostAddr }

# Already running?
$conn = Get-NetTCPConnection -LocalPort ([int]$Port) -State Listen -ErrorAction SilentlyContinue
if ($conn) {
    $owners = ($conn | Select-Object -ExpandProperty OwningProcess -Unique)
    $ours = $false
    foreach ($owner in $owners) {
        $p = Get-CimInstance Win32_Process -Filter "ProcessId=$owner" -ErrorAction SilentlyContinue
        if ($p -and $p.CommandLine -match 'main\.py' -and $p.Name -match '^python') { $ours = $true }
    }
    if ($ours) {
        Write-Host "[INFO] Qwen3.5-2B-RSI already listening on ${HostAddr}:${Port} (PID: $($owners -join ', '))"
        exit 0
    }
    Write-Host "[ERROR] Port $Port is already used by another process (PID: $($owners -join ', '))."
    Write-Host "        Stop it or set another RSI_PORT."
    exit 1
}

# Python: prefer .venv, then python, then py -3
$PythonExe = ""
$PythonArgs = @()
$VenvPython = Join-Path $Root ".venv\Scripts\python.exe"
if (Test-Path $VenvPython) {
    $PythonExe = $VenvPython
} else {
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd) {
        $PythonExe = $cmd.Source
    } else {
        $cmd = Get-Command py -ErrorAction SilentlyContinue
        if ($cmd) {
            $PythonExe = $cmd.Source
            $PythonArgs = @("-3")
        }
    }
}
if (-not $PythonExe) {
    Write-Host "[ERROR] Python not found. Install Python 3.10+ and add it to PATH."
    exit 1
}

# Dependencies
$OldEap = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
& $PythonExe @PythonArgs -c "import fastapi, uvicorn, torch, transformers, peft" *> $null
$DepCode = $LASTEXITCODE
$ErrorActionPreference = $OldEap
if ($DepCode -ne 0) {
    Write-Host "[ERROR] Missing dependencies. Run:"
    Write-Host "        `"$PythonExe`" $($PythonArgs -join ' ') -m pip install -r requirements.txt"
    exit 1
}

Write-Host "============================================================"
Write-Host " Qwen3.5-2B-RSI"
Write-Host " Model  : $($env:RSI_MODEL)    Recipe: $($env:RSI_RECIPE)"
Write-Host " Host   : ${HostAddr}:${Port}"
Write-Host " Preload: $($env:RSI_PRELOAD)  (1=load model at startup)"
Write-Host "============================================================"

$ArgumentList = @()
$ArgumentList += $PythonArgs
$ArgumentList += "main.py"

try {
    $proc = Start-Process -FilePath $PythonExe -ArgumentList $ArgumentList `
        -WorkingDirectory $Root -WindowStyle Hidden `
        -RedirectStandardOutput $OutLog -RedirectStandardError $ErrLog -PassThru
    $proc.Id | Set-Content -Encoding ASCII $PidFile
} catch {
    Write-Host "[ERROR] Failed to start process: $($_.Exception.Message)"
    exit 1
}

$Ready = $false
for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 500
    if ($proc.HasExited) { break }
    try {
        $resp = Invoke-RestMethod -Uri "http://${ProbeHost}:${Port}/api/rsi/health" -TimeoutSec 1
        if ($resp.code -eq 200) { $Ready = $true; break }
    } catch { }
}

if ($proc.HasExited) {
    Write-Host "[ERROR] Service exited early. Check: $ErrLog"
    Remove-Item $PidFile -ErrorAction SilentlyContinue
    exit 1
}

if ($Ready) {
    Write-Host "[OK] Started (PID: $($proc.Id))"
} else {
    Write-Host "[WARN] Process started (PID: $($proc.Id)) but health check is not ready yet."
}
Write-Host "     URL  : http://${ProbeHost}:${Port}/docs"
Write-Host "     Logs : $OutLog"
Write-Host "            $ErrLog"
Write-Host "     Stop : deploy\stop.bat"
Write-Host "     Restart: deploy\restart.bat"
exit 0
