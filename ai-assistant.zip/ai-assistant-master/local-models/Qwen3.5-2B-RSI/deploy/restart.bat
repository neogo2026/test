@echo off
setlocal EnableExtensions
call "%~dp0stop.bat" /nopause
timeout /t 2 /nobreak >nul
call "%~dp0start.bat" /nopause
set "CODE=%ERRORLEVEL%"
if /i not "%1"=="/nopause" pause
endlocal & exit /b %CODE%
