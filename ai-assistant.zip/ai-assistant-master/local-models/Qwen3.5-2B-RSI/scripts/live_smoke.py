# -*- coding: utf-8 -*-
"""本地模型线上实测：复现 tools + 历史 tool_calls(JSON 字符串参数) + 流式 的崩溃场景。"""
import json
import httpx

BASE = "http://127.0.0.1:9065"
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a text file and return its content.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string"}, "limit": {"type": "integer", "default": 400}},
                "required": ["path"],
            },
        },
    }
]

# 历史里 assistant.tool_calls 的 arguments 是 JSON 字符串（AI助理 ContextBuilder 的真实形态）
MESSAGES = [
    {"role": "system", "content": "You are a coding agent. Use tools when needed."},
    {"role": "user", "content": "Read the file notes/a.py"},
    {
        "role": "assistant",
        "content": None,
        "tool_calls": [{
            "id": "call_1",
            "type": "function",
            "function": {"name": "read_file", "arguments": "{\"path\": \"notes/a.py\"}"},
        }],
    },
    {"role": "tool", "tool_call_id": "call_1", "name": "read_file", "content": "print('hello')"},
    {"role": "user", "content": "Summarize the file in one short sentence, then list what tool you would call next."},
]

ok = True

# ---- 1) 非流式 + tools ----
r = httpx.post(f"{BASE}/v1/chat/completions", json={
    "model": "qwen3.5-2b-rsi", "messages": MESSAGES, "tools": TOOLS,
    "temperature": 0.2, "max_tokens": 160, "stream": False,
}, timeout=300)
print("non-stream status:", r.status_code)
if r.status_code != 200:
    ok = False
    print(r.text[:800])
else:
    data = r.json()
    msg = data["choices"][0]["message"]
    print("finish:", data["choices"][0]["finish_reason"], "| tool_calls:", len(msg.get("tool_calls") or []),
          "| usage:", data.get("usage"))
    for call in msg.get("tool_calls") or []:
        print("  call:", call["function"]["name"], call["function"]["arguments"])
    print("  text:", (msg.get("content") or "")[:200])

# ---- 2) 流式 + tools + 历史参数为 JSON 字符串（原崩溃路径） ----
with httpx.Client(timeout=300) as client:
    with client.stream("POST", f"{BASE}/v1/chat/completions", json={
        "model": "qwen3.5-2b-rsi", "messages": MESSAGES, "tools": TOOLS,
        "temperature": 0.2, "max_tokens": 160, "stream": True,
    }) as resp:
        print("stream status:", resp.status_code)
        if resp.status_code != 200:
            ok = False
            print(resp.read()[:800].decode("utf-8", "replace"))
        else:
            frames = 0
            final_calls = []
            finish = None
            usage = None
            for line in resp.iter_lines():
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                chunk = json.loads(payload)
                frames += 1
                choice = (chunk.get("choices") or [{}])[0]
                if choice.get("finish_reason"):
                    finish = choice["finish_reason"]
                delta = choice.get("delta") or {}
                if delta.get("tool_calls"):
                    final_calls = delta["tool_calls"]
                if chunk.get("usage"):
                    usage = chunk["usage"]
            print("stream frames:", frames, "| finish:", finish, "| tool_calls:", len(final_calls), "| usage:", usage)
            if frames == 0:
                ok = False

print("RESULT:", "PASS" if ok else "FAIL")
