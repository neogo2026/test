# scripts/selftest.py
"""Qwen3.5-2B-RSI 工程自测（不加载权重、不消耗 GPU）。

覆盖：配置 / ModelSpec / Recipe / Adapter 注册 / codec / 数据归一化 /
manifest / OpenAI 路由健康检查。
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {detail}")


def test_configs() -> None:
    print("== 1. 配置与模型 spec ==")
    from configs.configs import PORT
    from configs.models import MODELS, get_model, list_models
    from configs.recipes import get_recipe

    check("2B spec 存在", "qwen3.5-2b" in MODELS)
    check("9B spec 存在", "qwen3.5-9b" in MODELS)
    check("35B-A3B spec 存在", "qwen3.5-35b-a3b" in MODELS)
    check("默认 recipe", get_recipe().name == "rsi-v1")
    check("端口默认 9065", PORT == 9065, str(PORT))
    spec = get_model("qwen3.5-2b")
    check("2B 有 fallback 基座", bool(spec.resolved_dir()))
    check("模型列表", len(list_models()) == 3)


def test_codec() -> None:
    print("== 2. codec / tool_calls 解析 ==")
    from extensions.rsi_engine import codec

    # Qwen3.5 原生格式
    qwen_text = (
        "先读文件\n<tool_call>\n<function=read_file>\n<parameter=path>\nnotes/a.py\n</parameter>\n"
        "<parameter=limit>\n200\n</parameter>\n</function>\n</tool_call>"
    )
    cleaned, calls = codec.parse_tool_calls(qwen_text)
    check("解析 Qwen 原生 tool_call", len(calls) == 1 and calls[0]["function"]["name"] == "read_file")
    args = json.loads(calls[0]["function"]["arguments"])
    check("Qwen 参数值类型", args.get("path") == "notes/a.py" and args.get("limit") == 200, json.dumps(args))

    # 旧式 JSON 格式
    json_text = '先读文件\n<tool_call>{"name":"read_file","arguments":{"path":"a.py"}}</tool_call>'
    cleaned2, calls2 = codec.parse_tool_calls(json_text)
    check("解析 JSON tool_call", len(calls2) == 1 and calls2[0]["function"]["name"] == "read_file")
    check("清理标签", "<tool_call>" not in cleaned and "<tool_call>" not in cleaned2)
    check("无调用", codec.parse_tool_calls("hello")[1] == [])

    # 历史消息：arguments 为 JSON 字符串（OpenAI 格式）→ dict（Qwen 模板要求）
    msgs = codec.normalize_messages([
        {"role": "assistant", "tool_calls": [{
            "id": "call_1", "type": "function",
            "function": {"name": "read_file", "arguments": "{\"path\": \"a.py\"}"},
        }]},
        {"role": "user", "content": [{"type": "text", "text": "hi"}]},
    ])
    tc = msgs[0]["tool_calls"][0]["function"]["arguments"]
    check("历史 arguments 字符串转 dict", isinstance(tc, dict) and tc.get("path") == "a.py", repr(tc))
    check("多模态 content 归一化", msgs[1]["content"] == "hi")


def test_registry() -> None:
    print("== 3. Adapter 注册 ==")
    from configs.configs import ADAPTERS_DIR
    from extensions.rsi_engine.registry import AdapterRegistry

    registry = AdapterRegistry()
    check("adapter 目录存在", Path(ADAPTERS_DIR).exists())
    check("空注册表可扫描", isinstance(registry.list(), list))
    check("未知 adapter 返回空", registry.resolve("not-exist") is None)


def test_data_pipeline() -> None:
    print("== 4. 数据导入 / 去重 / 去污染 ==")
    from extensions.rsi_train import import_export

    tmp = Path(tempfile.mkdtemp(prefix="rsi-data-"))
    sft = tmp / "sft.jsonl"
    dpo = tmp / "dpo.jsonl"
    ev = tmp / "eval.jsonl"
    messages = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "写一个函数"},
        {"role": "assistant", "content": "已实现"},
    ]
    contaminated = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "评测专用任务"},
        {"role": "assistant", "content": "已实现"},
    ]
    sft.write_text(json.dumps({"id": "1", "messages": messages, "outcome": "success"}) + "\n" +
                   json.dumps({"id": "2", "messages": messages, "outcome": "success"}) + "\n" +
                   json.dumps({"id": "3", "messages": messages, "outcome": "failed"}) + "\n" +
                   json.dumps({"id": "4", "messages": contaminated, "outcome": "success"}) + "\n",
                   encoding="utf-8")
    dpo.write_text(json.dumps({
        "id": "p1", "prompt_messages": [{"role": "user", "content": "修复 bug"}],
        "chosen": {"content": "fixed"}, "rejected": {"content": "wrong"},
    }) + "\n", encoding="utf-8")
    ev.write_text(json.dumps({"id": "e1", "instruction": "评测专用任务", "checks": {"contains": ["x"]}}) + "\n",
                  encoding="utf-8")
    report = import_export.prepare(str(sft), str(dpo), str(ev), tmp / "processed")
    check("SFT 去重/过滤", report["sft"]["kept"] == 1, json.dumps(report.get("sft")))
    check("SFT 去污染", report["sft"]["contaminated"] == 1, json.dumps(report.get("sft")))
    check("DPO 归一化", report["dpo"]["kept"] == 1)
    check("评测集归一化", report["eval"]["kept"] == 1)
    check("processed 文件生成", (tmp / "processed" / "sft.jsonl").exists())


def test_manifest() -> None:
    print("== 5. Manifest ==")
    from configs.models import get_model
    from configs.recipes import get_recipe
    from extensions.rsi_train.manifest import build_manifest, write_manifest

    tmp = Path(tempfile.mkdtemp(prefix="rsi-manifest-"))
    data = tmp / "sft.jsonl"
    data.write_text('{"messages":[]}\n', encoding="utf-8")
    manifest = build_manifest(get_model("qwen3.5-2b"), get_recipe(), "sft", tmp / "adapter",
                              [data], {"train_samples": 1}, alias="sft")
    path = write_manifest(tmp / "adapter", manifest)
    check("manifest 写入", path.exists())
    loaded = json.loads(path.read_text(encoding="utf-8"))
    check("manifest 关键字段", loaded["stage"] == "sft" and loaded["alias"] == "sft")
    check("数据 hash", bool(loaded["data"].get("sft.jsonl")))


async def test_routes() -> None:
    print("== 6. OpenAI 兼容路由（不加载权重） ==")
    import httpx

    import main as model_main

    async with model_main.app.router.lifespan_context(model_main.app):
        transport = httpx.ASGITransport(app=model_main.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=30) as cli:
            health = (await cli.get("/api/rsi/health")).json()["data"]
            check("health 可访问", health["model"]["name"] == "qwen3.5-2b")
            check("health 报告基座", "base_exists" in health)
            models = (await cli.get("/v1/models")).json()
            check("模型列表", any(m["id"] == "qwen3.5-2b-rsi" for m in models["data"]))
            versions = (await cli.get("/api/rsi/versions")).json()["data"]
            check("版本接口", "models" in versions)


def main() -> int:
    test_configs()
    test_codec()
    test_registry()
    test_data_pipeline()
    test_manifest()
    asyncio.run(test_routes())
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
