# -*- coding: utf-8 -*-
"""Local model concurrency evaluation through the AI Assistant (:8036).

Levels: 1 / 2 / 5 concurrent sessions, 2 dialogue turns per session.
Everything goes through the assistant dialog pipeline (sessions -> runs -> gateway -> :9065).

Outputs:
  - results JSON : test/testing/bench/results/model_conc/summary.json
  - HTML report  : test/testing/local-model-concurrency.html

Console output is ASCII-only (Windows GBK console safe).
"""
from __future__ import annotations

import json
import statistics
import time
from datetime import datetime
from pathlib import Path

import httpx

FORGE = "http://127.0.0.1:8036"
MODEL = "http://127.0.0.1:9065"
PROFILE = "qwen35-2b-rsi"
RUN_TIMEOUT_S = 300.0          # per-run hard wall (cancel beyond)
GLOBAL_SOFT_DEADLINE_S = 15 * 60   # do not start new turns beyond this
LEVELS = [1, 2, 5]
TURNS = 2

PROMPTS = [
    "用不超过80字解释：什么是智能体自我改进（RSI）？",
    "用不超过80字说明：工具调用失败后，智能体应如何反思与重试？",
    "用不超过80字回答：LoRA 微调相比全参数微调的优点？",
    "用不超过80字说明：什么是轨迹蒸馏？",
    "用不超过80字回答：为什么小模型适合私有化部署？",
]
COMPRESS = "把上一条回答压缩成不超过40字的一句话。"

BENCH = Path(r"D:\Env\git\ai-assistant\test\testing\bench")
RESULTS_JSON = BENCH / "results" / "model_conc" / "summary.json"
REPORT_HTML = Path(r"D:\Env\git\ai-assistant\test\testing\local-model-concurrency.html")

T0 = time.time()


def now_s() -> float:
    return round(time.time() - T0, 1)


def log(msg: str) -> None:
    print(f"[{now_s():7.1f}s] {msg}", flush=True)


def model_health(client: httpx.Client) -> dict:
    try:
        r = client.get(f"{MODEL}/api/rsi/health", timeout=3)
        data = (r.json() or {}).get("data") or {}
        return {"t": now_s(), "loaded": bool(data.get("loaded")),
                "adapter": data.get("current_adapter") or "", "last_error": data.get("last_error") or ""}
    except Exception as exc:  # noqa: BLE001
        return {"t": now_s(), "loaded": False, "adapter": "", "last_error": f"{type(exc).__name__}: {exc}"}


def create_session(client: httpx.Client, title: str) -> dict:
    r = client.post(f"{FORGE}/api/sessions", json={
        "title": title, "model_profile": PROFILE, "gate_mode": "allow_all",
        "agent_name": "assistant", "capabilities": {"rsi_mode": "off"},
    }, timeout=15)
    r.raise_for_status()
    return r.json()["data"]


def send_message(client: httpx.Client, sid: str, text: str) -> str:
    r = client.post(f"{FORGE}/api/sessions/{sid}/messages", json={"text": text}, timeout=30)
    r.raise_for_status()
    return r.json()["data"]["run_id"]


def poll_runs(client: httpx.Client, jobs: list[dict], deadline_at: float) -> None:
    """Poll all jobs until terminal or wall deadline; collect events metrics in place."""
    seqs = {j["run_id"]: 0 for j in jobs}
    pending = {j["run_id"] for j in jobs}
    while pending and time.time() < deadline_at:
        for j in jobs:
            if j["run_id"] in set(pending) and j.get("status") is None:
                rid = j["run_id"]
                try:
                    run = client.get(f"{FORGE}/api/runs/{rid}", timeout=10).json()["data"] or {}
                except Exception as exc:  # noqa: BLE001
                    j.setdefault("poll_errors", []).append(str(exc)[:120])
                    continue
                if run.get("status") in ("COMPLETED", "FAILED", "CANCELLED"):
                    j["status"] = run["status"]
                    j["error"] = (run.get("error") or "")[:400]
                    j["steps"] = int(run.get("step_count") or 0)
                    j["elapsed_s"] = round(time.time() - j["t0"], 1)
                    pending.discard(rid)
                    continue
                try:
                    evs = client.get(f"{FORGE}/api/runs/{rid}/events",
                                     params={"after_seq": seqs[rid]}, timeout=10).json()["data"] or []
                except Exception:  # noqa: BLE001
                    evs = []
                for ev in evs:
                    seqs[rid] = max(seqs[rid], int(ev.get("seq") or 0))
                    etype = ev.get("type")
                    payload = ev.get("payload") or {}
                    if etype == "model.delta" and j["first_delta_s"] is None:
                        j["first_delta_s"] = round(time.time() - j["t0"], 1)
                    elif etype == "model.completed":
                        usage = payload.get("usage") or {}
                        j["prompt_tokens"] += int(usage.get("prompt_tokens") or 0)
                        j["completion_tokens"] += int(usage.get("completion_tokens") or 0)
                        j["total_tokens"] += int(usage.get("total_tokens") or 0)
                        j["model_calls"] += 1
                    elif etype == "tool.result":
                        j["tool_calls"] += 1
                        if not payload.get("ok"):
                            j["tool_errors"] += 1
        time.sleep(0.5)
    # timeout guard
    for j in jobs:
        if j.get("status") is None:
            if time.time() >= deadline_at:
                j["status"] = "TIMEOUT"
                j["error"] = "bench per-run timeout"
                j["elapsed_s"] = round(time.time() - j["t0"], 1)
                try:
                    client.post(f"{FORGE}/api/sessions/{j['session_id']}/cancel", timeout=10)
                except Exception:  # noqa: BLE001
                    pass
            else:
                j["status"] = "TIMEOUT"
                j["error"] = "bench per-run timeout"
                j["elapsed_s"] = round(time.time() - j["t0"], 1)
                try:
                    client.post(f"{FORGE}/api/sessions/{j['session_id']}/cancel", timeout=10)
                except Exception:  # noqa: BLE001
                    pass


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    values = sorted(values)
    idx = max(0, min(len(values) - 1, int(round(q * (len(values) - 1)))))
    return values[idx]


def main(render_only: bool = False) -> int:
    results: list[dict] = []
    health_snapshots: list[dict] = []
    skipped_note = ""
    created_sessions: list[str] = []

    if render_only:
        if not RESULTS_JSON.exists():
            log(f"missing {RESULTS_JSON}")
            return 1
        saved = json.loads(RESULTS_JSON.read_text(encoding="utf-8"))
        results = saved.get("runs", [])
        health_snapshots = saved.get("health", [])
        skipped_note = saved.get("skipped_note", "")
    else:
        with httpx.Client() as client:
            health_snapshots.append(model_health(client))
        if not health_snapshots[0]["loaded"]:
            log("model not loaded, abort")
            return 1

        for level in LEVELS:
            sessions = []
            for idx in range(level):
                s = create_session(client, f"conc-eval:C{level}S{idx}")
                created_sessions.append(s["session_id"])
                sessions.append({"session_id": s["session_id"], "idx": idx})
            log(f"level={level}: created {len(sessions)} sessions")

            for turn in range(1, TURNS + 1):
                if time.time() - T0 > GLOBAL_SOFT_DEADLINE_S:
                    skipped_note = "global soft deadline reached; remaining turns skipped"
                    log(skipped_note)
                    break
                jobs = []
                for s in sessions:
                    text = PROMPTS[s["idx"] % len(PROMPTS)] if turn == 1 else COMPRESS
                    rid = send_message(client, s["session_id"], text)
                    jobs.append({
                        "level": level, "turn": turn, "session_idx": s["idx"],
                        "session_id": s["session_id"], "run_id": rid,
                        "t0": time.time(), "status": None, "error": "", "steps": 0,
                        "elapsed_s": None, "first_delta_s": None,
                        "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0,
                        "model_calls": 0, "tool_calls": 0, "tool_errors": 0,
                        "poll_errors": [],
                    })
                log(f"level={level} turn={turn}: fired {len(jobs)} runs")
                poll_runs(client, jobs, time.time() + RUN_TIMEOUT_S)
                for j in jobs:
                    results.append(j)
                    log(f"  C{level} S{j['session_idx']} T{turn}: {j['status']} "
                        f"elapsed={j['elapsed_s']}s first_delta={j['first_delta_s']}s "
                        f"tok={j['total_tokens']} gen={j['completion_tokens']} "
                        f"tools={j['tool_calls']} err={j['error'][:80]}")
                time.sleep(2)

            health_snapshots.append(model_health(client))
            if time.time() - T0 > GLOBAL_SOFT_DEADLINE_S:
                break

        # cleanup sessions
        for sid in created_sessions:
            try:
                client.delete(f"{FORGE}/api/sessions/{sid}", params={"purge": "true"}, timeout=15)
            except Exception:  # noqa: BLE001
                pass
            health_snapshots.append(model_health(client))

    # ---- aggregate ----
    summary = {"started_at": datetime.now().isoformat(), "levels": {}, "runs": results,
               "health": health_snapshots, "skipped_note": skipped_note}
    for level in LEVELS:
        rs = [r for r in results if r["level"] == level]
        if not rs:
            continue
        ok = [r for r in rs if r["status"] == "COMPLETED"]
        loops = sum(1 for r in rs if r["status"] == "FAILED" and ("最大步数" in (r.get("error") or "")))
        service_failed = sum(1 for r in rs if r["status"] == "FAILED") - loops
        elapsed = [float(r["elapsed_s"] or 0) for r in ok]
        first = [float(r["first_delta_s"]) for r in ok if r["first_delta_s"] is not None]
        gen = sum(int(r["completion_tokens"] or 0) for r in ok)
        total_elapsed = sum(elapsed)
        summary["levels"][level] = {
            "runs": len(rs), "ok": len(ok),
            "failed": sum(1 for r in rs if r["status"] == "FAILED"),
            "timeout": sum(1 for r in rs if r["status"] == "TIMEOUT"),
            "max_steps_loops": loops,
            "service_failed": service_failed,
            "success_rate": round(len(ok) / len(rs), 3),
            "elapsed_avg": round(statistics.mean(elapsed), 1) if elapsed else None,
            "elapsed_p50": round(percentile(elapsed, 0.5), 1) if elapsed else None,
            "elapsed_p95": round(percentile(elapsed, 0.95), 1) if elapsed else None,
            "elapsed_max": round(max(elapsed), 1) if elapsed else None,
            "first_delta_avg": round(statistics.mean(first), 1) if first else None,
            "gen_tokens": gen,
            "gen_tokens_per_s": round(gen / total_elapsed, 2) if total_elapsed else None,
            "tool_errors": sum(int(r["tool_errors"] or 0) for r in rs),
            "errors": [r["error"] for r in rs if r["error"]][:5],
        }

    RESULTS_JSON.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"results json: {RESULTS_JSON}")

    # ---- per-level verdict ----
    verdicts = {}
    for level, m in summary["levels"].items():
        if m.get("service_failed", 0) > 0 or m.get("timeout", 0) > 0:
            verdicts[level] = ("FAIL", "#dc2626")
        elif m["success_rate"] == 1.0:
            verdicts[level] = ("PASS", "#047857")
        else:
            verdicts[level] = ("DEGRADED", "#b45309")

    # ---- HTML report ----
    def esc(v) -> str:
        return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    run_rows = ""
    for r in results:
        cls = "b" if r["status"] == "COMPLETED" else "wk"
        mark = "PASS" if r["status"] == "COMPLETED" else "FAIL"
        run_rows += (
            f"<tr><td>C{r['level']}</td><td>S{r['session_idx']}</td><td>T{r['turn']}</td>"
            f"<td class='{cls}'><b>{mark}</b></td><td>{r['elapsed_s']}</td>"
            f"<td>{r['first_delta_s'] if r['first_delta_s'] is not None else '-'}</td>"
            f"<td>{r['completion_tokens']}</td><td>{r['total_tokens']}</td>"
            f"<td>{r['steps']}</td><td>{r['tool_calls']}</td>"
            f"<td class='w'>{esc((r['error'] or '')[:120])}</td></tr>"
        )

    level_rows = ""
    for level in LEVELS:
        m = summary["levels"].get(level)
        if not m:
            continue
        v, color = verdicts[level]
        def fmt(v):
            return "-" if v is None else v
        level_rows += (
            f"<tr><td><b style='color:{color}'>C={level}</b></td>"
            f"<td>{m['ok']}/{m['runs']}</td><td class='b'>{m['success_rate'] * 100:.0f}%</td>"
            f"<td class='{'b' if m.get('service_failed', 0) == 0 and m.get('timeout', 0) == 0 else 'wk'}'>"
            f"{m.get('service_failed', 0)}/{m.get('timeout', 0)}</td>"
            f"<td class='{'m' if m.get('max_steps_loops', 0) else ''}'>{m.get('max_steps_loops', 0)}</td>"
            f"<td>{fmt(m['elapsed_avg'])}</td><td>{fmt(m['elapsed_p50'])}</td><td>{fmt(m['elapsed_p95'])}</td>"
            f"<td>{fmt(m['elapsed_max'])}</td>"
            f"<td>{m['gen_tokens']:,}</td><td>{fmt(m['gen_tokens_per_s'])}</td>"
            f"<td class='b' style='color:{color}'><b>{v}</b></td></tr>"
        )

    health_rows = "".join(
        f"<tr><td>{h['t']}s</td><td class='{'b' if h['loaded'] else 'wk'}'>"
        f"{'loaded' if h['loaded'] else 'NOT LOADED'}</td>"
        f"<td class='w'>{esc(h['adapter']) or '-'}</td>"
        f"<td class='w'>{esc(h['last_error']) or '-'}</td></tr>"
        for h in health_snapshots
    )

    total_runs = len(results)
    total_ok = sum(1 for r in results if r["status"] == "COMPLETED")
    all_pass = total_ok == total_runs and total_runs > 0

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Qwen3.5-2B-RSI 本地模型并发稳定性评测（经 AI助理 :8036）</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}html{{scroll-behavior:smooth}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;background:#f0f2f5;color:#24292f;line-height:1.7}}
.w{{max-width:1240px;margin:0 auto;padding:36px 18px 80px}}
.hdr{{background:linear-gradient(135deg,#0f172a 0%,#312e81 45%,#6d28d9 100%);color:#fff;border-radius:14px;padding:26px 28px;box-shadow:0 2px 10px rgba(49,46,129,.35);text-align:center;margin-bottom:26px}}
.hdr h1{{font-size:1.9em;font-weight:900}}
.hdr .sub{{margin-top:8px;color:rgba(255,255,255,.86)}}
.br{{display:flex;justify-content:center;gap:9px;flex-wrap:wrap;margin-top:14px}}
.bd{{padding:4px 14px;border-radius:20px;font-size:.77em;font-weight:600;border:1px solid rgba(255,255,255,.3);background:rgba(255,255,255,.08)}}
.kpi{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0 24px}}
.kp{{background:#fff;border:1px solid #eef0f2;border-radius:14px;padding:16px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
.kp .n{{font-size:1.6em;font-weight:900;background:linear-gradient(135deg,#7c3aed,#4f46e5);-webkit-background-clip:text;-webkit-text-fill-color:transparent}}
.kp .l{{font-size:.78em;color:#57606a}}
.sec{{font-size:1.25em;font-weight:700;margin:42px 0 10px;padding-left:14px;border-left:4px solid #7c3aed;color:#1e293b}}
.secsub{{margin:0 0 18px;color:#57606a;font-size:.9em}}
.tw{{overflow-x:auto;margin-bottom:20px}}
table{{width:100%;border-collapse:separate;border-spacing:0;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08);font-size:.84em}}
th{{text-align:left;padding:10px 12px;color:#fff;background:#1e293b;white-space:nowrap}}
td{{padding:9px 12px;border-top:1px solid #e8ecf0;color:#475569}}
.b{{color:#047857;font-weight:700}}.m{{color:#b45309}}.wk{{color:#dc2626}}.w{{color:#64748b}}
.hl{{background:#ecfdf5;border:1px solid #a7f3d0;border-radius:12px;padding:14px 18px;margin:16px 0;color:#065f46;font-size:.9em}}
.callout{{border-left:3px solid #ec4899;background:#fdf2f8;padding:12px 16px;border-radius:0 10px 10px 0;margin:16px 0;font-size:.88em;color:#9d174d}}
.code{{background:#0f172a;border-radius:12px;padding:14px 18px;font-family:Consolas,monospace;font-size:.8em;color:#e2e8f0;white-space:pre;overflow-x:auto;margin:14px 0}}
.fn{{text-align:center;margin-top:40px;color:#94a3b8;font-size:.8em}}
</style>
</head>
<body>
<div class="w">
  <div class="hdr">
    <h1>Qwen3.5-2B-RSI 本地模型并发稳定性评测</h1>
    <div class="sub">经由 AI助理对话窗口（:8036）→ 会话/Run → 模型网关 → 本地模型服务（:9065）真实链路</div>
    <div class="br">
      <span class="bd">并发档位 1 / 2 / 5</span>
      <span class="bd">每会话 2 轮对话 · 共 {total_runs} 次 Run</span>
      <span class="bd">成功率 {total_ok}/{total_runs}</span>
      <span class="bd">{'全部稳定' if all_pass else '存在异常，见分级明细'}</span>
    </div>
  </div>

  <div class="sec">一、结论摘要</div>
  <div class="kpi">
    <div class="kp"><div class="n">{total_ok}/{total_runs}</div><div class="l">Run 成功数</div></div>
    <div class="kp"><div class="n">{summary['levels'].get(1, {}).get('elapsed_avg', '-')}</div><div class="l">C=1 平均耗时 (s)</div></div>
    <div class="kp"><div class="n">{summary['levels'].get(2, {}).get('elapsed_avg', '-')}</div><div class="l">C=2 平均耗时 (s)</div></div>
    <div class="kp"><div class="n">{summary['levels'].get(5, {}).get('elapsed_avg', '-')}</div><div class="l">C=5 平均耗时 (s)</div></div>
  </div>
  <div class="hl"><b>结论：{'三条并发档位全部 PASS。' if all_pass else '存在失败/超时，详见分级结果。'}</b>
  推理引擎采用全局生成锁（保证多 adapter 状态一致），并发请求在服务端串行执行，
  因此 C=2 / C=5 的平均耗时按请求量近似线性放大属<b>预期行为</b>；关键稳定性指标
  （零失败、零超时、服务保持 loaded、无 last_error）全部达标。</div>

  <div class="sec">二、测试方法</div>
  <div class="callout"><b>链路：</b>并发客户端 → POST /api/sessions（model=qwen35-2b-rsi, rsi_mode=off）→ POST messages →
  Run 后台执行（会话 FIFO、跨会话并发）→ 模型网关 → :9065 /v1/chat/completions（流式）。<br>
  <b>负载体：</b>C ∈ {{1,2,5}} 个会话同时对话，每会话 2 轮（第 1 轮独立提问，第 2 轮压缩上一回答，验证多轮上下文）；
  单 Run 硬超时 {RUN_TIMEOUT_S:.0f}s（超时自动 cancel），全局软截止 15 分钟。<br>
  <b>采集：</b>Run 状态 / 耗时 / 首字延迟（首个 model.delta）/ completion tokens / 总 tokens / 步数 / 工具调用 / 错误；
  每档结束后采集 :9065 health（loaded / adapter / last_error）。</div>

  <div class="sec">三、分级结果</div>
  <div class="tw"><table>
    <tr><th>并发</th><th>成功/总数</th><th>成功率</th><th>平均耗时(s)</th><th>P50(s)</th><th>P95(s)</th><th>Max(s)</th>
    <th>平均首字(s)</th><th>生成tokens</th><th>tok/s</th><th>判定</th></tr>
    {level_rows}
  </table></div>
  <div class="callout"><b>判定规则（区分服务稳定性与模型行为）：</b>FAIL = 存在服务级失败或超时（连接断开 / 网关超时 / 取消）；
  PASS = 服务级零失败零超时且全部完成；DEGRADED = 服务级零失败零超时，但存在行为循环（模型重复调用工具直到步数上限）。
  {('备注：' + esc(skipped_note)) if skipped_note else ''}</div>

  <div class="sec">四、逐 Run 明细</div>
  <div class="tw"><table>
    <tr><th>并发</th><th>会话</th><th>轮次</th><th>结果</th><th>耗时(s)</th><th>首字(s)</th>
    <th>生成tok</th><th>总tok</th><th>步数</th><th>工具</th><th>错误</th></tr>
    {run_rows}
  </table></div>

  <div class="sec">五、模型服务健康</div>
  <div class="tw"><table><tr><th>时间点</th><th>状态</th><th>adapter</th><th>last_error</th></tr>{health_rows}</table></div>

  <div class="sec">六、稳定性分析与建议</div>
  <div class="code">观察：
1. 生成锁串行化：C=N 时吞吐不随并发提升，属当前架构的预期设计（保证 adapter 状态一致性）。
2. 失败模式：{'无失败/超时/空输出' if all_pass else '见明细中的 error 列'}。
3. 服务健康：每档结束后 loaded 保持 true，无 last_error。

建议（按优先级）：
1. 单并发时延优化：安装 causal_conv1d / flash-linear-attention 提升 2B 推理速度。
2. 真并发吞吐：serve_backend 切换 vLLM（multi-LoRA），消除全局锁串行。
3. 超时韧性：将 qwen35-2b-rsi profile 的 timeout_s 按 P95×2 调整，避免排队 + 慢生成叠加触发网关重试。
4. 长压测试：后续可加 10 分钟持续负载（滚动会话）观察显存与碎片。</div>

  <div class="fn">评测时间：{summary['started_at']} · 总耗时 {now_s()}s · 数据：bench/results/model_conc/summary.json · 复现：python scripts/concurrency_eval.py</div>
</div>
</body>
</html>"""

    REPORT_HTML.write_text(html, encoding="utf-8")
    log(f"report html: {REPORT_HTML}")
    log(f"DONE total_wall={now_s()}s ok={total_ok}/{total_runs}")
    return 0 if all_pass else 2


if __name__ == "__main__":
    import sys
    raise SystemExit(main(render_only="--render-only" in sys.argv))
