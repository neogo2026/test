# -*- coding: utf-8 -*-
"""验证模型真实输出 <tool_call><function=...> 时能被解析为 OpenAI tool_calls。"""
import json
import httpx

BASE = "http://127.0.0.1:9065"
TOOLS = [{
    "type": "function",
    "function": {
        "name": "read_file",
        "description": "Read a text file and return its content.",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
}]
MESSAGES = [
    {"role": "system", "content": "You are a tool-calling agent. When the user asks to read a file, you MUST call the read_file tool. Do not answer in plain text."},
    {"role": "user", "content": "Read the file notes/a.py"},
]

r = httpx.post(f"{BASE}/v1/chat/completions", json={
    "model": "qwen3.5-2b-rsi", "messages": MESSAGES, "tools": TOOLS,
    "temperature": 0, "max_tokens": 120, "stream": False,
}, timeout=300)
print("status:", r.status_code)
data = r.json()
msg = data["choices"][0]["message"]
print("finish:", data["choices"][0]["finish_reason"], "| tool_calls:", len(msg.get("tool_calls") or []))
for call in msg.get("tool_calls") or []:
    args = json.loads(call["function"]["arguments"])
    ok_args = call["function"]["name"] == "read_file" and args.get("path") == "notes/a.py"
    print("  call:", call["function"]["name"], args, "| args_ok:", ok_args)
print("  text:", (msg.get("content") or "")[:200])
