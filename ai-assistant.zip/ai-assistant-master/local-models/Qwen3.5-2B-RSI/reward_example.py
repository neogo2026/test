"""示例奖励函数：配合 GRPO 使用。

仅用于有可执行校验的任务。生产请把 test_cmd / checks 接进来，
不要用「模型自己觉得好」作为奖励。
"""

from __future__ import annotations

import re


def reward(response: str, sample: dict) -> float:
    text = response or ""
    score = 0.0
    if len(text) >= 80:
        score += 0.2
    if "```" in text or re.search(r"\bdef\s+\w+", text):
        score += 0.3
    if any(word in text for word in ("验证", "测试", "pytest", "test")):
        score += 0.2
    checks = sample.get("checks") or {}
    for needle in checks.get("contains") or []:
        if needle in text:
            score += 0.15
    for needle in checks.get("not_contains") or []:
        if needle in text:
            score -= 0.3
    return max(0.0, min(1.0, score))
